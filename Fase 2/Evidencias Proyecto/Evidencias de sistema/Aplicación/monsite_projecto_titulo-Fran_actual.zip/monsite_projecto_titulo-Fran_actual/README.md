# monsite_projecto_titulo

Repositorio organizado en dos carpetas principales:

- `01-documentacion/`: documentación funcional y técnica del proyecto.
- `02-desarrollo/`: código fuente completo (frontend, backend, scripts y configuración de deploy).

## Cómo trabajar

1. Entrar a la carpeta de desarrollo:
   - `cd 02-desarrollo`
2. Instalar dependencias:
   - `npm --prefix backend install`
3. Copiar variables de entorno:
   - `cp backend/.env.example backend/.env` (o crear manualmente en Windows)
4. Levantar entorno local:
   - `npm run start:clean`

## Deploy hosting

Desde `02-desarrollo/`:

- `npm run stamp && npm run validate` (versiona los `.js`/`.css` por contenido; ver `01-documentacion/docs/DEVELOPMENT_WORKFLOW.md`)
- `firebase deploy --only hosting --project monsite-85424`
- Reglas de Firestore: `firebase deploy --only firestore:rules --project monsite-85424`

El backend (`02-desarrollo/backend`) corre en Cloud Run: sus cambios **no** se publican con `firebase deploy`.

## Seguridad

- Nunca subir secretos reales (`.env`, `service-account*.json`, configs locales de Firebase/pagos).
- Ejecutar antes de cada PR:
  - `cd 02-desarrollo`
  - `npm run security:scan`
