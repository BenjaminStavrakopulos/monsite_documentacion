// stamp-assets.js - Pone en cada <script> y <link> local un ?v= que depende del CONTENIDO del archivo.
//
// Firebase Hosting sirve los .js y .css con "Cache-Control: public, max-age=31536000, immutable" (1 año).
// Si un archivo cambia pero su URL queda igual, los navegadores que ya lo descargaron nunca ven el cambio.
// Con la versión calculada a partir del contenido, la URL cambia sola cuando el archivo cambia.
//
// Uso (desde 02-desarrollo/):
//   npm run stamp         actualiza los ?v= de todos los HTML (ejecutar antes de cada deploy)
//   npm run stamp:check   solo revisa (falla si falta o está desactualizado algún ?v=); lo usa "npm run validate"
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const ignoredDirectories = new Set(['node_modules', 'load-tests', 'backend', 'media-worker', 'scripts', 'data', 'images', 'videos-originales', 'preview-videos']);
const checkOnly = process.argv.includes('--check');

function listHtmlFiles(directory) {
    return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
        const fullPath = path.join(directory, entry.name);
        if (entry.isDirectory()) {
            return entry.name.startsWith('.') || ignoredDirectories.has(entry.name) ? [] : listHtmlFiles(fullPath);
        }
        // Los bocetos preview-* no se publican (están en .gitignore y en el "ignore" de firebase.json)
        return entry.isFile() && entry.name.endsWith('.html') && !entry.name.startsWith('preview-') ? [fullPath] : [];
    });
}

// El hash ignora el tipo de salto de línea: no cambia entre Windows (CRLF) y Linux/macOS (LF)
function contentVersion(filePath) {
    const normalized = fs.readFileSync(filePath, 'utf8').replace(/\r\n/g, '\n');
    return crypto.createHash('sha1').update(normalized).digest('hex').slice(0, 10);
}

function isLocalAsset(reference) {
    if (/^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(reference)) return false;
    return /\.(?:js|css)(?:[?#].*)?$/i.test(reference);
}

function wantsVersion(tag) {
    if (/^<script\b/i.test(tag)) return true;
    const rel = (tag.match(/\brel=["']([^"']+)["']/i) || [])[1] || '';
    return /\b(?:stylesheet|preload|modulepreload)\b/i.test(rel);
}

function stampHtml(htmlFile) {
    const original = fs.readFileSync(htmlFile, 'utf8');
    const problems = [];

    const stamped = original.replace(/<(?:script|link)\b[^>]*>/gi, (tag) => {
        if (!wantsVersion(tag)) return tag;

        return tag.replace(/\b(src|href)=(["'])([^"']+)\2/i, (match, attribute, quote, reference) => {
            if (!isLocalAsset(reference)) return match;

            const cleanReference = reference.split(/[?#]/)[0];
            const assetPath = path.resolve(path.dirname(htmlFile), cleanReference);
            if (!fs.existsSync(assetPath)) {
                problems.push(`${path.relative(projectRoot, htmlFile)}: no existe ${reference}`);
                return match;
            }

            const expected = `${cleanReference}?v=${contentVersion(assetPath)}`;
            if (expected !== reference) {
                problems.push(`${path.relative(projectRoot, htmlFile)}: ${reference} -> ${expected}`);
            }
            return `${attribute}=${quote}${expected}${quote}`;
        });
    });

    return { original, stamped, problems };
}

function run() {
    let changedFiles = 0;
    const allProblems = [];

    for (const htmlFile of listHtmlFiles(projectRoot)) {
        const { original, stamped, problems } = stampHtml(htmlFile);
        allProblems.push(...problems);
        if (stamped !== original) {
            changedFiles += 1;
            if (!checkOnly) fs.writeFileSync(htmlFile, stamped, 'utf8');
        }
    }

    if (checkOnly) {
        if (allProblems.length > 0) {
            console.error('Versiones de assets desactualizadas o ausentes (ejecuta "npm run stamp"):');
            allProblems.forEach((problem) => console.error(` - ${problem}`));
            process.exit(1);
        }
        console.log('Versiones de assets OK: cada <script>/<link> local tiene el ?v= de su contenido.');
        return;
    }

    const missing = allProblems.filter((problem) => problem.includes(': no existe '));
    if (missing.length > 0) {
        console.error('Referencias a archivos que no existen:');
        missing.forEach((problem) => console.error(` - ${problem}`));
        process.exit(1);
    }

    console.log(changedFiles === 0
        ? 'Los ?v= ya estaban al día: no se modificó ningún HTML.'
        : `Se actualizaron los ?v= en ${changedFiles} archivo(s) HTML.`);
}

run();
