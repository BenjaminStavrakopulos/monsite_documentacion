const nodemailer = require('nodemailer');
const { trackingUrl, courierInfo } = require('../lib/order-tracking');

// Correos al cliente: boleta al confirmar el pago y aviso en cada cambio de estado.
// Plantillas en tablas con estilos en línea (lo único que respetan Gmail/Outlook).

function isEnabled() {
  return Boolean(
    process.env.SMTP_HOST
      && process.env.SMTP_PORT
      && process.env.SMTP_USER
      && process.env.SMTP_PASSWORD
      && process.env.EMAIL_FROM
  );
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatCLP(value) {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    maximumFractionDigits: 0
  }).format(Number(value) || 0);
}

function formatDate(value) {
  const date = new Date(value || Date.now());
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleString('es-CL', {
    timeZone: 'America/Santiago',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function formatRut(rut) {
  const clean = String(rut || '').replace(/[^0-9kK]/g, '');
  if (clean.length < 2) return String(rut || '');
  const body = clean.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${body}-${clean.slice(-1).toUpperCase()}`;
}

let transporter = null;
function getTransporter() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: String(process.env.SMTP_SECURE).toLowerCase() === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
      },
      // Un servidor SMTP lento no debe dejar colgado el pago ni el aviso de Mercado Pago
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 30000
    });
  }
  return transporter;
}

function getOrderEmail(order) {
  return String(order?.shippingData?.email || order?.userEmail || '').trim();
}

function getSiteUrl() {
  return String(process.env.FRONTEND_URL || 'https://monsite-85424.web.app').replace(/\/+$/, '');
}

// Número de orden que ve el cliente: el corto (MO-4827-1936) si existe
function getOrderId(order) {
  return String(order?.trackingCode || order?.id || order?.firestoreDocId || '');
}

function getTotals(order) {
  const items = Array.isArray(order?.items) ? order.items : [];
  const totals = order?.totals || {};
  const subtotal = Number(totals.subtotal) || items.reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 0), 0);
  const shipping = Number(totals.shipping) || 0;
  const discount = Number(totals.discount) || 0;
  const total = Number(totals.total) || subtotal + shipping - discount;
  return { subtotal, shipping, discount, total };
}

const PAYMENT_METHODS = { mercado_pago: 'Mercado Pago', transbank_webpay: 'Webpay' };

// Textos de cada correo
const TEMPLATES = {
  confirmation: {
    subject: id => `¡Recibimos tu pedido! Boleta #${id}`,
    preheader: 'Tu pago fue confirmado. Aquí está tu boleta y el estado de tu pedido.',
    eyebrow: 'Pedido confirmado',
    title: name => (name ? `¡Gracias por tu compra, ${name}!` : '¡Gracias por tu compra!'),
    body: 'Tu pago fue confirmado y ya estamos preparando tu pedido. Te escribiremos de nuevo cuando vaya en camino.',
    step: 0
  },
  shipped: {
    subject: id => `Tu pedido #${id} va en camino`,
    preheader: 'Tu pedido ya salió y va rumbo a tu dirección.',
    eyebrow: 'Pedido enviado',
    title: name => (name ? `${name}, tu pedido va en camino` : 'Tu pedido va en camino'),
    body: 'Ya despachamos tu pedido. Pronto llegará a la dirección que indicaste; asegúrate de que alguien pueda recibirlo.',
    step: 1
  },
  delivered: {
    subject: id => `Tu pedido #${id} fue entregado`,
    preheader: 'Tu pedido llegó. ¡Esperamos que lo disfrutes!',
    eyebrow: 'Pedido entregado',
    title: name => (name ? `¡Tu pedido llegó, ${name}!` : '¡Tu pedido llegó!'),
    body: 'Registramos la entrega de tu pedido. Esperamos que disfrutes tus productos; si algo no está bien, respóndenos este correo.',
    step: 2
  },
  refunded: {
    subject: id => `Devolución de tu pedido #${id}`,
    preheader: 'Procesamos la devolución de tu pedido.',
    eyebrow: 'Devolución procesada',
    title: () => 'Procesamos tu devolución',
    body: 'Registramos la devolución de tu pedido y el reembolso del pago. Según tu banco o medio de pago, el monto puede tardar algunos días hábiles en verse reflejado.',
    step: -1
  },
  cancelled: {
    subject: id => `Tu pedido #${id} fue cancelado`,
    preheader: 'Tu pedido fue cancelado.',
    eyebrow: 'Pedido cancelado',
    title: () => 'Tu pedido fue cancelado',
    body: 'Tu pedido fue cancelado. Si se realizó un cobro, lo reembolsaremos al mismo medio de pago. Si no solicitaste esta cancelación, respóndenos este correo y lo revisamos.',
    step: -1
  }
};

function renderTracker(step) {
  if (step < 0) return '';
  // Barra segmentada: cada tramo en negro cuando la etapa ya ocurrió
  const steps = ['Pago confirmado', 'Enviado', 'Entregado'];
  const cells = steps.map((label, index) => {
    const done = index <= step;
    return `<td width="33%" valign="top" style="padding:0 4px;">
        <div style="height:4px;border-radius:4px;background:${done ? '#111111' : '#e5e5e5'};font-size:0;line-height:0;">&nbsp;</div>
        <div style="margin-top:8px;font-size:12px;line-height:1.3;color:${done ? '#111111' : '#999999'};font-weight:${done ? '700' : '400'};">${done ? '&#10003; ' : ''}${label}</div>
      </td>`;
  }).join('');
  return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>${cells}</tr></table>`;
}

function renderItems(order) {
  const items = Array.isArray(order?.items) ? order.items : [];
  return items.map(item => {
    const quantity = Number(item.quantity) || 0;
    const price = Number(item.price) || 0;
    const image = /^https:\/\//.test(String(item.image || '')) ? item.image : '';
    return `<tr>
      <td width="56" valign="middle" style="padding:12px 0;border-bottom:1px solid #f0f0f0;">
        ${image
          ? `<img src="${escapeHtml(image)}" width="48" height="48" alt="" style="display:block;width:48px;height:48px;object-fit:contain;border:1px solid #eeeeee;border-radius:8px;background:#ffffff;">`
          : '<div style="width:48px;height:48px;border-radius:8px;background:#f5f5f5;"></div>'}
      </td>
      <td valign="middle" style="padding:12px 12px;border-bottom:1px solid #f0f0f0;font-size:14px;line-height:1.35;color:#111111;">
        ${escapeHtml(item.name || 'Producto')}
        <div style="font-size:12px;color:#888888;margin-top:2px;">${quantity} × ${formatCLP(price)}</div>
      </td>
      <td valign="middle" align="right" style="padding:12px 0;border-bottom:1px solid #f0f0f0;font-size:14px;font-weight:700;color:#111111;white-space:nowrap;">${formatCLP(price * quantity)}</td>
    </tr>`;
  }).join('');
}

function totalRow(label, value, { strong = false, color = '#555555' } = {}) {
  return `<tr>
    <td style="padding:${strong ? '12px 0 0' : '4px 0'};font-size:${strong ? '16px' : '14px'};color:${strong ? '#111111' : color};font-weight:${strong ? '700' : '400'};${strong ? 'border-top:1px solid #111111;' : ''}">${label}</td>
    <td align="right" style="padding:${strong ? '12px 0 0' : '4px 0'};font-size:${strong ? '18px' : '14px'};color:${strong ? '#111111' : color};font-weight:${strong ? '700' : '400'};white-space:nowrap;${strong ? 'border-top:1px solid #111111;' : ''}">${value}</td>
  </tr>`;
}

function buildOrderEmail(order, kind = 'confirmation') {
  const template = TEMPLATES[kind] || TEMPLATES.confirmation;
  const id = getOrderId(order);
  const shipping = order?.shippingData || {};
  const firstName = String(shipping.firstName || '').trim();
  const totals = getTotals(order);
  const site = getSiteUrl();
  const address = [shipping.street, shipping.apartment].filter(Boolean).join(', ');
  const place = [shipping.city, String(shipping.region || '').replace(/^Region/, 'Región')].filter(Boolean).join(', ');
  const paymentMethod = PAYMENT_METHODS[String(order?.paymentMethod || '').toLowerCase()] || '';
  const isGuest = Boolean(order?.guestCheckout);
  // "Seguir mi pedido" abre el seguimiento con un enlace firmado (sirve también sin cuenta)
  const followUrl = trackingUrl(site, order);
  const ctaUrl = followUrl || (isGuest ? `${site}/products.html` : `${site}/my-orders.html`);
  const ctaLabel = followUrl ? 'Seguir mi pedido' : (isGuest ? 'Visitar la tienda' : 'Ver mi pedido');
  const isReceipt = kind === 'confirmation';
  // Solo en "enviado" y solo si el admin puso el N° de Starken
  const courier = kind === 'shipped' ? courierInfo(order) : null;

  const html = `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light">
<title>${escapeHtml(template.subject(id))}</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:'Segoe UI',Helvetica,Arial,sans-serif;color:#111111;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(template.preheader)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f4f4;">
<tr><td align="center" style="padding:28px 12px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#ffffff;border:1px solid #e8e8e8;border-radius:16px;">

    <tr><td style="padding:28px 32px 0;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
        <td valign="middle"><img src="${site}/images/logo.jpg" width="40" height="40" alt="Monsite" style="display:inline-block;vertical-align:middle;border-radius:8px;"><span style="display:inline-block;vertical-align:middle;margin-left:10px;font-size:16px;font-weight:700;letter-spacing:.06em;">MONSITE</span></td>
        <td align="right" valign="middle" style="font-size:12px;color:#888888;">Orden #${escapeHtml(id)}</td>
      </tr></table>
    </td></tr>

    <tr><td style="padding:32px 32px 8px;">
      <div style="font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#888888;">${escapeHtml(template.eyebrow)}</div>
      <h1 style="margin:6px 0 12px;font-size:24px;line-height:1.25;color:#111111;">${escapeHtml(template.title(firstName))}</h1>
      <p style="margin:0;font-size:15px;line-height:1.6;color:#555555;">${escapeHtml(template.body)}</p>
    </td></tr>

    ${template.step >= 0 ? `<tr><td style="padding:20px 28px 4px;">${renderTracker(template.step)}</td></tr>` : ''}

    ${courier ? `<tr><td style="padding:20px 32px 0;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fafafa;border:1px solid #eeeeee;border-radius:12px;">
        <tr><td style="padding:16px 18px;font-size:14px;line-height:1.55;color:#444444;">
          <div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#888888;margin-bottom:4px;">Enviado por ${escapeHtml(courier.name)}</div>
          N° de seguimiento: <strong style="color:#111111;letter-spacing:.03em;">${escapeHtml(courier.code)}</strong><br>
          <a href="${escapeHtml(courier.url)}" style="display:inline-block;margin-top:10px;padding:9px 18px;border-radius:999px;border:1px solid #111111;color:#111111;font-size:13px;font-weight:700;text-decoration:none;">Seguir mi envío en ${escapeHtml(courier.name)}</a>
        </td></tr>
      </table>
    </td></tr>` : ''}

    <tr><td align="center" style="padding:20px 32px 8px;">
      <a href="${ctaUrl}" style="display:inline-block;padding:13px 28px;border-radius:999px;background:#111111;color:#ffffff;font-size:14px;font-weight:700;text-decoration:none;">${ctaLabel}</a>
    </td></tr>

    <tr><td style="padding:24px 32px 0;">
      <div style="font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#888888;padding-bottom:4px;border-bottom:1px solid #e8e8e8;">${isReceipt ? 'Boleta de compra' : 'Resumen del pedido'}</div>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">${renderItems(order)}</table>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:12px;">
        ${totalRow('Subtotal', formatCLP(totals.subtotal))}
        ${totalRow('Envío', totals.shipping > 0 ? formatCLP(totals.shipping) : 'Gratis')}
        ${totals.discount > 0 ? totalRow(`Descuento${order?.discountCode ? ` (${escapeHtml(order.discountCode)})` : ''}`, `−${formatCLP(totals.discount)}`, { color: '#15803d' }) : ''}
        ${totalRow('Total', formatCLP(totals.total), { strong: true })}
      </table>
    </td></tr>

    <tr><td style="padding:28px 32px 8px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#fafafa;border-radius:12px;">
        <tr>
          <td width="50%" valign="top" style="padding:16px 18px;font-size:13px;line-height:1.55;color:#444444;">
            <div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#888888;margin-bottom:6px;">Despacho</div>
            <strong style="color:#111111;">${escapeHtml(`${shipping.firstName || ''} ${shipping.lastName || ''}`.trim() || 'Cliente')}</strong><br>
            ${escapeHtml(address)}${address ? '<br>' : ''}${escapeHtml(place)}
          </td>
          <td width="50%" valign="top" style="padding:16px 18px;font-size:13px;line-height:1.55;color:#444444;">
            <div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#888888;margin-bottom:6px;">Pago</div>
            ${escapeHtml(formatDate(order?.paymentDate || order?.createdAt))}<br>
            ${paymentMethod ? `${escapeHtml(paymentMethod)}<br>` : ''}
            ${shipping.rut ? `RUT ${escapeHtml(formatRut(shipping.rut))}` : ''}
            ${order?.billing?.documentType === 'factura' ? `<br><strong style="color:#111111;">Factura</strong> para ${escapeHtml(order.billing.businessName || '')}<br>RUT ${escapeHtml(order.billing.rut || '')}` : ''}
          </td>
        </tr>
      </table>
    </td></tr>

    <tr><td style="padding:24px 32px 28px;font-size:12px;line-height:1.6;color:#888888;text-align:center;">
      ¿Dudas con tu pedido? Responde este correo o escríbenos a Instagram <a href="https://www.instagram.com/monsitechile" style="color:#111111;">@monsitechile</a>.<br>
      Monsite · Vitacura 9540, Santiago
    </td></tr>
  </table>
</td></tr>
</table>
</body>
</html>`;

  const itemsText = (Array.isArray(order?.items) ? order.items : [])
    .map(item => `- ${item.name || 'Producto'} x${Number(item.quantity) || 0}: ${formatCLP((Number(item.price) || 0) * (Number(item.quantity) || 0))}`)
    .join('\n');
  const text = [
    template.title(firstName),
    '',
    template.body,
    '',
    `Orden #${id}`,
    itemsText,
    `Subtotal: ${formatCLP(totals.subtotal)}`,
    `Envío: ${totals.shipping > 0 ? formatCLP(totals.shipping) : 'Gratis'}`,
    totals.discount > 0 ? `Descuento: -${formatCLP(totals.discount)}` : '',
    `Total: ${formatCLP(totals.total)}`,
    '',
    courier ? `Enviado por ${courier.name}. N° de seguimiento: ${courier.code}\nSeguir en ${courier.name}: ${courier.url}\n` : null,
    `${ctaLabel}: ${ctaUrl}`
  ].filter(line => line !== null).join('\n');

  return { subject: template.subject(id), html, text };
}

// Compatibilidad con código anterior
function buildReceiptHtml(order) {
  return buildOrderEmail(order, 'confirmation').html;
}

async function sendOrderEmail(order, kind) {
  const to = getOrderEmail(order);
  if (!isEnabled() || !to) return false;
  const { subject, html, text } = buildOrderEmail(order, kind);
  await getTransporter().sendMail({
    from: process.env.EMAIL_FROM,
    to,
    replyTo: process.env.EMAIL_REPLY_TO || undefined,
    subject,
    html,
    text
  });
  return true;
}

async function sendReceiptEmail(order) {
  return sendOrderEmail(order, 'confirmation');
}

async function sendStatusEmail(order, status) {
  const kind = status === 'paid' ? 'confirmation' : status;
  if (!TEMPLATES[kind]) return false;
  return sendOrderEmail(order, kind);
}

// ---------- Correos de la cuenta (confirmar correo, nueva contraseña) ----------
// Los envía la tienda (no Firebase): el enlace lleva el código de Firebase a auth-action.html.
const ACCOUNT_TEMPLATES = {
  verify: {
    subject: 'Confirma tu correo para activar tu cuenta Monsite',
    preheader: 'Un clic y tu cuenta queda lista.',
    title: name => (name ? `Hola ${name}, confirma tu correo` : 'Confirma tu correo'),
    body: 'Creaste una cuenta en Monsite con este correo. Para activarla y poder iniciar sesión, confirma que el correo es tuyo:',
    cta: 'Confirmar mi correo',
    footer: 'Si no creaste esta cuenta, ignora este mensaje: sin la confirmación la cuenta no se activa.'
  },
  reset: {
    subject: 'Crea una nueva contraseña para tu cuenta Monsite',
    preheader: 'Pediste cambiar tu contraseña.',
    title: () => 'Crea una nueva contraseña',
    body: 'Recibimos una solicitud para cambiar la contraseña de tu cuenta Monsite. Presiona el botón para crear una nueva:',
    cta: 'Crear nueva contraseña',
    footer: 'Si no lo pediste, ignora este correo: tu contraseña actual sigue funcionando. El enlace vence en 1 hora.'
  }
};

function buildAccountEmail(kind, { link, name } = {}) {
  const t = ACCOUNT_TEMPLATES[kind];
  const site = getSiteUrl();
  const firstName = String(name || '').trim().split(/\s+/)[0] || '';
  const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light"><title>${escapeHtml(t.subject)}</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:'Segoe UI',Helvetica,Arial,sans-serif;color:#111111;">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;">${escapeHtml(t.preheader)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f4f4f4;"><tr><td align="center" style="padding:28px 12px;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#ffffff;border:1px solid #e8e8e8;border-radius:16px;">
    <tr><td style="padding:28px 32px 0;"><img src="${site}/images/logo.jpg" width="40" height="40" alt="Monsite" style="display:inline-block;vertical-align:middle;border-radius:8px;"><span style="display:inline-block;vertical-align:middle;margin-left:10px;font-size:16px;font-weight:700;letter-spacing:.06em;">MONSITE</span></td></tr>
    <tr><td style="padding:28px 32px 8px;">
      <h1 style="margin:0 0 12px;font-size:22px;line-height:1.3;color:#111111;">${escapeHtml(t.title(firstName))}</h1>
      <p style="margin:0;font-size:15px;line-height:1.6;color:#555555;">${escapeHtml(t.body)}</p>
    </td></tr>
    <tr><td align="center" style="padding:24px 32px;">
      <a href="${escapeHtml(link)}" style="display:inline-block;padding:14px 30px;border-radius:999px;background:#111111;color:#ffffff;font-size:15px;font-weight:700;text-decoration:none;">${escapeHtml(t.cta)}</a>
    </td></tr>
    <tr><td style="padding:0 32px 8px;font-size:12px;line-height:1.6;color:#888888;">Si el botón no funciona, copia este enlace en tu navegador:<br><a href="${escapeHtml(link)}" style="color:#555555;word-break:break-all;">${escapeHtml(link)}</a></td></tr>
    <tr><td style="padding:16px 32px 28px;font-size:12px;line-height:1.6;color:#888888;border-top:1px solid #f0f0f0;">${escapeHtml(t.footer)}<br>Monsite · Vitacura 9540, Santiago</td></tr>
  </table>
</td></tr></table>
</body></html>`;
  const text = `${t.title(firstName)}

${t.body}
${link}

${t.footer}`;
  return { subject: t.subject, html, text };
}

async function sendAccountEmail(to, kind, data) {
  if (!isEnabled() || !to || !ACCOUNT_TEMPLATES[kind]) return false;
  const { subject, html, text } = buildAccountEmail(kind, data);
  await getTransporter().sendMail({
    from: process.env.EMAIL_FROM,
    to,
    replyTo: process.env.EMAIL_REPLY_TO || undefined,
    subject,
    html,
    text
  });
  return true;
}

module.exports = { buildOrderEmail, buildReceiptHtml, buildAccountEmail, isEnabled, sendReceiptEmail, sendStatusEmail, sendAccountEmail, getSiteUrl };
