// routes/account.js - Validaciones previas a crear una cuenta.
// POST /api/account/email-check: revisa que el dominio del correo reciba correos (registros MX).
// Así "ana@gmial.cm" o "x@dominioinventado.cl" se detectan antes de crear la cuenta; que la casilla
// exista de verdad se confirma después con el enlace de verificación que envía Firebase.
const dns = require('dns').promises;
const express = require('express');
const { createLimiter, createRecipientThrottle } = require('../lib/rate-limit');
const { getAuthAdminSafe, verifyIdTokenSafe } = require('../lib/firebase-admin');
const emailService = require('../services/email');

const router = express.Router();
// Respaldo si el resolvedor del sistema no responde
const publicResolver = new dns.Resolver({ timeout: 3000, tries: 1 });
publicResolver.setServers(['8.8.8.8', '1.1.1.1']);
const CACHE_TTL_MS = 60 * 60 * 1000;
const cache = new Map(); // dominio -> { deliverable, at }

const emailCheckLimiter = createLimiter({
    windowMs: 10 * 60 * 1000,
    max: 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Demasiadas verificaciones seguidas. Espera unos minutos.' }
});

const withTimeout = (promise, ms) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error('timeout'), { code: 'ETIMEOUT' })), ms))
]);

async function domainReceivesMail(domain) {
    const cached = cache.get(domain);
    if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.deliverable;
    let deliverable;
    try {
        let records;
        try {
            records = await withTimeout(dns.resolveMx(domain), 4000);
        } catch (systemError) {
            if (['ENOTFOUND', 'ENODATA', 'ENONAME', 'NXDOMAIN'].includes(systemError.code)) throw systemError;
            records = await withTimeout(publicResolver.resolveMx(domain), 4000);
        }
        // Un MX "nulo" (prioridad 0 y destino vacío) significa que el dominio no acepta correos
        deliverable = records.some(record => record.exchange && record.exchange !== '.');
    } catch (error) {
        if (['ENOTFOUND', 'ENODATA', 'ENONAME', 'NXDOMAIN'].includes(error.code)) {
            deliverable = false;
        } else {
            // Falla temporal del DNS: no se bloquea a la persona (la verificación por correo es la garantía final)
            return null;
        }
    }
    cache.set(domain, { deliverable, at: Date.now() });
    if (cache.size > 2000) cache.delete(cache.keys().next().value);
    return deliverable;
}

router.post('/email-check', emailCheckLimiter, async (req, res) => {
    const email = String(req.body?.email || '').trim().toLowerCase().slice(0, 254);
    const match = /^[a-z0-9._%+-]+@([a-z0-9-]+(?:\.[a-z0-9-]+)+)$/.exec(email);
    if (!match) return res.json({ deliverable: false, reason: 'format' });
    const deliverable = await domainReceivesMail(match[1]);
    if (deliverable === null) return res.json({ deliverable: true, reason: 'unverified' });
    return res.json({ deliverable, reason: deliverable ? 'ok' : 'domain' });
});

// ---------- Correos de la cuenta enviados por la tienda ----------
// Firebase genera el código de seguridad (oobCode) y la tienda arma el enlace hacia su propia
// página (auth-action.html) y envía el correo con su diseño y su remitente. Así no dependemos de
// la "URL de acción" de las plantillas de Firebase.
const accountEmailLimiter = createLimiter({
    windowMs: 15 * 60 * 1000,
    max: 6,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Pediste demasiados correos seguidos. Espera unos minutos e inténtalo de nuevo.' }
});

// Aunque alguien rote IPs, una misma dirección no recibe más de 3 correos de la cuenta por hora
const allowAccountEmailTo = createRecipientThrottle({ windowMs: 60 * 60 * 1000, max: 3 });

function actionLink(firebaseLink, mode) {
    const code = new URL(firebaseLink).searchParams.get('oobCode');
    if (!code) throw new Error('Firebase no devolvió el código');
    return `${emailService.getSiteUrl()}/auth-action.html?mode=${mode}&oobCode=${encodeURIComponent(code)}`;
}

const continueSettings = () => ({ url: `${emailService.getSiteUrl()}/login.html` });

// Confirmación de correo: la pide la propia cuenta recién creada (o al intentar ingresar sin confirmar)
router.post('/send-verification', accountEmailLimiter, async (req, res) => {
    try {
        const match = String(req.get('authorization') || '').match(/^Bearer\s+(.+)$/i);
        const decoded = match ? await verifyIdTokenSafe(match[1].trim()) : null;
        if (!decoded?.uid || !decoded.email) return res.status(401).json({ error: 'Sesión inválida o expirada' });
        if (decoded.email_verified) return res.json({ sent: false, reason: 'already_verified' });

        const auth = getAuthAdminSafe();
        if (!auth || !emailService.isEnabled()) return res.status(503).json({ error: 'El envío de correos no está disponible' });
        if (!allowAccountEmailTo(decoded.email)) {
            return res.status(429).json({ error: 'Ya te enviamos varios correos. Revisa tu bandeja (y spam) o inténtalo en una hora.' });
        }
        const user = await auth.getUser(decoded.uid);
        const link = actionLink(await auth.generateEmailVerificationLink(user.email, continueSettings()), 'verifyEmail');
        await emailService.sendAccountEmail(user.email, 'verify', { link, name: user.displayName });
        return res.json({ sent: true });
    } catch (error) {
        console.error('Error enviando confirmación de correo:', error.code || error.message);
        return res.status(500).json({ error: 'No se pudo enviar el correo de confirmación' });
    }
});

// Nueva contraseña: misma respuesta, y en un tiempo mínimo fijo, exista o no la cuenta (no revela
// quién está registrado). El envío se hace antes de responder: en Cloud Run el trabajo posterior a
// la respuesta puede quedar sin CPU.
const PASSWORD_RESET_MIN_RESPONSE_MS = 1500;

router.post('/password-reset', accountEmailLimiter, async (req, res) => {
    const startedAt = Date.now();
    const email = String(req.body?.email || '').trim().toLowerCase().slice(0, 254);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Correo inválido' });
    const auth = getAuthAdminSafe();
    if (!auth || !emailService.isEnabled()) return res.status(503).json({ error: 'El envío de correos no está disponible' });

    if (allowAccountEmailTo(email)) {
        try {
            const user = await auth.getUserByEmail(email);
            const link = actionLink(await auth.generatePasswordResetLink(email, continueSettings()), 'resetPassword');
            await emailService.sendAccountEmail(email, 'reset', { link, name: user.displayName });
        } catch (error) {
            if (error.code !== 'auth/user-not-found') {
                console.error('Error enviando nueva contraseña:', error.code || error.message);
            }
        }
    }

    const wait = PASSWORD_RESET_MIN_RESPONSE_MS - (Date.now() - startedAt);
    if (wait > 0) await new Promise(resolve => setTimeout(resolve, wait));
    return res.json({ ok: true });
});

module.exports = router;
