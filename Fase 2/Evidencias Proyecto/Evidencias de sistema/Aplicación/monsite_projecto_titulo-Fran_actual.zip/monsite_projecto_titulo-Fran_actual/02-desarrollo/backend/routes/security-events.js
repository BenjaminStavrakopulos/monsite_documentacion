const express = require('express');
const router = express.Router();
const requireAdmin = require('../middleware/require-admin');
const admin = require('firebase-admin');
const { getFirestoreAdminSafe } = require('../lib/firebase-admin');

// Cursor opaco para "cargar más": timestamp + id del último evento mostrado.
function encodeCursor(event) {
    return Buffer.from(JSON.stringify({ t: event.timestamp, id: event.id })).toString('base64url');
}

function decodeCursor(value) {
    try {
        const parsed = JSON.parse(Buffer.from(String(value || ''), 'base64url').toString('utf8'));
        if (typeof parsed?.t === 'string' && typeof parsed?.id === 'string' && parsed.id.length <= 100) return parsed;
    } catch (_) { /* cursor inválido: se ignora */ }
    return null;
}

router.get('/', requireAdmin, async (req, res) => {
    try {
        const db = getFirestoreAdminSafe();
        if (!db) return res.status(503).json({ error: 'Firestore no disponible' });

        const requestedLimit = Number.parseInt(req.query.limit, 10);
        const limit = Number.isInteger(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 100) : 15;
        const category = String(req.query.category || '').trim();
        const cursor = decodeCursor(req.query.cursor);

        let query = db.collection('securityEvents');
        if (['unauthorized', 'forbidden', 'rate_limited', 'server_error'].includes(category)) {
            query = query.where('category', '==', category);
        }
        query = query.orderBy('timestamp', 'desc').orderBy(admin.firestore.FieldPath.documentId(), 'desc');
        if (cursor) query = query.startAfter(cursor.t, cursor.id);
        // Se pide uno extra para saber si hay más páginas
        const snapshot = await query.limit(limit + 1).get();
        const pageDocs = snapshot.docs.slice(0, limit);
        const hasMore = snapshot.docs.length > limit;

        // El resumen solo se calcula en la primera página
        if (cursor) {
            const events = pageDocs.map(toPublicEvent);
            return res.json({ events, nextCursor: hasMore && events.length ? encodeCursor(events[events.length - 1]) : null });
        }

        const recentSnapshot = await db.collection('securityEvents')
            .where('timestamp', '>=', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
            .orderBy('timestamp', 'desc')
            .limit(500)
            .get();
        const recentEvents = recentSnapshot.docs.map((eventDoc) => eventDoc.data() || {});
        const countBy = (field) => recentEvents.reduce((counts, event) => {
            const value = String(event[field] || 'unknown');
            counts[value] = (counts[value] || 0) + 1;
            return counts;
        }, {});
        const uniqueIps = new Set(recentEvents.map(event => event.ipHash).filter(Boolean));
        const uniqueUsers = new Set(recentEvents.map(event => event.userIdHash).filter(Boolean));
        const events = pageDocs.map(toPublicEvent);

        return res.json({
            events,
            nextCursor: hasMore && events.length ? encodeCursor(events[events.length - 1]) : null,
            summary: {
                last24h: recentEvents.length,
                attacks: recentEvents.length,
                blocked: recentEvents.filter(event => event.blocked !== false).length,
                notBlocked: recentEvents.filter(event => event.blocked === false).length,
                suspiciousIps: uniqueIps.size,
                affectedUsers: uniqueUsers.size,
                byCategory: countBy('category'),
                bySeverity: countBy('severity'),
                byAttackType: countBy('attackType'),
                byEndpoint: countBy('path')
            }
        });
    } catch (error) {
        console.error('Error consultando eventos de seguridad:', {
            requestId: req.requestId,
            name: error?.name
        });
        return res.status(500).json({ error: 'No se pudieron consultar los eventos de seguridad' });
    }
});

function toPublicEvent(eventDoc) {
    const data = eventDoc.data() || {};
    return {
        id: eventDoc.id,
        requestId: String(data.requestId || eventDoc.id),
        method: String(data.method || ''),
        path: String(data.path || ''),
        status: Number(data.status) || 0,
        category: String(data.category || 'server_error'),
        attackType: String(data.attackType || 'unauthorized_access'),
        severity: String(data.severity || 'low'),
        blocked: data.blocked !== false,
        ruleId: String(data.ruleId || ''),
        detection: String(data.detection || ''),
        action: String(data.action || ''),
        ipHash: String(data.ipHash || ''),
        userAgent: String(data.userAgent || '').slice(0, 200),
        origin: String(data.origin || '').slice(0, 200),
        timestamp: String(data.timestamp || '')
    };
}

module.exports = router;