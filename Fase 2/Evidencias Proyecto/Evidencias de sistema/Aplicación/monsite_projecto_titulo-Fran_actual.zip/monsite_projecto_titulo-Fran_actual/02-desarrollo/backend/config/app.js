const nodeEnv = process.env.NODE_ENV || 'development';
const isProduction = nodeEnv === 'production';
const requestedPort = Number(process.env.PORT) || 3000;

const defaultLocalOrigins = [
    'http://localhost:5500',
    'http://127.0.0.1:5500',
    'http://localhost:5173',
    'http://127.0.0.1:5173'
];

const envOrigins = (process.env.FRONTEND_URLS || process.env.FRONTEND_URL || '')
    .split(',')
    .map(origin => origin.trim())
    .filter(Boolean);

const allowedOrigins = envOrigins.length > 0 ? envOrigins : defaultLocalOrigins;
const allowedOriginsSet = new Set(allowedOrigins);

const rateLimitWindowMs = Number(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000;
const rateLimitMaxRequests = Number(process.env.RATE_LIMIT_MAX_REQUESTS) || 300;
const paymentRateLimitWindowMs = Number(process.env.PAYMENT_RATE_LIMIT_WINDOW_MS) || 10 * 60 * 1000;
const paymentRateLimitMaxRequests = Number(process.env.PAYMENT_RATE_LIMIT_MAX_REQUESTS) || 60;
const requestBodyLimit = process.env.REQUEST_BODY_LIMIT || '2mb';

const canTryFallbackPort = nodeEnv !== 'production';
const maxFallbackAttempts = 10;

function validateProductionEnvironment() {
    // Con esta variable firebase-admin deja de verificar la firma de los tokens: nunca en Cloud Run
    if (process.env.K_SERVICE && process.env.FIREBASE_AUTH_EMULATOR_HOST) {
        throw new Error('FIREBASE_AUTH_EMULATOR_HOST no puede estar definida en Cloud Run');
    }

    if (!isProduction) {
        return;
    }

    const requiredVariables = [
        'MERCADOPAGO_ACCESS_TOKEN',
        'WEBHOOK_TOKEN',
        'MERCADOPAGO_WEBHOOK_SECRET',
        'WEBHOOK_URL'
    ];

    const missingVariables = requiredVariables.filter((variableName) => !process.env[variableName]);
    // Sin el dominio de la tienda se permitirían orígenes localhost y los retornos de pago irían allí
    if (!process.env.FRONTEND_URL && !process.env.FRONTEND_URLS) {
        missingVariables.push('FRONTEND_URL o FRONTEND_URLS');
    }
    if (String(process.env.MERCADOPAGO_ACCESS_TOKEN || '').trim().startsWith('TEST-')) {
        throw new Error('MERCADOPAGO_ACCESS_TOKEN es una credencial de prueba (TEST-); producción requiere APP_USR-');
    }
    const hasFirebaseServiceAccount = Boolean(process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
    const hasFirebaseEnvironmentCredentials = Boolean(
        process.env.FIREBASE_PROJECT_ID
        && process.env.FIREBASE_CLIENT_EMAIL
        && process.env.FIREBASE_PRIVATE_KEY
    );
    const hasGoogleCloudIdentity = Boolean(
        process.env.GOOGLE_CLOUD_PROJECT
        || process.env.GCLOUD_PROJECT
        || process.env.K_SERVICE
    );

    if (!hasFirebaseServiceAccount && !hasFirebaseEnvironmentCredentials && !hasGoogleCloudIdentity) {
        missingVariables.push('FIREBASE_SERVICE_ACCOUNT_PATH o FIREBASE_PROJECT_ID/FIREBASE_CLIENT_EMAIL/FIREBASE_PRIVATE_KEY');
    }

    if (missingVariables.length > 0) {
        throw new Error(`Faltan variables críticas en producción: ${missingVariables.join(', ')}`);
    }
}

function getFrontendBaseUrl() {
    if (process.env.FRONTEND_URL) {
        return process.env.FRONTEND_URL;
    }

    return allowedOrigins[0] || 'http://localhost:5500';
}

function getWebhookUrl() {
    const rawWebhookUrl = process.env.WEBHOOK_URL;

    if (!rawWebhookUrl) {
        return undefined;
    }

    try {
        return new URL(rawWebhookUrl).toString();
    } catch (_) {
        return rawWebhookUrl;
    }
}

function getRuntimeReadiness() {
    const checks = {
        mercadopagoAccessToken: Boolean(process.env.MERCADOPAGO_ACCESS_TOKEN),
        transbankConfigured: Boolean(
            process.env.TRANSBANK_COMMERCE_CODE && process.env.TRANSBANK_API_KEY
        ) || !isProduction,
        webhookTokenConfigured: Boolean(process.env.WEBHOOK_TOKEN),
        mercadoPagoWebhookSecretConfigured: Boolean(process.env.MERCADOPAGO_WEBHOOK_SECRET),
        webhookUrlConfigured: Boolean(getWebhookUrl()),
        firebaseAdminConfigured: Boolean(
            process.env.FIREBASE_SERVICE_ACCOUNT_PATH
            || (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY)
            || process.env.GOOGLE_CLOUD_PROJECT
            || process.env.GCLOUD_PROJECT
            || process.env.K_SERVICE
        )
    };

    return {
        checks,
        ready: Object.values(checks).every(Boolean)
    };
}

module.exports = {
    allowedOrigins,
    allowedOriginsSet,
    canTryFallbackPort,
    getFrontendBaseUrl,
    getRuntimeReadiness,
    getWebhookUrl,
    isProduction,
    maxFallbackAttempts,
    nodeEnv,
    paymentRateLimitMaxRequests,
    paymentRateLimitWindowMs,
    rateLimitMaxRequests,
    rateLimitWindowMs,
    requestBodyLimit,
    requestedPort,
    validateProductionEnvironment
};