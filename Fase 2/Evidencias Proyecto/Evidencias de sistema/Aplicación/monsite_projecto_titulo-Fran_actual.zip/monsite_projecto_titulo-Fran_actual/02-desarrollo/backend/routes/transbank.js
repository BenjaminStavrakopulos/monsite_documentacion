// routes/transbank.js - Transbank Webpay Plus Payment Routes
const crypto = require('crypto');
const express = require('express');
const router = express.Router();
const {
    WebpayPlus,
    Options,
    IntegrationCommerceCodes,
    IntegrationApiKeys,
    Environment
} = require('transbank-sdk');
const {
    allowedOriginsSet,
    getFrontendBaseUrl,
    isProduction
} = require('../config/app');
const { verifyIdTokenSafe, getFirestoreAdminSafe } = require('../lib/firebase-admin');
const { getShippingCost } = require('../lib/pricing');
const {
    buildOrderItemsSignature,
    findOrderByReference,
    getOrderPaymentBlockReason,
    loadProductsByIds,
    markOrderAsPaid,
    normalizeEntityId
} = require('../lib/order-payment');

// Webpay solo se habilita con credenciales reales del comercio. Sin ellas el SDK usa el
// ambiente de pruebas de Transbank, donde tarjetas de prueba públicas "aprueban" pagos
// y la orden quedaría pagada sin dinero real. ALLOW_WEBPAY_INTEGRATION=true solo para desarrollo.
function isWebpayEnabled() {
    const hasCredentials = Boolean(normalizeEntityId(process.env.TRANSBANK_COMMERCE_CODE) && normalizeEntityId(process.env.TRANSBANK_API_KEY));
    return hasCredentials || process.env.ALLOW_WEBPAY_INTEGRATION === 'true';
}

function getTransbankTransaction() {
    const commerceCode = normalizeEntityId(process.env.TRANSBANK_COMMERCE_CODE) || IntegrationCommerceCodes.WEBPAY_PLUS;
    const apiKey = normalizeEntityId(process.env.TRANSBANK_API_KEY) || IntegrationApiKeys.WEBPAY;
    const environment = isProduction ? Environment.Production : Environment.Integration;

    return new WebpayPlus.Transaction(new Options(commerceCode, apiKey, environment));
}

function sanitizeText(value, { maxLength = 120, allowEmpty = false } = {}) {
    if (typeof value !== 'string') {
        return allowEmpty ? '' : null;
    }

    const normalized = value.trim().replace(/\s+/g, ' ');
    if (!normalized && !allowEmpty) {
        return null;
    }

    return normalized.slice(0, maxLength);
}

function getBearerToken(req) {
    const rawAuth = req.get('authorization') || '';
    const match = rawAuth.match(/^Bearer\s+(.+)$/i);
    return match ? String(match[1]).trim() : '';
}

function isValidEmail(email) {
    if (typeof email !== 'string') {
        return false;
    }

    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) && email.length <= 254;
}

// Precio unitario con el descuento del producto aplicado (desde Firestore).
// Replica la lógica del frontend para cobrar lo que el cliente vio en el checkout.
function getDiscountedUnitPrice(product) {
    const price = Number(product?.price) || 0;

    if (product?.discountType === 'percentage') {
        const pct = Number(product.discountPercent) || 0;
        if (pct > 0) {
            return Math.max(0, Math.round(price - (price * pct / 100)));
        }
    }

    if (product?.discountType === 'amount') {
        const amount = Number(product.discountAmount) || 0;
        if (amount > 0) {
            return Math.max(0, price - amount);
        }
    }

    return Math.round(price);
}

function isValidPublicOrigin(origin) {
    if (!origin) {
        return false;
    }

    return allowedOriginsSet.has(origin);
}

function requirePublicOrigin(req, res, next) {
    if (!isProduction) {
        return next();
    }

    const origin = req.get('origin');
    if (!isValidPublicOrigin(origin)) {
        return res.status(403).json({ error: 'Origen no autorizado' });
    }

    return next();
}

function getBackendBaseUrl(req) {
    const configured = normalizeEntityId(process.env.BACKEND_PUBLIC_URL);
    if (configured) {
        return configured.replace(/\/+$/, '');
    }

    const protocol = req.protocol || 'http';
    const host = req.get('host') || `localhost:${process.env.PORT || 3000}`;
    return `${protocol}://${host}`;
}

function redirectToPaymentResult(res, page, orderId, extraParams = {}) {
    const frontendBaseUrl = getFrontendBaseUrl();
    const params = new URLSearchParams({ orderId: String(orderId || '') });
    Object.entries(extraParams).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
            params.set(key, String(value));
        }
    });
    return res.redirect(`${frontendBaseUrl}/${page}?${params.toString()}`);
}

/**
 * POST /api/transbank/create
 * Crear transacción Webpay Plus y devolver { url, token } para redirigir al usuario.
 */
router.post('/create', requirePublicOrigin, async (req, res) => {
    if (!isWebpayEnabled()) {
        return res.status(503).json({ error: 'Webpay aún no está disponible. Paga con Mercado Pago.' });
    }
    try {
        const { items, email, orderId } = req.body || {};

        if (!Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'No hay items en el carrito' });
        }

        const requestedItems = items
            .map(item => ({
                productId: normalizeEntityId(item?.id || item?.productId),
                quantity: Number(item?.quantity)
            }))
            .filter(item => item.productId && Number.isInteger(item.quantity) && item.quantity > 0 && item.quantity <= 100);

        if (requestedItems.length === 0 || requestedItems.length > 30) {
            return res.status(400).json({ error: 'Items inválidos' });
        }

        const sanitizedOrderId = sanitizeText(orderId, { maxLength: 80, allowEmpty: true });
        if (!sanitizedOrderId) {
            return res.status(400).json({ error: 'orderId requerido' });
        }

        if (!isValidEmail(email)) {
            return res.status(400).json({ error: 'Email inválido' });
        }

        const idToken = getBearerToken(req);
        const decodedToken = await verifyIdTokenSafe(idToken);
        if (!decodedToken?.uid) {
            return res.status(401).json({ error: 'Sesión inválida o expirada' });
        }

        const order = await findOrderByReference(sanitizedOrderId);
        if (!order || !order.firestoreDocId) {
            return res.status(404).json({ error: 'Orden no encontrada' });
        }

        const orderOwnerId = normalizeEntityId(order.userId);
        if (!orderOwnerId || orderOwnerId !== decodedToken.uid) {
            return res.status(403).json({ error: 'No autorizado para pagar esta orden' });
        }

        const paymentBlockReason = getOrderPaymentBlockReason(order);
        if (paymentBlockReason) {
            return res.status(409).json({ error: paymentBlockReason });
        }

        // Validar que el carrito solicitado coincida con la orden guardada
        const requestedSignature = buildOrderItemsSignature(requestedItems);
        const orderSignature = buildOrderItemsSignature(order.items);
        if (!requestedSignature || !orderSignature || requestedSignature !== orderSignature) {
            return res.status(409).json({ error: 'El carrito no coincide con la orden guardada' });
        }

        // Recalcular el subtotal de productos desde Firestore (nunca confiar en el precio del cliente)
        const productsById = await loadProductsByIds(requestedItems.map(item => item.productId));
        let itemsSubtotal = 0;

        for (const item of requestedItems) {
            const product = productsById.get(item.productId);
            if (!product || product.active === false) {
                return res.status(400).json({ error: `Producto inválido o inactivo: ${item.productId}` });
            }

            const basePrice = Number(product.price);
            if (!Number.isFinite(basePrice) || basePrice <= 0 || basePrice > 2000000) {
                return res.status(400).json({ error: `Precio inválido para producto: ${item.productId}` });
            }

            const stock = Number.parseInt(product.stock, 10);
            if (Number.isFinite(stock) && stock >= 0 && item.quantity > stock) {
                return res.status(400).json({ error: `Stock insuficiente para producto: ${item.productId}` });
            }

            // Aplicar el descuento del producto (leído de Firestore, igual que el frontend)
            const unitPrice = getDiscountedUnitPrice(product);
            itemsSubtotal += unitPrice * item.quantity;
        }

        // Envío y descuento se recalculan en el servidor: el envío con la regla vigente
        // según la región, y el descuento solo si la orden la creó el servidor
        // (/api/orders marca pricingSource: 'server'; un cliente no puede escribir esa marca).
        const shippingCost = getShippingCost(order?.shippingData?.region, itemsSubtotal);
        const discountAmount = order?.pricingSource === 'server'
            ? Math.min(itemsSubtotal + shippingCost, Math.max(0, Math.round(Number(order?.totals?.discount) || 0)))
            : 0;

        // Total real de la orden: productos + envío - descuento
        let totalAmount = Math.round(itemsSubtotal + shippingCost - discountAmount);
        if (!Number.isFinite(totalAmount) || totalAmount <= 0) {
            return res.status(400).json({ error: 'Monto total inválido' });
        }

        const transaction = getTransbankTransaction();
        const returnUrl = `${getBackendBaseUrl(req)}/api/transbank/commit`;
        // buyOrder propio y único (<=26), NO derivado del id de la orden: así en el retorno no se
        // puede resolver otra orden por coincidencia de prefijo. El mapeo autoritativo buyOrder ->
        // orden (con monto y token) se guarda en webpayIntents y es lo único que valida la confirmación.
        const buyOrder = `MW${crypto.randomBytes(12).toString('hex')}`; // 26 caracteres
        const sessionId = `s${crypto.randomBytes(16).toString('hex')}`; // no expone el uid

        const tbkResponse = await transaction.create(buyOrder, sessionId, totalAmount, returnUrl);
        const webpayToken = String(tbkResponse?.token || '');

        const db = getFirestoreAdminSafe();
        if (db) {
            const nowIso = new Date().toISOString();
            // Intención de pago: fuente de verdad para confirmar (orden, monto esperado y token)
            await db.collection('webpayIntents').doc(buyOrder).set({
                buyOrder,
                token: webpayToken,
                orderId: order.firestoreDocId,
                userId: decodedToken.uid,
                expectedAmount: totalAmount,
                currency: 'CLP',
                status: 'created',
                createdAt: nowIso
            });
            await db.collection('orders').doc(order.firestoreDocId).set({
                paymentMethod: 'transbank_webpay',
                paymentExpectedAmount: totalAmount,
                paymentExpectedCurrency: 'CLP',
                paymentItemsSignature: requestedSignature,
                transbankBuyOrder: buyOrder,
                transbankSessionId: sessionId,
                transbankToken: webpayToken.slice(0, 200),
                transbankStatus: 'created',
                updatedAt: nowIso
            }, { merge: true });
        }

        console.log('✅ Transacción Webpay creada:', buyOrder);

        return res.json({
            success: true,
            url: tbkResponse?.url,
            token: tbkResponse?.token,
            buyOrder
        });

    } catch (error) {
        console.error('❌ Error creando transacción Webpay:', error);
        return res.status(500).json({
            error: 'Error al crear transacción de pago',
            message: isProduction || process.env.NODE_ENV === 'staging' ? 'Error interno' : error.message
        });
    }
});

// Valida y consume la intencion de pago (webpayIntents) de forma atomica: token correcto, monto
// esperado valido, monto exacto y pago aprobado. Falla cerrado si falta cualquier dato. No marca
// la orden (eso se hace fuera, de forma idempotente).
async function settleWebpayIntent(db, { buyOrder, token, amount, responseCode, status }) {
    if (!db || !buyOrder) return { ok: false, reason: 'order_not_found' };
    const intentRef = db.collection('webpayIntents').doc(buyOrder);
    return db.runTransaction(async (tx) => {
        const snap = await tx.get(intentRef);
        if (!snap.exists) return { ok: false, reason: 'order_not_found' };
        const intent = snap.data() || {};
        const orderId = intent.orderId || null;
        // El token devuelto por Webpay debe ser el que generamos para ESTA intencion
        if (!token || intent.token !== token) return { ok: false, reason: 'token_mismatch', orderId };
        const expected = Number(intent.expectedAmount);
        if (!Number.isFinite(expected) || expected <= 0) return { ok: false, reason: 'amount_mismatch', orderId };
        if (Number(amount) !== expected) return { ok: false, reason: 'amount_mismatch', orderId };
        const approved = Number(responseCode) === 0 && ['AUTHORIZED', 'CAPTURED'].includes(String(status || '').toUpperCase());
        if (!approved) return { ok: false, reason: 'rejected', orderId };
        if (intent.status !== 'committed') {
            tx.update(intentRef, { status: 'committed', committedAt: new Date().toISOString() });
        }
        return { ok: true, orderId };
    });
}

async function loadOrderByDocId(db, docId) {
    if (!db || !docId) return null;
    const snap = await db.collection('orders').doc(String(docId)).get();
    return snap.exists ? { firestoreDocId: snap.id, ...snap.data() } : null;
}

// Marca la orden pagada (idempotente) y guarda los datos de Transbank
async function finalizeWebpay(res, db, orderId, gateway) {
    const order = await loadOrderByDocId(db, orderId);
    if (!order) return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: 'order_not_found' });
    await markOrderAsPaid(order, {
        paymentMethod: 'transbank_webpay',
        gatewayPaymentId: gateway.buyOrder,
        gatewayStatus: gateway.status || 'AUTHORIZED',
        paymentDate: gateway.paymentDate || new Date().toISOString()
    });
    await db.collection('orders').doc(order.firestoreDocId).set({
        transbankAuthorizationCode: gateway.authorizationCode || '',
        transbankPaymentTypeCode: gateway.paymentTypeCode || '',
        transbankAmount: Number(gateway.amount) || 0,
        transbankResponseCode: Number(gateway.responseCode),
        transbankStatus: gateway.status || 'AUTHORIZED',
        updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log('OK Pago Webpay confirmado:', gateway.buyOrder, '-> orden', order.id || order.firestoreDocId);
    return redirectToPaymentResult(res, 'payment-success.html', order.id || order.firestoreDocId);
}

// Estados de un pedido que todavía no se pagó: solo ahí un retorno fallido de Webpay puede marcar el fallo.
// Un pedido ya pagado, enviado, entregado, cancelado o reembolsado no se degrada por un token viejo.
const WEBPAY_FAILURE_ALLOWED_STATUSES = ['', 'pending', 'payment_failed', 'payment_validation_failed'];

async function recordWebpayFailure(db, settle, gateway) {
    if (!db || !settle.orderId) return;
    const mismatch = settle.reason === 'amount_mismatch' || settle.reason === 'token_mismatch';
    const orderRef = db.collection('orders').doc(String(settle.orderId));

    await db.runTransaction(async (tx) => {
        const snap = await tx.get(orderRef);
        if (!snap.exists) return;
        const currentStatus = normalizeEntityId(snap.data()?.status).toLowerCase();
        if (!WEBPAY_FAILURE_ALLOWED_STATUSES.includes(currentStatus)) return;

        tx.set(orderRef, {
            status: mismatch ? 'payment_validation_failed' : 'payment_failed',
            paymentStatus: mismatch ? 'validation_failed' : 'rejected',
            transbankStatus: gateway.status || 'REJECTED',
            transbankResponseCode: Number(gateway.responseCode),
            paymentProcessingStatus: 'failed',
            paymentProcessingError: 'Webpay no validado (' + settle.reason + ')',
            updatedAt: new Date().toISOString()
        }, { merge: true });
    });
}

/**
 * GET/POST /api/transbank/commit
 * Webpay redirige aquí al usuario tras el pago (return_url). Se confirma la transacción.
 */
async function handleCommit(req, res) {
    // Sin credenciales reales no se confirma ningún pago (ver isWebpayEnabled)
    if (!isWebpayEnabled()) {
        return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: 'commit_error' });
    }
    // Webpay puede volver con token_ws (pago completado), TBK_TOKEN (anulación/timeout), etc.
    const tokenWs = normalizeEntityId(req.method === 'POST' ? (req.body?.token_ws ?? req.query?.token_ws) : req.query?.token_ws);
    const tbkToken = normalizeEntityId(req.method === 'POST' ? (req.body?.TBK_TOKEN ?? req.query?.TBK_TOKEN) : req.query?.TBK_TOKEN);
    const tbkBuyOrder = normalizeEntityId(req.method === 'POST' ? (req.body?.TBK_ORDEN_COMPRA ?? req.query?.TBK_ORDEN_COMPRA) : req.query?.TBK_ORDEN_COMPRA);
    const tbkSessionId = normalizeEntityId(req.method === 'POST' ? (req.body?.TBK_ID_SESION ?? req.query?.TBK_ID_SESION) : req.query?.TBK_ID_SESION);

    // El usuario anuló el pago o hubo timeout (Webpay devuelve TBK_TOKEN en ese caso)
    if (!tokenWs && tbkToken) {
        console.warn('⚠️ Pago Webpay anulado o expirado. buyOrder:', tbkBuyOrder);
        return redirectToPaymentResult(res, 'payment-failure.html', tbkBuyOrder || '', { reason: 'aborted' });
    }

    if (!tokenWs) {
        return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: 'missing_token' });
    }

    try {
        const transaction = getTransbankTransaction();
        const commitResponse = await transaction.commit(tokenWs);
        const gateway = {
            buyOrder: normalizeEntityId(commitResponse?.buy_order),
            amount: Number(commitResponse?.amount),
            responseCode: Number(commitResponse?.response_code),
            status: normalizeEntityId(commitResponse?.status).toUpperCase(),
            authorizationCode: normalizeEntityId(commitResponse?.authorization_code),
            paymentTypeCode: normalizeEntityId(commitResponse?.payment_type_code),
            paymentDate: commitResponse?.transaction_date || new Date().toISOString()
        };
        const db = getFirestoreAdminSafe();
        const settle = await settleWebpayIntent(db, {
            buyOrder: gateway.buyOrder, token: tokenWs,
            amount: gateway.amount, responseCode: gateway.responseCode, status: gateway.status
        });
        if (settle.ok) {
            return await finalizeWebpay(res, db, settle.orderId, gateway);
        }
        await recordWebpayFailure(db, settle, gateway);
        console.warn('Pago Webpay no validado:', gateway.buyOrder, settle.reason);
        return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: settle.reason });

    } catch (error) {
        console.error('Error confirmando transaccion Webpay:', error);
        // Recarga o doble retorno: la transaccion pudo quedar confirmada. Recuperar estado y validar igual.
        try {
            const transaction = getTransbankTransaction();
            const statusResponse = await transaction.status(tokenWs);
            const gateway = {
                buyOrder: normalizeEntityId(statusResponse?.buy_order),
                amount: Number(statusResponse?.amount),
                responseCode: Number(statusResponse?.response_code),
                status: normalizeEntityId(statusResponse?.status).toUpperCase(),
                authorizationCode: normalizeEntityId(statusResponse?.authorization_code),
                paymentTypeCode: normalizeEntityId(statusResponse?.payment_type_code),
                paymentDate: statusResponse?.transaction_date || new Date().toISOString()
            };
            const db = getFirestoreAdminSafe();
            const settle = await settleWebpayIntent(db, {
                buyOrder: gateway.buyOrder, token: tokenWs,
                amount: gateway.amount, responseCode: gateway.responseCode, status: gateway.status
            });
            if (settle.ok) {
                return await finalizeWebpay(res, db, settle.orderId, gateway);
            }
            return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: settle.reason || 'commit_error' });
        } catch (statusError) {
            console.error('Error recuperando estado de transaccion Webpay:', statusError);
            return redirectToPaymentResult(res, 'payment-failure.html', '', { reason: 'commit_error' });
        }
    }
}

router.get('/commit', handleCommit);
router.post('/commit', handleCommit);

module.exports = router;
