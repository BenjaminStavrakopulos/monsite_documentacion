/**
 * build-hair-ia-matrix.js
 *
 * Convierte el Excel de etiquetas IA (data/Catalogo_MONSITE_Matriz_IA_Multidimensional.xlsx)
 * en data/hair-ia-matrix.json, que usa el análisis capilar para recomendar productos.
 * Además enlaza cada producto del Excel con su ID real en Firestore (catálogo público).
 *
 * Uso (desde 02-desarrollo/backend):
 *   node scripts/build-hair-ia-matrix.js
 *
 * Volver a ejecutarlo cada vez que se actualice el Excel o se agreguen productos.
 */
const path = require('path');
const fs = require('fs');
const XLSX = require('xlsx');

const ROOT = path.join(__dirname, '..', '..');
const EXCEL_PATH = path.join(ROOT, 'data', 'Catalogo_MONSITE_Matriz_IA_Multidimensional.xlsx');
const OUTPUT_PATH = path.join(ROOT, 'data', 'hair-ia-matrix.json');
const FIRESTORE_PRODUCTS_URL = 'https://firestore.googleapis.com/v1/projects/monsite-85424/databases/(default)/documents/products?pageSize=300';

const NON_DIMENSION_COLUMNS = new Set(['Producto', 'Fuente principal', 'Confianza de catalogación', 'Nota metodológica']);

function toKey(label) {
    return String(label)
        .normalize('NFD').replace(/[̀-ͯ]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '_')
        .replace(/^_+|_+$/g, '');
}

function normalizeName(name) {
    return String(name || '')
        .normalize('NFD').replace(/[̀-ͯ]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, ' ')
        .trim();
}

// Similitud por palabras (Jaccard): resuelve diferencias como "Antifrizz"/"Anti frizz" o "75"/"75g"
function nameSimilarity(a, b) {
    const tokensA = new Set(normalizeName(a).replace(/\s+/g, ' ').split(' '));
    const tokensB = new Set(normalizeName(b).replace(/\s+/g, ' ').split(' '));
    const compactA = normalizeName(a).replace(/\s+/g, '');
    const compactB = normalizeName(b).replace(/\s+/g, '');
    if (compactA && compactB && (compactA.startsWith(compactB) || compactB.startsWith(compactA))) return 0.95;
    const intersection = [...tokensA].filter(token => tokensB.has(token)).length;
    return intersection / new Set([...tokensA, ...tokensB]).size;
}

function readSheet(workbook, sheetName) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) throw new Error(`No existe la hoja "${sheetName}" en el Excel`);
    return XLSX.utils.sheet_to_json(sheet, { defval: null });
}

async function fetchCatalog() {
    const products = [];
    let pageToken = '';
    do {
        const response = await fetch(FIRESTORE_PRODUCTS_URL + (pageToken ? `&pageToken=${pageToken}` : ''));
        if (!response.ok) throw new Error(`Firestore respondió HTTP ${response.status}`);
        const page = await response.json();
        (page.documents || []).forEach(doc => {
            products.push({ id: doc.name.split('/').pop(), name: doc.fields?.name?.stringValue || '' });
        });
        pageToken = page.nextPageToken || '';
    } while (pageToken);
    return products;
}

async function main() {
    const workbook = XLSX.readFile(EXCEL_PATH);
    const matrixRows = readSheet(workbook, 'Matriz IA');
    const detailRows = readSheet(workbook, 'Productos únicos');
    const detailsByName = new Map(detailRows.map(row => [normalizeName(row['Producto']), row]));

    const dimensionLabels = Object.keys(matrixRows[0]).filter(column => !NON_DIMENSION_COLUMNS.has(column));
    const dimensions = dimensionLabels.map(label => ({ key: toKey(label), label }));
    // Dimensiones que no vienen en el Excel pero se asignan desde el editor de etiquetas del admin
    const ADMIN_ONLY_DIMENSIONS = [
        { key: 'cuidado_canas', label: 'Cuidado de canas' },
        { key: 'anticaspa', label: 'Anticaspa' },
        { key: 'piritionato_zinc', label: 'Contiene piritionato de zinc' },
        { key: 'ketoconazol', label: 'Contiene ketoconazol' },
        { key: 'sulfuro_selenio', label: 'Contiene sulfuro de selenio' },
        { key: 'acido_salicilico', label: 'Contiene ácido salicílico' }
    ];
    const extraDimensions = ADMIN_ONLY_DIMENSIONS.filter(extra => !dimensions.some(dim => dim.key === extra.key));

    let catalog = [];
    try {
        catalog = await fetchCatalog();
    } catch (error) {
        console.warn(`⚠️ No se pudo leer el catálogo de Firestore (${error.message}); se enlazará solo por nombre en el navegador.`);
    }

    const unmatched = [];
    const usedIds = new Set();
    const products = matrixRows.filter(row => row['Producto']).map(row => {
        const name = String(row['Producto']).trim();
        const scores = {};
        dimensions.forEach(({ key, label }) => {
            const value = Number(row[label]) || 0;
            if (value > 0) scores[key] = Math.max(0, Math.min(3, value));
        });

        let best = null;
        catalog.forEach(product => {
            if (usedIds.has(product.id)) return;
            const similarity = nameSimilarity(name, product.name);
            if (!best || similarity > best.similarity) best = { ...product, similarity };
        });
        const productId = best && best.similarity >= 0.75 ? best.id : null;
        if (productId) usedIds.add(productId);
        else if (catalog.length) unmatched.push(name);

        const details = detailsByName.get(normalizeName(name)) || {};
        return {
            name,
            productId,
            confidence: row['Confianza de catalogación'] || 'Media',
            need: details['Necesidad principal IA'] || '',
            hairTypes: details['Para qué tipo de pelo se usa'] || '',
            scores
        };
    });

    const output = {
        generatedAt: new Date().toISOString(),
        source: path.basename(EXCEL_PATH),
        scale: '0 = sin evidencia · 1 = secundario · 2 = beneficio claro · 3 = principal',
        dimensions: [...dimensions, ...extraDimensions],
        products
    };

    fs.writeFileSync(OUTPUT_PATH, JSON.stringify(output));
    console.log(`✅ ${products.length} productos · ${dimensions.length} dimensiones → ${path.relative(ROOT, OUTPUT_PATH)}`);
    if (catalog.length) {
        console.log(`🔗 Enlazados con el catálogo: ${products.length - unmatched.length}/${products.length}`);
        if (unmatched.length) console.log('   Sin producto en la tienda (no se recomendarán):\n   - ' + unmatched.join('\n   - '));
        const notInExcel = catalog.filter(product => !usedIds.has(product.id)).map(product => product.name);
        if (notInExcel.length) console.log('   Productos de la tienda sin etiquetas en el Excel:\n   - ' + notInExcel.join('\n   - '));
    }
}

main().catch(error => {
    console.error('❌', error.message);
    process.exit(1);
});
