#!/usr/bin/env node
/**
 * export-hair-dataset.js
 *
 * Descarga el dataset de entrenamiento de la IA capilar: las fotos que los clientes
 * aportaron con su consentimiento, junto con sus respuestas (puntas, calor, teñido y la
 * confirmación de canas/caspa que sugiere el modelo de cuero cabelludo) y
 * la predicción que hizo el modelo en ese momento. ("plancha" = respuesta 0-3 a la frecuencia de
 * uso de plancha; en Firestore se guarda como answers.calor.)
 *
 * Requisitos (una sola vez, con una cuenta con acceso al proyecto):
 *   gcloud auth application-default login
 *
 * Uso (desde 02-desarrollo/backend):
 *   node scripts/export-hair-dataset.js                  -> ../../dataset-ia
 *   node scripts/export-hair-dataset.js --out C:\ruta     -> otra carpeta
 *   node scripts/export-hair-dataset.js --desde 2026-10-01
 *
 * Resultado:
 *   dataset-ia/
 *     dataset.csv                     una fila por muestra (respuestas, predicción, partición)
 *     muestras/<sampleId>/img_0.jpg   foto del cuero cabelludo
 *     muestras/<sampleId>/img_1.jpg   foto del cuerpo del cabello
 *     por-etiqueta/tenido/<no|tenido|decolorado>/<sampleId>.jpg
 *                                     foto del cuero cabelludo (donde se ve la raíz) ordenada
 *                                     por la respuesta del cliente, lista para entrenar
 *
 * - Quien revocó su consentimiento de entrenamiento queda FUERA del export.
 * - La partición entrenamiento/validación/prueba es por persona (hash del usuario), para que las
 *   fotos de una misma persona no queden en grupos distintos. No se exporta el uid real.
 * - La carpeta de salida queda fuera del sitio (no se publica) y está en .gitignore.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');

const PROJECT_ID = process.env.GOOGLE_CLOUD_PROJECT || 'monsite-85424';
const BUCKET = process.env.STORAGE_BUCKET || 'monsite-85424.firebasestorage.app';

function parseArgs(argv) {
    const args = { out: path.resolve(__dirname, '..', '..', '..', 'dataset-ia'), desde: '' };
    for (let index = 0; index < argv.length; index += 1) {
        if (argv[index] === '--out') args.out = path.resolve(argv[++index] || args.out);
        else if (argv[index] === '--desde') args.desde = String(argv[++index] || '');
    }
    return args;
}

// Grupo estable por persona sin exponer el uid: 70 % entrenamiento, 15 % validación, 15 % prueba
function personGroup(userId) {
    const hash = crypto.createHash('sha256').update(`monsite-dataset:${userId}`).digest('hex');
    const bucket = parseInt(hash.slice(0, 8), 16) % 100;
    return {
        person: hash.slice(0, 12),
        split: bucket < 70 ? 'entrenamiento' : bucket < 85 ? 'validacion' : 'prueba'
    };
}

const csvCell = value => {
    const text = value === undefined || value === null ? '' : String(value);
    return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

const TENIDO_FOLDERS = { no: 'no', tenido: 'tenido', decolorado: 'decolorado' };

async function main() {
    const args = parseArgs(process.argv.slice(2));
    admin.initializeApp({ credential: admin.credential.applicationDefault(), projectId: PROJECT_ID, storageBucket: BUCKET });
    const db = admin.firestore();
    const bucket = admin.storage().bucket();

    // Consentimientos vigentes: solo se exportan muestras de quienes mantienen la autorización
    const consentSnap = await db.collection('hairAnalysisConsents').get();
    const consenting = new Set(consentSnap.docs
        .filter(docSnap => docSnap.data()?.consentimiento_entrenamiento === true && docSnap.data()?.consentimiento_revocado !== true)
        .map(docSnap => docSnap.id));

    const samplesSnap = await db.collection('hairAnalysisTrainingSamples').get();
    fs.mkdirSync(path.join(args.out, 'muestras'), { recursive: true });

    const header = ['sampleId', 'persona', 'particion', 'fecha', 'fotos', 'puntas', 'plancha', 'tenido',
        'canas', 'caspa', 'version_modelo', 'pred_tipo', 'pred_condicion', 'pred_frizz', 'prob_seco', 'prob_con_frizz',
        'cuero_prob_graso', 'cuero_prob_caspa', 'cuero_prob_baja_densidad', 'cuero_prob_canas', 'cuero_nivel_canas',
        'pred_quimico', 'prob_natural', 'prob_mechas', 'prob_color', 'archivos'];
    const rows = [header.join(',')];
    let exported = 0;
    let skippedRevoked = 0;
    let skippedEmpty = 0;

    for (const docSnap of samplesSnap.docs) {
        const sample = docSnap.data() || {};
        if (args.desde && String(sample.createdAt || '') < args.desde) continue;
        if (!consenting.has(sample.userId)) { skippedRevoked += 1; continue; }
        const paths = Array.isArray(sample.storagePaths) ? sample.storagePaths : [];
        if (!paths.length) { skippedEmpty += 1; continue; }

        const sampleDir = path.join(args.out, 'muestras', docSnap.id);
        fs.mkdirSync(sampleDir, { recursive: true });
        const files = [];
        for (const storagePath of paths) {
            // Solo rutas de entrenamiento de esta misma muestra
            if (!storagePath.startsWith(`hair-analysis-training/${docSnap.id}/`)) continue;
            const fileName = path.basename(storagePath);
            const destination = path.join(sampleDir, fileName.replace(`_${docSnap.id}`, ''));
            try {
                await bucket.file(storagePath).download({ destination });
                files.push(path.relative(args.out, destination).replace(/\\/g, '/'));
            } catch (error) {
                console.warn(`No se pudo descargar ${storagePath}: ${error.message}`);
            }
        }
        if (!files.length) { skippedEmpty += 1; continue; }

        const answers = sample.answers || {};
        const prediction = sample.prediction || {};
        const group = personGroup(sample.userId);

        // Carpeta por etiqueta de teñido con la foto del cuero cabelludo (img_0)
        const tenidoFolder = TENIDO_FOLDERS[answers.tenido];
        const scalp = path.join(sampleDir, 'img_0.jpg');
        if (tenidoFolder && fs.existsSync(scalp)) {
            const labelDir = path.join(args.out, 'por-etiqueta', 'tenido', tenidoFolder);
            fs.mkdirSync(labelDir, { recursive: true });
            fs.copyFileSync(scalp, path.join(labelDir, `${docSnap.id}.jpg`));
        }

        rows.push([
            docSnap.id, group.person, group.split, sample.createdAt, files.length,
            answers.puntas, answers.calor, answers.tenido, answers.canas, answers.caspa, sample.modelVersion,
            prediction.type?.prediction, prediction.condition?.prediction, prediction.frizz?.prediction,
            prediction.condition?.probabilities?.seco, prediction.frizz?.probabilities?.con_frizz,
            // Modelo de cuero cabelludo (beta): se compara con las respuestas canas/caspa del cliente
            prediction.scalp?.probabilities?.graso, prediction.scalp?.probabilities?.caspa_irritacion,
            prediction.scalp?.probabilities?.baja_densidad, prediction.scalp?.probabilities?.canas,
            prediction.scalp?.prediction,
            prediction.chemical?.prediction, prediction.chemical?.probabilities?.natural,
            prediction.chemical?.probabilities?.mechas, prediction.chemical?.probabilities?.color,
            files.join(' ')
        ].map(csvCell).join(','));
        exported += 1;
    }

    fs.writeFileSync(path.join(args.out, 'dataset.csv'), `${rows.join('\n')}\n`, 'utf8');
    console.log(`Listo: ${exported} muestras exportadas en ${args.out}`);
    console.log(`Omitidas: ${skippedRevoked} sin consentimiento vigente, ${skippedEmpty} sin fotos`);
}

main().catch(error => {
    console.error('Error exportando el dataset:', error.message);
    if (/default credentials|Could not load/i.test(error.message)) {
        console.error('Ejecuta primero: gcloud auth application-default login');
    }
    process.exit(1);
});
