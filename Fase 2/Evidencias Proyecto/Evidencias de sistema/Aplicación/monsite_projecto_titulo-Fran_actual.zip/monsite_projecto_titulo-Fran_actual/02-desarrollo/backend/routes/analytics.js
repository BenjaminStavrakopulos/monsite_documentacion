// Visitas anónimas del sitio (estadística del dashboard). Antes las escribía el navegador
// directo en Firestore, lo que obligaba a dejar la colección abierta a cualquiera.
// Ahora pasan por aquí: tope por IP y un solo registro por visitante y día.
const express = require('express');
const { createLimiter } = require('../lib/rate-limit');
const { getFirestoreAdminSafe } = require('../lib/firebase-admin');

const router = express.Router();

const visitLimiter = createLimiter({
    windowMs: 15 * 60 * 1000,
    max: Number(process.env.ANALYTICS_VISIT_MAX_PER_IP) || 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { ok: false }
});

const VISITOR_ID_PATTERN = /^[A-Za-z0-9-]{16,80}$/;
const VISIT_RETENTION_MS = 365 * 24 * 60 * 60 * 1000;

// Fecha en Chile (AAAA-MM-DD), la misma que usa el dashboard para agrupar
function todayInChile() {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(new Date());
}

router.post('/visit', visitLimiter, async (req, res) => {
    const visitorId = typeof req.body?.visitorId === 'string' ? req.body.visitorId.trim() : '';
    if (!VISITOR_ID_PATTERN.test(visitorId)) {
        return res.status(400).json({ ok: false });
    }

    const db = getFirestoreAdminSafe();
    if (!db) return res.status(503).json({ ok: false });

    const date = todayInChile();
    try {
        // El id del documento es fecha + visitante: repetir la llamada el mismo día no suma visitas
        await db.collection('analyticsVisits').doc(`${date}_${visitorId}`).create({
            date,
            visitorId,
            createdAt: new Date().toISOString(),
            // Firestore la borra sola a los 12 meses (política TTL sobre expireAt)
            expireAt: new Date(Date.now() + VISIT_RETENTION_MS)
        });
        return res.status(201).json({ ok: true });
    } catch (error) {
        if (error?.code === 6 || /already exists/i.test(error?.message || '')) {
            return res.json({ ok: true, repeated: true });
        }
        console.error('No se pudo registrar la visita:', error.message);
        return res.status(500).json({ ok: false });
    }
});

module.exports = router;
