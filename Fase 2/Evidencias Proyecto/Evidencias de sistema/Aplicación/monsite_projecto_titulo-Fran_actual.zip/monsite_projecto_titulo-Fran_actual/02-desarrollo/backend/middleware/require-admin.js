const { getFirestoreAdminSafe, verifyIdTokenSafe } = require('../lib/firebase-admin');

// Exige administrador verificando SIEMPRE el rol actual en Firestore (autoritativo), no solo el
// claim del token. Así, un admin al que se le quitó el rol pierde el acceso de inmediato, aunque
// todavía tenga un token con "admin: true". El token ya se verifica con checkRevoked en verifyIdTokenSafe.
async function requireAdmin(req, res, next) {
    try {
        const rawAuthorization = req.get('authorization') || '';
        const match = rawAuthorization.match(/^Bearer\s+(.+)$/i);
        const token = match ? match[1].trim() : '';
        const decodedToken = await verifyIdTokenSafe(token);

        if (!decodedToken?.uid) {
            return res.status(401).json({ error: 'Sesión inválida o expirada' });
        }

        const db = getFirestoreAdminSafe();
        if (!db) {
            return res.status(503).json({ error: 'Firebase Admin no disponible' });
        }

        const userSnapshot = await db.collection('users').doc(decodedToken.uid).get();
        if (!userSnapshot.exists || userSnapshot.data()?.role !== 'admin') {
            return res.status(403).json({ error: 'Se requiere rol de administrador' });
        }

        req.user = decodedToken;
        return next();
    } catch (error) {
        console.error('Error verificando administrador:', error);
        return res.status(503).json({ error: 'No se pudo verificar la autorización' });
    }
}

module.exports = requireAdmin;
