const crypto = require('crypto');
const express = require('express');
const { createLimiter } = require('../lib/rate-limit');
const router = express.Router();
const { getFirestoreAdminSafe, verifyIdTokenSafe } = require('../lib/firebase-admin');
const tracking = require('../lib/order-tracking');
const {
    FREE_SHIPPING_THRESHOLD,
    getShippingCost,
    discountedPrice,
    getDiscountEligibilityError,
    getDiscountUserKey,
    computeDiscountAmount,
    resolveDiscountCode
} = require('../lib/pricing');

function getBearerToken(req) {
    const match = String(req.get('authorization') || '').match(/^Bearer\s+(.+)$/i);
    return match ? match[1].trim() : '';
}

function safeText(value, maxLength, required = false) {
    const normalized = typeof value === 'string' ? value.trim().replace(/\s+/g, ' ') : '';
    if (required && !normalized) return null;
    return normalized.slice(0, maxLength);
}

// RUT chileno con dígito verificador (módulo 11). Devuelve "12.345.678-9" o null.
function normalizeRut(value) {
    const clean = String(value || '').toUpperCase().replace(/[^0-9K]/g, '');
    if (!/^\d{7,8}[0-9K]$/.test(clean)) return null;
    const body = clean.slice(0, -1);
    let sum = 0;
    let factor = 2;
    for (let i = body.length - 1; i >= 0; i -= 1) {
        sum += Number(body[i]) * factor;
        factor = factor === 7 ? 2 : factor + 1;
    }
    const expected = 11 - (sum % 11);
    const dv = expected === 11 ? '0' : expected === 10 ? 'K' : String(expected);
    if (clean.slice(-1) !== dv) return null;
    return `${body.replace(/\B(?=(\d{3})+(?!\d))/g, '.')}-${dv}`;
}

// Boleta (por defecto) o factura con los datos de la empresa.
// @returns {{ billing } | { error }}
// Una sola dirección de correo: sin comas, punto y coma, espacios, comillas ni <> (evita que un correo
// armado como "a@x.cl, b@y.cl" se envíe a varios destinatarios)
const SINGLE_EMAIL_PATTERN = /^[^\s@,;<>()"\\]+@[^\s@,;<>()"\\]+\.[^\s@,;<>()"\\]+$/;
const isSingleEmail = value => typeof value === 'string' && value.length <= 254 && SINGLE_EMAIL_PATTERN.test(value);

function resolveBilling(input, shippingData) {
    if (input?.documentType !== 'factura') return { billing: { documentType: 'boleta' } };
    const rut = normalizeRut(input.rut);
    const billing = {
        documentType: 'factura',
        rut,
        businessName: safeText(input.businessName, 100),
        businessActivity: safeText(input.businessActivity, 80),
        address: safeText(input.address, 160),
        city: safeText(input.city, 100),
        email: safeText(input.email, 254) || shippingData.email
    };
    if (!rut) return { error: 'El RUT de la empresa no es válido' };
    if (billing.businessName.length < 3) return { error: 'Falta la razón social de la empresa' };
    if (billing.businessActivity.length < 3) return { error: 'Falta el giro de la empresa' };
    if (billing.address.length < 5 || billing.city.length < 2) return { error: 'Falta la dirección de la empresa' };
    if (!isSingleEmail(billing.email)) return { error: 'El correo para la factura no es válido' };
    return { billing };
}

// Valida los productos pedidos contra Firestore (precio real, activo, stock).
// @returns {{ orderItems, subtotal } | { status, error }}
async function resolveItems(db, requestedItems, { checkStock = true } = {}) {
    if (!Array.isArray(requestedItems) || requestedItems.length === 0 || requestedItems.length > 30) {
        return { status: 400, error: 'Items inválidos' };
    }

    const itemsById = new Map();
    for (const item of requestedItems) {
        const productId = safeText(item?.id || item?.productId, 120, true);
        const quantity = Number.parseInt(item?.quantity, 10);
        if (!productId || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
            return { status: 400, error: 'Producto o cantidad inválidos' };
        }
        itemsById.set(productId, (itemsById.get(productId) || 0) + quantity);
    }

    const productIds = [...itemsById.keys()];
    const productSnapshots = await db.getAll(...productIds.map(productId => db.collection('products').doc(productId)));
    const orderItems = [];
    let subtotal = 0;

    for (let index = 0; index < productSnapshots.length; index += 1) {
        const productSnapshot = productSnapshots[index];
        const productId = productIds[index];
        const quantity = itemsById.get(productId);
        const product = productSnapshot.data() || {};
        const price = discountedPrice(product);
        const stock = Number.parseInt(product.stock, 10);

        if (!productSnapshot.exists || product.active === false || price <= 0) {
            return { status: 400, error: `Producto inválido o inactivo: ${productId}` };
        }
        if (checkStock && Number.isInteger(stock) && stock < quantity) {
            return { status: 409, error: `Stock insuficiente para producto: ${productId}` };
        }

        orderItems.push({
            id: productId,
            name: safeText(product.name, 120) || 'Producto',
            description: safeText(product.description, 300),
            image: safeText(product.image, 500),
            price,
            quantity
        });
        subtotal += price * quantity;
    }

    return { orderItems, subtotal };
}

// La cotización con código revela si el código existe y cuánto descuenta: tope más estricto por IP
const quoteDiscountLimiter = createLimiter({
    windowMs: 15 * 60 * 1000,
    max: Number(process.env.QUOTE_DISCOUNT_MAX_ATTEMPTS) || 20,
    standardHeaders: true,
    legacyHeaders: false,
    skip: req => !safeText(req.body?.discountCode, 80),
    message: { error: 'Probaste demasiados códigos seguidos. Espera unos minutos e inténtalo de nuevo.' }
});

// Cotización para el checkout: subtotal real, envío y descuento validados en el
// servidor. No requiere sesión (sirve para invitados); los códigos de descuento
// solo se validan para cuentas habilitadas, con su límite de usos por persona.
router.post('/quote', quoteDiscountLimiter, async (req, res) => {
    try {
        const db = getFirestoreAdminSafe();
        if (!db) return res.status(503).json({ error: 'Firestore no disponible' });

        const items = await resolveItems(db, req.body?.items, { checkStock: false });
        if (items.error) return res.status(items.status).json({ error: items.error });

        const region = safeText(req.body?.region, 100);
        const shipping = getShippingCost(region, items.subtotal);
        const response = {
            subtotal: items.subtotal,
            shipping,
            shippingPending: !region && items.subtotal < FREE_SHIPPING_THRESHOLD,
            freeShippingThreshold: FREE_SHIPPING_THRESHOLD,
            discount: 0,
            discountCode: null,
            discountError: null
        };

        const requestedCode = safeText(req.body?.discountCode, 80);
        if (requestedCode) {
            const token = getBearerToken(req);
            const decodedToken = token ? await verifyIdTokenSafe(token).catch(() => null) : null;
            const eligibilityError = getDiscountEligibilityError(decodedToken);
            // Sin cuenta habilitada no se consulta el código: tampoco se revela si existe
            const discount = eligibilityError
                ? { ok: false, error: eligibilityError }
                : await resolveDiscountCode(db, requestedCode, getDiscountUserKey(decodedToken));
            if (discount.ok) {
                response.discount = computeDiscountAmount(discount.discountData, items.subtotal, shipping);
                response.discountCode = discount.code;
                response.discountType = discount.discountData.type === 'percentage' ? 'percentage' : 'amount';
                response.discountValue = Number(discount.discountData.value) || 0;
            } else {
                response.discountError = discount.error;
            }
        }

        response.total = response.subtotal + response.shipping - response.discount;
        return res.json(response);
    } catch (error) {
        console.error('Error cotizando orden:', error);
        return res.status(500).json({ error: 'No se pudo calcular el total' });
    }
});

// Crear pedidos tiene un tope por IP: evita llenar la base con pedidos falsos
const createOrderLimiter = createLimiter({
    windowMs: 15 * 60 * 1000,
    max: Number(process.env.ORDER_CREATE_MAX_ATTEMPTS) || 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Estás creando muchos pedidos seguidos. Espera unos minutos e inténtalo de nuevo.' }
});

router.post('/', createOrderLimiter, async (req, res) => {
    try {
        const decodedToken = await verifyIdTokenSafe(getBearerToken(req));
        if (!decodedToken?.uid) {
            return res.status(401).json({ error: 'Sesión inválida o expirada' });
        }
        // Una cuenta con contraseña debe haber verificado su correo (como invitado sí se puede comprar)
        if (decodedToken.firebase?.sign_in_provider === 'password' && decodedToken.email_verified !== true) {
            return res.status(403).json({ error: 'Verifica tu correo antes de comprar con tu cuenta' });
        }

        const db = getFirestoreAdminSafe();
        if (!db) return res.status(503).json({ error: 'Firestore no disponible' });

        const items = await resolveItems(db, req.body?.items);
        if (items.error) return res.status(items.status).json({ error: items.error });
        const { orderItems, subtotal } = items;

        const inputShipping = req.body?.shippingData || {};
        const shippingData = {
            firstName: safeText(inputShipping.firstName, 80, true),
            lastName: safeText(inputShipping.lastName, 80, true),
            rut: safeText(inputShipping.rut, 20),
            email: safeText(decodedToken.email || inputShipping.email, 254, true),
            phone: safeText(inputShipping.phone, 20, true),
            street: safeText(inputShipping.street, 160, true),
            apartment: safeText(inputShipping.apartment, 80),
            city: safeText(inputShipping.city, 100, true),
            region: safeText(inputShipping.region, 100, true),
            notes: safeText(inputShipping.notes, 500)
        };

        if (Object.values(shippingData).some(value => value === null)) {
            return res.status(400).json({ error: 'Datos de despacho incompletos' });
        }
        if (!isSingleEmail(shippingData.email)) {
            return res.status(400).json({ error: 'El correo electrónico no es válido' });
        }

        const billingResult = resolveBilling(req.body?.billing, shippingData);
        if (billingResult.error) return res.status(400).json({ error: billingResult.error });

        const shipping = getShippingCost(shippingData.region, subtotal);
        const requestedDiscountCode = safeText(req.body?.discountCode, 80);
        let discountUserKey = null;
        let discount = 0;
        let resolvedDiscount = null;

        if (requestedDiscountCode) {
            const eligibilityError = getDiscountEligibilityError(decodedToken);
            if (eligibilityError) return res.status(400).json({ error: eligibilityError });
            discountUserKey = getDiscountUserKey(decodedToken);
            resolvedDiscount = await resolveDiscountCode(db, requestedDiscountCode, discountUserKey);
            if (!resolvedDiscount.ok) return res.status(400).json({ error: resolvedDiscount.error });
            discount = computeDiscountAmount(resolvedDiscount.discountData, subtotal, shipping);
        }

        const now = new Date().toISOString();
        const orderId = crypto.randomUUID();
        const order = {
            id: orderId,
            userId: decodedToken.uid,
            userName: safeText(decodedToken.name, 120) || shippingData.firstName,
            userEmail: shippingData.email,
            items: orderItems,
            shippingData,
            billing: billingResult.billing,
            totals: { subtotal, shipping, discount, total: subtotal + shipping - discount },
            discountCode: resolvedDiscount?.code || null,
            // El uso del código se descuenta al confirmarse el pago (markOrderAsPaid), no aquí:
            // un pedido que nunca se paga no consume cupones.
            discountDocId: resolvedDiscount?.discountDocId || null,
            discountUserKey,
            // Marca de orden calculada por el servidor: los pagos solo aceptan
            // descuentos de órdenes con esta marca (el cliente no puede escribirla).
            pricingSource: 'server',
            guestCheckout: decodedToken?.firebase?.sign_in_provider === 'anonymous',
            status: 'pending',
            paymentMethod: safeText(req.body?.paymentMethod, 40) || 'mercado_pago',
            createdAt: now,
            updatedAt: now
        };

        const orderRef = db.collection('orders').doc(orderId);
        await db.runTransaction(async transaction => {
            // --- TODAS LAS LECTURAS PRIMERO (requisito de Firestore) ---
            // Número de orden corto para la boleta y el seguimiento
            const { code, ref: codeRef } = await tracking.reserveCode(db, transaction);

            // Cupón: se relee dentro de la transacción y se valida contra los usos ya PAGADOS.
            // Un pedido anterior de la misma cuenta, aún sin pagar y con el mismo código, se
            // reemplaza por este (queda cancelado): así no se juntan varios pedidos impagos con
            // descuento, y quien volvió de Mercado Pago sin pagar puede comprar de nuevo.
            let replacedOrders = [];
            if (resolvedDiscount?.ok && discountUserKey) {
                const discountRef = db.collection('discountCodes').doc(resolvedDiscount.discountDocId);
                const [discountSnap, pendingSnap] = await Promise.all([
                    transaction.get(discountRef),
                    transaction.get(db.collection('orders')
                        .where('userId', '==', decodedToken.uid)
                        .where('status', '==', 'pending'))
                ]);
                if (!discountSnap.exists) throw Object.assign(new Error('Código de descuento no válido'), { status: 400 });
                const fresh = discountSnap.data() || {};
                const expired = fresh.expiresAt && new Date(fresh.expiresAt).getTime() < Date.now();
                const usedCount = Number(fresh.usedCount || 0);
                const usedByUser = Number(fresh.usersApplied?.[discountUserKey] || 0);
                if (fresh.active === false || expired || usedCount >= Number(fresh.maxUses || Infinity)) {
                    throw Object.assign(new Error('Este código ya no está disponible'), { status: 400 });
                }
                if (usedByUser >= Number(fresh.usesPerUser || Infinity)) {
                    throw Object.assign(new Error('Ya usaste este código el máximo de veces permitido'), { status: 400 });
                }
                replacedOrders = pendingSnap.docs
                    .filter(docSnap => docSnap.data()?.discountDocId === resolvedDiscount.discountDocId)
                    .map(docSnap => docSnap.ref);
            }

            // --- ESCRITURAS ---
            const nowIso = new Date().toISOString();
            replacedOrders.forEach(ref => transaction.update(ref, {
                status: 'cancelled',
                cancelReason: 'replaced_by_new_order',
                replacedByOrderId: orderId,
                cancelledAt: nowIso,
                updatedAt: nowIso
            }));
            order.trackingCode = tracking.formatCode(code);
            transaction.create(codeRef, tracking.codeRecord(orderId, code));
            transaction.create(orderRef, order);
        });

        return res.status(201).json({ order });
    } catch (error) {
        if (error?.status === 400) {
            return res.status(400).json({ error: error.message });
        }
        console.error('Error creando orden:', error);
        return res.status(500).json({ error: 'No se pudo crear la orden' });
    }
});

// ---------- Cancelar un pedido (admin o bodega) ----------
// Cancela y, si el pedido ya había descontado stock al pagarse, lo devuelve en la misma
// transacción (una sola vez). Un reembolso NO repone stock: el producto aún no ha vuelto.
const CANCELLABLE_BY_ROLE = {
    admin: ['pending', 'payment_failed', 'payment_validation_failed', 'paid', 'shipped', 'delivered'],
    bodeguero: ['paid', 'shipped', 'delivered']
};

router.post('/:orderId/cancel', async (req, res) => {
    try {
        const decodedToken = await verifyIdTokenSafe(getBearerToken(req));
        if (!decodedToken?.uid) return res.status(401).json({ error: 'Sesión inválida o expirada' });

        const db = getFirestoreAdminSafe();
        if (!db) return res.status(503).json({ error: 'Firestore no disponible' });

        const userSnap = await db.collection('users').doc(decodedToken.uid).get();
        const role = userSnap.exists ? userSnap.data()?.role : '';
        if (!CANCELLABLE_BY_ROLE[role]) return res.status(403).json({ error: 'No tienes permiso para cancelar pedidos' });

        const orderId = safeText(req.params.orderId, 128);
        const orderRef = db.collection('orders').doc(orderId);
        const result = await db.runTransaction(async transaction => {
            const orderSnap = await transaction.get(orderRef);
            if (!orderSnap.exists) throw Object.assign(new Error('Pedido no encontrado'), { status: 404 });
            const order = orderSnap.data() || {};
            const status = String(order.status || '').toLowerCase();
            if (!CANCELLABLE_BY_ROLE[role].includes(status)) {
                throw Object.assign(new Error('Este pedido no se puede cancelar en su estado actual'), { status: 409 });
            }

            // Lecturas antes de escribir: productos a reponer
            const restore = new Map();
            if (order.inventoryAdjustedAt && !order.stockRestoredAt) {
                for (const item of Array.isArray(order.items) ? order.items : []) {
                    const productId = String(item?.id || item?.productId || '').trim();
                    const quantity = Math.max(0, Number.parseInt(item?.quantity, 10) || 0);
                    if (productId && quantity > 0) restore.set(productId, (restore.get(productId) || 0) + quantity);
                }
            }
            const productIds = [...restore.keys()];
            const productSnaps = productIds.length
                ? await transaction.getAll(...productIds.map(id => db.collection('products').doc(id)))
                : [];

            const nowIso = new Date().toISOString();
            productSnaps.forEach((productSnap, index) => {
                if (!productSnap.exists) return;
                const product = productSnap.data() || {};
                const quantity = restore.get(productIds[index]);
                // Producto que la bodega marcó como agotado: se suma a lo que devolverá "Volver a mostrar"
                if (Number.isInteger(product.stockBeforeOutOfStock)) {
                    transaction.update(productSnap.ref, { stockBeforeOutOfStock: product.stockBeforeOutOfStock + quantity, updatedAt: nowIso });
                } else {
                    transaction.update(productSnap.ref, { stock: (Number.parseInt(product.stock, 10) || 0) + quantity, updatedAt: nowIso });
                }
            });

            transaction.update(orderRef, {
                status: 'cancelled',
                paymentStatus: order.paymentStatus === 'approved' ? 'approved' : 'cancelled',
                cancelledAt: nowIso,
                cancelledBy: decodedToken.uid,
                cancelledByRole: role,
                ...(productIds.length ? { stockRestoredAt: nowIso } : {}),
                updatedAt: nowIso
            });
            return { restoredItems: productIds.length };
        });

        return res.json({ cancelled: true, ...result });
    } catch (error) {
        if (error?.status) return res.status(error.status).json({ error: error.message });
        console.error('Error cancelando pedido:', error);
        return res.status(500).json({ error: 'No se pudo cancelar el pedido' });
    }
});

// ---------- Seguimiento público de pedidos ----------
// Para invitados y usuarios: número de orden + correo o RUT de la compra, o el enlace firmado
// de los correos. Límite estricto de intentos para que no se puedan adivinar números.
const trackLimiter = createLimiter({
    windowMs: 15 * 60 * 1000,
    max: Number(process.env.ORDER_TRACK_MAX_ATTEMPTS) || 10,
    standardHeaders: true,
    legacyHeaders: false,
    // Los intentos correctos no cuentan: solo se limita a quien prueba datos que no coinciden
    skipSuccessfulRequests: true,
    message: { error: 'Hiciste demasiados intentos. Espera unos minutos e inténtalo de nuevo.' }
});

const NOT_FOUND_MESSAGE = 'No encontramos una compra con esos datos. Revisa el número de orden y el correo o RUT.';
const TRACKING_EXPIRED_MESSAGE = 'Este pedido ya fue entregado y su seguimiento venció. Si tienes cuenta, puedes verlo en "Mis compras".';

router.post('/track', trackLimiter, async (req, res) => {
    try {
        const code = tracking.normalizeCode(req.body?.code);
        const contact = safeText(req.body?.contact, 254);
        const token = safeText(req.body?.token, 64);
        // Mismo mensaje para todo error de datos: no revela si el número existe
        if (!code || (!contact && !token)) return res.status(404).json({ error: NOT_FOUND_MESSAGE });

        const db = getFirestoreAdminSafe();
        if (!db) return res.status(503).json({ error: 'Servicio no disponible' });

        const codeSnap = await db.collection(tracking.CODES_COLLECTION).doc(code).get();
        const orderId = codeSnap.exists ? codeSnap.data()?.orderId : null;
        const orderSnap = orderId ? await db.collection('orders').doc(String(orderId)).get() : null;
        if (!orderSnap?.exists) return res.status(404).json({ error: NOT_FOUND_MESSAGE });

        const order = orderSnap.data() || {};
        const allowed = token
            ? tracking.isValidLinkToken(orderSnap.id, token)
            : tracking.contactMatches(order, contact);
        if (!allowed) return res.status(404).json({ error: NOT_FOUND_MESSAGE });

        // Después de entregado, el seguimiento público dura 2 días y luego vence
        if (tracking.isPublicTrackingExpired(order)) {
            return res.status(410).json({ error: TRACKING_EXPIRED_MESSAGE });
        }

        res.set('Cache-Control', 'no-store');
        return res.json({ order: tracking.publicOrder(order) });
    } catch (error) {
        console.error('Error en seguimiento de pedido:', error);
        return res.status(500).json({ error: 'No se pudo consultar el pedido' });
    }
});

module.exports = router;
