// routes/webhook.js - Mercado Pago Webhook Handler
const express = require('express');
const router = express.Router();
const mercadopago = require('mercadopago');
const { safeCompareTokens } = require('../utils/security');
const { getFirestoreAdminSafe } = require('../lib/firebase-admin');
const whatsappService = require('../services/whatsapp');
const {
    buildOrderItemsSignature,
    checkExpectedAmount,
    findOrderByReference,
    markOrderAsPaid,
    normalizeEntityId,
    verifyMercadoPagoPaymentOrigin
} = require('../lib/order-payment');

const REVERSED_PAYMENT_STATUSES = new Set(['refunded', 'charged_back', 'cancelled', 'in_mediation']);

// Registra la reversión en el pedido pagado con ESE pago. Un pedido aún no despachado pasa a
// "refunded" para que la bodega no lo envíe; uno ya enviado solo queda marcado para revisión.
async function recordPaymentReversal(payment) {
    const db = getFirestoreAdminSafe();
    const order = await findOrderByReference(payment.external_reference);
    if (!db || !order?.firestoreDocId) return;

    const orderRef = db.collection('orders').doc(order.firestoreDocId);
    await db.runTransaction(async (transaction) => {
        const snap = await transaction.get(orderRef);
        if (!snap.exists) return;
        const current = snap.data() || {};
        const paidWithThisPayment = normalizeEntityId(current.mercadoPagoPaymentId || current.paymentGatewayPaymentId)
            === normalizeEntityId(payment.id);
        if (!paidWithThisPayment) return;
        // Reembolso hecho desde el admin: el pedido ya quedó reembolsado, no hay nada que revisar
        if (String(current.status || '').toLowerCase() === 'refunded' && payment.status === 'refunded') return;

        const nowIso = new Date().toISOString();
        const update = {
            paymentReversalStatus: payment.status,
            paymentReversalDetail: String(payment.status_detail || '').slice(0, 120),
            paymentReversalAt: nowIso,
            needsReview: true,
            updatedAt: nowIso
        };
        if (String(current.status || '').toLowerCase() === 'paid' && payment.status !== 'in_mediation') {
            update.status = 'refunded';
            update.paymentStatus = payment.status;
        }
        transaction.set(orderRef, update, { merge: true });
    });
    console.warn(`⚠️ Pago ${payment.id} revertido (${payment.status}); orden ${order.id} marcada para revisión`);
}

function getWebhookType(req) {
    return req.query.type || req.body?.type || req.body?.topic || null;
}

function getWebhookPaymentId(req) {
    const queryData = req.query.data;
    const queryDataId = req.query['data.id'];
    const bodyDataId = req.body?.data?.id;
    const bodyResource = req.body?.resource;

    const candidates = [
        queryData?.id,
        queryDataId,
        bodyDataId,
        bodyResource
    ];

    for (const candidate of candidates) {
        if (candidate == null) {
            continue;
        }

        const asString = String(candidate).trim();
        if (/^\d+$/.test(asString)) {
            return asString;
        }
    }

    return null;
}

function parseMercadoPagoSignature(signatureHeader) {
    if (typeof signatureHeader !== 'string' || !signatureHeader.trim()) {
        return null;
    }

    const values = {};
    signatureHeader.split(',').forEach((part) => {
        const [key, value] = part.split('=');
        if (!key || !value) return;
        values[key.trim()] = value.trim();
    });

    if (!values.ts || !values.v1) {
        return null;
    }

    return {
        ts: values.ts,
        v1: values.v1
    };
}

function verifyMercadoPagoSignature(req, webhookSecret) {
    if (typeof webhookSecret !== 'string' || !webhookSecret.trim()) {
        return false;
    }

    const signatureHeader = req.headers['x-signature'];
    const requestId = req.headers['x-request-id'];
    const parsed = parseMercadoPagoSignature(signatureHeader);
    const paymentId = getWebhookPaymentId(req);

    if (!parsed || typeof requestId !== 'string' || !paymentId) {
        return false;
    }

    const timestamp = Number(parsed.ts);
    const maxAgeSeconds = Number(process.env.WEBHOOK_MAX_AGE_SECONDS) || 300;
    if (!Number.isInteger(timestamp) || Math.abs(Math.floor(Date.now() / 1000) - timestamp) > maxAgeSeconds) {
        return false;
    }

    const manifest = `id:${paymentId};request-id:${requestId};ts:${parsed.ts};`;
    const expectedHash = require('crypto')
        .createHmac('sha256', webhookSecret)
        .update(manifest)
        .digest('hex');

    return safeCompareTokens(parsed.v1, expectedHash);
}

function requireWebhookAuth(req, res, next) {
    const webhookSecret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
    if (webhookSecret) {
        const signatureValid = verifyMercadoPagoSignature(req, webhookSecret);
        if (signatureValid) {
            return next();
        }
        return res.status(401).json({ error: 'Firma de webhook inválida' });
    }

    if (process.env.NODE_ENV === 'production') {
        return res.status(500).json({ error: 'MERCADOPAGO_WEBHOOK_SECRET no configurado en producción' });
    }

    const configuredToken = String(process.env.WEBHOOK_TOKEN || '').trim();
    const providedToken = req.headers['x-webhook-token'];

    if (!configuredToken) {
        if (['development', 'test'].includes(process.env.NODE_ENV)) {
            return next();
        }

        return res.status(500).json({ error: 'Autenticación de webhook no configurada' });
    }

    if (!safeCompareTokens(providedToken, configuredToken)) {
        return res.status(401).json({ error: 'Webhook no autorizado' });
    }

    next();
}
function getMercadoPagoClient() {
    const accessToken = String(process.env.MERCADOPAGO_ACCESS_TOKEN || '').trim();
    if (!accessToken) {
        return null;
    }

    return new mercadopago.MercadoPagoConfig({
        accessToken,
        options: { timeout: 5000 }
    });
}

async function markOrderProcessingFailure(order, reason, payment) {
    const db = getFirestoreAdminSafe();
    if (!db || !order?.firestoreDocId) {
        return;
    }

    const nowIso = new Date().toISOString();
    await db.collection('orders').doc(order.firestoreDocId).set({
        paymentProcessingStatus: 'failed',
        paymentProcessingError: String(reason || 'Error desconocido').slice(0, 500),
        paymentProcessingUpdatedAt: nowIso,
        mercadoPagoPaymentId: String(payment?.id || '').trim() || null,
        mercadoPagoStatus: payment?.status || null,
        updatedAt: nowIso
    }, { merge: true });
}

async function markOrderValidationFailure(order, validationStatus, details, payment) {
    const db = getFirestoreAdminSafe();
    if (!db || !order?.firestoreDocId) {
        return;
    }

    const nowIso = new Date().toISOString();
    await db.collection('orders').doc(order.firestoreDocId).set({
        paymentValidationStatus: String(validationStatus || 'validation_failed').slice(0, 80),
        paymentValidationDetails: String(details || 'Validacion de pago fallida').slice(0, 500),
        paymentValidationUpdatedAt: nowIso,
        paymentProcessingStatus: 'failed',
        paymentProcessingError: String(details || 'Validacion de pago fallida').slice(0, 500),
        paymentProcessingUpdatedAt: nowIso,
        paymentReceivedAmount: Number(payment?.transaction_amount) || null,
        mercadoPagoPaymentId: String(payment?.id || '').trim() || null,
        mercadoPagoStatus: payment?.status || null,
        updatedAt: nowIso
    }, { merge: true });
}

/**
 * POST /webhook/mercadopago
 * Escuchar notificaciones de Mercado Pago
 */
router.post('/mercadopago', requireWebhookAuth, async (req, res) => {
    try {
        const client = getMercadoPagoClient();
        if (!client) {
            return res.status(503).json({ error: 'MERCADOPAGO_ACCESS_TOKEN no configurado en backend' });
        }

        const type = getWebhookType(req);

        if (type === 'payment') {
            const paymentId = getWebhookPaymentId(req);

            if (!paymentId) {
                return res.status(400).json({ error: 'payment_id inválido' });
            }

            // Obtener detalles del pago
            const paymentClient = new mercadopago.Payment(client);
            const payment = await paymentClient.get(paymentId);

            const paymentData = {
                id: payment.id,
                status: payment.status,
                status_detail: payment.status_detail,
                amount: payment.transaction_amount,
                external_reference: payment.external_reference
            };

            console.log('💰 Notificación de pago recibida:', paymentData);

            // 🔔 ENVIAR NOTIFICACIÓN POR WHATSAPP SI EL PAGO FUE APROBADO
            if (payment.status === 'approved') {
                console.log('✅ Pago aprobado, buscando orden para enviar WhatsApp...');

                let order = null;
                try {
                    const orderReference = payment.external_reference;
                    order = await findOrderByReference(orderReference);

                    if (!order) {
                        console.warn(`⚠️ No se encontró orden para referencia ${orderReference}`);
                    } else {
                        // El monto cobrado debe coincidir con el que el servidor calculó al crear el pago.
                        // Si la orden no tiene monto esperado tampoco se puede dar por válida.
                        const amountCheck = checkExpectedAmount(order, payment.transaction_amount);

                        if (!amountCheck.ok) {
                            console.warn(`⚠️ Pago no válido para ${order.id}: ${amountCheck.details}`);

                            await markOrderValidationFailure(
                                order,
                                amountCheck.reason,
                                amountCheck.details,
                                payment
                            );

                            return res.status(200).json({
                                success: true,
                                message: 'Webhook recibido con monto inconsistente, orden marcada para revision'
                            });
                        }

                        const expectedSignature = normalizeEntityId(order.paymentItemsSignature);
                        const currentSignature = buildOrderItemsSignature(order.items);
                        if (expectedSignature && currentSignature && expectedSignature !== currentSignature) {
                            console.warn(`⚠️ Firma de items inconsistente para orden ${order.id}`);
                            await markOrderValidationFailure(
                                order,
                                'items_signature_mismatch',
                                'La firma esperada de items no coincide con la orden persistida',
                                payment
                            );
                            return res.status(200).json({
                                success: true,
                                message: 'Webhook recibido con firma inconsistente, orden marcada para revision'
                            });
                        }

                        // El pago debe salir de una preferencia de esta orden (no basta external_reference + monto)
                        const originCheck = await verifyMercadoPagoPaymentOrigin(order, payment, client);
                        if (!originCheck.ok) {
                            console.warn(`⚠️ Pago de origen no verificado para ${order.id}: ${originCheck.details}`);
                            // Si Mercado Pago no respondió, que reintente el aviso
                            if (originCheck.reason === 'merchant_order_unavailable') {
                                return res.status(500).json({ error: 'No se pudo verificar el pago; reintentar' });
                            }
                            await markOrderValidationFailure(order, originCheck.reason, originCheck.details, payment);
                            return res.status(200).json({
                                success: true,
                                message: 'Webhook recibido con pago de origen no verificado, orden marcada para revision'
                            });
                        }

                        // Misma lógica que /confirm, /sync-pending y Webpay: solo un pedido pendiente pasa a
                        // pagado (y descuenta stock una vez); un aviso tardío no deshace envíos ni cancelaciones.
                        // También envía la boleta una sola vez.
                        await markOrderAsPaid(order, {
                            paymentMethod: 'mercado_pago',
                            gatewayPaymentId: String(payment.id || '').trim(),
                            gatewayStatus: payment.status || 'approved',
                            paymentDate: payment.date_approved || payment.date_created || new Date().toISOString()
                        });
                        // El aviso de "pedido pagado" solo va si el pedido quedó realmente pagado
                        order = await findOrderByReference(orderReference) || order;
                    }
                } catch (error) {
                    console.error('❌ Error crítico procesando pago aprobado:', error.message);
                    await markOrderProcessingFailure(order, error.message, payment);
                    return res.status(500).json({
                        error: 'Error aplicando pago aprobado'
                    });
                }

                const orderIsPaid = ['paid', 'shipped', 'delivered'].includes(String(order?.status || '').toLowerCase());
                if (order && orderIsPaid) {
                    try {
                        if (order.whatsappSentAt) {
                            console.log(`ℹ️ WhatsApp ya enviado para orden ${order.id}`);
                        } else if (!whatsappService.isEnabled()) {
                            console.warn('⚠️ Twilio no configurado; se omite notificación WhatsApp');
                        } else {
                            const result = await whatsappService.sendPaidOrderNotification(order);
                            console.log(`✅ WhatsApp enviado desde webhook. SID: ${result.messageId}`);
                            const db = getFirestoreAdminSafe();
                            if (db && order.firestoreDocId) {
                                await db.collection('orders').doc(order.firestoreDocId).set({
                                    whatsappSentAt: new Date().toISOString()
                                }, { merge: true });
                            }
                        }
                    } catch (notifyError) {
                        console.warn('⚠️ Error enviando WhatsApp (no bloqueante):', notifyError.message);
                    }
                }
            }

            // Pago revertido fuera de la app (reembolso desde el panel, contracargo, reclamo):
            // el pedido no debe seguir como pagado y listo para despachar.
            if (REVERSED_PAYMENT_STATUSES.has(payment.status)) {
                await recordPaymentReversal(payment);
            }

            // Responder a Mercado Pago
            res.status(200).json({
                success: true,
                message: 'Webhook procesado correctamente'
            });
        } else {
            res.status(200).json({ message: 'Notificación recibida' });
        }

    } catch (error) {
        console.error('❌ Error procesando webhook:', error);
        res.status(500).json({ error: 'Error procesando webhook' });
    }
});

/**
 * GET /webhook/test
 * Test endpoint para verificar que el webhook está funcionando
 */
router.get('/test', (req, res) => {
    if (['production', 'staging'].includes(process.env.NODE_ENV)) {
        return res.status(404).json({ error: 'No encontrado' });
    }

    res.json({ 
        message: '✅ Webhook está activo',
        timestamp: new Date().toISOString()
    });
});

module.exports = router;
