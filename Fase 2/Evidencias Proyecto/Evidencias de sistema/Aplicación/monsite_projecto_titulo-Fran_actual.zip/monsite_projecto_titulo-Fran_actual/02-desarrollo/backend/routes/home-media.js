// home-media.js - Videos del inicio (admin)
// El procesador de videos (monsite-media-staging) es un servicio privado de Cloud Run.
// Esta ruta verifica que quien llama sea administrador y le reenvía el pedido con la
// identidad de la cuenta de servicio del backend (X-Serverless-Authorization), junto
// con la sesión del administrador para que el procesador la verifique también.
const express = require('express');
const requireAdmin = require('../middleware/require-admin');

const router = express.Router();
const MEDIA_WORKER_URL = (process.env.MEDIA_WORKER_URL || 'https://monsite-media-staging-736268363141.southamerica-west1.run.app').replace(/\/$/, '');
const METADATA_IDENTITY_URL = 'http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/identity';
// Un tutorial de 90 s puede tardar algunos minutos en optimizarse
const WORKER_TIMEOUT_MS = 14 * 60 * 1000;

async function getIdentityToken() {
    const response = await fetch(`${METADATA_IDENTITY_URL}?audience=${encodeURIComponent(MEDIA_WORKER_URL)}`, {
        headers: { 'Metadata-Flavor': 'Google' },
        signal: AbortSignal.timeout(5000)
    });
    if (!response.ok) throw new Error(`metadata ${response.status}`);
    return response.text();
}

async function forward(req, res, workerPath) {
    try {
        const identityToken = await getIdentityToken();
        const response = await fetch(`${MEDIA_WORKER_URL}${workerPath}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: req.get('authorization'),
                'X-Serverless-Authorization': `Bearer ${identityToken}`
            },
            body: JSON.stringify(req.body || {}),
            signal: AbortSignal.timeout(WORKER_TIMEOUT_MS)
        });
        const payload = await response.json().catch(() => ({ error: 'Respuesta inválida del procesador de videos' }));
        return res.status(response.status).json(payload);
    } catch (error) {
        console.error('Error contactando al procesador de videos:', error.message);
        const timedOut = error.name === 'TimeoutError';
        return res.status(timedOut ? 504 : 502).json({
            error: timedOut ? 'El procesamiento tardó demasiado. Prueba con un video más corto.' : 'El procesador de videos no está disponible'
        });
    }
}

router.post('/process', requireAdmin, (req, res) => forward(req, res, '/process'));
router.post('/config', requireAdmin, (req, res) => forward(req, res, '/config'));

module.exports = router;
