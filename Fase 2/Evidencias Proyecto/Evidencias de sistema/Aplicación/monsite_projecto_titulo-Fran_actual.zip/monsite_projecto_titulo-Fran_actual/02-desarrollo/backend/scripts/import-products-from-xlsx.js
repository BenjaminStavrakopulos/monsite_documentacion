const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const XLSX = require('xlsx');

const workbookPath = process.argv[2] || path.resolve(__dirname, '../../data/Catalogo_MONSITE_Etiquetas.xlsx');
const shouldApply = process.argv.includes('--apply');
const projectId = process.env.FIREBASE_PROJECT_ID || 'monsite-85424';
const firestoreBaseUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents`;
const firestoreDocumentBase = `projects/${projectId}/databases/(default)/documents`;

function normalizeHeader(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
}

function normalizeText(value) {
    return String(value == null ? '' : value).trim().replace(/\s+/g, ' ');
}

function getColumn(values, aliases) {
    for (const alias of aliases) {
        if (Object.prototype.hasOwnProperty.call(values, alias)) return values[alias];
    }
    return '';
}

function parseNumber(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
    const raw = normalizeText(value).replace(/[^\d,.-]/g, '');
    if (!raw) return 0;
    const normalized = raw.includes(',') && raw.includes('.')
        ? (raw.lastIndexOf(',') > raw.lastIndexOf('.') ? raw.replace(/\./g, '').replace(',', '.') : raw.replace(/,/g, ''))
        : raw.replace(/\./g, '').replace(',', '.');
    const number = Number(normalized);
    return Number.isFinite(number) ? number : 0;
}

function parseDiscount(value, listPrice, finalPrice) {
    const raw = normalizeText(value);
    if (!raw || /^0([,.]0+)?\s*%?$/.test(raw)) return null;

    const numericValue = typeof value === 'number'
        ? value
        : Number(String(value).replace(',', '.').replace(/[^\d.-]/g, ''));
    if (!Number.isFinite(numericValue) || numericValue <= 0) return null;

    const percent = numericValue <= 1 ? numericValue * 100 : numericValue;
    if (percent > 100) return null;
    return {
        discountType: 'percentage',
        discountPercent: percent,
        discountedPrice: finalPrice > 0 ? finalPrice : Math.round(listPrice * (1 - percent / 100))
    };
}

function slugify(value) {
    const slug = normalizeText(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
    return slug || `producto-${crypto.createHash('sha1').update(String(value)).digest('hex').slice(0, 12)}`;
}

function firestoreValue(value) {
    if (typeof value === 'boolean') return { booleanValue: value };
    if (typeof value === 'number') {
        return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
    }
    if (Array.isArray(value)) return { arrayValue: { values: value.map(firestoreValue) } };
    if (value && typeof value === 'object') {
        return { mapValue: { fields: Object.fromEntries(Object.entries(value).map(([key, item]) => [key, firestoreValue(item)])) } };
    }
    return { stringValue: String(value == null ? '' : value) };
}

function getAccessToken() {
    if (process.env.GOOGLE_ACCESS_TOKEN) return process.env.GOOGLE_ACCESS_TOKEN.trim();
    const candidates = [
        process.env.GCLOUD_PATH,
        'C:\\Program Files (x86)\\Google\\Cloud SDK\\google-cloud-sdk\\bin\\gcloud.cmd',
        'C:\\Program Files\\Google\\Cloud SDK\\google-cloud-sdk\\bin\\gcloud.cmd',
        'gcloud.cmd'
    ].filter(Boolean);
    const gcloud = candidates.find(candidate => candidate === 'gcloud.cmd' || fs.existsSync(candidate));
    if (!gcloud) throw new Error('No se encontró Google Cloud CLI para obtener un token temporal');
    const args = ['auth', 'print-access-token', `--project=${projectId}`];
    if (process.platform === 'win32' && gcloud.toLowerCase().endsWith('.cmd')) {
        const escapedPath = gcloud.replace(/'/g, "''");
        return execFileSync('powershell.exe', ['-NoProfile', '-Command', `& '${escapedPath}' ${args.join(' ')}`], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    }
    return execFileSync(gcloud, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
}

async function commitDocuments(documents) {
    const token = getAccessToken();
    const writes = documents.map(({ collection, id, data }) => ({
        update: {
            name: `${firestoreDocumentBase}/${collection}/${id}`,
            fields: Object.fromEntries(Object.entries(data).map(([key, value]) => [key, firestoreValue(value)]))
        },
        updateMask: collection === 'products'
            ? { fieldPaths: [...new Set([...Object.keys(data), 'discountType', 'discountPercent', 'discountAmount', 'discountedPrice'])] }
            : undefined
    }));
    const response = await fetch(`${firestoreBaseUrl}:commit`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ writes })
    });
    if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`Firestore commit HTTP ${response.status}: ${errorBody.slice(0, 500)}`);
    }
}

async function listCollection(collection) {
    const token = getAccessToken();
    const response = await fetch(`${firestoreBaseUrl}/${collection}?pageSize=1000`, {
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!response.ok) throw new Error(`No se pudo leer ${collection}: HTTP ${response.status}`);
    const payload = await response.json();
    return Array.isArray(payload.documents) ? payload.documents : [];
}

function firestoreDocumentFields(document) {
    const fields = document.fields || {};
    return Object.fromEntries(Object.entries(fields).map(([key, value]) => {
        if (value.integerValue != null) return [key, Number(value.integerValue)];
        if (value.doubleValue != null) return [key, Number(value.doubleValue)];
        if (value.stringValue != null) return [key, value.stringValue];
        return [key, null];
    }));
}

function nextSkuFactory(existingDocuments) {
    const skuByProductId = new Map();
    let sequence = existingDocuments.reduce((max, document) => {
        const fields = firestoreDocumentFields(document);
        const productId = String(fields.id || document.name?.split('/').pop() || '');
        const sku = String(fields.sku || '');
        const match = sku.match(/(\d+)$/);
        if (productId && /^PRD-\d+$/.test(sku)) skuByProductId.set(productId, sku);
        return match ? Math.max(max, Number.parseInt(match[1], 10)) : max;
    }, 0);
    return (productId) => {
        if (skuByProductId.has(productId)) return skuByProductId.get(productId);
        return `PRD-${String(++sequence).padStart(5, '0')}`;
    };
}

function buildImportRows(nextSku) {
    if (!fs.existsSync(workbookPath)) throw new Error(`No existe el Excel: ${workbookPath}`);
    const workbook = XLSX.readFile(workbookPath, { cellDates: false });
    const sheet = workbook.Sheets['Productos únicos'] || workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    const usedIds = new Set();
    const documents = [];
    const report = { rows: rows.length, valid: 0, skipped: 0, withDiscount: 0, withoutDiscount: 0, skippedRows: [], samples: [] };

    for (const row of rows) {
        const values = Object.fromEntries(Object.entries(row).map(([key, value]) => [normalizeHeader(key), value]));
        const name = normalizeText(getColumn(values, ['producto', 'nombre del producto', 'nombre producto', 'nombre']));
        const listPrice = parseNumber(getColumn(values, ['valor total / lista', 'valor total lista', 'precio lista', 'precio']));
        const finalPrice = parseNumber(getColumn(values, ['valor con descuento', 'precio final', 'precio con descuento']));
        if (!name || listPrice <= 0) {
            report.skipped += 1;
            if (report.skippedRows.length < 20) report.skippedRows.push({ name: name || '(sin nombre)', reason: !name ? 'nombre vacío' : 'precio de lista inválido' });
            continue;
        }

        let id = slugify(name);
        if (usedIds.has(id)) id = `${id}-${crypto.createHash('sha1').update(name).digest('hex').slice(0, 6)}`;
        usedIds.add(id);
        const discount = parseDiscount(getColumn(values, ['descuento', 'descuento porcentaje', 'rebaja']), listPrice, finalPrice);
        const now = new Date().toISOString();
        const category = normalizeText(getColumn(values, ['categoría', 'categoria', 'category']));
        const brand = normalizeText(getColumn(values, ['marca', 'brand']));
        const categoryId = category ? slugify(category) : '';
        const brandId = brand ? slugify(brand) : '';
        const product = {
            id,
            sku: nextSku(id),
            name,
            price: listPrice,
            description: normalizeText(getColumn(values, ['descripcion', 'descripción', 'detalle'])),
            usage: normalizeText(getColumn(values, ['modo de uso', 'uso', 'forma de uso'])),
            hairType: normalizeText(getColumn(values, ['para que tipo de pelo se usa', 'para qué tipo de pelo se usa', 'tipo de pelo', 'tipo pelo'])),
            image: '',
            stock: 10,
            active: true,
            updatedAt: now,
            createdAt: now
        };
        if (categoryId) product.category = categoryId;
        if (brandId) product.brand = brandId;
        if (discount) Object.assign(product, discount);
        documents.push({ collection: 'products', id, data: product });

        if (category) {
            const categoryId = slugify(category);
            documents.push({ collection: 'categories', id: categoryId, data: { id: categoryId, name: category, updatedAt: now } });
        }
        if (brand) {
            const brandId = slugify(brand);
            documents.push({ collection: 'brands', id: brandId, data: { id: brandId, name: brand, updatedAt: now } });
        }

        const label = normalizeText(getColumn(values, ['etiquetas / necesidad capilar', 'etiqueta', 'etiquetas', 'necesidad capilar']));
        if (label) {
            documents.push({ collection: 'productAiMetadata', id, data: { productId: id, label, updatedAt: now } });
        }
        report.valid += 1;
        if (discount) report.withDiscount += 1;
        else report.withoutDiscount += 1;
        if (report.samples.length < 5 || (discount && !report.samples.some(sample => sample.hasDiscount))) report.samples.push({
            id,
            name,
            price: listPrice,
            discountPercent: discount?.discountPercent || null,
            discountAmount: discount?.discountAmount || null,
            discountedPrice: discount?.discountedPrice || null,
            hasDiscount: Boolean(discount),
            hasAiLabel: Boolean(label)
        });
    }
    const uniqueDocuments = new Map();
    for (const document of documents) {
        uniqueDocuments.set(`${document.collection}/${document.id}`, document);
    }
    report.categories = [...uniqueDocuments.values()].filter(document => document.collection === 'categories').length;
    report.brands = [...uniqueDocuments.values()].filter(document => document.collection === 'brands').length;
    return { documents: [...uniqueDocuments.values()], report };
}

async function main() {
    const existingProducts = shouldApply ? await listCollection('products') : [];
    const nextSku = nextSkuFactory(existingProducts);
    const { documents, report } = buildImportRows(nextSku);
    console.log(JSON.stringify({ mode: shouldApply ? 'apply' : 'dry-run', projectId, ...report }, null, 2));
    if (shouldApply && documents.length > 0) await commitDocuments(documents);
    if (shouldApply) console.log(`Importación completada: ${documents.length} documentos escritos.`);
}

main().catch((error) => {
    console.error(`Importación fallida: ${error.message}`);
    process.exit(1);
});