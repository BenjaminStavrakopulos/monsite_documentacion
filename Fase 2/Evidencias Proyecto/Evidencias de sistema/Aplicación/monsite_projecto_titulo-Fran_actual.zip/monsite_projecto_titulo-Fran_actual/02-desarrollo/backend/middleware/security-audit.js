const crypto = require('crypto');
const { getFirestoreAdminSafe } = require('../lib/firebase-admin');

// req.ip ya respeta "trust proxy": el primer valor de X-Forwarded-For lo escribe el propio cliente
function getClientIp(req) {
    return String(req.ip || req.socket?.remoteAddress || 'unknown').trim().slice(0, 80);
}

function classifySecurityEvent(statusCode) {
    if (statusCode === 401) return 'unauthorized';
    if (statusCode === 403) return 'forbidden';
    if (statusCode === 429) return 'rate_limited';
    return 'server_error';
}

// Tipo de evento. Distingue ruido operativo (avisos de pago rechazados, orígenes no
// permitidos, sesiones vencidas) de intentos reales, para no confundir al revisar.
function classifyAttack(path, method, userAgent, statusCode, corsBlocked = false) {
    if (/\.env|\.git|phpmyadmin|wp-admin|wp-login/i.test(path)) return 'sensitive_path_scan';
    if (/^\/webhook/i.test(path) && /mercadopago/i.test(userAgent)) return 'payment_webhook_rejected';
    if (statusCode === 403 && (corsBlocked || method === 'OPTIONS')) return 'cors_blocked';
    if (statusCode === 429 && /\/api\/orders\/track/i.test(path)) return 'order_tracking_limit';
    if (statusCode === 429) return 'rate_limit';
    if (statusCode >= 500) return 'server_error';
    if (method === 'POST' && /login|auth/i.test(path)) return 'credential_attack';
    if (/\/order-status\//i.test(path) && statusCode === 401) return 'session_missing';
    return 'unauthorized_access';
}

function classifySeverity(category, attackType) {
    if (attackType === 'sensitive_path_scan' || attackType === 'credential_attack') return 'high';
    if (attackType === 'payment_webhook_rejected') return 'high';
    if (category === 'server_error' || category === 'rate_limited') return 'high';
    if (attackType === 'cors_blocked' || attackType === 'session_missing') return 'low';
    if (attackType === 'order_tracking_limit') return 'medium';
    if (category === 'forbidden') return 'medium';
    return 'low';
}

const DETECTIONS = {
    sensitive_path_scan: 'Búsqueda de archivos o paneles sensibles (.env, .git, wp-admin...). Típico de bots que escanean servidores.',
    payment_webhook_rejected: 'Aviso de Mercado Pago rechazado: la firma no coincide con la clave configurada o es un aviso antiguo (IPN) sin firma.',
    cors_blocked: 'Petición desde un sitio que no está en la lista de orígenes permitidos (CORS).',
    rate_limit: 'Demasiadas peticiones seguidas desde el mismo origen; se aplicó el límite.',
    order_tracking_limit: 'Demasiados intentos fallidos en "Sigue tu pedido" desde el mismo origen; se bloqueó por 15 minutos.',
    server_error: 'El servidor respondió con un error interno.',
    credential_attack: 'Intento de inicio de sesión o autenticación rechazado.',
    session_missing: 'Consulta de una orden sin sesión válida (sesión vencida o sin iniciar).',
    unauthorized_access: 'Solicitud sin permisos suficientes para esta ruta.'
};

// HMAC con una clave del servidor: un SHA-256 simple de una IPv4 se puede revertir probando las 4.300 millones de direcciones
const FALLBACK_HASH_SECRET = crypto.randomBytes(32).toString('hex');

function hashValue(value) {
    const secret = process.env.SECURITY_HASH_SECRET
        || process.env.WEBHOOK_TOKEN
        || process.env.MERCADOPAGO_WEBHOOK_SECRET
        || FALLBACK_HASH_SECRET;
    return crypto.createHmac('sha256', secret).update(String(value || '')).digest('hex').slice(0, 16);
}

// Los eventos se guardan 14 días y luego Firestore los borra automáticamente (TTL)
const EVENT_RETENTION_MS = (Number(process.env.SECURITY_EVENTS_RETENTION_DAYS) || 14) * 24 * 60 * 60 * 1000;

// Tope de eventos registrados: sin él, quien provoque 401/403/429 en bucle haría una escritura
// en Firestore por cada solicitud (costo) y llenaría la lista de eventos.
const EVENTS_WINDOW_MS = 60 * 1000;
const EVENTS_MAX_PER_IP = Number(process.env.SECURITY_EVENTS_MAX_PER_IP_MINUTE) || 20;
const EVENTS_MAX_TOTAL = Number(process.env.SECURITY_EVENTS_MAX_PER_MINUTE) || 300;
const eventCounters = new Map();
let eventsWindowStart = Date.now();
let eventsInWindow = 0;

function canRecordEvent(ipHash) {
    const now = Date.now();
    if (now - eventsWindowStart >= EVENTS_WINDOW_MS) {
        eventsWindowStart = now;
        eventsInWindow = 0;
        eventCounters.clear();
    }
    if (eventsInWindow >= EVENTS_MAX_TOTAL) return false;
    const count = eventCounters.get(ipHash) || 0;
    if (count >= EVENTS_MAX_PER_IP) return false;
    eventCounters.set(ipHash, count + 1);
    eventsInWindow += 1;
    return true;
}

async function persistSecurityEvent(event) {
    const db = getFirestoreAdminSafe();
    if (!db) return;

    try {
        await db.collection('securityEvents').doc(event.requestId).set(event, { merge: true });
    } catch (error) {
        console.error('Error guardando evento de seguridad:', {
            requestId: event.requestId,
            name: error?.name
        });
    }
}

function securityAudit(req, res, next) {
    const requestId = crypto.randomUUID();
    req.requestId = requestId;
    res.setHeader('X-Request-Id', requestId);

    res.on('finish', () => {
        const suspiciousResponse = res.statusCode === 401
            || res.statusCode === 403
            || res.statusCode === 429
            || res.statusCode >= 500;

        if (!suspiciousResponse) return;

        // Ruta completa (req.path queda recortada dentro de los routers montados)
        const fullPath = String(req.originalUrl || req.url || '').split('?')[0].slice(0, 200);
        const userAgent = String(req.get('user-agent') || '');
        const category = classifySecurityEvent(res.statusCode);
        const attackType = classifyAttack(fullPath, req.method, userAgent, res.statusCode, res.locals?.corsBlocked === true);

        const ipHash = hashValue(getClientIp(req));
        if (!canRecordEvent(ipHash)) return;

        const event = {
            event: 'security_request',
            requestId,
            method: req.method,
            path: fullPath,
            status: res.statusCode,
            category,
            attackType,
            severity: classifySeverity(category, attackType),
            blocked: res.statusCode === 401 || res.statusCode === 403 || res.statusCode === 429,
            ruleId: `WAF-${category.toUpperCase()}-001`,
            detection: DETECTIONS[attackType] || DETECTIONS.unauthorized_access,
            action: res.statusCode >= 500 ? 'Evento registrado para revisión' : 'Solicitud bloqueada',
            ipHash,
            userAgent: String(req.get('user-agent') || '').slice(0, 200),
            origin: String(req.get('origin') || '').slice(0, 200),
            timestamp: new Date().toISOString(),
            // Firestore borra el evento solo al vencer (política TTL sobre "expireAt")
            expireAt: new Date(Date.now() + EVENT_RETENTION_MS)
        };

        console.warn(JSON.stringify(event));
        void persistSecurityEvent(event);
    });

    return next();
}

module.exports = securityAudit;