// server.js - Procesador de videos del inicio (Monsite)
// El admin sube el video original a Storage (home-media-uploads/) y pide aquí el recorte.
// Este servicio lo recorta, lo optimiza con ffmpeg (misma calidad aprobada para el inicio),
// genera la portada (jpg) y la vista previa liviana, y publica la configuración del inicio
// en Firestore (siteContent/homeMedia). Es un servicio privado de Cloud Run: solo lo invoca
// el backend (IAM), que reenvía la sesión del administrador para verificarla aquí también.
const fs = require('fs/promises');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const express = require('express');
const admin = require('firebase-admin');

const BUCKET = process.env.STORAGE_BUCKET || 'monsite-85424.firebasestorage.app';
const PORT = Number(process.env.PORT) || 8080;

const MEDIA_PREFIX = 'home-media/';
const UPLOAD_PREFIX = 'home-media-uploads/';
const MAX_SOURCE_BYTES = 600 * 1024 * 1024;
const LIMITS = {
    hero: { min: 3, max: 15, width: 1920, crf: 24, maxrate: '5M', bufsize: '10M', audio: false },
    tutorial: { min: 5, max: 90, width: 1080, crf: 23, maxrate: '6M', bufsize: '12M', audio: true }
};
const MAX_TUTORIALS = 12;
const MAX_HERO_SLIDES = 6;
const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
const FFPROBE = process.env.FFPROBE_PATH || 'ffprobe';
// ffmpeg/ffprobe solo leen el archivo local descargado: nada de URLs ni listas que apunten a la red
const INPUT_PROTOCOLS = ['-protocol_whitelist', 'file'];
const FILE_NAME = /^[A-Za-z0-9_-]+\.(mp4|jpg)$/;
const SOURCE_PATH = /^home-media-uploads\/[A-Za-z0-9_-]+\.(mp4|mov|m4v|webm)$/i;
// Archivos recién procesados que todavía no se publican no se borran en la limpieza
const KEEP_UNPUBLISHED_MS = 6 * 60 * 60 * 1000;
// Videos con los que se lanzó el inicio: index.html los usa mientras carga la configuración,
// así que nunca se borran
const PROTECTED_FILES = new Set(['portada.mp4', 'portada.jpg',
    ...['no-frizz', 'moisture-rescue', 'flex-hairspray', 'triple-bond'].flatMap(key => [`${key}.mp4`, `${key}.jpg`, `${key}-preview.mp4`])]);

admin.initializeApp({ storageBucket: BUCKET });
const db = admin.firestore();
const bucket = admin.storage().bucket();
const configRef = db.collection('siteContent').doc('homeMedia');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));

// ---------- Autorización ----------
async function requireAdmin(req, res, next) {
    try {
        const match = (req.get('authorization') || '').match(/^Bearer\s+(.+)$/i);
        if (!match) return res.status(401).json({ error: 'Sesión inválida o expirada' });
        // checkRevoked: rechaza tokens de admins a los que se les revocó el acceso
        const decoded = await admin.auth().verifyIdToken(match[1].trim(), true);
        // Se exige el rol actual en Firestore (autoritativo), no solo el claim del token
        const user = await db.collection('users').doc(decoded.uid).get();
        if (!user.exists || user.data()?.role !== 'admin') {
            return res.status(403).json({ error: 'Se requiere rol de administrador' });
        }
        req.user = decoded;
        return next();
    } catch (error) {
        return res.status(401).json({ error: 'Sesión inválida o expirada' });
    }
}

// ---------- ffmpeg ----------
function run(command, args, timeoutMs = 12 * 60 * 1000) {
    return new Promise((resolve, reject) => {
        const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
        let stdout = '';
        let stderr = '';
        const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error(`${command} tardó demasiado`)); }, timeoutMs);
        child.stdout.on('data', chunk => { stdout += chunk; });
        child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-4000); });
        child.on('error', error => { clearTimeout(timer); reject(error); });
        child.on('close', code => {
            clearTimeout(timer);
            if (code === 0) resolve(stdout);
            else reject(new Error(`${command} terminó con código ${code}: ${stderr.split('\n').slice(-4).join(' ')}`));
        });
    });
}

async function probe(file) {
    const out = await run(FFPROBE, ['-v', 'error', ...INPUT_PROTOCOLS, '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height:stream_side_data=rotation:stream_tags=rotate:format=duration',
        '-of', 'json', file], 60 * 1000);
    const info = JSON.parse(out);
    const stream = info.streams?.[0];
    if (!stream) throw Object.assign(new Error('El archivo no tiene video'), { status: 400 });
    const rotation = Math.abs(Number(stream.side_data_list?.find(item => item.rotation != null)?.rotation ?? stream.tags?.rotate ?? 0)) % 180;
    const width = rotation === 90 ? stream.height : stream.width;
    const height = rotation === 90 ? stream.width : stream.height;
    return { width, height, duration: Number(info.format?.duration) || 0 };
}

// Recorta y optimiza: video final, portada (jpg) y, para tutoriales, vista previa de 4 s
async function encode(kind, input, workDir, info, startInput, durationInput) {
    const limits = LIMITS[kind];
    const start = Math.max(0, Math.min(Number(startInput) || 0, Math.max(0, info.duration - limits.min)));
    // Lo que queda del video desde el inicio elegido debe alcanzar el mínimo (antes el mínimo se
    // imponía con Math.max y un video demasiado corto nunca se rechazaba)
    const available = info.duration - start;
    if (!(available >= limits.min - 0.05)) throw Object.assign(new Error(`El video debe durar al menos ${limits.min} segundos`), { status: 400 });
    const duration = Math.min(Math.max(Number(durationInput) || limits.max, limits.min), limits.max, available);

    const scale = `scale='min(${limits.width},iw)':-2`;
    const videoOut = path.join(workDir, 'video.mp4');
    const posterOut = path.join(workDir, 'poster.jpg');

    await run(FFMPEG, ['-y', '-ss', String(start), '-t', String(duration), ...INPUT_PROTOCOLS, '-i', input,
        '-map', '0:v:0', ...(limits.audio ? ['-map', '0:a:0?', '-c:a', 'aac', '-b:a', '128k'] : ['-an']),
        '-vf', scale, '-c:v', 'libx264', '-preset', 'medium', '-crf', String(limits.crf),
        '-maxrate', limits.maxrate, '-bufsize', limits.bufsize, '-pix_fmt', 'yuv420p',
        '-movflags', '+faststart', videoOut]);
    await run(FFMPEG, ['-y', '-ss', String(Math.min(start + 0.5, start + duration / 2)), ...INPUT_PROTOCOLS, '-i', input,
        '-frames:v', '1', '-vf', scale, '-q:v', '3', posterOut], 2 * 60 * 1000);

    let preview = null;
    if (kind === 'tutorial') {
        preview = path.join(workDir, 'preview.mp4');
        await run(FFMPEG, ['-y', '-ss', String(start), '-t', String(Math.min(4, duration)), ...INPUT_PROTOCOLS, '-i', input,
            '-an', '-vf', 'scale=360:-2', '-c:v', 'libx264', '-preset', 'medium', '-crf', '28',
            '-pix_fmt', 'yuv420p', '-movflags', '+faststart', preview], 3 * 60 * 1000);
    }
    return { video: videoOut, poster: posterOut, preview, start, duration };
}

const newName = (base, ext) => `${base}-${Date.now().toString(36)}${crypto.randomBytes(3).toString('hex')}.${ext}`;

async function upload(localFile, name, contentType) {
    await bucket.upload(localFile, {
        destination: MEDIA_PREFIX + name,
        resumable: false,
        metadata: { contentType, cacheControl: 'public, max-age=31536000, immutable' }
    });
    return name;
}

// ---------- Rutas ----------
app.get('/health', (req, res) => res.json({ ok: true }));

// Recorta y optimiza un video subido. No publica: devuelve los archivos para que el admin
// los vea y decida guardar.
app.post('/process', requireAdmin, async (req, res) => {
    const { kind, source } = req.body || {};
    const limits = LIMITS[kind];
    if (!limits) return res.status(400).json({ error: 'Tipo de video inválido' });
    if (typeof source !== 'string' || !SOURCE_PATH.test(source)) return res.status(400).json({ error: 'Archivo de origen inválido' });

    const workDir = await fs.mkdtemp(path.join(os.tmpdir(), 'media-'));
    const sourceFile = bucket.file(source);
    try {
        const [metadata] = await sourceFile.getMetadata().catch(() => [null]);
        if (!metadata) return res.status(404).json({ error: 'No se encontró el video subido' });
        if (Number(metadata.size) > MAX_SOURCE_BYTES) return res.status(413).json({ error: 'El video supera los 600 MB' });

        const input = path.join(workDir, 'source' + path.extname(source).toLowerCase());
        await sourceFile.download({ destination: input });
        const info = await probe(input);

        if (kind === 'hero' && info.height > info.width) return res.status(400).json({ error: 'La portada necesita un video horizontal' });
        if (kind === 'tutorial' && info.width > info.height) return res.status(400).json({ error: 'Los tutoriales necesitan un video vertical' });

        const encoded = await encode(kind, input, workDir, info, req.body.start, req.body.duration);

        const base = kind === 'hero' ? 'portada' : 'tutorial';
        const result = {
            video: await upload(encoded.video, newName(base, 'mp4'), 'video/mp4'),
            poster: await upload(encoded.poster, newName(base, 'jpg'), 'image/jpeg'),
            duration: Math.round(encoded.duration),
            width: info.width,
            height: info.height
        };
        if (encoded.preview) result.preview = await upload(encoded.preview, newName(base + '-preview', 'mp4'), 'video/mp4');

        await sourceFile.delete().catch(() => {});
        return res.json(result);
    } catch (error) {
        console.error('Error procesando video:', error);
        return res.status(error.status || 500).json({ error: error.status ? error.message : 'No se pudo procesar el video' });
    } finally {
        fs.rm(workDir, { recursive: true, force: true }).catch(() => {});
    }
});

// ---------- Configuración del inicio ----------
const text = (value, max) => String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, max);
const fileName = value => (typeof value === 'string' && FILE_NAME.test(value) ? value : null);

// Portada: carrusel de videos (al terminar uno pasa al siguiente). Acepta también el
// formato anterior de un solo video ({ hero: { video, poster, ... } }).
function sanitizeSlide(slide, index) {
    const linkHref = text(slide?.linkHref, 200);
    const entry = {
        video: fileName(slide?.video),
        poster: fileName(slide?.poster),
        eyebrow: text(slide?.eyebrow, 40),
        title: text(slide?.title, 60),
        linkText: text(slide?.linkText, 40),
        // Solo enlaces internos al catálogo
        linkHref: /^products\.html(\?[A-Za-z0-9=&_%.-]*)?$/.test(linkHref) ? linkHref : 'products.html',
        alt: text(slide?.alt, 120)
    };
    if (!entry.video || !entry.poster) throw Object.assign(new Error(`Falta el video ${index + 1} de la portada`), { status: 400 });
    return entry;
}

function sanitizeConfig(input) {
    const hero = input?.hero || {};
    const slides = Array.isArray(hero.slides) ? hero.slides : [hero];
    if (!slides.length) throw Object.assign(new Error('La portada necesita al menos un video'), { status: 400 });
    const config = {
        hero: { slides: slides.slice(0, MAX_HERO_SLIDES).map(sanitizeSlide) },
        tutorials: []
    };

    const tutorials = Array.isArray(input?.tutorials) ? input.tutorials.slice(0, MAX_TUTORIALS) : [];
    tutorials.forEach((item, index) => {
        const entry = {
            id: text(item?.id, 40).replace(/[^A-Za-z0-9_-]/g, '') || `t${index + 1}`,
            title: text(item?.title, 80),
            brand: text(item?.brand, 40),
            duration: Math.max(0, Math.min(600, Math.round(Number(item?.duration) || 0))),
            video: fileName(item?.video),
            poster: fileName(item?.poster),
            preview: fileName(item?.preview),
            productIds: (Array.isArray(item?.productIds) ? item.productIds : []).map(id => text(id, 80)).filter(Boolean).slice(0, 4),
            match: (Array.isArray(item?.match) ? item.match : []).map(term => text(term, 80)).filter(Boolean).slice(0, 4),
            featured: item?.featured === true
        };
        if (!entry.title || !entry.video || !entry.poster || !entry.preview) {
            throw Object.assign(new Error(`El tutorial ${index + 1} está incompleto`), { status: 400 });
        }
        config.tutorials.push(entry);
    });
    if (!config.tutorials.length) throw Object.assign(new Error('Debe haber al menos un tutorial'), { status: 400 });
    if (!config.tutorials.some(item => item.featured)) config.tutorials[0].featured = true;
    // Solo un tutorial destacado (el del mosaico de la portada)
    let featuredSeen = false;
    config.tutorials.forEach(item => { item.featured = item.featured && !featuredSeen; featuredSeen = featuredSeen || item.featured; });
    return config;
}

function referencedFiles(config) {
    const files = new Set(config.hero.slides.flatMap(slide => [slide.video, slide.poster]));
    config.tutorials.forEach(item => [item.video, item.poster, item.preview].forEach(file => files.add(file)));
    return files;
}

// Borra videos que ya no usa el inicio y subidas abandonadas
async function cleanup(config) {
    const keep = referencedFiles(config);
    const now = Date.now();
    const [mediaFiles] = await bucket.getFiles({ prefix: MEDIA_PREFIX });
    const [uploads] = await bucket.getFiles({ prefix: UPLOAD_PREFIX });
    const stale = [
        ...mediaFiles.filter(file => {
            const name = file.name.slice(MEDIA_PREFIX.length);
            const age = now - new Date(file.metadata.timeCreated).getTime();
            return name && !keep.has(name) && !PROTECTED_FILES.has(name) && age > KEEP_UNPUBLISHED_MS;
        }),
        ...uploads.filter(file => now - new Date(file.metadata.timeCreated).getTime() > 24 * 60 * 60 * 1000)
    ];
    await Promise.all(stale.map(file => file.delete().catch(() => {})));
    return stale.length;
}

app.post('/config', requireAdmin, async (req, res) => {
    try {
        const config = sanitizeConfig(req.body?.config);
        const missing = [];
        await Promise.all([...referencedFiles(config)].map(async name => {
            const [exists] = await bucket.file(MEDIA_PREFIX + name).exists();
            if (!exists) missing.push(name);
        }));
        if (missing.length) return res.status(400).json({ error: 'Hay videos que no existen en el almacenamiento', missing });

        await configRef.set({
            ...config,
            updatedAt: new Date().toISOString(),
            updatedBy: req.user.email || req.user.uid
        });
        const removed = await cleanup(config).catch(error => { console.warn('Limpieza fallida:', error.message); return 0; });
        return res.json({ ok: true, removed });
    } catch (error) {
        console.error('Error guardando configuración:', error);
        return res.status(error.status || 500).json({ error: error.status ? error.message : 'No se pudo guardar la configuración' });
    }
});

if (require.main === module) {
    app.listen(PORT, () => console.log(`media-worker escuchando en ${PORT}`));
}

module.exports = { probe, encode, sanitizeConfig, LIMITS };
