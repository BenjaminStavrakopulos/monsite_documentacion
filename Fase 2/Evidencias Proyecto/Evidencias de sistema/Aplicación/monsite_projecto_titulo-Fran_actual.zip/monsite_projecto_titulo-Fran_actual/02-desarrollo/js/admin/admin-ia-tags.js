// admin-ia-tags.js - Etiquetas IA de productos (admin → Desarrollo).
// Permite etiquetar productos nuevos o ajustar los del Excel. Se guardan en Firestore
// (iaProductTags/{productId}) y el recomendador del análisis capilar las usa en vez del Excel.
(function () {
    const TYPE_LABELS = { straight: 'Liso', wavy: 'Ondulado', curly: 'Rizado', kinky: 'Afro', dreadlocks: 'Rastas' };
    const CONDITION_LABELS = { normal: 'normal', seco: 'seco' };
    const LEVEL_TEXT = ['Sin', '1', '2', '3'];

    const state = {
        catalog: [],
        baseMatrix: null,
        adminTags: [],
        matrix: null,
        labels: {},
        editing: null
    };

    const $ = id => document.getElementById(id);

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    function notify(message, isError) {
        if (typeof window.notifyAdminDesarrollo === 'function') {
            window.notifyAdminDesarrollo(message, isError);
        } else if (isError) {
            console.error(message);
        }
    }

    function recommender() {
        if (!window.hairRecommender) throw new Error('hair-recommender.js no está cargado');
        return window.hairRecommender;
    }

    function rebuildMatrix() {
        state.matrix = recommender().mergeAdminTags(state.baseMatrix, state.adminTags);
    }

    function findEntry(product, matrix = state.matrix) {
        const normalize = recommender().normalizeName;
        const products = matrix?.products || [];
        return products.find(entry => entry.productId && String(entry.productId) === String(product.id))
            || products.find(entry => normalize(entry.name) === normalize(product.name))
            || null;
    }

    function findBaseEntry(product) {
        return findEntry(product, state.baseMatrix);
    }

    function getStatus(product) {
        const entry = findEntry(product);
        if (!entry || !Object.keys(entry.scores || {}).length) return 'missing';
        return entry.source === 'admin' ? 'admin' : 'excel';
    }

    function topTags(scores, limit = 3) {
        return Object.entries(scores || {})
            .sort((a, b) => b[1] - a[1])
            .slice(0, limit)
            .map(([key, value]) => `${state.labels[key] || key} ${value}`);
    }

    // ---------- Lista ----------
    function renderStats() {
        const counts = { excel: 0, admin: 0, missing: 0 };
        state.catalog.forEach(product => { counts[getStatus(product)] += 1; });
        $('iaTagsStatTagged').textContent = counts.excel + counts.admin;
        $('iaTagsStatMissing').textContent = counts.missing;
        $('iaTagsStatAdmin').textContent = counts.admin;
        $('iaTagsStats').querySelector('.is-warning').classList.toggle('has-missing', counts.missing > 0);
    }

    function renderList() {
        const list = $('iaTagsList');
        const search = recommender().normalizeName($('iaTagsSearch').value);
        const filter = $('iaTagsFilter').value;
        const statusOrder = { missing: 0, admin: 1, excel: 2 };

        const rows = state.catalog
            .map(product => ({ product, status: getStatus(product), entry: findEntry(product) }))
            .filter(row => filter === 'all' || row.status === filter)
            .filter(row => !search || recommender().normalizeName(row.product.name).includes(search))
            .sort((a, b) => statusOrder[a.status] - statusOrder[b.status] || String(a.product.name).localeCompare(String(b.product.name), 'es'));

        if (!rows.length) {
            list.innerHTML = '<p class="ia-tags-empty">No hay productos que coincidan.</p>';
            return;
        }

        const statusText = { missing: 'Sin etiquetas', admin: 'Editado aquí', excel: 'Desde el Excel' };
        list.innerHTML = rows.map(({ product, status, entry }) => {
            const image = typeof product.image === 'string' && /^https?:/i.test(product.image) ? product.image : '';
            const tags = topTags(entry?.scores).map(tag => `<li>${escapeHtml(tag)}</li>`).join('');
            return `
                <article class="ia-tags-row ia-tags-row--${status}">
                    <span class="ia-tags-thumb">${image ? `<img src="${escapeHtml(image)}" alt="" loading="lazy">` : ''}</span>
                    <div class="ia-tags-row-info">
                        <strong>${escapeHtml(product.name || 'Producto')}</strong>
                        ${tags ? `<ul class="ia-tags-chips">${tags}</ul>` : '<span class="ia-tags-row-hint">No se recomienda en el análisis hasta etiquetarlo.</span>'}
                    </div>
                    <span class="ia-tags-status ia-tags-status--${status}">${statusText[status]}</span>
                    <button type="button" class="btn-secondary ia-tags-edit" data-product-id="${escapeHtml(String(product.id))}">${status === 'missing' ? 'Etiquetar' : 'Editar'}</button>
                </article>`;
        }).join('');
    }

    // ---------- Editor ----------
    function renderGroups() {
        const scores = state.editing.scores;
        $('iaTagsGroups').innerHTML = recommender().DIMENSION_GROUPS.map(group => `
            <fieldset class="ia-tags-group">
                <legend>${escapeHtml(group.title)}</legend>
                ${group.keys.map(key => {
                    const value = scores[key] || 0;
                    return `
                    <div class="ia-tags-dim${value ? ' is-set' : ''}" data-dim="${key}">
                        <span class="ia-tags-dim-label">${escapeHtml(state.labels[key] || key)}</span>
                        <div class="ia-tags-levels" role="radiogroup" aria-label="${escapeHtml(state.labels[key] || key)}">
                            ${[0, 1, 2, 3].map(level => `<button type="button" role="radio" aria-checked="${level === value}" class="ia-tags-level${level === value ? ' is-active' : ''}" data-level="${level}">${LEVEL_TEXT[level]}</button>`).join('')}
                        </div>
                    </div>`;
                }).join('')}
            </fieldset>
        `).join('');
    }

    function renderPreview() {
        const { product } = state.editing;
        const draftEntry = {
            name: product.name,
            productId: String(product.id),
            confidence: $('iaTagsConfidence').value,
            scores: { ...state.editing.scores },
            source: 'admin'
        };
        const draftMatrix = recommender().mergeAdminTags(state.matrix, [draftEntry]);
        // En la vista previa el producto se considera disponible aunque esté agotado
        const catalog = state.catalog.map(item => (String(item.id) === String(product.id) ? { ...item, active: true, stock: 1 } : item));

        $('iaTagsPreview').innerHTML = recommender().REFERENCE_PROFILES.map(profile => {
            const { items, partial } = recommender().recommend(profile.apiResult, catalog, draftMatrix);
            const index = partial ? -1 : items.findIndex(item => String(item.product.id) === String(product.id));
            const label = `${TYPE_LABELS[profile.type]} · ${CONDITION_LABELS[profile.condition]}`;
            const status = index < 0 ? 'none' : index < 6 ? 'top' : 'more';
            const text = index < 0 ? 'No aparece' : `#${index + 1} de ${items.length}`;
            return `<li class="ia-tags-preview-item ia-tags-preview-item--${status}"><span>${label}</span><strong>${text}</strong></li>`;
        }).join('');
    }

    function openEditor(productId) {
        const product = state.catalog.find(item => String(item.id) === String(productId));
        if (!product) return;

        const entry = findEntry(product);
        const baseEntry = findBaseEntry(product);
        state.editing = { product, entry, baseEntry, scores: { ...(entry?.scores || {}) } };

        $('iaTagsModalTitle').textContent = product.name || 'Producto';
        const status = getStatus(product);
        $('iaTagsModalSubtitle').textContent = status === 'missing'
            ? 'Producto sin etiquetas: marca para qué sirve y guarda.'
            : status === 'admin' ? 'Etiquetas editadas en el admin.' : 'Etiquetas cargadas desde el Excel.';

        const image = $('iaTagsModalImage');
        if (typeof product.image === 'string' && /^https?:/i.test(product.image)) {
            image.src = product.image;
            image.hidden = false;
        } else {
            image.hidden = true;
        }

        $('iaTagsConfidence').value = entry?.confidence || 'Media';
        $('iaTagsNeed').value = entry?.need || '';
        $('iaTagsHairTypes').value = entry?.hairTypes || '';

        const resetBtn = $('iaTagsResetBtn');
        resetBtn.hidden = entry?.source !== 'admin';
        resetBtn.textContent = baseEntry ? 'Volver a las etiquetas del Excel' : 'Quitar etiquetas';

        renderGroups();
        renderPreview();
        $('iaTagsModal').classList.add('active');
        $('iaTagsModal').querySelector('.ia-tags-editor').scrollTop = 0;
    }

    function closeEditor() {
        $('iaTagsModal').classList.remove('active');
        state.editing = null;
    }

    async function saveEditor() {
        const { product } = state.editing;
        const scores = Object.fromEntries(Object.entries(state.editing.scores).filter(([, value]) => value > 0));
        if (!Object.keys(scores).length && !confirm('El producto quedará sin etiquetas y no se recomendará en el análisis. ¿Guardar igual?')) return;

        const saveBtn = $('iaTagsSaveBtn');
        saveBtn.disabled = true;
        saveBtn.textContent = 'Guardando...';
        try {
            const saved = await window.firebaseData.saveIaProductTags(product.id, {
                name: product.name,
                scores,
                confidence: $('iaTagsConfidence').value,
                need: $('iaTagsNeed').value.trim(),
                hairTypes: $('iaTagsHairTypes').value.trim()
            });
            state.adminTags = state.adminTags.filter(tag => String(tag.productId) !== String(product.id)).concat(saved);
            rebuildMatrix();
            renderStats();
            renderList();
            closeEditor();
            notify(`Etiquetas guardadas: ${product.name}`);
        } catch (error) {
            console.error('No se pudieron guardar las etiquetas:', error);
            notify('No se pudieron guardar las etiquetas. Revisa tu sesión de admin.', true);
        } finally {
            saveBtn.disabled = false;
            saveBtn.textContent = 'Guardar etiquetas';
        }
    }

    async function resetEditor() {
        const { product, baseEntry } = state.editing;
        const question = baseEntry
            ? '¿Descartar los cambios hechos aquí y volver a las etiquetas del Excel?'
            : '¿Quitar las etiquetas de este producto? Dejará de recomendarse en el análisis.';
        if (!confirm(question)) return;

        try {
            await window.firebaseData.deleteIaProductTags(product.id);
            state.adminTags = state.adminTags.filter(tag => String(tag.productId) !== String(product.id));
            rebuildMatrix();
            renderStats();
            renderList();
            closeEditor();
            notify(baseEntry ? 'Se restauraron las etiquetas del Excel' : 'Etiquetas eliminadas');
        } catch (error) {
            console.error('No se pudieron quitar las etiquetas:', error);
            notify('No se pudieron quitar las etiquetas.', true);
        }
    }

    function wireEvents() {
        $('iaTagsSearch').addEventListener('input', renderList);
        $('iaTagsFilter').addEventListener('change', renderList);
        $('iaTagsList').addEventListener('click', event => {
            const button = event.target.closest('.ia-tags-edit');
            if (button) openEditor(button.dataset.productId);
        });

        $('iaTagsGroups').addEventListener('click', event => {
            const button = event.target.closest('.ia-tags-level');
            if (!button || !state.editing) return;
            const dim = button.closest('.ia-tags-dim');
            const level = Number(button.dataset.level);
            state.editing.scores[dim.dataset.dim] = level;
            dim.classList.toggle('is-set', level > 0);
            dim.querySelectorAll('.ia-tags-level').forEach(item => {
                const active = Number(item.dataset.level) === level;
                item.classList.toggle('is-active', active);
                item.setAttribute('aria-checked', String(active));
            });
            renderPreview();
        });

        $('iaTagsConfidence').addEventListener('change', () => { if (state.editing) renderPreview(); });
        $('iaTagsModalClose').addEventListener('click', closeEditor);
        $('iaTagsCancelBtn').addEventListener('click', closeEditor);
        $('iaTagsSaveBtn').addEventListener('click', saveEditor);
        $('iaTagsResetBtn').addEventListener('click', resetEditor);
        $('iaTagsModal').addEventListener('click', event => { if (event.target === $('iaTagsModal')) closeEditor(); });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && $('iaTagsModal').classList.contains('active')) closeEditor();
        });
    }

    async function initIaTagsSection() {
        if (!$('iaTagsList')) return;
        try {
            const [catalog, baseMatrix, adminTags] = await Promise.all([
                window.firebaseData.loadProducts(),
                recommender().loadBaseMatrix(),
                window.firebaseData.loadIaProductTags().catch(error => {
                    console.warn('No se pudieron leer las etiquetas del admin:', error);
                    return [];
                })
            ]);
            state.catalog = Array.isArray(catalog) ? catalog : [];
            state.baseMatrix = baseMatrix;
            state.adminTags = adminTags;
            state.labels = Object.fromEntries((baseMatrix.dimensions || []).map(dim => [dim.key, dim.label]));
            rebuildMatrix();
            wireEvents();
            renderStats();
            renderList();
        } catch (error) {
            console.error('No se pudo cargar la sección de etiquetas IA:', error);
            $('iaTagsList').innerHTML = '<p class="ia-tags-empty">No se pudieron cargar los productos o la matriz de etiquetas.</p>';
        }
    }

    window.initIaTagsSection = initIaTagsSection;
})();
