// account-guard.js - Páginas de la cuenta (Mis compras, Opciones de cuenta).
// Se carga en <head> como script normal (bloqueante): si no hay sesión, redirige al login
// ANTES de que la página se pinte, sin mostrarla ni mostrar avisos. El login explica por qué
// llegó ahí y ofrece "Sigue tu pedido" a quien compró como invitado.
(function () {
    try {
        var raw = window.localStorage.getItem('hairia_current_user') || window.sessionStorage.getItem('hairia_current_user');
        var user = raw ? JSON.parse(raw) : null;
        if (user && (user.uid || user.id)) return;
    } catch (error) {
        // Sesión ilegible: se trata como sin sesión
    }
    var script = document.currentScript;
    var page = (script && script.getAttribute('data-redirect')) || 'my-orders';
    window.location.replace('login.html?redirect=' + encodeURIComponent(page));
})();
