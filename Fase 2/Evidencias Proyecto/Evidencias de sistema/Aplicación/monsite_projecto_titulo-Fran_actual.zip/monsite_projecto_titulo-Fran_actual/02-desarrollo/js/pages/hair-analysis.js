// ============================================================
// MONSITE - ANÁLISIS CAPILAR CON IA
// Triple IA: tipo + condición visible + frizz
// ============================================================

(function () {
    'use strict';

    // ========================================================
    // CONFIGURACIÓN API
    // ========================================================

    // Servicio permanente en Cloud Run (02-desarrollo/hair-ai): ya no depende de Colab ni ngrok
    const DEFAULT_API_BASE_URL = 'https://monsite-hair-ai-736268363141.southamerica-west1.run.app';
    // Las vistas previas (canales monsite-85424--xxx.web.app) usan la revisión de prueba "beta" de
    // Cloud Run (desplegada sin tráfico), así se prueba un modelo nuevo sin tocar la tienda publicada
    const BETA_API_BASE_URL = 'https://beta---monsite-hair-ai-cwv4lkpasa-tl.a.run.app';
    const IS_PREVIEW_CHANNEL = /^monsite-85424--[a-z0-9-]+\.web\.app$/.test(window.location.hostname);
    const API_BASE_URL = String(
        window.HAIR_AI_API_BASE_URL || (IS_PREVIEW_CHANNEL ? BETA_API_BASE_URL : DEFAULT_API_BASE_URL)
    ).replace(/\/+$/, '');
    const API_PREDICT_URL = `${API_BASE_URL}/predict`;
    const DARK_BRIGHTNESS_THRESHOLD = 55;
    const LOW_CONFIDENCE_THRESHOLD = 0.7;

    // Cloud Run apaga la IA cuando no se usa: el primer chequeo la despierta y cargar los
    // los modelos tarda ~30-40 s. Mientras tanto la persona lee y se toma las fotos.
    const API_HEALTH_TIMEOUT_MS = 60000;
    const MAX_PHOTO_SIDE_PX = 1600;

    // Versión de los modelos en Cloud Run: se guarda con cada muestra de entrenamiento
    // (máx. 40 caracteres: lo exige la regla de Firestore)
    const MODEL_VERSION = 'tipo2_cond3_frizz1_cuero1.1_quim1';

    const CONSENT_VERSION = '1.0';
    const GUEST_CONSENT_STORAGE_KEY = 'hairia_hair_analysis_consent';

    // ========================================================
    // TRADUCCIONES
    // ========================================================

    const TYPE_LABELS = {
        straight: 'Liso',
        wavy: 'Ondulado',
        curly: 'Rizado',
        dreadlocks: 'Rastas',
        kinky: 'Afro'
    };

    const CONDITION_LABELS = {
        normal: 'Normal',
        seco: 'Seco',
        // El modelo duda (cerca del 50 %): no se afirma ni una cosa ni la otra
        inconclusive: 'No concluyente'
    };

    const FRIZZ_LABELS = {
        sin_frizz: 'Sin frizz',
        con_frizz: 'Con frizz',
        inconclusive: 'Frizz no concluyente'
    };

    // ========================================================
    // NECESIDADES / FALLBACK DE PRODUCTOS
    // ========================================================

    const NEED_CONFIG = {
        hidratacion: {
            label: 'HIDRATACIÓN',
            categories: ['mascarilla', 'acondicionador', 'aceite']
        },
        control_frizz: {
            label: 'CONTROL DE FRIZZ',
            categories: ['acondicionador', 'mascarilla', 'aceite']
        },
        definicion: {
            label: 'DEFINICIÓN Y CUIDADO',
            categories: ['acondicionador', 'mascarilla', 'aceite']
        },
        mantenimiento: {
            label: 'CUIDADO Y MANTENIMIENTO',
            categories: ['shampoo', 'acondicionador']
        }
    };

    // ========================================================
    // ESTADO
    // ========================================================

    const state = {
        photos: {},
        stepIndex: 0,
        lastCapture: null,
        stream: null,
        cameraFacing: 'environment',
        // Cámara que eligió la persona con el botón de cambiar (trasera o selfie)
        preferredFacing: 'environment',
        consent: null,
        lastResult: null,
        trainingSampleSent: false,
        // La pantalla de ejemplo de la foto del cuerpo se muestra una sola vez por análisis
        bodyExampleShown: false,
        returnToReview: false
    };

    let elements = null;

    // ========================================================
    // ELEMENTOS DOM
    // ========================================================

    function cacheElements() {
        elements = {
            startAnalysisBtn: document.getElementById('startAnalysisBtn'),
            consentBackBtn: document.getElementById('consentBackBtn'),
            consentAnalysis: document.getElementById('consentAnalysis'),
            consentTraining: document.getElementById('consentTraining'),
            consentGuestNote: document.getElementById('consentGuestNote'),
            continueToCameraBtn: document.getElementById('continueToCameraBtn'),
            captureExitBtn: document.getElementById('captureExitBtn'),
            captureHelpBtn: document.getElementById('captureHelpBtn'),
            cameraHelpTip: document.getElementById('cameraHelpTip'),
            captureStepLabel: document.getElementById('captureStepLabel'),
            captureProgress: document.getElementById('captureProgress'),
            video: document.getElementById('hairCameraVideo'),
            guideFrame: document.getElementById('hairGuideFrame'),
            fallbackMsg: document.getElementById('cameraFallbackMsg'),
            captureTitle: document.getElementById('captureTitle'),
            captureInstructions: document.getElementById('captureInstructions'),
            shutterBtn: document.getElementById('shutterBtn'),
            cameraSwitchBtn: document.getElementById('cameraSwitchBtn'),
            galleryInput: document.getElementById('galleryInput'),
            canvas: document.getElementById('hairCaptureCanvas'),
            confirmPhotoPreview: document.getElementById('confirmPhotoPreview'),
            confirmIcon: document.getElementById('confirmIcon'),
            confirmTitle: document.getElementById('confirmTitle'),
            confirmMessage: document.getElementById('confirmMessage'),
            useThisPhotoBtn: document.getElementById('useThisPhotoBtn'),
            retakePhotoBtn: document.getElementById('retakePhotoBtn'),
            reviewBackBtn: document.getElementById('reviewBackBtn'),
            reviewGrid: document.getElementById('reviewGrid'),
            analyzeBtn: document.getElementById('analyzeBtn'),
            analyzingProgressFill: document.getElementById('analyzingProgressFill'),
            analyzingPercent: document.getElementById('analyzingPercent'),
            analyzingChecklist: document.getElementById('analyzingChecklist'),
            resultsNeed: document.getElementById('resultsNeed'),
            resultsMetrics: document.getElementById('resultsMetrics'),
            resultsRecommendations: document.getElementById('resultsRecommendations'),
            recommendationsEmpty: document.getElementById('recommendationsEmpty'),
            recommendationsSummary: document.getElementById('recommendationsSummary'),
            recommendationsToggle: document.getElementById('recommendationsToggle'),
            captureEyebrow: document.getElementById('captureEyebrow'),
            resultsPhotos: document.getElementById('resultsPhotos'),
            apiStatus: document.getElementById('apiStatus'),
            apiStatusRetryBtn: document.getElementById('apiStatusRetryBtn'),
            captureError: document.getElementById('captureError'),
            errorTitle: document.getElementById('errorTitle'),
            errorMessage: document.getElementById('errorMessage'),
            errorRetryBtn: document.getElementById('errorRetryBtn'),
            errorChangePhotoBtn: document.getElementById('errorChangePhotoBtn'),
            resultsWarning: document.getElementById('resultsWarning'),
            resultsRetakeBtn: document.getElementById('resultsRetakeBtn'),
            viewAllProductsLink: document.getElementById('viewAllProductsLink')
        };
    }

    // ========================================================
    // UTILIDADES
    // ========================================================

    function showPanel(name) {
        document.querySelectorAll('.hair-panel').forEach(panel => {
            panel.classList.toggle('active', panel.dataset.panel === name);
        });
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')

            .replace(/</g, '&lt;')

            .replace(/>/g, '&gt;')

            .replace(/"/g, '&quot;')

            .replace(/'/g, '&#39;');
    }

    function formatPrice(amount) {
        if (typeof window.formatCLP === 'function') {
            return window.formatCLP(amount);
        }

        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(Number(amount) || 0);
    }

    // ========================================================
    // CAPTURA
    // 2 FOTOS: CUERO CABELLUDO + CUERPO
    // ========================================================

    const CAPTURE_STEPS = [
        {
            key: 'scalp',
            label: 'Cuero cabelludo',
            hint: 'Acércate a la raíz',
            title: 'Cuero cabelludo',
            instructions:
                'Separa el cabello con los dedos o un peine y acerca la cámara a la raíz, con buena luz.',
            shape: 'scalp',
            // La sequedad/daño se ve en los largos, no en la raíz: esta foto no cuenta para la condición
            weights: {
                type: 0.25,
                condition: 0,
                frizz: 0.2
            }
        },
        {
            key: 'body',
            label: 'Cuerpo del cabello',
            hint: 'Cabello suelto',
            title: 'Cuerpo del cabello',
            instructions:
                'Muestra el largo de tu cabello suelto para ver su forma natural, condición y frizz.',
            shape: 'general',
            weights: {
                type: 0.75,
                condition: 0.6,
                frizz: 0.8
            }
        }
    ];

    function getStep(index = state.stepIndex) {
        return CAPTURE_STEPS[index] || CAPTURE_STEPS[0];
    }

    function getCapturedPhotos() {
        return CAPTURE_STEPS.filter(step => state.photos[step.key]?.dataUrl)

            .map(step => ({
                ...state.photos[step.key],
                key: step.key,
                label: step.label,
                weights: step.weights
            }));
    }

    function allPhotosReady() {
        return CAPTURE_STEPS.every(step => state.photos[step.key]?.dataUrl);
    }

    function firstMissingStepIndex() {
        return CAPTURE_STEPS.findIndex(step => !state.photos[step.key]?.dataUrl);
    }

    // Respuestas de las preguntas opcionales de la pantalla "Tus fotos"
    function getQuestionAnswers() {
        const answers = {};
        const read = name => document.querySelector(`input[name="${name}"]:checked`)?.value;
        const puntas = read('q-puntas');
        const calor = read('q-calor');

        if (puntas !== undefined) answers.puntas = Number(puntas);
        if (calor !== undefined) answers.calor = Number(calor);

        return answers;
    }

    function resetFlowState() {
        document.querySelectorAll('#hairQuestions input[type="radio"]').forEach(input => {
            input.checked = false;
        });

        state.photos = {};

        state.stepIndex = 0;

        state.lastCapture = null;

        state.lastResult = null;

        state.trainingSampleSent = false;

        state.bodyExampleShown = false;

        state.returnToReview = false;
    }

    // ========================================================
    // CÁMARA
    // ========================================================

    async function ensureCamera() {
        if (state.stream) {
            elements.fallbackMsg.hidden = true;

            elements.shutterBtn.disabled = false;

            return true;
        }

        if (!navigator.mediaDevices?.getUserMedia) {
            elements.fallbackMsg.hidden = false;

            elements.shutterBtn.disabled = true;

            return false;
        }

        try {
            state.stream = await navigator.mediaDevices.getUserMedia({
                // Sin resolución pedida, el navegador entrega 640x480 y la imagen se ve borrosa.
                // Se pide 4:3, el formato nativo del sensor: pedir 16:9 (1920x1080) hace que muchos
                // celulares recorten el sensor y la imagen se vea "acercada", sobre todo en selfie.
                video: {
                    facingMode: {
                        ideal: state.preferredFacing
                    },
                    width: {
                        ideal: 1920
                    },
                    aspectRatio: {
                        ideal: 4 / 3
                    }
                },
                audio: false
            });

            await resetCameraZoom(state.stream.getVideoTracks()[0]);

            const settings = state.stream.getVideoTracks()[0]?.getSettings?.() || {};

            // Algunos equipos (notebooks) no informan facingMode: se usa la que se pidió
            state.cameraFacing = settings.facingMode || state.preferredFacing;

            updateCameraSwitchButton();

            elements.video.classList.toggle('is-mirrored', state.cameraFacing === 'user');

            elements.video.srcObject = state.stream;

            elements.fallbackMsg.hidden = true;

            elements.shutterBtn.disabled = false;

            return true;
        } catch (error) {
            console.warn('No se pudo acceder a la cámara:', error);

            elements.fallbackMsg.hidden = false;

            elements.shutterBtn.disabled = true;

            return false;
        }
    }

    // Algunos equipos abren la cámara con zoom: se deja en el mínimo (la vista normal de la cámara)
    async function resetCameraZoom(track) {
        try {
            const zoom = track?.getCapabilities?.().zoom;

            if (zoom && Number.isFinite(zoom.min)) {
                await track.applyConstraints({ advanced: [{ zoom: zoom.min }] });
            }
        } catch (_) {
            // Sin soporte de zoom: se usa la cámara tal cual
        }
    }

    // Botón para alternar entre la cámara trasera y la frontal (selfie).
    // Solo aparece si el equipo tiene más de una cámara.
    async function updateCameraSwitchButton() {
        const button = elements.cameraSwitchBtn;

        if (!button) return;

        let cameraCount = 0;

        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            cameraCount = devices.filter(device => device.kind === 'videoinput').length;
        } catch (_) {
            cameraCount = 0;
        }

        button.hidden = cameraCount < 2;

        button.setAttribute(
            'aria-label',
            state.cameraFacing === 'user' ? 'Cambiar a la cámara trasera' : 'Cambiar a la cámara frontal'
        );
    }

    async function switchCamera() {
        const button = elements.cameraSwitchBtn;

        if (button) button.disabled = true;

        state.preferredFacing = state.cameraFacing === 'user' ? 'environment' : 'user';

        stopCamera();

        await ensureCamera();

        if (button) button.disabled = false;
    }

    function stopCamera() {
        if (!state.stream) {
            return;
        }

        state.stream.getTracks().forEach(track => track.stop());

        state.stream = null;
    }

    // ========================================================
    // BRILLO
    // ========================================================

    function computeAverageBrightness(imageData) {
        const data = imageData.data;
        const sampleStep = 4 * 20;
        let sum = 0;
        let sampledPixels = 0;

        for (let i = 0; i < data.length; i += sampleStep) {
            sum += data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;

            sampledPixels++;
        }

        return sampledPixels ? sum / sampledPixels : 140;
    }

    // ========================================================
    // CAPTURAR FOTO
    // ========================================================

    // Zona del video que corresponde al marco guía, en píxeles reales del video.
    // El video se muestra completo, sin recortar (object-fit: contain) y, con la cámara
    // frontal, en espejo: hay que deshacer ambas cosas. Se deja un margen para no cortar
    // el cabello del borde. Si algo no cuadra, se usa el cuadro completo.
    const GUIDE_CROP_MARGIN = 0.12;

    function getGuideCropRect(video) {
        const vw = video.videoWidth;
        const vh = video.videoHeight;
        const full = { sx: 0, sy: 0, sw: vw, sh: vh };
        const videoBox = video.getBoundingClientRect();
        const guideBox = elements.guideFrame?.getBoundingClientRect();

        if (!guideBox || !videoBox.width || !videoBox.height || !guideBox.width || !guideBox.height) {
            return full;
        }

        const scale = Math.min(videoBox.width / vw, videoBox.height / vh);
        const offsetX = (videoBox.width - vw * scale) / 2;
        const offsetY = (videoBox.height - vh * scale) / 2;
        const marginX = guideBox.width * GUIDE_CROP_MARGIN;
        const marginY = guideBox.height * GUIDE_CROP_MARGIN;
        let left = guideBox.left - videoBox.left - marginX;
        const top = guideBox.top - videoBox.top - marginY;
        const width = guideBox.width + marginX * 2;
        const height = guideBox.height + marginY * 2;

        // Vista en espejo: la izquierda de la pantalla es la derecha del video
        if (video.classList.contains('is-mirrored')) {
            left = videoBox.width - (left + width);
        }

        let sx = (left - offsetX) / scale;
        let sy = (top - offsetY) / scale;
        let sw = width / scale;
        let sh = height / scale;

        sx = Math.max(0, sx);
        sy = Math.max(0, sy);
        sw = Math.min(vw - sx, sw);
        sh = Math.min(vh - sy, sh);

        // Recorte demasiado chico o inválido: mejor la foto completa
        if (!(sw > vw * 0.2 && sh > vh * 0.2)) {
            return full;
        }

        return { sx, sy, sw, sh };
    }

    function capturePhoto() {
        const { video, canvas } = elements;

        if (!video.videoWidth || !video.videoHeight) {
            return;
        }

        // Se envía solo el cabello dentro del marco guía (sin fondo ni objetos alrededor)
        const crop = getGuideCropRect(video);
        const scale = Math.min(1, MAX_PHOTO_SIDE_PX / Math.max(crop.sw, crop.sh));

        canvas.width = Math.round(crop.sw * scale);
        canvas.height = Math.round(crop.sh * scale);

        const ctx = canvas.getContext('2d');

        ctx.save();

        if (state.cameraFacing === 'user') {
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
        }

        ctx.drawImage(video, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, canvas.width, canvas.height);

        ctx.restore();

        state.lastCapture = {
            dataUrl: canvas.toDataURL('image/jpeg', 0.9),
            brightness: computeAverageBrightness(ctx.getImageData(0, 0, canvas.width, canvas.height)),
            label: getStep().label
        };

        showConfirmPanel();
    }

    // ========================================================
    // GALERÍA
    // ========================================================

    function readFileAsDataUrl(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = () => resolve(reader.result);

            reader.onerror = () => reject(reader.error);

            reader.readAsDataURL(file);
        });
    }

    function normalizePhotoDataUrl(dataUrl) {
        return new Promise((resolve, reject) => {
            const image = new Image();

            image.onload = () => {
                const scale = Math.min(
                    1,
                    MAX_PHOTO_SIDE_PX / Math.max(image.naturalWidth, image.naturalHeight)
                );

                const canvas = document.createElement('canvas');

                canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));

                canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));

                const context = canvas.getContext('2d');

                context.fillStyle = '#ffffff';

                context.fillRect(0, 0, canvas.width, canvas.height);

                context.drawImage(image, 0, 0, canvas.width, canvas.height);

                resolve(canvas.toDataURL('image/jpeg', 0.88));
            };

            image.onerror = () => reject(new Error('Imagen no compatible'));

            image.src = dataUrl;
        });
    }

    function computeBrightnessFromDataUrl(dataUrl) {
        return new Promise(resolve => {
            const img = new Image();

            img.onload = () => {
                const canvas = elements.canvas;

                canvas.width = img.naturalWidth;

                canvas.height = img.naturalHeight;

                const ctx = canvas.getContext('2d');

                ctx.drawImage(img, 0, 0);

                try {
                    resolve(computeAverageBrightness(ctx.getImageData(0, 0, canvas.width, canvas.height)));
                } catch (error) {
                    console.warn(error);

                    resolve(140);
                }
            };

            img.onerror = () => resolve(140);

            img.src = dataUrl;
        });
    }

    async function handleGalleryUpload(event) {
        const input = event.target;
        const file = input.files?.[0];

        if (!file) {
            return;
        }

        try {
            await processGalleryFile(file);
        } finally {
            // Se limpia DESPUÉS de leer el archivo: limpiarlo antes (como se hacía) deja el archivo
            // inaccesible en iPhone y algunos Android, y había que elegir la foto dos veces.
            // Limpiarlo permite volver a elegir la misma foto si se repite el paso.
            input.value = '';
        }
    }

    async function processGalleryFile(file) {
        showCaptureError('');

        // Algunos celulares entregan el archivo sin tipo (file.type vacío): se intenta leer igual
        if (file.type && !file.type.startsWith('image/')) {
            showCaptureError('Ese archivo no es una imagen. Elige una foto JPG o PNG de tu cabello.');

            return;
        }

        try {
            const original = await readFileAsDataUrl(file);
            const dataUrl = await normalizePhotoDataUrl(original);

            state.lastCapture = {
                dataUrl,
                brightness: await computeBrightnessFromDataUrl(dataUrl),
                label: getStep().label
            };

            showConfirmPanel();
        } catch (error) {
            console.warn('No se pudo leer la imagen:', error);

            showCaptureError(
                'No pudimos leer esa imagen. Si es una foto HEIC de iPhone, compártela como JPG o toma la foto con la cámara.'
            );
        }
    }

    // Las fotos de ejemplo están en pantallas ocultas: se descargan apenas empieza el flujo
    // (mientras la persona lee los permisos), así aparecen al instante en su pantalla
    let exampleImagesPreloaded = false;

    function preloadExampleImages() {
        if (exampleImagesPreloaded) {
            return;
        }

        exampleImagesPreloaded = true;

        document.querySelectorAll('.hair-example-shot img').forEach(img => {
            const preload = new Image();
            preload.decoding = 'async';
            preload.src = img.currentSrc || img.src;
        });
    }

    // ========================================================
    // PASO DE CAPTURA
    // ========================================================

    function renderCaptureProgress() {
        if (!elements.captureProgress) {
            return;
        }

        elements.captureProgress.innerHTML = CAPTURE_STEPS.map((step, index) => {
            const done = Boolean(state.photos[step.key]?.dataUrl);
            const current = index === state.stepIndex;

            return `

                            <span
                                class="hair-dot${current ? ' hair-dot-active' : ''}${
                                    done ? ' hair-dot-done' : ''
                                }"
                            ></span>

                        `;
        })

            .join('');
    }

    function setupCaptureStep(index = state.stepIndex) {
        state.stepIndex = Math.max(0, Math.min(CAPTURE_STEPS.length - 1, index));

        const step = getStep();

        elements.captureStepLabel.textContent = `Foto ${state.stepIndex + 1} de ${CAPTURE_STEPS.length}`;

        if (elements.captureEyebrow) {
            elements.captureEyebrow.textContent = step.hint;
        }

        elements.captureTitle.textContent = step.title;

        elements.captureInstructions.textContent = step.instructions;

        elements.guideFrame.dataset.shape = step.shape;

        elements.cameraHelpTip.hidden = true;

        showCaptureError('');

        renderCaptureProgress();

        ensureCamera();
    }

    // ========================================================
    // CONFIRMACIÓN
    // ========================================================

    function firstMissingStepAfterAccept() {
        const currentKey = getStep().key;

        return CAPTURE_STEPS.findIndex(step => step.key !== currentKey && !state.photos[step.key]?.dataUrl);
    }

    function showConfirmPanel() {
        if (!state.lastCapture) {
            return;
        }

        const { dataUrl, brightness } = state.lastCapture;
        const step = getStep();
        const isDark = brightness < DARK_BRIGHTNESS_THRESHOLD;

        elements.confirmPhotoPreview.src = dataUrl;

        elements.confirmIcon.textContent = isDark ? '!' : '✓';

        elements.confirmIcon.classList.toggle('hair-confirm-icon-warning', isDark);

        elements.confirmTitle.textContent = isDark ? 'Foto muy oscura' : `${step.label}: se ve bien`;

        elements.confirmMessage.textContent = isDark
            ? 'Repite la foto con mejor iluminación para obtener un resultado más preciso.'
            : firstMissingStepAfterAccept() === -1
              ? 'Es la última foto. Luego podrás revisar ambas.'
              : 'Tiene buena iluminación. Sigue con la siguiente foto.';

        elements.useThisPhotoBtn.disabled = isDark;

        elements.useThisPhotoBtn.classList.toggle('hair-btn-disabled', isDark);

        elements.useThisPhotoBtn.textContent =
            firstMissingStepAfterAccept() === -1 || state.returnToReview
                ? 'Usar esta foto'
                : 'Usar y continuar';

        showPanel('confirm');
    }

    function acceptCurrentPhoto() {
        if (!state.lastCapture || elements.useThisPhotoBtn.disabled) {
            return;
        }

        state.photos[getStep().key] = {
            ...state.lastCapture
        };

        state.lastCapture = null;

        const nextIndex = firstMissingStepIndex();

        if (nextIndex !== -1 && !state.returnToReview) {
            setupCaptureStep(nextIndex);

            // Antes de la foto del cuerpo, ejemplos de cómo tomarla (solo la primera vez)
            if (CAPTURE_STEPS[nextIndex].key === 'body' && !state.bodyExampleShown) {
                state.bodyExampleShown = true;

                showPanel('example-body');

                return;
            }

            showPanel('capture');

            return;
        }

        state.returnToReview = false;

        if (nextIndex !== -1) {
            setupCaptureStep(nextIndex);

            showPanel('capture');

            return;
        }

        stopCamera();

        renderReviewGrid();

        showPanel('review');
    }

    function retakeCurrentPhoto() {
        state.lastCapture = null;

        setupCaptureStep(state.stepIndex);

        showPanel('capture');
    }

    // ========================================================
    // REVISIÓN
    // ========================================================

    function renderReviewGrid() {
        elements.reviewGrid.innerHTML = CAPTURE_STEPS.map((step, index) => {
            const photo = state.photos[step.key];

            return `

                            <div class="hair-review-card">

                                ${
                                    photo?.dataUrl
                                        ? `<img
                                            class="hair-review-thumb"
                                            src="${photo.dataUrl}"
                                            alt="Foto: ${escapeHtml(step.label)}"
                                        >`
                                        : '<div class="hair-review-thumb hair-review-thumb--empty"></div>'
                                }

                                <div class="hair-review-card-footer">

                                    <span>
                                        ${escapeHtml(step.label)}
                                    </span>

                                    <button
                                        type="button"
                                        class="hair-review-retake"
                                        data-step="${index}"
                                    >
                                        Repetir
                                    </button>

                                </div>

                            </div>

                        `;
        })

            .join('');

        elements.reviewGrid.querySelectorAll('.hair-review-retake').forEach(button => {
            button.addEventListener('click', () => retakeSinglePhoto(Number(button.dataset.step)));
        });
    }

    // ========================================================
    // COMBINAR RESULTADOS DE LAS DOS FOTOS
    // ========================================================

    function mergeProbabilities(results, blockKey, weightKey) {
        const totals = {};
        let totalWeight = 0;

        results.forEach(({ result, weights }) => {
            const block = result?.[blockKey];

            const probabilities =
                block?.probabilities ||
                (block?.prediction
                    ? {
                          [block.prediction]: Number(block.confidence) || 1
                      }
                    : null);

            if (!probabilities) {
                return;
            }

            const weight = Number(weights[weightKey]) || 0;

            totalWeight += weight;

            Object.entries(probabilities).forEach(([label, value]) => {
                totals[label] = (totals[label] || 0) + weight * (Number(value) || 0);
            });
        });

        if (!totalWeight) {
            return null;
        }

        const probabilities = Object.fromEntries(
            Object.entries(totals).map(([label, value]) => [label, value / totalWeight])
        );

        const [prediction, confidence] = Object.entries(probabilities)

            .sort((a, b) => b[1] - a[1])[0];

        return {
            prediction,
            confidence,
            probabilities
        };
    }

    // Con menos de esta confianza (entre 40 % y 60 % en un modelo de dos opciones)
    // el resultado se muestra como "no concluyente" en vez de elegir una opción al azar
    const INCONCLUSIVE_THRESHOLD = 0.6;

    function markInconclusive(block) {
        if (!block || Number(block.confidence) >= INCONCLUSIVE_THRESHOLD) {
            return;
        }

        block.inconclusive = true;
        block.rawPrediction = block.prediction;
        block.prediction = 'inconclusive';
    }

    // Modelo de condición (normal/seco): ordena bien las fotos, pero sus probabilidades salen bajas
    // (probado con fotos etiquetadas: el cabello dañado da ~30 % de mediana y el sano ~2 %).
    // Por eso no se usa el 60 % de "no concluyente", sino estos cortes sobre P(seco):
    //   ≥ 40 % -> "Seco o dañado"   ·   25-40 % -> "Algo reseco"   ·   < 25 % -> normal
    const DAMAGE_STRONG_FROM = 0.4;
    const DAMAGE_MILD_FROM = 0.25;

    function classifyCondition(block) {
        const seco = Number(block?.probabilities?.seco) || 0;

        block.rawPrediction = block.prediction;
        block.prediction = seco >= DAMAGE_MILD_FROM ? 'seco' : 'normal';
        block.mild = seco >= DAMAGE_MILD_FROM && seco < DAMAGE_STRONG_FROM;
    }

    function generateCombinedNeeds(type, condition, frizz) {
        const needs = [];

        if (condition?.prediction === 'seco') {
            needs.push('Hidratación / cabello seco');

            needs.push('Brillo / suavidad');
        }

        if (frizz?.prediction === 'con_frizz') {
            needs.push('Control de frizz');
        }

        if (['wavy', 'curly', 'kinky'].includes(type?.prediction)) {
            needs.push('Rizos / ondas');
        }

        if (!needs.length) {
            needs.push('Mantenimiento');
        }

        return [...new Set(needs)];
    }

    function combineResults(results) {
        const type = mergeProbabilities(results, 'type', 'type');
        const condition = mergeProbabilities(results, 'condition', 'condition');
        const frizz = mergeProbabilities(results, 'frizz', 'frizz');

        if (!type || !condition || !frizz) {
            throw new Error('La respuesta de la Triple IA está incompleta.');
        }

        // Condición: cortes propios (ver classifyCondition). Frizz es de dos opciones: si el modelo
        // queda cerca del 50 % no se afirma nada. Las probabilidades se conservan para el recomendador.
        classifyCondition(condition);

        markInconclusive(frizz);

        const needs = generateCombinedNeeds(type, condition, frizz);

        // Modelo de cuero cabelludo (beta): viene solo en la respuesta de la foto de la raíz
        const scalp = results.find(item => item.key === 'scalp')?.result?.scalp || null;

        // Modelo químico: viene solo en la respuesta de la foto del cuerpo. Con menos de 60 %
        // de seguridad queda "no concluyente" y no se dice nada sobre el color.
        const chemical = results.find(item => item.key === 'body')?.result?.chemical || null;

        if (chemical) {
            markInconclusive(chemical);
        }

        return {
            success: true,
            type,
            condition,
            frizz,
            scalp,
            chemical,
            analysis: {
                hair_type: type.prediction,
                hair_type_label: TYPE_LABELS[type.prediction] || type.prediction,
                condition: condition.prediction,
                condition_label: CONDITION_LABELS[condition.prediction] || condition.prediction,
                frizz: frizz.prediction,
                frizz_label: FRIZZ_LABELS[frizz.prediction] || frizz.prediction,
                needs
            },
            perPhoto: results.map(({ key, label, result }) => ({
                key,
                label,
                type: result.type,
                condition: result.condition,
                frizz: result.frizz
            }))
        };
    }

    async function analyzeAllPhotos() {
        const photos = getCapturedPhotos();
        const settled = await Promise.allSettled(photos.map(photo => analyzeHairWithApi(photo)));

        const ok = settled

            .map((outcome, index) =>
                outcome.status === 'fulfilled'
                    ? {
                          ...photos[index],
                          result: outcome.value
                      }
                    : null
            )

            .filter(Boolean);

        if (!ok.length) {
            throw (
                settled.find(result => result.status === 'rejected')?.reason ||
                new Error('No se pudo analizar ninguna foto.')
            );
        }

        if (ok.length < photos.length) {
            console.warn(`Se analizaron ${ok.length} de ${photos.length} fotos.`);
        }

        return combineResults(ok);
    }

    // ========================================================
    // CONSENTIMIENTO
    // ========================================================

    function resetConsentPanel() {
        elements.consentAnalysis.checked = false;

        elements.consentTraining.checked = false;

        elements.consentGuestNote.hidden = true;

        elements.continueToCameraBtn.disabled = true;
    }

    function updateGuestNoteVisibility() {
        const currentUser = window.hairiaSession?.getCurrentUser?.();
        const isGuest = !currentUser?.uid;

        elements.consentGuestNote.hidden = !(elements.consentTraining.checked && isGuest);
    }

    async function recordConsent() {
        const consentRecord = {
            consentimiento_analisis: elements.consentAnalysis.checked,
            consentimiento_entrenamiento: elements.consentTraining.checked,
            version_terminos: CONSENT_VERSION,
            fecha_consentimiento: new Date().toISOString(),
            consentimiento_revocado: false
        };

        state.consent = consentRecord;

        const currentUser = window.hairiaSession?.getCurrentUser?.();
        const userId = currentUser?.uid || currentUser?.id;

        if (userId && window.firebaseData?.saveHairAnalysisConsent) {
            try {
                await window.firebaseData.saveHairAnalysisConsent(userId, consentRecord);

                return;
            } catch (error) {
                console.warn('No se pudo guardar consentimiento:', error);
            }
        }

        try {
            localStorage.setItem(GUEST_CONSENT_STORAGE_KEY, JSON.stringify(consentRecord));
        } catch (error) {
            console.warn(error);
        }
    }

    // ========================================================
    // DATA URL -> BLOB
    // ========================================================

    function dataUrlToBlob(dataUrl) {
        const parts = dataUrl.split(',');

        if (parts.length !== 2) {
            throw new Error('La fotografía no tiene un formato válido.');
        }

        const mimeMatch = parts[0].match(/data:(.*?);base64/);
        const mimeType = mimeMatch?.[1] || 'image/jpeg';
        const binary = atob(parts[1]);
        const bytes = new Uint8Array(binary.length);

        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }

        return new Blob([bytes], {
            type: mimeType
        });
    }

    // ========================================================
    // API REAL
    //
    // IMPORTANTE:
    // Esta sección mantiene el mismo consumo de la API.
    // ========================================================

    async function analyzeHairWithApi(photo) {
        if (!photo?.dataUrl) {
            throw new Error('No existe una fotografía para analizar.');
        }

        const blob = dataUrlToBlob(photo.dataUrl);
        const formData = new FormData();

        formData.append('image', blob, 'hair-analysis.jpg');

        // El modelo de cuero cabelludo solo se pide para la foto de la raíz
        if (photo.key === 'scalp') {
            formData.append('scalp', '1');
        }

        // El modelo químico (natural / mechas / color) solo se pide para la foto del cuerpo del cabello
        if (photo.key === 'body') {
            formData.append('chem', '1');
        }

        const controller = new AbortController();

        // Margen para un arranque en frío de la IA si el chequeo inicial no alcanzó a despertarla
        const timeout = setTimeout(() => controller.abort(), 60000);

        try {
            console.log('🤖 Enviando imagen a:', API_PREDICT_URL);

            const response = await fetch(API_PREDICT_URL, {
                method: 'POST',
                body: formData,
                signal: controller.signal
            });

            const responseText = await response.text();

            if (!response.ok) {
                throw new Error(`API HTTP ${response.status}: ${responseText}`);
            }

            let data;

            try {
                data = JSON.parse(responseText);
            } catch (_) {
                throw new Error('La API no devolvió JSON válido.');
            }

            if (!data.success) {
                throw new Error(data.error || 'La API no pudo realizar el análisis.');
            }

            if (!data.type || !data.condition || !data.frizz) {
                throw new Error('La respuesta de la Triple IA está incompleta.');
            }

            return data;
        } catch (error) {
            if (error.name === 'AbortError') {
                throw new Error('La API tardó demasiado en responder.');
            }

            throw error;
        } finally {
            clearTimeout(timeout);
        }
    }

    // ========================================================
    // ANIMACIÓN
    // ========================================================

    function resetAnalyzingUi() {
        elements.analyzingProgressFill.style.width = '0%';

        elements.analyzingPercent.textContent = '0%';

        elements.analyzingChecklist.querySelectorAll('li').forEach(item => {
            item.classList.remove('hair-stage-active', 'hair-stage-done');

            const icon = item.querySelector('.hair-check-icon');

            if (icon) {
                icon.textContent = '○';
            }
        });
    }

    function runAnalyzingSequence() {
        return new Promise(resolve => {
            resetAnalyzingUi();

            showPanel('analyzing');

            const items = Array.from(elements.analyzingChecklist.querySelectorAll('li'));

            /*
             * Calculado dinámicamente:
             * funciona con 2 o 3 etapas
             * sin depender de un número fijo.
             */

            const thresholds = Array.from(
                {
                    length: items.length + 1
                },
                (_, index) => Math.round(index * (100 / items.length))
            );

            const duration = 3000;
            const start = performance.now();

            function tick(now) {
                const elapsed = now - start;
                const progress = Math.min(100, Math.round((elapsed / duration) * 100));

                elements.analyzingProgressFill.style.width = `${progress}%`;

                elements.analyzingPercent.textContent = `${progress}%`;

                items.forEach((item, index) => {
                    const from = thresholds[index];
                    const to = thresholds[index + 1];
                    const icon = item.querySelector('.hair-check-icon');

                    if (progress >= to) {
                        if (icon) {
                            icon.textContent = '✓';
                        }

                        item.classList.add('hair-stage-done');

                        item.classList.remove('hair-stage-active');
                    } else if (progress >= from) {
                        if (icon) {
                            icon.textContent = '●';
                        }

                        item.classList.add('hair-stage-active');
                    }
                });

                if (progress < 100) {
                    requestAnimationFrame(tick);
                } else {
                    resolve();
                }
            }

            requestAnimationFrame(tick);
        });
    }

    // ========================================================
    // INTERPRETAR RESULTADO
    // ========================================================

    function determinePrimaryNeed(result) {
        const condition = result.condition?.prediction;
        const frizz = result.frizz?.prediction;
        const type = result.type?.prediction;

        if (condition === 'seco') {
            return 'hidratacion';
        }

        if (frizz === 'con_frizz') {
            return 'control_frizz';
        }

        if (['curly', 'wavy', 'kinky'].includes(type)) {
            return 'definicion';
        }

        return 'mantenimiento';
    }

    // ========================================================
    // ANÁLISIS PERSONALIZADO
    // ========================================================

    // ----- Lo que vio la IA, en palabras simples (se usa en el perfil y bajo cada foto) -----

    // Cuero cabelludo (foto de la raíz): solo se nombran las canas, y con cautela ("nos pareció ver").
    // La caspa NO se menciona nunca (equivocarse ahí incomoda): si el modelo la sospecha, el
    // recomendador suma en silencio productos para un cuero cabelludo equilibrado, que sirven igual
    // si fue una falsa alarma. Grasa y baja densidad se calculan y se guardan, pero no se muestran.
    function describeScalp(scalp) {
        if (!scalp) {
            return { findings: [], hasCanas: false };
        }

        const findings = [];
        const hasCanas = scalp.detected?.canas === true;

        if (hasCanas) {
            findings.push(Number(scalp.canas_nivel?.level) === 3 ? 'Nos pareció ver bastantes canas' : 'Nos pareció ver algunas canas');
        }

        return { findings, hasCanas };
    }

    // Cuerpo del cabello: tipo, estado (condición + frizz) y color. "Normal" se dice una sola vez.
    function describeBody(type, condition, frizz, chemical, mildDamage = false) {
        const TYPE_NAMES = { straight: 'Liso', wavy: 'Ondulado', curly: 'Rizado', kinky: 'Afro', dreadlocks: 'Con rastas' };
        const chemicalPrediction = chemical?.inconclusive ? null : chemical?.prediction;

        const estado = [];
        if (condition === 'seco') estado.push(mildDamage ? 'Algo reseco' : 'Seco o dañado');
        if (frizz === 'con_frizz') estado.push(estado.length ? 'con frizz' : 'Con frizz');
        const unclear = condition === 'inconclusive' || frizz === 'inconclusive';

        let estadoText = null;
        if (estado.length) estadoText = estado.join(' y ');
        else if (!unclear) estadoText = 'Normal';

        let color = null;
        if (chemicalPrediction === 'mechas') color = 'Con mechas';
        if (chemicalPrediction === 'color') color = 'Teñido o decolorado';

        return {
            type: TYPE_NAMES[type] || null,
            estado: estadoText,
            color,
            hasMechas: chemicalPrediction === 'mechas',
            hasColor: chemicalPrediction === 'color',
            unclear
        };
    }

    // Perfil: punteo de lo que vio la IA + una frase corta de cómo cuidarlo
    function buildPersonalizedAnalysis(result) {
        const type = result.type?.prediction;
        const condition = result.condition?.prediction;
        const frizz = result.frizz?.prediction;
        const mildDamage = result.condition?.mild === true;
        // Cuero cabelludo graso (no se nombra): nada de mascarillas ni hidratantes en la raíz
        const oily = result.scalp?.detected?.graso === true;
        const body = describeBody(type, condition, frizz, result.chemical, mildDamage);
        const scalp = describeScalp(result.scalp);

        const facts = [];
        if (body.type) facts.push({ label: 'Tipo de cabello', value: body.type });
        if (body.estado) facts.push({ label: 'Estado', value: body.estado });
        if (body.color) facts.push({ label: 'Color', value: body.color });
        // Solo si hay algo que decir (canas): no se afirma "sin alteraciones" porque la sección de
        // cuero cabelludo de los recomendados puede aparecer igual (ver describeScalp)
        if (scalp.findings.length) {
            facts.push({ label: 'Cuero cabelludo', value: scalp.findings.join(' y ') });
        }

        // Cómo cuidarlo: 2-3 frases personalizadas, con el porqué y la frecuencia (unas 4-5 líneas en el celular). Orden: base (tipo + estado),
        // color y cuero cabelludo; si sobra espacio, un consejo propio del tipo de cabello.
        // Las canas no llevan consejo: cuidarlas es decisión de la persona (su sección está en los recomendados).
        // La caspa tampoco: no se menciona (ver describeScalp).
        const TYPE_WORDS = { straight: 'liso', wavy: 'ondulado', curly: 'rizado', kinky: 'afro', dreadlocks: 'con rastas' };
        const typeWord = TYPE_WORDS[type] || '';
        const isCurly = ['wavy', 'curly', 'kinky'].includes(type);
        const seco = condition === 'seco';
        const conFrizz = frizz === 'con_frizz';
        const priorities = [];
        const sentences = [];

        // 1) Base: tipo + estado
        if (seco && oily) {
            sentences.push(mildDamage
                ? `Tu cabello ${typeWord} se ve algo reseco: un acondicionador liviano solo de medios a puntas, sin llevarlo a la raíz, le devuelve suavidad${conFrizz ? ', y un sérum antifrizz liviano en los largos controla el frizz' : ''}.`
                : `Tu cabello ${typeWord} se ve seco o dañado: usa productos reparadores livianos solo de medios a puntas, sin llevarlos a la raíz, y despunta las puntas abiertas${conFrizz ? '; un sérum antifrizz liviano en los largos controla el frizz' : ''}.`);
        } else if (seco && !mildDamage && conFrizz) {
            sentences.push(`Tu cabello ${typeWord} se ve seco o dañado y con frizz: una mascarilla reparadora 1 o 2 veces por semana le devuelve fuerza y suavidad, y una crema antihumedad al peinar mantiene el frizz bajo control.`);
        } else if (seco && !mildDamage) {
            sentences.push(`Tu cabello ${typeWord} se ve seco o dañado: una mascarilla reparadora 1 o 2 veces por semana y despuntar las puntas abiertas le devolverán fuerza y brillo.`);
        } else if (seco && conFrizz) {
            sentences.push(`Tu cabello ${typeWord} se ve algo reseco y con frizz: un acondicionador nutritivo en cada lavado y una crema antihumedad al peinar lo dejan suave y controlado.`);
        } else if (seco) {
            sentences.push(`Tu cabello ${typeWord} se ve algo reseco: un acondicionador nutritivo en cada lavado y una mascarilla una vez por semana le devuelven suavidad y brillo.`);
        } else if (conFrizz) {
            sentences.push(`Tu cabello ${typeWord} tiene frizz: un acondicionador ligero y un producto antihumedad al peinar ayudan a mantenerlo pulido durante el día.`);
        } else if (type === 'dreadlocks') {
            sentences.push('En rastas, lo clave es un cuero cabelludo limpio: lava con champú que no deje residuos y sécalas bien para evitar humedad.');
        } else {
            sentences.push(`Tu cabello ${typeWord} se ve equilibrado: con una rutina suave de champú y acondicionador basta para mantener su brillo${type === 'straight' ? ' sin apelmazarlo' : ''}.`);
        }
        if (seco) priorities.push(mildDamage ? 'hidratación' : 'reparación');
        if (conFrizz) priorities.push('control de frizz');
        if (type === 'dreadlocks') priorities.push('cuidado del cuero cabelludo');

        // 2) Color
        if (body.hasColor) {
            sentences.push('Como parece teñido o decolorado, usa champú sin sulfatos y productos que protejan el color: así dura más y la fibra sufre menos.');
            priorities.push('cuidado del color');
        } else if (body.hasMechas) {
            sentences.push('Para tus mechas, un champú sin sulfatos y un matizador de vez en cuando las mantienen luminosas y sin tonos amarillos.');
            priorities.push('cuidado del color');
        }

        // 4) Si queda espacio, un consejo propio del tipo de cabello
        if (sentences.length < 3 && isCurly) {
            sentences.push(type === 'wavy'
                ? 'Para definir tus ondas, aplica crema o espuma con el cabello húmedo y sécalo con difusor o al aire.'
                : 'Para definir tus rizos, aplica crema de peinar con el cabello húmedo y evita cepillarlos en seco.');
        } else if (sentences.length < 2 && type === 'straight') {
            sentences.push('Si usas plancha o secador, aplica antes un protector térmico para cuidar la fibra.');
        }
        if (isCurly) priorities.push('definición');

        const careText = sentences.slice(0, 3).join(' ');

        return {
            facts,
            care: careText,
            note: body.unclear ? 'Algo no se vio claro: repite las fotos con buena luz para más precisión.' : '',
            priorities: priorities.length ? priorities : ['mantenimiento']
        };
    }

    // ========================================================
    // PRODUCTOS - FALLBACK POR CATEGORÍA
    // ========================================================

    async function loadRecommendedProducts(needKey) {
        const categories = NEED_CONFIG[needKey]?.categories || [];
        let products = [];

        try {
            products = await window.firebaseData.loadProducts();
        } catch (error) {
            console.warn('No se pudieron cargar productos:', error);

            products = Array.isArray(window.productsData) ? window.productsData : [];
        }

        const available = products.filter(
            product =>
                product && product.active !== false && (product.stock == null || Number(product.stock) > 0)
        );

        const matched = [];

        categories.forEach(category => {
            available.forEach(product => {
                if (product.category === category && !matched.includes(product)) {
                    matched.push(product);
                }
            });
        });

        return (matched.length ? matched : available).slice(0, 4);
    }

    // ========================================================
    // RECOMENDADOR REAL
    // ========================================================

    const TOP_RECOMMENDATIONS = 6;

    async function loadRankedRecommendations(apiResult, needKey) {
        let catalog = [];

        try {
            catalog = await window.firebaseData.loadProducts();
        } catch (error) {
            console.warn('No se pudieron cargar productos:', error);

            catalog = Array.isArray(window.productsData) ? window.productsData : [];
        }

        try {
            if (!window.hairRecommender) {
                throw new Error('hair-recommender.js no está cargado');
            }

            const matrix = await window.hairRecommender.loadMatrix();

            return window.hairRecommender.recommend(apiResult, catalog, matrix);
        } catch (error) {
            console.warn(
                'Matriz de etiquetas IA no disponible; se utiliza recomendación por categoría:',
                error
            );

            const fallback = await loadRecommendedProducts(needKey);

            return {
                items: fallback.map(product => ({
                    product,
                    reasons: [],
                    level: null
                })),
                partial: true,
                fallback: true
            };
        }
    }

    function getProductPriceHtml(product) {
        const price = Number(product.price) || 0;

        const hasDiscount =
            typeof window.getDiscountedPrice === 'function' &&
            typeof window.getDiscountText === 'function' &&
            window.getDiscountText(product);

        if (!hasDiscount) {
            return `

                <span class="hair-rec-price">
                    ${formatPrice(price)}
                </span>

            `;
        }

        return `

            <span class="hair-rec-price">

                ${formatPrice(window.getDiscountedPrice(product))}

            </span>

            <span class="hair-rec-price-old">
                ${formatPrice(price)}
            </span>

        `;
    }

    // ========================================================
    // TEXTO DE RECOMENDACIONES
    // ========================================================

    function getRecommendationSummary(recommendation, items) {
        if (!items.length) {
            return '';
        }

        /*
         * IMPORTANTÍSIMO:
         *
         * partial NO significa que los productos sean malos.
         * Solo significa que ninguno superó todos los umbrales
         * internos de la matriz.
         *
         * Por eso no se muestra un mensaje negativo al usuario.
         */

        if (recommendation?.fallback) {
            return 'Seleccionamos productos disponibles relacionados con las principales necesidades detectadas en tu cabello.';
        }

        if (items.length === 1) {
            return 'Seleccionamos esta opción por su compatibilidad con las necesidades detectadas en tu cabello.';
        }

        if (items.length > TOP_RECOMMENDATIONS) {
            return `Encontramos ${items.length} opciones compatibles con tu perfil capilar. Te mostramos primero las ${TOP_RECOMMENDATIONS} mejor posicionadas según las necesidades detectadas.`;
        }

        if (recommendation?.partial) {
            return 'Estas son las opciones del catálogo con mayor compatibilidad con las necesidades detectadas en tu cabello.';
        }

        return 'Seleccionamos estas opciones según su compatibilidad con las necesidades detectadas en tu cabello.';
    }

    // ----- Recomendados en pestañas tipo carrusel -----
    // "Top" (los que cubren más cuidados a la vez) + una pestaña por cuidado, máx. 5 productos cada
    // una y sin repetir productos. La pestaña con punto es un cuidado que el Top no cubre.
    function buildRecommendationCard(item, index, tab) {
        const product = item.product;
        if (!product) {
            return null;
        }

        const safeName = escapeHtml(product.name || 'Producto');
        const safeImage = typeof product.image === 'string' && /^(https?:|data:image\/)/i.test(product.image)
            ? product.image
            : '';
        const productUrl = `products.html?search=${encodeURIComponent(product.name || '')}`;
        const isBest = tab.isTop && index === 0;

        // En el Top: qué cubre y qué le falta. En cada cuidado: qué cubre (ese cuidado primero).
        const covers = (item.covers || []).slice().sort((a, b) => Number(b === tab.careTitle) - Number(a === tab.careTitle));
        const chips = [
            ...covers.map(title => `<li class="is-covered">✓ ${escapeHtml(title)}</li>`),
            ...(tab.isTop ? (item.lacks || []).map(title => `<li class="is-lacking">Falta: ${escapeHtml(title)}</li>`) : [])
        ].join('');

        const card = document.createElement('article');
        card.className = `hair-rec-card${isBest ? ' is-best' : ''}`;
        card.innerHTML = `
            <span class="hair-rec-rank" aria-label="Puesto ${index + 1}">${index + 1}</span>
            <a class="hair-rec-image" href="${productUrl}">
                ${safeImage
                    ? `<img src="${escapeHtml(safeImage)}" alt="${safeName}" loading="lazy">`
                    : '<span class="hair-product-placeholder">IMG</span>'}
            </a>
            <div class="hair-rec-info">
                ${isBest ? '<div class="hair-rec-tags"><span class="hair-rec-best">Mejor opción</span></div>' : ''}
                <h4><a href="${productUrl}">${safeName}</a></h4>
                ${chips ? `<ul class="hair-rec-reasons hair-rec-coverage">${chips}</ul>` : ''}
                <div class="hair-rec-bottom">
                    <div class="hair-rec-prices">${getProductPriceHtml(product)}</div>
                    <button type="button" class="hair-product-add" data-product-id="${escapeHtml(String(product.id))}">Agregar</button>
                </div>
            </div>
        `;

        card.querySelector('.hair-product-add')?.addEventListener('click', () => {
            if (typeof window.addToCart === 'function') {
                window.addToCart(product);
            }
        });

        return card;
    }

    function renderRecommendationTabs(recommendation) {
        const container = elements.resultsRecommendations;
        const { top, tabs, careCount } = recommendation.tabs;

        container
            .querySelectorAll('.hair-rec-card, .hair-product-card, .hair-rec-group-head, .hair-rec-tabs, .hair-rec-tab-intro, .hair-rec-panel')
            .forEach(element => element.remove());
        container.classList.add('hair-rec-list');
        if (elements.recommendationsToggle) {
            elements.recommendationsToggle.hidden = true;
        }
        elements.recommendationsEmpty.hidden = true;
        if (elements.recommendationsSummary) {
            elements.recommendationsSummary.textContent = tabs.length
                ? 'Primero, los que cubren más de tus cuidados a la vez. Desliza las pestañas para ver más opciones por cada cuidado.'
                : 'Seleccionamos estas opciones según las necesidades detectadas en tu cabello.';
        }

        const allTabs = [
            {
                key: 'top',
                label: `Top ${top.length}`,
                title: 'Lo que más te sirve',
                description: careCount > 1
                    ? `Los productos que cubren más de tus ${careCount} cuidados a la vez.`
                    : 'Los productos que mejor calzan con tu cabello.',
                items: top,
                isTop: true
            },
            ...tabs.map(tab => ({ ...tab, careTitle: tab.title.split(' · ')[0] }))
        ];

        const bar = document.createElement('div');
        bar.className = 'hair-rec-tabs';
        bar.setAttribute('role', 'tablist');
        bar.setAttribute('aria-label', 'Recomendados por cuidado');
        bar.innerHTML = allTabs.map((tab, index) => `
            <button type="button" role="tab" class="hair-rec-tab${tab.missing ? ' is-missing' : ''}"
                id="hairRecTab-${escapeHtml(tab.key)}" data-tab="${escapeHtml(tab.key)}"
                aria-controls="hairRecPanel" aria-selected="${index === 0}" tabindex="${index === 0 ? 0 : -1}">
                ${escapeHtml(tab.label)}${tab.missing ? '<span class="hair-rec-tab-dot" title="Te falta" aria-label="(te falta)"></span>' : ''}
            </button>`).join('');

        const intro = document.createElement('div');
        intro.className = 'hair-rec-tab-intro';
        intro.setAttribute('aria-live', 'polite');

        const panel = document.createElement('div');
        panel.className = 'hair-rec-panel';
        panel.id = 'hairRecPanel';
        panel.setAttribute('role', 'tabpanel');

        // Orden: pestañas, título de la pestaña, tarjetas (antes del aviso "sin productos")
        container.prepend(panel);
        container.prepend(intro);
        container.prepend(bar);

        const show = (key, fromUser = false) => {
            const tab = allTabs.find(item => item.key === key) || allTabs[0];

            bar.querySelectorAll('.hair-rec-tab').forEach(button => {
                const active = button.dataset.tab === tab.key;
                button.classList.toggle('is-active', active);
                button.setAttribute('aria-selected', String(active));
                button.tabIndex = active ? 0 : -1;
                if (active) {
                    panel.setAttribute('aria-labelledby', button.id);
                    // Deja la pestaña elegida a la vista dentro del carrusel (sin mover la página)
                    if (fromUser) {
                        bar.scrollTo({ left: Math.max(0, button.offsetLeft - bar.clientWidth / 2 + button.offsetWidth / 2), behavior: 'smooth' });
                    }
                }
            });

            intro.innerHTML = `
                <h4>${escapeHtml(tab.title)}</h4>
                <p>${escapeHtml(tab.description || '')}</p>
            `;
            panel.innerHTML = '';
            tab.items.forEach((item, index) => {
                const card = buildRecommendationCard(item, index, tab);
                if (card) {
                    panel.appendChild(card);
                }
            });
        };

        bar.addEventListener('click', event => {
            const button = event.target.closest('.hair-rec-tab');
            if (button) {
                show(button.dataset.tab, true);
            }
        });

        // Flechas del teclado para moverse entre pestañas
        bar.addEventListener('keydown', event => {
            if (!['ArrowRight', 'ArrowLeft'].includes(event.key)) {
                return;
            }
            const buttons = [...bar.querySelectorAll('.hair-rec-tab')];
            const current = buttons.findIndex(button => button.getAttribute('aria-selected') === 'true');
            const next = buttons[(current + (event.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length];
            event.preventDefault();
            show(next.dataset.tab, true);
            next.focus();
        });

        show('top');
        elements.viewAllProductsLink.href = 'products.html';
    }

    function renderRankedRecommendations(recommendation) {
        // Con la matriz IA: pestañas (Top + una por cuidado). Sin ella: la lista general de siempre.
        if (recommendation?.tabs?.top?.length) {
            renderRecommendationTabs(recommendation);
            return;
        }

        const container = elements.resultsRecommendations;

        // Secciones por cuidado (Hidratación + Reparación, Hidratación, Reparación...).
        // Si no hay ninguna, se muestra la lista general como antes.
        const sections = Array.isArray(recommendation?.sections)
            ? recommendation.sections.filter(section => section.items?.length)
            : [];

        const grouped = sections.length > 0;
        const items = grouped ? sections.flatMap(section => section.items) : recommendation?.items || [];

        container
            .querySelectorAll('.hair-rec-card, .hair-product-card, .hair-rec-group-head, .hair-rec-tabs, .hair-rec-tab-intro, .hair-rec-panel')
            .forEach(element => element.remove());

        container.classList.add('hair-rec-list');

        const toggle = elements.recommendationsToggle;

        if (toggle) {
            toggle.hidden = true;

            toggle.setAttribute('aria-expanded', 'false');
        }

        if (!items.length) {
            elements.recommendationsEmpty.hidden = false;

            if (elements.recommendationsSummary) {
                elements.recommendationsSummary.textContent = '';
            }

            return;
        }

        elements.recommendationsEmpty.hidden = true;

        if (elements.recommendationsSummary) {
            elements.recommendationsSummary.textContent = getRecommendationSummary(recommendation, items);
        }

        items.forEach((item, index) => {
            const product = item.product;

            if (!product) {
                return;
            }

            const card = document.createElement('article');

            card.className = `hair-rec-card${index === 0 ? ' is-best' : ''}`;

            // Agrupado por secciones: cada sección ya viene acotada, no se ocultan tarjetas
            if (!grouped && index >= TOP_RECOMMENDATIONS) {
                card.classList.add('is-extra');

                card.hidden = true;
            }

            const safeName = escapeHtml(product.name || 'Producto');

            const safeImage =
                typeof product.image === 'string' && /^(https?:|data:image\/)/i.test(product.image)
                    ? product.image
                    : '';

            const productUrl = `products.html?search=${encodeURIComponent(product.name || '')}`;

            const reasons = (item.reasons || [])

                .map(reason => `<li>${escapeHtml(reason)}</li>`)

                .join('');

            /*
             * Si el algoritmo marcó partial,
             * "Mejor coincidencia" es más correcto
             * que ocultar completamente la distinción.
             */

            const bestLabel = recommendation?.partial ? 'Mejor coincidencia' : 'Mejor opción';

            card.innerHTML = `

                    <span
                        class="hair-rec-rank"
                        aria-label="Puesto ${index + 1}"
                    >
                        ${index + 1}
                    </span>


                    <a
                        class="hair-rec-image"
                        href="${productUrl}"
                    >

                        ${
                            safeImage
                                ? `<img
                                    src="${escapeHtml(safeImage)}"
                                    alt="${safeName}"
                                    loading="lazy"
                                >`
                                : '<span class="hair-product-placeholder">IMG</span>'
                        }

                    </a>


                    <div class="hair-rec-info">

                        <div class="hair-rec-tags">

                            ${
                                index === 0
                                    ? `<span class="hair-rec-best">
                                        ${bestLabel}
                                    </span>`
                                    : ''
                            }

                            ${
                                item.level
                                    ? `<span class="hair-rec-level hair-rec-level--${escapeHtml(item.level.key)}">
                                        ${escapeHtml(item.level.label)}
                                    </span>`
                                    : ''
                            }

                        </div>


                        <h4>

                            <a href="${productUrl}">
                                ${safeName}
                            </a>

                        </h4>


                        ${
                            reasons
                                ? `<ul class="hair-rec-reasons">
                                    ${reasons}
                                </ul>`
                                : ''
                        }


                        <div class="hair-rec-bottom">

                            <div class="hair-rec-prices">
                                ${getProductPriceHtml(product)}
                            </div>


                            <button
                                type="button"
                                class="hair-product-add"
                                data-product-id="${escapeHtml(String(product.id))}"
                            >
                                Agregar
                            </button>

                        </div>

                    </div>

                `;

            card.querySelector('.hair-product-add')?.addEventListener('click', () => {
                if (typeof window.addToCart === 'function') {
                    window.addToCart(product);
                }
            });

            container.appendChild(card);
        });

        // Títulos de cada sección y numeración que vuelve a partir en 1 en cada una
        if (grouped) {
            const cards = container.querySelectorAll('.hair-rec-card');
            let offset = 0;

            sections.forEach(section => {
                const head = document.createElement('div');

                head.className = 'hair-rec-group-head';

                head.innerHTML = `
                        <h4>${escapeHtml(section.title)}</h4>
                        <p>${escapeHtml(section.description || '')}</p>
                    `;

                container.insertBefore(head, cards[offset] || null);

                section.items.forEach((_, position) => {
                    const rank = cards[offset + position]?.querySelector('.hair-rec-rank');
                    if (rank) {
                        rank.textContent = String(position + 1);
                        rank.setAttribute('aria-label', `Puesto ${position + 1}`);
                    }
                });

                offset += section.items.length;
            });
        }

        if (toggle && !grouped && items.length > TOP_RECOMMENDATIONS) {
            const collapsedLabel = `Ver las ${items.length} opciones`;

            toggle.textContent = collapsedLabel;

            toggle.hidden = false;

            toggle.onclick = () => {
                const expand = toggle.getAttribute('aria-expanded') !== 'true';

                container.querySelectorAll('.hair-rec-card.is-extra').forEach(card => {
                    card.hidden = !expand;
                });

                toggle.setAttribute('aria-expanded', String(expand));

                toggle.textContent = expand ? `Mostrar solo el top ${TOP_RECOMMENDATIONS}` : collapsedLabel;
            };
        }

        elements.viewAllProductsLink.href = 'products.html';
    }

    // ========================================================
    // CONFIABILIDAD / ERRORES
    // ========================================================

    function showCaptureError(message) {
        if (!elements.captureError) {
            return;
        }

        elements.captureError.textContent = message || '';

        elements.captureError.hidden = !message;
    }

    async function checkApiAvailability() {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), API_HEALTH_TIMEOUT_MS);
        let available = false;

        try {
            const response = await fetch(API_BASE_URL, {
                signal: controller.signal
            });

            const data = response.ok ? await response.json().catch(() => null) : null;

            available = Boolean(data?.success);
        } catch (_) {
            available = false;
        } finally {
            clearTimeout(timeout);
        }

        if (elements.apiStatus) {
            elements.apiStatus.hidden = available;
        }

        if (elements.startAnalysisBtn) {
            elements.startAnalysisBtn.disabled = !available;
        }

        return available;
    }

    function describeAnalysisError(error) {
        const message = String(error?.message || '');

        if (/tardó demasiado|abort/i.test(message)) {
            return {
                title: 'El análisis está tardando más de lo normal',
                message:
                    'Nuestro servicio de IA está muy ocupado. Intenta nuevamente en unos segundos; tus fotos se mantienen.'
            };
        }

        if (/failed to fetch|networkerror|load failed|HTTP 5\d\d|HTTP 404|offline/i.test(message)) {
            return {
                title: 'El análisis no está disponible en este momento',
                message:
                    'No pudimos conectarnos con nuestro servicio de IA. Revisa tu conexión o intenta nuevamente en unos minutos.'
            };
        }

        return {
            title: 'No pudimos completar el análisis',
            message:
                'Prueba nuevamente o utiliza fotos con buena iluminación, sin filtros y mostrando claramente tu cabello.'
        };
    }

    function showAnalysisError(error) {
        const copy = describeAnalysisError(error);

        if (elements.errorTitle) {
            elements.errorTitle.textContent = copy.title;
        }

        if (elements.errorMessage) {
            elements.errorMessage.textContent = copy.message;
        }

        showPanel('error');
    }

    function updateConfidenceWarning(result) {
        if (!elements.resultsWarning) {
            return;
        }

        const confidence = Math.min(
            Number(result?.type?.confidence) || 0,
            Number(result?.condition?.confidence) || 0,
            Number(result?.frizz?.confidence) || 0
        );

        // Lo que el modelo no pudo determinar (no concluyente) se dice explícitamente
        const unclear = [];
        if (result?.condition?.inconclusive) unclear.push('la condición');
        if (result?.frizz?.inconclusive) unclear.push('el frizz');

        const warningText = document.getElementById('resultsWarningText');

        if (warningText) {
            warningText.textContent = unclear.length
                ? `Con estas fotos no pudimos determinar con claridad ${unclear.join(' ni ')} de tu cabello. Repítelas con buena luz natural, sin filtros y siguiendo el marco guía.`
                : 'Tus fotos no permitieron identificar tu cabello con claridad. Repítelas con buena luz, sin filtros y siguiendo el marco guía.';
        }

        elements.resultsWarning.hidden = confidence >= LOW_CONFIDENCE_THRESHOLD && !unclear.length;
    }

    // ========================================================
    // CONTRIBUCIÓN A ENTRENAMIENTO
    // ========================================================

    function contributeTrainingSampleIfAllowed() {
        const allowed = state.consent?.consentimiento_entrenamiento === true;
        const user = window.hairiaSession?.getCurrentUser?.();
        const photos = getCapturedPhotos();

        if (
            !allowed ||
            !user?.uid ||
            !photos.length ||
            state.trainingSampleSent ||
            typeof window.firebaseData?.uploadHairAnalysisTrainingSample !== 'function'
        ) {
            return;
        }

        state.trainingSampleSent = true;

        // Fotos + respuestas del cliente (etiquetas para entrenar) + predicción del modelo
        window.firebaseData
            .uploadHairAnalysisTrainingSample(
                photos.map(photo => ({
                    dataUrl: photo.dataUrl
                })),
                {
                    answers: getQuestionAnswers(),
                    prediction: state.lastResult,
                    modelVersion: MODEL_VERSION
                }
            )

            .then(sampleId => console.log('✅ Muestra de entrenamiento guardada:', sampleId))

            .catch(error => {
                state.trainingSampleSent = false;

                console.warn('No se pudo guardar la muestra:', error);
            });
    }

    function applyGuestTrainingRules() {
        const isGuest = !window.hairiaSession?.getCurrentUser?.()?.uid;

        if (!elements.consentTraining) {
            return;
        }

        elements.consentTraining.disabled = isGuest;

        if (isGuest) {
            elements.consentTraining.checked = false;
        }

        elements.consentTraining.closest('label')?.classList.toggle('is-disabled', isGuest);

        if (elements.consentGuestNote) {
            elements.consentGuestNote.hidden = !isGuest;
        }
    }

    // ========================================================
    // FOTOS EN RESULTADO
    // ========================================================

    // Bajo cada foto, solo lo que corresponde a esa foto
    function renderResultPhotos(result) {
        if (!elements.resultsPhotos) {
            return;
        }

        const byKey = Object.fromEntries((result.perPhoto || []).map(item => [item.key, item]));

        const captionFor = (photo, detail) => {
            if (!detail) {
                return 'No se pudo analizar';
            }

            if (photo.key === 'scalp') {
                const { findings } = describeScalp(result.scalp);
                return findings.length ? findings.join(' · ') : 'Raíz revisada';
            }

            // La condición sale solo de esta foto (la raíz no cuenta), ya con los cortes de daño
            const body = describeBody(detail.type?.prediction, result.condition?.prediction, detail.frizz?.prediction, result.chemical, result.condition?.mild === true);
            return [body.type, body.estado, body.color].filter(Boolean).join(' · ');
        };

        elements.resultsPhotos.innerHTML = getCapturedPhotos()
            .map(photo => `
                <figure class="hair-results-shot">
                    <img src="${photo.dataUrl}" alt="Foto: ${escapeHtml(photo.label)}">
                    <figcaption>
                        <strong>${escapeHtml(photo.label)}</strong>
                        <span>${escapeHtml(captionFor(photo, byKey[photo.key]))}</span>
                        <button type="button" class="hair-results-retake" data-step-key="${escapeHtml(photo.key)}">Repetir esta foto</button>
                    </figcaption>
                </figure>
            `)
            .join('');
    }

    // Repetir una sola foto desde el resultado o la revisión: se vuelve a la cámara de esa foto y,
    // al aceptarla, a "Tus fotos" para analizar de nuevo (la otra foto y las respuestas se conservan)
    function retakeSinglePhoto(stepIndex) {
        if (stepIndex < 0) {
            return;
        }

        state.returnToReview = true;

        state.trainingSampleSent = false;

        setupCaptureStep(stepIndex);

        showPanel('capture');
    }

    // ========================================================
    // MOSTRAR RESULTADO PERSONALIZADO
    // ========================================================

    async function renderResults(result) {
        state.lastResult = result;

        const type = result.type;
        const condition = result.condition;
        const frizz = result.frizz;
        const primaryNeedKey = determinePrimaryNeed(result);
        const needConfig = NEED_CONFIG[primaryNeedKey] || NEED_CONFIG.mantenimiento;

        elements.resultsNeed.textContent = needConfig.label;

        // ----------------------------------------------------
        // FOTOS
        // ----------------------------------------------------

        renderResultPhotos(result);

        // ----------------------------------------------------
        // GUÍA PERSONALIZADA
        // ----------------------------------------------------

        const guide = buildPersonalizedAnalysis(result);

        /*
         * Se reutiliza resultsMetrics.
         *
         * No hay barras.
         * No requiere cambiar el HTML.
         * No requiere cambiar el CSS.
         */

        elements.resultsMetrics.innerHTML = `

            <div class="hair-metric-row">

                <p class="hair-result-heading">Lo que vio la IA en tus fotos</p>

                <ul class="hair-result-facts">
                    ${guide.facts.map(fact => `<li><span>${escapeHtml(fact.label)}</span><strong>${escapeHtml(fact.value)}</strong></li>`).join('')}
                </ul>

                <p class="hair-result-care">${escapeHtml(guide.care)}</p>

                ${guide.note ? `<small>${escapeHtml(guide.note)}</small>` : ''}

            </div>

        `;

        // ----------------------------------------------------
        // PRODUCTOS
        // ----------------------------------------------------

        // Las respuestas (puntas, plancha) y lo que se ve en la raíz (canas, caspa) suman secciones a los recomendados
        const recommendation = await loadRankedRecommendations(
            {
                ...result,
                answers: getQuestionAnswers()
            },
            primaryNeedKey
        );

        renderRankedRecommendations(recommendation);

        // ----------------------------------------------------
        // CONFIABILIDAD
        // ----------------------------------------------------

        updateConfidenceWarning(result);

        contributeTrainingSampleIfAllowed();
    }

    // ========================================================
    // INICIAR ANÁLISIS
    // ========================================================

    async function startAnalysis() {
        if (!allPhotosReady()) {
            setupCaptureStep(Math.max(0, firstMissingStepIndex()));

            showPanel('capture');

            showCaptureError(`Faltan fotos: completa las ${CAPTURE_STEPS.length} para analizar tu cabello.`);

            return;
        }

        elements.analyzeBtn.disabled = true;

        try {
            console.log('🚀 Iniciando análisis...');

            const [, apiResult] = await Promise.all([runAnalyzingSequence(), analyzeAllPhotos()]);

            await renderResults(apiResult);

            showPanel('results');
        } catch (error) {
            console.error('❌ ERROR DEL ANÁLISIS:', error);

            showAnalysisError(error);
        } finally {
            elements.analyzeBtn.disabled = false;
        }
    }

    // ========================================================
    // EVENTOS DE CONFIABILIDAD
    // ========================================================

    function wireReliabilityEvents() {
        elements.apiStatusRetryBtn?.addEventListener('click', async () => {
            elements.apiStatusRetryBtn.disabled = true;

            elements.apiStatusRetryBtn.textContent = 'Revisando...';

            await checkApiAvailability();

            elements.apiStatusRetryBtn.disabled = false;

            elements.apiStatusRetryBtn.textContent = 'Reintentar';
        });

        elements.errorRetryBtn?.addEventListener('click', () => {
            showPanel('review');

            startAnalysis();
        });

        const goToCapture = () => {
            state.photos = {};

            state.returnToReview = false;

            state.trainingSampleSent = false;

            setupCaptureStep(0);

            showPanel('capture');
        };

        elements.errorChangePhotoBtn?.addEventListener('click', goToCapture);

        // Aviso de baja confianza: a "Tus fotos", donde se puede repetir solo la que salió mal
        elements.resultsRetakeBtn?.addEventListener('click', () => {
            state.trainingSampleSent = false;

            renderReviewGrid();

            showPanel('review');
        });

        elements.resultsPhotos?.addEventListener('click', event => {
            const button = event.target.closest('.hair-results-retake[data-step-key]');

            if (!button) return;

            retakeSinglePhoto(CAPTURE_STEPS.findIndex(step => step.key === button.dataset.stepKey));
        });

        elements.startAnalysisBtn?.addEventListener('click', applyGuestTrainingRules);

        applyGuestTrainingRules();
    }

    // ========================================================
    // SALIR
    // ========================================================

    function exitFlow() {
        const shouldExit = window.confirm('¿Salir del análisis? Perderás el progreso.');

        if (!shouldExit) {
            return;
        }

        stopCamera();

        resetFlowState();

        showPanel('intro');
    }

    // ========================================================
    // EVENTOS
    // ========================================================

    function wireEvents() {
        elements.startAnalysisBtn.addEventListener('click', () => {
            preloadExampleImages();

            resetFlowState();

            resetConsentPanel();

            showPanel('consent');
        });

        elements.consentBackBtn.addEventListener('click', () => {
            showPanel('intro');
        });

        elements.consentAnalysis.addEventListener('change', () => {
            elements.continueToCameraBtn.disabled = !elements.consentAnalysis.checked;
        });

        elements.consentTraining.addEventListener('change', updateGuestNoteVisibility);

        elements.continueToCameraBtn.addEventListener('click', async () => {
            if (!elements.consentAnalysis.checked) {
                return;
            }

            await recordConsent();

            // Antes de la cámara, ejemplos de cómo tomar la foto del cuero cabelludo
            showPanel('example');
        });

        document.getElementById('exampleBackBtn')?.addEventListener('click', () => {
            showPanel('consent');
        });

        document.getElementById('exampleBodyExitBtn')?.addEventListener('click', exitFlow);

        document.getElementById('exampleBodyContinueBtn')?.addEventListener('click', () => {
            showPanel('capture');
        });

        document.getElementById('exampleContinueBtn')?.addEventListener('click', () => {
            setupCaptureStep();

            showPanel('capture');
        });

        elements.shutterBtn.addEventListener('click', capturePhoto);

        elements.cameraSwitchBtn?.addEventListener('click', switchCamera);

        elements.galleryInput.addEventListener('change', handleGalleryUpload);

        elements.useThisPhotoBtn.addEventListener('click', acceptCurrentPhoto);

        elements.retakePhotoBtn.addEventListener('click', retakeCurrentPhoto);

        // Repitiendo una foto: la X vuelve a "Tus fotos" sin perder nada
        elements.captureExitBtn.addEventListener('click', () => {
            if (state.returnToReview && allPhotosReady()) {
                state.returnToReview = false;

                stopCamera();

                renderReviewGrid();

                showPanel('review');

                return;
            }

            exitFlow();
        });

        elements.captureHelpBtn.addEventListener('click', () => {
            elements.cameraHelpTip.hidden = !elements.cameraHelpTip.hidden;
        });

        elements.reviewBackBtn.addEventListener('click', () => {
            resetFlowState();

            showPanel('intro');
        });

        elements.analyzeBtn.addEventListener('click', startAnalysis);

        elements.video.addEventListener('playing', () => {
            elements.fallbackMsg.hidden = true;

            elements.shutterBtn.disabled = false;
        });

        window.addEventListener('beforeunload', stopCamera);
    }

    // ========================================================
    // PERMISOS
    // ========================================================

    async function verifyCurrentUserIsAdmin() {
        const currentUser = window.hairiaSession?.getCurrentUser?.();
        const userId = currentUser?.uid || currentUser?.id;

        if (!userId || typeof window.firebase?.isUserAdmin !== 'function') {
            return false;
        }

        try {
            return await window.firebase.isUserAdmin(userId);
        } catch (error) {
            console.warn('No se pudieron verificar permisos:', error);

            return false;
        }
    }

    async function verifyFeatureEnabled() {
        const defaults = window.hairAnalysisConfig?.getDefaults?.() || {
            habilitada: true,
            visibilidad: 'publico'
        };

        const config = await (window.hairAnalysisConfig?.load?.() || Promise.resolve(defaults));

        if (!config.habilitada) {
            window.location.href = 'index.html';

            return false;
        }

        if (config.visibilidad === 'solo_admin') {
            const isAdmin = await verifyCurrentUserIsAdmin();

            if (!isAdmin) {
                window.location.href = 'index.html';

                return false;
            }
        }

        return true;
    }

    // ========================================================
    // INIT
    // ========================================================

    async function init() {
        cacheElements();

        const enabled = await verifyFeatureEnabled();

        if (!enabled) {
            return;
        }

        wireEvents();

        wireReliabilityEvents();

        checkApiAvailability();

        console.log('✅ Hair Analysis inicializado');
        console.log('🤖 API:', API_PREDICT_URL);
    }
    document.addEventListener('DOMContentLoaded', init);
})();
