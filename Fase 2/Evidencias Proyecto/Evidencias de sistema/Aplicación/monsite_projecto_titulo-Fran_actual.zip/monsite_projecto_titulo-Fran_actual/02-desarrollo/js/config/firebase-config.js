// firebase-config.js - VERSIÓN COMPLETA CORREGIDA
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app.js";
import { initializeAppCheck, ReCaptchaEnterpriseProvider } from "https://www.gstatic.com/firebasejs/12.8.0/firebase-app-check.js";
import {
    getFirestore,
    initializeFirestore,
    persistentLocalCache,
    persistentMultipleTabManager,
    collection,
    addDoc,
    getDocs,
    getDocsFromCache,
    query,
    where,
    updateDoc,
    doc,
    setDoc,
    getDoc,
    deleteDoc,
    deleteField,
    orderBy,
    limit,
    getCountFromServer,
    terminate,
    clearIndexedDbPersistence,
    runTransaction
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-firestore.js";
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signInWithPopup,
    signInWithRedirect,
    getRedirectResult,
    GoogleAuthProvider,
    signOut, 
    onAuthStateChanged,
    signInAnonymously,
    updateProfile,
    updatePassword,
    EmailAuthProvider,
    reauthenticateWithCredential,
    confirmPasswordReset,
    verifyPasswordResetCode,
    applyActionCode
} from "https://www.gstatic.com/firebasejs/12.8.0/firebase-auth.js";

// Correos de la cuenta (confirmar correo y nueva contraseña): los envía el backend de la tienda,
// con su diseño y remitente, y el enlace lleva a auth-action.html (no a la "URL de acción" de Firebase).
const ACCOUNT_API_BASE = ['localhost', '127.0.0.1'].includes(window.location.hostname)
    ? 'http://localhost:3000/api/account'
    : 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app/api/account';
// Visitas anónimas: las registra el backend (tope por IP, una por visitante y día)
const ANALYTICS_VISIT_URL = ACCOUNT_API_BASE.replace(/\/account$/, '/analytics/visit');

async function callAccountApi(path, body, idToken) {
    const response = await fetch(`${ACCOUNT_API_BASE}${path}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}) },
        body: JSON.stringify(body || {})
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw Object.assign(new Error(payload.error || `Error ${response.status}`), { status: response.status });
    return payload;
}

// Envía el correo de confirmación a la cuenta con sesión abierta. Devuelve true si salió.
async function requestVerificationEmail(user) {
    try {
        const result = await callAccountApi('/send-verification', {}, await user.getIdToken());
        return result.sent === true;
    } catch (error) {
        console.warn('⚠️ No se pudo enviar el correo de confirmación:', error.message);
        return false;
    }
}

// Configuración de Firebase (modo seguro para repositorio público)
// Opciones de carga de config:
// 1) window.FIREBASE_CONFIG inyectado por script local
// 2) archivo local JSON (si existe)
// 3) fallback publico embebido (seguro para cliente web)
const FALLBACK_FIREBASE_CONFIG = {
    apiKey: 'AIzaSyAYqq0MEXq4mHvLxMM8V334dnExPcPqZ5w',
    authDomain: 'monsite-85424.firebaseapp.com',
    projectId: 'monsite-85424',
    storageBucket: 'monsite-85424.firebasestorage.app',
    messagingSenderId: '736268363141',
    appId: '1:736268363141:web:1acf814ce570374ccb90ec',
    measurementId: 'G-WG4CRFJWJJ'
};

function loadFirebaseConfigFromLocalJson() {
    const configPaths = [
        '/js/config/firebase-config.local.json',
        './firebase-config.local.json',
        'firebase-config.local.json'
    ];

    for (const path of configPaths) {
        try {
            const request = new XMLHttpRequest();
            request.open('GET', path, false);
            request.send(null);

            if (request.status >= 200 && request.status < 300 && request.responseText) {
                const parsed = JSON.parse(request.responseText);
                if (parsed && typeof parsed === 'object' && parsed.apiKey) {
                    return parsed;
                }
            }
        } catch (_) {
            // no-op
        }
    }

    return null;
}

const firebaseConfig = window.FIREBASE_CONFIG || FALLBACK_FIREBASE_CONFIG || loadFirebaseConfigFromLocalJson();

if (!firebaseConfig || typeof firebaseConfig !== 'object' || !firebaseConfig.apiKey) {
    throw new Error('No se pudo resolver la configuracion de Firebase.');
}

// Inicializar Firebase
const app = initializeApp(firebaseConfig);

// App Check: Firestore y Storage solo atienden solicitudes que vienen de esta tienda (reCAPTCHA
// Enterprise puntúa al visitante sin mostrarle desafíos). Debe iniciarse antes de usar los servicios.
// En localhost se usa un token de depuración: el navegador lo muestra en la consola y hay que
// registrarlo una vez en Firebase → App Check → Apps → Administrar tokens de depuración.
const APP_CHECK_SITE_KEY = '6LfmiegtAAAAAGscvqU_Txf2-XabPrZhTJcqJPzJ';
if (['localhost', '127.0.0.1'].includes(window.location.hostname)) {
    self.FIREBASE_APPCHECK_DEBUG_TOKEN = true;
}
try {
    initializeAppCheck(app, {
        provider: new ReCaptchaEnterpriseProvider(APP_CHECK_SITE_KEY),
        isTokenAutoRefreshEnabled: true
    });
} catch (appCheckError) {
    console.warn('⚠️ App Check no se pudo iniciar:', appCheckError?.message || appCheckError);
}

const db = createFirestoreWithCache(app);
const auth = getAuth(app);

// ---------- Sesión guardada vs. sesión real de Firebase ----------
// La tienda guarda una copia de la sesión (hairia_current_user). Si Firebase la cerró (por ejemplo,
// al cambiar la contraseña se cierran todas las sesiones) esa copia queda vencida: se borra para
// que el login pida la contraseña de nuevo y el admin no muestre "acceso denegado" por error.
const SESSION_KEY = 'hairia_current_user';

function readStoredSession() {
    try {
        return JSON.parse(localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY) || 'null');
    } catch (error) {
        return null;
    }
}

function clearStoredSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (error) { /* noop */ }
    try { sessionStorage.removeItem(SESSION_KEY); } catch (error) { /* noop */ }
}

const authReady = auth.authStateReady().then(() => {
    const stored = readStoredSession();
    const current = auth.currentUser;
    const staleSession = stored?.uid && (!current || current.isAnonymous || current.uid !== stored.uid);
    if (staleSession) {
        console.warn('⚠️ La sesión guardada ya no es válida en Firebase; se cierra.');
        clearStoredSession();
    }
    return !staleSession;
}).catch(() => true);

/**
 * Para las páginas internas (admin, bodega): confirma que la sesión de Firebase existe y es de
 * esa persona. Si venció, limpia la copia y lleva al login (en vez de "acceso denegado").
 */
async function ensureLiveSession(userId, redirectTarget) {
    await authReady;
    const current = auth.currentUser;
    if (current && !current.isAnonymous && (!userId || current.uid === userId)) return true;
    clearStoredSession();
    const inAdmin = window.location.pathname.includes('/admin/');
    window.location.replace(`${inAdmin ? '../' : ''}login.html?redirect=${encodeURIComponent(redirectTarget || 'admin')}&sesion=vencida`);
    return false;
}

// Caché persistente (IndexedDB): permite pintar el catálogo al instante en
// visitas siguientes mientras se consulta el servidor en segundo plano.
function createFirestoreWithCache(firebaseApp) {
    try {
        return initializeFirestore(firebaseApp, {
            localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
        });
    } catch (error) {
        console.warn('⚠️ Caché persistente de Firestore no disponible, usando memoria:', error?.message || error);
        return getFirestore(firebaseApp);
    }
}

// Storage se carga bajo demanda: las páginas públicas nunca suben archivos,
// así que no deben pagar la descarga del SDK de Storage.
const STORAGE_SDK_URL = "https://www.gstatic.com/firebasejs/12.8.0/firebase-storage.js";
let storageContextPromise = null;

function getStorageContext() {
    if (!storageContextPromise) {
        storageContextPromise = import(STORAGE_SDK_URL).then((storageSdk) => ({
            storage: storageSdk.getStorage(app),
            storageRef: storageSdk.ref,
            uploadString: storageSdk.uploadString,
            uploadBytesResumable: storageSdk.uploadBytesResumable,
            getDownloadURL: storageSdk.getDownloadURL
        })).catch((error) => {
            storageContextPromise = null;
            throw error;
        });
    }
    return storageContextPromise;
}
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

console.log('✅ Firebase Inicializado');

// ========== FUNCIONES DE AUTENTICACIÓN ==========

/**
 * Registrar nuevo usuario
 */
async function registerUser(email, password, name) {
    console.log('🔄 [registerUser] Iniciando registro');

    const nameCheck = window.MonsiteValidation?.validateName(name);
    if (nameCheck && !nameCheck.ok) {
        throw { code: 'validation/invalid-name', message: 'Nombre inválido', customMessage: nameCheck.message };
    }
    if (nameCheck?.value) name = nameCheck.value;

    if (!isStrongPassword(password)) {
        throw {
            code: 'auth/weak-password',
            message: 'La contraseña no cumple los requisitos de seguridad',
            customMessage: 'La contraseña debe tener al menos 12 caracteres, 1 mayúscula, 1 número y 1 carácter especial.'
        };
    }
    
    // Mientras se crea la cuenta, la sesión que abre Firebase no cuenta como "sesión iniciada"
    window.__monsiteRegistering = true;
    try {
        // 1. Crear usuario en Authentication
        console.log('🔑 Creando usuario en Auth...');
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        console.log('✅ Usuario creado en Auth');

        // 2. Actualizar el displayName en el perfil
        console.log('👤 Actualizando perfil...');
        try {
            await updateProfile(user, { displayName: name });
            console.log('✅ Perfil actualizado');
        } catch (profileError) {
            console.warn('⚠️ No se pudo actualizar el perfil (continuando):', profileError.message);
        }

        // 3. Guardar datos en Firestore
        console.log('💾 Guardando datos en Firestore...');
        try {
            const userDocRef = doc(db, "users", user.uid);
            
            const userData = {
                uid: user.uid,
                name: name,
                email: email,
                displayName: name,
                role: "client",
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                emailVerified: false,
                // Las cuentas nuevas deben confirmar su correo antes de poder ingresar
                requiresEmailVerification: true
            };

            await setDoc(userDocRef, userData);
            console.log('✅ Datos guardados en Firestore');
                
        } catch (firestoreError) {
            console.error('❌ Error en Firestore:', firestoreError);
            // Continuamos aunque falle Firestore
        }

        // 4. Correo de verificación: confirma que el correo existe y es de la persona
        const verificationSent = await requestVerificationEmail(user);

        // 5. Sin sesión hasta que confirme el correo
        await signOut(auth);

        console.log('🎉 Registro completado; falta confirmar el correo');
        return {
            uid: user.uid,
            email: user.email,
            name: name,
            displayName: name,
            role: "client",
            success: true,
            needsVerification: true,
            verificationSent
        };

    } catch (error) {
        console.error('💥 ERROR en registerUser:', error);

        const structuredError = {
            code: error.code || 'unknown',
            message: error.message || 'Error desconocido',
            customMessage: getFirebaseErrorMessage(error.code),
            timestamp: new Date().toISOString()
        };

        throw structuredError;
    } finally {
        window.__monsiteRegistering = false;
    }
}

/** Confirma el correo con el código del enlace de verificación (auth-action.html → login). */
async function confirmEmailVerification(oobCode) {
    await applyActionCode(auth, String(oobCode || ''));
    return { success: true };
}

/**
 * Iniciar sesión
 */
async function loginUser(email, password) {
    console.log('🔄 [loginUser] Intentando login');
    
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        console.log('✅ Login exitoso');
        
        // Obtener datos adicionales de Firestore
        let firestoreData = {};
        try {
            const userDoc = await getDoc(doc(db, "users", user.uid));
            if (userDoc.exists()) {
                firestoreData = userDoc.data();
                console.log('📄 Datos de Firestore obtenidos');
            }
        } catch (fsError) {
            console.warn('⚠️ No se pudieron obtener datos de Firestore:', fsError.message);
        }

        if (firestoreData.requiresEmailVerification && !user.emailVerified) {
            // Por si lo confirmó en otra pestaña o dispositivo
            await user.reload().catch(() => {});
            if (!auth.currentUser?.emailVerified) {
                const resent = await requestVerificationEmail(auth.currentUser || user);
                await signOut(auth);
                throw {
                    code: 'auth/email-not-verified',
                    message: 'Correo no verificado',
                    customMessage: resent
                        ? `Tu cuenta aún no está activada. Te reenviamos el correo de confirmación a ${user.email}: ábrelo y vuelve a ingresar (revisa también spam o promociones).`
                        : `Tu cuenta aún no está activada. Abre el correo de confirmación que te enviamos a ${user.email} (revisa también spam o promociones).`
                };
            }
        }
        if (firestoreData.requiresEmailVerification && firestoreData.emailVerified !== true) {
            setDoc(doc(db, 'users', user.uid), { emailVerified: true, updatedAt: new Date().toISOString() }, { merge: true }).catch(() => {});
            firestoreData.emailVerified = true;
        }

        const userData = {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || user.email,
            name: firestoreData.name || user.displayName || user.email,
            role: firestoreData.role || 'client',
            ...firestoreData
        };
        
        return userData;
        
    } catch (error) {
        console.error('❌ Error en loginUser:', error);
        if (error.code === 'auth/email-not-verified') throw error;
        throw {
            code: error.code,
            message: error.message,
            customMessage: getFirebaseErrorMessage(error.code)
        };
    }
}

/**
 * Iniciar sesión con Google
 */
async function loginWithGoogle() {
    console.log('🔄 [loginWithGoogle] Iniciando login con Google...');

    try {
        const result = await signInWithPopup(auth, googleProvider);
        const user = result.user;
        let firestoreData = {};
        try {
            firestoreData = await upsertGoogleUserProfile(user);
        } catch (profileError) {
            console.warn('⚠️ Login Google correcto; no se pudo sincronizar el perfil:', profileError.message);
        }
        return buildGoogleUserSessionPayload(user, firestoreData);

    } catch (error) {
        console.error('❌ Error en loginWithGoogle:', error);

        if (error.code === 'auth/operation-not-allowed') {
            throw {
                code: error.code,
                message: error.message,
                customMessage: 'Google Sign-In no está habilitado en Firebase. Activa el proveedor Google en Firebase Console > Authentication > Sign-in method.'
            };
        }

        if (error.code === 'auth/popup-blocked' || error.code === 'auth/cancelled-popup-request') {
            await signInWithRedirect(auth, googleProvider);
            return {
                redirectStarted: true
            };
        }

        throw {
            code: error.code,
            message: error.message,
            customMessage: getFirebaseErrorMessage(error.code)
        };
    }
}

function buildGoogleUserSessionPayload(user, firestoreData = {}) {
    return {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email,
        name: firestoreData?.name || user.displayName || user.email,
        role: firestoreData?.role || 'client',
        photoURL: user.photoURL || '',
        provider: 'google'
    };
}

async function upsertGoogleUserProfile(user) {
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    let firestoreData = null;

    if (!userSnap.exists()) {
        firestoreData = {
            uid: user.uid,
            name: user.displayName || user.email?.split('@')[0] || 'Usuario',
            email: user.email,
            displayName: user.displayName || user.email,
            photoURL: user.photoURL || '',
            role: 'client',
            provider: 'google',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            emailVerified: !!user.emailVerified
        };

        await setDoc(userRef, firestoreData, { merge: true });
        console.log('✅ Usuario Google creado en Firestore');
    } else {
        firestoreData = userSnap.data();
        await setDoc(userRef, {
            name: user.displayName || firestoreData.name || user.email,
            displayName: user.displayName || firestoreData.displayName || user.email,
            photoURL: user.photoURL || firestoreData.photoURL || '',
            updatedAt: new Date().toISOString(),
            provider: 'google'
        }, { merge: true });
    }

    return firestoreData;
}

/**
 * Procesar resultado de login con Google vía redirect
 */
async function getGoogleRedirectUser() {
    try {
        const result = await getRedirectResult(auth);
        if (!result || !result.user) {
            return null;
        }

        const user = result.user;
        const userRef = doc(db, 'users', user.uid);
        const userSnap = await getDoc(userRef);
        let firestoreData = null;

        if (!userSnap.exists()) {
            firestoreData = {
                uid: user.uid,
                name: user.displayName || user.email?.split('@')[0] || 'Usuario',
                email: user.email,
                displayName: user.displayName || user.email,
                photoURL: user.photoURL || '',
                role: 'client',
                provider: 'google',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                emailVerified: !!user.emailVerified
            };
            await setDoc(userRef, firestoreData, { merge: true });
        } else {
            firestoreData = userSnap.data();
            await setDoc(userRef, {
                name: user.displayName || firestoreData.name || user.email,
                displayName: user.displayName || firestoreData.displayName || user.email,
                photoURL: user.photoURL || firestoreData.photoURL || '',
                updatedAt: new Date().toISOString(),
                provider: 'google'
            }, { merge: true });
        }

        return {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || user.email,
            name: firestoreData?.name || user.displayName || user.email,
            role: firestoreData?.role || 'client',
            photoURL: user.photoURL || '',
            provider: 'google'
        };
    } catch (error) {
        console.error('❌ Error en getGoogleRedirectUser:', error);
        throw {
            code: error.code,
            message: error.message,
            customMessage: getFirebaseErrorMessage(error.code)
        };
    }
}

/**
 * Enviar email de restablecimiento de contraseña
 */
async function requestPasswordReset(email) {
    console.log('🔄 [requestPasswordReset] Solicitud enviada');

    try {
        await callAccountApi('/password-reset', { email });

        return {
            success: true,
            message: 'Email de restablecimiento enviado'
        };

    } catch (error) {
        console.error('❌ Error en requestPasswordReset:', error);
        return {
            success: false,
            notFound: false,
            message: error.status === 429 ? error.message : 'No pudimos enviar el correo. Inténtalo de nuevo en unos minutos.'
        };
    }
}

/**
 * Confirmar restablecimiento de contraseña
 */
/** Revisa el enlace de nueva contraseña y devuelve el correo de la cuenta (o lanza si venció). */
async function verifyResetCode(oobCode) {
    return verifyPasswordResetCode(auth, String(oobCode || ''));
}

async function confirmPasswordResetFunction(oobCode, newPassword) {
    console.log('🔄 [confirmPasswordReset] Confirmando reset...');

    // Mismas reglas que al crear la cuenta
    if (!isStrongPassword(newPassword)) {
        return {
            success: false,
            code: 'auth/weak-password',
            message: 'La contraseña debe tener al menos 12 caracteres, 1 mayúscula, 1 número y 1 símbolo.'
        };
    }

    try {
        await confirmPasswordReset(auth, oobCode, newPassword);
        console.log('✅ Contraseña restablecida exitosamente');
        // Firebase cierra todas las sesiones de la cuenta: también se borra la copia guardada
        clearStoredSession();
        
        return {
            success: true,
            message: 'Contraseña cambiada exitosamente'
        };

    } catch (error) {
        console.error('❌ Error en confirmPasswordReset:', error);
        return {
            success: false,
            code: error.code,
            message: getFirebaseErrorMessage(error.code) || error.message
        };
    }
}

async function updateCurrentUserName(newName) {
    let trimmedName = String(newName || '').trim();
    const nameCheck = window.MonsiteValidation?.validateName(trimmedName);
    if (!trimmedName || (nameCheck && !nameCheck.ok)) {
        throw {
            code: 'validation/invalid-name',
            message: 'Nombre inválido',
            customMessage: nameCheck?.message || 'Ingresa un nombre válido.'
        };
    }
    if (nameCheck?.value) trimmedName = nameCheck.value;

    const currentUser = auth.currentUser;
    if (!currentUser) {
        throw {
            code: 'auth/not-authenticated',
            message: 'No hay sesión activa',
            customMessage: 'Debes iniciar sesión para actualizar tu perfil.'
        };
    }

    await updateProfile(currentUser, { displayName: trimmedName });
    await setDoc(doc(db, 'users', currentUser.uid), {
        name: trimmedName,
        displayName: trimmedName,
        updatedAt: new Date().toISOString()
    }, { merge: true });

    return {
        uid: currentUser.uid,
        name: trimmedName,
        email: currentUser.email || ''
    };
}

async function verifyCurrentPassword(currentPassword) {
    const currentUser = auth.currentUser;
    const normalizedPassword = String(currentPassword || '').trim();

    if (!currentUser || !currentUser.email) {
        throw {
            code: 'auth/not-authenticated',
            message: 'No hay sesión activa',
            customMessage: 'Debes iniciar sesión para cambiar tu contraseña.'
        };
    }

    if (!normalizedPassword) {
        throw {
            code: 'validation/empty-current-password',
            message: 'Contraseña actual vacía',
            customMessage: 'Ingresa tu contraseña actual.'
        };
    }

    const credential = EmailAuthProvider.credential(currentUser.email, normalizedPassword);
    await reauthenticateWithCredential(currentUser, credential);
    return true;
}

async function changeCurrentUserPassword(newPassword) {
    const currentUser = auth.currentUser;

    if (!currentUser) {
        throw {
            code: 'auth/not-authenticated',
            message: 'No hay sesión activa',
            customMessage: 'Debes iniciar sesión para cambiar tu contraseña.'
        };
    }

    if (!isStrongPassword(newPassword)) {
        throw {
            code: 'auth/weak-password',
            message: 'La contraseña no cumple los requisitos de seguridad',
            customMessage: 'La nueva contraseña debe tener al menos 12 caracteres, 1 mayúscula, 1 número y 1 carácter especial.'
        };
    }

    await updatePassword(currentUser, newPassword);
    await setDoc(doc(db, 'users', currentUser.uid), {
        updatedAt: new Date().toISOString()
    }, { merge: true });

    return true;
}

async function requestAccountDeletion(reason = '') {
    const currentUser = auth.currentUser;

    if (!currentUser) {
        throw {
            code: 'auth/not-authenticated',
            message: 'No hay sesión activa',
            customMessage: 'Debes iniciar sesión para solicitar la eliminación de tu cuenta.'
        };
    }

    const payload = {
        uid: currentUser.uid,
        email: currentUser.email || '',
        name: currentUser.displayName || currentUser.email || 'Usuario',
        reason: String(reason || '').trim(),
        status: 'pending',
        requestedAt: new Date().toISOString()
    };

    const requestRef = await addDoc(collection(db, 'accountDeletionRequests'), payload);

    await setDoc(doc(db, 'users', currentUser.uid), {
        deletionRequest: {
            status: 'pending',
            requestedAt: payload.requestedAt,
            requestId: requestRef.id,
            reason: payload.reason
        },
        updatedAt: new Date().toISOString()
    }, { merge: true });

    return {
        requestId: requestRef.id,
        ...payload
    };
}

/**
 * Verificar si un usuario es administrador
 */
async function isUserAdmin(userId) {
    try {
        if (!(await ensureLiveSession(userId, 'admin'))) return false;
        const userDoc = await getDoc(doc(db, "users", userId));
        if (userDoc.exists()) {
            const userData = userDoc.data();
            return userData.role === 'admin';
        }
        return false;
    } catch (error) {
        console.error('Error al verificar rol:', error);
        return false;
    }
}

async function getUserRole(userId) {
    try {
        const userDoc = await getDoc(doc(db, "users", userId));
        if (!userDoc.exists()) {
            return 'client';
        }

        const userData = userDoc.data() || {};
        return String(userData.role || 'client');
    } catch (error) {
        console.error('Error al obtener rol de usuario:', error);
        return 'client';
    }
}

async function isUserBodeguero(userId) {
    try {
        if (!(await ensureLiveSession(userId, 'bodega'))) return false;
        const role = await getUserRole(userId);
        if (role === 'bodeguero') {
            return true;
        }

        const userDoc = await getDoc(doc(db, "users", userId));
        if (!userDoc.exists()) {
            return false;
        }

        return false;
    } catch (error) {
        console.error('Error al verificar rol bodeguero:', error);
        return false;
    }
}

/**
 * Cerrar sesión
 */
async function logoutUser({ clearLocalCache = false } = {}) {
    try {
        await signOut(auth);
        console.log('✅ Sesión cerrada');
        // La caché local de Firestore guarda pedidos y datos de clientes (sobre todo en los
        // paneles admin y bodega): se borra para que no queden en un computador compartido.
        // Solo cuando quien llama redirige después: Firestore queda inutilizable en esta página.
        if (clearLocalCache) {
            try {
                await terminate(db);
                await clearIndexedDbPersistence(db);
            } catch (cacheError) {
                console.warn('⚠️ No se pudo borrar la caché local (otra pestaña abierta):', cacheError?.code || cacheError);
            }
        }
        return true;
    } catch (error) {
        console.error('❌ Error al cerrar sesión:', error);
        throw error;
    }
}

/**
 * Crear usuario admin (solo por administrador)
 */
async function createAdminUser(email, password, name) {
    console.log('👨‍💼 [createAdminUser] Creando usuario admin');
    
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        await updateProfile(user, { displayName: name });
        
        // Guardar con rol admin en Firestore
        const userDocRef = doc(db, "users", user.uid);
        await setDoc(userDocRef, {
            uid: user.uid,
            name: name,
            email: email,
            displayName: name,
            role: "admin",
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            emailVerified: false,
            permissions: {
                products: true,
                categories: true,
                orders: true,
                users: false
            }
        });
        
        console.log('✅ Usuario admin creado');
        return {
            uid: user.uid,
            email: user.email,
            name: name,
            role: "admin",
            success: true
        };
    } catch (error) {
        console.error('❌ Error creando admin:', error);
        throw {
            code: error.code,
            message: error.message,
            customMessage: getFirebaseErrorMessage(error.code)
        };
    }
}

/**
 * Promover usuario a admin
 */
async function promoteUserToAdmin(userId) {
    console.log('👨‍💼 [promoteUserToAdmin] Promoviendo usuario');
    
    try {
        const userRef = doc(db, "users", userId);
        await updateDoc(userRef, {
            role: "admin",
            updatedAt: new Date().toISOString(),
            permissions: {
                products: true,
                categories: true,
                orders: true,
                users: false
            }
        });
        
        console.log('✅ Usuario promovido a admin');
        return true;
    } catch (error) {
        console.error('❌ Error promoviendo usuario:', error);
        throw error;
    }
}

/**
 * Obtener usuario actual
 */
// Compra como invitado: sesión anónima de Firebase, invisible para el cliente.
// Si ya hay una sesión (real o anónima) se reutiliza.
async function signInAsGuest() {
    if (auth.currentUser) return auth.currentUser;
    const credential = await signInAnonymously(auth);
    return credential.user;
}

function getCurrentUser(callback) {
    return onAuthStateChanged(auth, async (user) => {
        // Las sesiones anónimas (compras como invitado) no cuentan como "sesión iniciada"
        if (user?.isAnonymous || window.__monsiteRegistering) {
            callback(null);
            return;
        }
        if (user) {
            try {
                const userDoc = await getDoc(doc(db, "users", user.uid));
                let userData = {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName || user.email
                };

                if (userDoc.exists()) {
                    const firestoreData = userDoc.data();
                    // Cuenta nueva que aún no confirma su correo: no cuenta como sesión iniciada
                    if (firestoreData.requiresEmailVerification && !user.emailVerified) {
                        callback(null);
                        return;
                    }
                    userData = { ...userData, ...firestoreData };
                }
                
                callback(userData);
            } catch (error) {
                console.error('Error al obtener datos de usuario:', error);
                callback(user);
            }
        } else {
            callback(null);
        }
    });
}

// ========== FUNCIONES DE ÓRDENES (DEFINIRLAS ANTES DE USARLAS) ==========

/**
 * Sanitizar datos para Firestore
 */
function sanitizeForFirestore(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;
    
    if (Array.isArray(obj)) {
        return obj.map(item => sanitizeForFirestore(item));
    }
    
    const cleaned = {};
    for (const key in obj) {
        if (obj.hasOwnProperty(key) && obj[key] !== undefined) {
            cleaned[key] = sanitizeForFirestore(obj[key]);
        }
    }
    return cleaned;
}

/**
 * Crear nueva orden
 */
async function createOrder(order) {
    try {
        const sanitizedOrder = sanitizeForFirestore(order);
        const explicitId = sanitizedOrder?.id ? String(sanitizedOrder.id) : '';

        if (explicitId) {
            await setDoc(doc(db, "orders", explicitId), {
                ...sanitizedOrder,
                id: explicitId
            }, { merge: true });
            console.log('✅ Orden creada en Firestore con ID determinístico:', explicitId);
            return explicitId;
        }

        const orderRef = await addDoc(collection(db, "orders"), sanitizedOrder);
        console.log('✅ Orden creada en Firestore:', orderRef.id);
        return orderRef.id;
    } catch (error) {
        console.error('❌ Error al crear orden:', error);
        throw error;
    }
}

/**
 * Obtener TODAS las órdenes (para admin)
 */
async function getAllOrders() {
    try {
        console.log('🔄 getAllOrders() - Conectando a Firebase...');
        
        // Verificar que db está disponible
        if (!db) {
            throw new Error('Firestore db no inicializado');
        }
        
        console.log('🔄 getAllOrders() - Obteniendo colección...');
        const ordersCollection = collection(db, "orders");
        
        console.log('🔄 getAllOrders() - Ejecutando query...');
        const querySnapshot = await getDocs(ordersCollection);
        
        console.log('🔄 getAllOrders() - Procesando documentos...', querySnapshot.size);
        const orders = [];

        querySnapshot.forEach((doc) => {
            const orderData = doc.data();
            console.log('📄 Documento encontrado:', doc.id, 'Status:', orderData.status);
            orders.push({
                ...orderData,
                id: orderData.id || doc.id,
                firestoreId: doc.id
            });
        });

        console.log('✅ Todas las órdenes cargadas desde Firebase:', orders.length, 'órdenes');
        return orders;
    } catch (error) {
        console.error('❌ Error CRÍTICO en getAllOrders:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        throw error;
    }
}

// ========== ÓRDENES PARA LOS PANELES (admin y bodega) ==========
// Los paneles ya no descargan todo el historial: piden un rango de fechas y,
// además, todas las órdenes pagadas pendientes de envío (aunque sean antiguas).
const PANEL_ORDERS_MAX = 2000;

function mapOrderDoc(orderDoc) {
    const data = orderDoc.data() || {};
    return { ...data, id: data.id || orderDoc.id, firestoreId: orderDoc.id };
}

/**
 * @param {object} options
 * @param {string|null} options.since - ISO desde (incluido). null = sin límite inferior.
 * @param {string|null} options.until - ISO hasta (excluido). null = hasta hoy.
 * @param {boolean} options.includePendingShipment - sumar pagadas sin enviar de cualquier fecha.
 * @returns {Promise<{orders: object[], truncated: boolean}>}
 */
async function getOrdersForPanel({ since = null, until = null, includePendingShipment = true } = {}) {
    const constraints = [];
    if (since) constraints.push(where("createdAt", ">=", since));
    if (until) constraints.push(where("createdAt", "<", until));
    constraints.push(orderBy("createdAt", "desc"), limit(PANEL_ORDERS_MAX));

    const [rangeSnapshot, pendingSnapshot] = await Promise.all([
        getDocs(query(collection(db, "orders"), ...constraints)),
        includePendingShipment
            ? getDocs(query(collection(db, "orders"), where("status", "==", "paid")))
            : Promise.resolve(null)
    ]);

    const byId = new Map();
    rangeSnapshot.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));
    pendingSnapshot?.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));

    return { orders: [...byId.values()], truncated: rangeSnapshot.size >= PANEL_ORDERS_MAX };
}

/** Busca en todo el historial por número de orden (MO-4827-1936 o el ID largo) o por correo del cliente. */
async function searchOrdersHistory(term) {
    const value = String(term || '').trim();
    if (!value) return [];
    const byId = new Map();

    if (value.includes('@')) {
        const email = value.toLowerCase();
        const [byUserEmail, byShippingEmail] = await Promise.all([
            getDocs(query(collection(db, "orders"), where("userEmail", "==", email), limit(50))),
            getDocs(query(collection(db, "orders"), where("shippingData.email", "==", email), limit(50)))
        ]);
        byUserEmail.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));
        byShippingEmail.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));
        return [...byId.values()];
    }

    // Número corto: acepta "MO-4827-1936", "mo48271936", "MO 4827 1936"
    const shortCode = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (/^MO\d{8}$/.test(shortCode)) {
        const formatted = `MO-${shortCode.slice(2, 6)}-${shortCode.slice(6)}`;
        const byCode = await getDocs(query(collection(db, "orders"), where("trackingCode", "==", formatted), limit(1)));
        byCode.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));
        return [...byId.values()];
    }

    const cleanId = value.replace(/^#/, '');
    const direct = await getDoc(doc(db, "orders", cleanId));
    if (direct.exists()) return [mapOrderDoc(direct)];
    const byField = await getDocs(query(collection(db, "orders"), where("id", "==", cleanId), limit(1)));
    byField.forEach(orderDoc => byId.set(orderDoc.id, mapOrderDoc(orderDoc)));
    return [...byId.values()];
}

/** Conteo por estado sin descargar las órdenes (agregación de Firestore). */
async function countOrdersByStatus() {
    const statuses = ['paid', 'shipped', 'delivered', 'cancelled', 'refunded'];
    const counts = await Promise.all(statuses.map(status =>
        getCountFromServer(query(collection(db, "orders"), where("status", "==", status)))
            .then(snapshot => snapshot.data().count)
    ));
    return Object.fromEntries(statuses.map((status, index) => [status, counts[index]]));
}

/**
 * Obtener órdenes del usuario
 */
async function getUserOrders(userId) {
    try {
        const q = query(collection(db, "orders"), where("userId", "==", userId));
        const querySnapshot = await getDocs(q);
        const orders = [];

        querySnapshot.forEach((doc) => {
            const orderData = doc.data();
            orders.push({
                ...orderData,
                id: orderData.id || doc.id,
                firestoreId: doc.id
            });
        });

        console.log('✅ Órdenes cargadas:', orders.length);
        return orders;
    } catch (error) {
        console.error('❌ Error al obtener órdenes:', error);
        throw error;
    }
}

async function trackPageVisit() {
    try {
        const visitorKey = 'monsite_visitor_id';
        let visitorId = localStorage.getItem(visitorKey);
        if (!visitorId) {
            visitorId = window.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
            localStorage.setItem(visitorKey, visitorId);
        }

        const today = new Intl.DateTimeFormat('en-CA', {
            timeZone: 'America/Santiago', year: 'numeric', month: '2-digit', day: '2-digit'
        }).format(new Date());
        const lastVisitKey = 'monsite_last_visit_date';
        if (localStorage.getItem(lastVisitKey) === today) return;
        localStorage.setItem(lastVisitKey, today);

        await fetch(ANALYTICS_VISIT_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ visitorId }),
            keepalive: true
        });
    } catch (error) {
        console.warn('No se pudo registrar visita anónima:', error.message);
    }
}

async function getAnalyticsMetrics(startDate, endDate) {
    const visitsQuery = query(collection(db, 'analyticsVisits'), where('date', '>=', startDate), where('date', '<=', endDate));
    const usersQuery = query(collection(db, 'users'), where('createdAt', '>=', `${startDate}T00:00:00.000Z`), where('createdAt', '<=', `${endDate}T23:59:59.999Z`));
    const [visitsSnapshot, usersSnapshot] = await Promise.all([getDocs(visitsQuery), getDocs(usersQuery)]);
    return {
        visits: visitsSnapshot.docs.map(snapshot => snapshot.data()),
        newUsers: usersSnapshot.docs.map(snapshot => snapshot.data())
    };
}

/**
 * Actualizar estado de orden
 */
// N° de seguimiento de Starken (opcional) al marcar "Enviado". Mismo formato que firestore.rules.
const COURIER_CODE_PATTERN = /^[A-Z0-9-]{4,40}$/;

function normalizeCourierCode(code) {
    return String(code || '').toUpperCase().replace(/\s+/g, '');
}

function courierFields(newStatus, extra = {}) {
    const code = normalizeCourierCode(extra.courierTrackingCode);
    if (newStatus !== 'shipped' || !code) return {};
    if (!COURIER_CODE_PATTERN.test(code)) throw new Error('Número de seguimiento de Starken inválido');
    return { courier: 'starken', courierTrackingCode: code };
}

async function updateOrderStatus(orderId, newStatus, extra = {}) {
    try {
        const payload = {
            status: newStatus,
            updatedAt: new Date().toISOString(),
            paymentStatus: ['paid', 'shipped', 'delivered'].includes(newStatus) ? 'approved' : newStatus,
            ...courierFields(newStatus, extra)
        };

        if (newStatus === 'paid') {
            payload.paymentDate = new Date().toISOString();
        }
        // Desde la entrega corre el vencimiento del seguimiento público (2 días)
        if (newStatus === 'delivered') {
            payload.deliveredAt = new Date().toISOString();
        }

        const orderRef = doc(db, "orders", String(orderId));
        await updateDoc(orderRef, payload);

        console.log('✅ Orden actualizada:', orderId, '->', newStatus);
        return true;
    } catch (error) {
        const isNotFound = error?.code === 'not-found' || error?.message?.includes('No document to update');

        if (isNotFound) {
            console.warn('⚠️ Orden no encontrada por docId, buscando por campo id:', orderId);
            const lookupQuery = query(collection(db, "orders"), where("id", "==", String(orderId)));
            const lookupSnapshot = await getDocs(lookupQuery);

            if (!lookupSnapshot.empty) {
                const docToUpdate = lookupSnapshot.docs[0];
                const payload = {
                    status: newStatus,
                    updatedAt: new Date().toISOString(),
                    paymentStatus: ['paid', 'shipped', 'delivered'].includes(newStatus) ? 'approved' : newStatus,
                    ...courierFields(newStatus, extra)
                };

                if (newStatus === 'paid') {
                    payload.paymentDate = new Date().toISOString();
                }

                await updateDoc(docToUpdate.ref, payload);
                console.log('✅ Orden actualizada por id lógico:', orderId, '->', newStatus);
                return true;
            }
        }

        console.error('❌ Error al actualizar orden:', error);
        throw error;
    }
}

async function updateOrderWarehouseData(orderId, updateData = {}) {
    const validStatus = new Set(['paid', 'shipped', 'delivered', 'cancelled', 'refunded']);
    const validStockStatus = new Set(['unknown', 'in_stock', 'out_of_stock']);

    const payload = {
        updatedAt: new Date().toISOString()
    };

    if (typeof updateData.status === 'string' && validStatus.has(updateData.status)) {
        payload.status = updateData.status;
        if (updateData.status === 'delivered') payload.deliveredAt = new Date().toISOString();
        Object.assign(payload, courierFields(updateData.status, updateData));
    }

    if (typeof updateData.warehouseStockStatus === 'string' && validStockStatus.has(updateData.warehouseStockStatus)) {
        payload.warehouseStockStatus = updateData.warehouseStockStatus;
    }

    if (typeof updateData.warehouseStockNote === 'string') {
        payload.warehouseStockNote = updateData.warehouseStockNote.trim().slice(0, 200);
    }

    if (typeof updateData.warehouseUpdatedBy === 'string' && updateData.warehouseUpdatedBy.trim()) {
        payload.warehouseUpdatedBy = updateData.warehouseUpdatedBy.trim();
    }

    if (updateData.warehouseItemsStatus && typeof updateData.warehouseItemsStatus === 'object') {
        payload.warehouseItemsStatus = sanitizeForFirestore(updateData.warehouseItemsStatus);
    }

    payload.warehouseUpdatedAt = new Date().toISOString();

    try {
        const orderRef = doc(db, "orders", String(orderId));
        await updateDoc(orderRef, payload);
        console.log('✅ Orden actualizada por bodega:', orderId);
        return true;
    } catch (error) {
        const isNotFound = error?.code === 'not-found' || error?.message?.includes('No document to update');

        if (isNotFound) {
            const lookupQuery = query(collection(db, "orders"), where("id", "==", String(orderId)));
            const lookupSnapshot = await getDocs(lookupQuery);

            if (!lookupSnapshot.empty) {
                await updateDoc(lookupSnapshot.docs[0].ref, payload);
                console.log('✅ Orden actualizada por id lógico (bodega):', orderId);
                return true;
            }
        }

        console.error('❌ Error al actualizar orden de bodega:', error);
        throw error;
    }
}

// ========== BODEGA: DISPONIBILIDAD DE PRODUCTOS ==========
/**
 * Única forma en que la bodega toca un producto (las reglas de Firestore lo exigen):
 * - available=false: "Marcar agotado". Stock a 0, se oculta de la tienda y se guarda
 *   el stock que tenía en stockBeforeOutOfStock.
 * - available=true: "Volver a mostrar". Solo si lo ocultó la bodega: devuelve
 *   exactamente el stock guardado. No se puede inventar ni cambiar stock.
 */
async function setProductWarehouseAvailability(productId, available) {
    const user = auth.currentUser;
    if (!user) throw new Error('Sesión no válida');

    const productRef = doc(db, "products", String(productId));
    const snapshot = await getDoc(productRef);
    if (!snapshot.exists()) throw new Error('Producto no encontrado');
    const product = snapshot.data() || {};
    const nowIso = new Date().toISOString();

    if (available) {
        if (product.active !== false || !Number.isInteger(product.stockBeforeOutOfStock)) {
            throw new Error('Este producto no fue ocultado por bodega');
        }
        await updateDoc(productRef, {
            stock: product.stockBeforeOutOfStock,
            active: true,
            stockBeforeOutOfStock: deleteField(),
            outOfStockBy: deleteField(),
            outOfStockAt: deleteField(),
            updatedAt: nowIso
        });
        return { active: true, stock: product.stockBeforeOutOfStock };
    }

    const currentStock = Number.isInteger(product.stock) ? product.stock : Math.max(0, Number.parseInt(product.stock, 10) || 0);
    await updateDoc(productRef, {
        stock: 0,
        active: false,
        stockBeforeOutOfStock: currentStock,
        outOfStockBy: user.uid,
        outOfStockAt: nowIso,
        updatedAt: nowIso
    });
    return { active: false, stock: 0 };
}

// ========== FUNCIONES DE PRODUCTOS ==========

/**
 * Productos guardados en la caché local de Firestore (sin red).
 * Devuelve [] si todavía no hay nada en caché.
 */
async function getProductsFromCache() {
    try {
        const snapshot = await getDocsFromCache(collection(db, "products"));
        return snapshot.docs.map((productDoc) => {
            const data = productDoc.data();
            return { ...data, legacyId: data?.id ?? null, id: productDoc.id };
        });
    } catch (_) {
        return [];
    }
}

/**
 * Obtener todos los productos.
 * options.source === 'cache' lee solo la caché local (respuesta inmediata).
 */
async function getProducts(options = {}) {
    if (options.source === 'cache') {
        return getProductsFromCache();
    }

    try {
        const productsQuery = collection(db, "products");

        const querySnapshot = await getDocs(productsQuery);
        const products = [];

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            products.push({
                ...data,
                legacyId: data?.id ?? null,
                id: doc.id
            });
        });

        console.log('✅ Productos cargados:', products.length);
        return products;
    } catch (error) {
        const isPermissionError = error?.code === 'permission-denied' || error?.code === 'firestore/permission-denied';

        if (isPermissionError) {
            console.warn('⚠️ Permiso denegado en consulta admin, reintentando consulta pública...');
            try {
                const publicQuery = query(collection(db, "products"), where("active", "==", true));
                const publicSnapshot = await getDocs(publicQuery);
                const publicProducts = [];

                publicSnapshot.forEach((productDoc) => {
                    const data = productDoc.data();
                    publicProducts.push({
                        ...data,
                        legacyId: data?.id ?? null,
                        id: productDoc.id
                    });
                });

                console.log('✅ Productos públicos cargados tras fallback:', publicProducts.length);
                return publicProducts;
            } catch (fallbackError) {
                console.error('❌ Error en fallback de productos públicos:', fallbackError);
            }
        }

        console.error('❌ Error al obtener productos:', error);
        throw error;
    }
}

/**
 * Crear nuevo producto
 */
async function createProduct(productData) {
    try {
        const sanitizedData = sanitizeForFirestore(productData);
        const docRef = await addDoc(collection(db, "products"), {
            ...sanitizedData,
            active: sanitizedData.active !== false,
            createdAt: new Date().toISOString()
        });
        
        console.log('✅ Producto creado:', docRef.id);
        return {
            id: docRef.id,
            ...sanitizedData
        };
    } catch (error) {
        console.error('❌ Error al crear producto:', error);
        throw error;
    }
}

const BODEGA_MARKER_FIELDS = ['stockBeforeOutOfStock', 'outOfStockBy', 'outOfStockAt'];

// Datos de una edición del admin. Si cambia la visibilidad o el stock, se borra la marca
// "ocultado por bodega": así la bodega no puede volver a mostrar un producto que el admin
// ocultó, ni devolverle un stock antiguo (las reglas también lo exigen).
function buildAdminProductUpdate(productData, currentData) {
    const sanitizedData = sanitizeForFirestore(productData);
    BODEGA_MARKER_FIELDS.forEach(field => delete sanitizedData[field]);
    const changesVisibilityOrStock = ['active', 'stock'].some(field =>
        field in sanitizedData && sanitizedData[field] !== currentData?.[field]);
    const payload = { ...sanitizedData, updatedAt: new Date().toISOString() };
    if (changesVisibilityOrStock && BODEGA_MARKER_FIELDS.some(field => field in (currentData || {}))) {
        BODEGA_MARKER_FIELDS.forEach(field => { payload[field] = deleteField(); });
    }
    return payload;
}

/**
 * Actualizar producto
 */
async function updateProduct(productId, productData) {
    try {
        const productRef = doc(db, "products", String(productId));
        const currentSnap = await getDoc(productRef);
        if (!currentSnap.exists()) {
            throw Object.assign(new Error('No document to update'), { code: 'not-found' });
        }

        await updateDoc(productRef, buildAdminProductUpdate(productData, currentSnap.data()));

        console.log('✅ Producto actualizado:', productId);
        return true;
    } catch (error) {
        const isNotFound = error?.code === 'not-found' || error?.message?.includes('No document to update');

        if (isNotFound) {
            console.warn('⚠️ Producto no encontrado por docId, intentando búsqueda por id lógico:', productId);
            const lookupQuery = query(collection(db, "products"), where("id", "==", String(productId)));
            const lookupSnapshot = await getDocs(lookupQuery);

            if (!lookupSnapshot.empty) {
                const productDoc = lookupSnapshot.docs[0];
                await updateDoc(productDoc.ref, buildAdminProductUpdate(productData, productDoc.data()));
                console.log('✅ Producto actualizado por id lógico:', productId);
                return true;
            }
        }

        console.error('❌ Error al actualizar producto:', error);
        throw error;
    }
}

/**
 * Eliminar producto
 */
async function deleteProduct(productId) {
    try {
        const normalizedId = String(productId);
        await deleteDoc(doc(db, "products", normalizedId));

        console.log('✅ Producto eliminado definitivamente:', normalizedId);
        return true;
    } catch (error) {
        const isNotFound = error?.code === 'not-found' || error?.message?.includes('No document to delete');

        if (isNotFound) {
            console.warn('⚠️ Producto no encontrado por docId, intentando búsqueda por id lógico:', productId);
            const lookupQuery = query(collection(db, "products"), where("id", "==", String(productId)));
            const lookupSnapshot = await getDocs(lookupQuery);

            if (!lookupSnapshot.empty) {
                await deleteDoc(lookupSnapshot.docs[0].ref);
                console.log('✅ Producto eliminado por id lógico:', productId);
                return true;
            }
        }

        console.error('❌ Error al eliminar producto:', error);
        throw error;
    }
}

/**
 * Obtener productos por categoría
 */
async function getProductsByCategory(categoryId) {
    try {
        const q = query(
            collection(db, "products"), 
            where("category", "==", categoryId),
            where("active", "==", true)
        );
        const querySnapshot = await getDocs(q);
        const products = [];

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            products.push({
                ...data,
                legacyId: data?.id ?? null,
                id: doc.id
            });
        });

        console.log(`✅ Productos de categoría ${categoryId}:`, products.length);
        return products;
    } catch (error) {
        console.error('❌ Error al obtener productos por categoría:', error);
        throw error;
    }
}

/**
 * Obtener productos destacados
 */
async function getFeaturedProducts() {
    try {
        const q = query(
            collection(db, "products"), 
            where("featured", "==", true),
            where("active", "==", true)
        );
        const querySnapshot = await getDocs(q);
        const products = [];

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            products.push({
                ...data,
                legacyId: data?.id ?? null,
                id: doc.id
            });
        });

        console.log('✅ Productos destacados:', products.length);
        return products;
    } catch (error) {
        console.error('❌ Error al obtener productos destacados:', error);
        throw error;
    }
}

// ========== FUNCIONES DE CATEGORÍAS, MARCAS Y DESCUENTOS ==========

async function getCategories(options = {}) {
    if (options.source === 'cache') {
        try {
            const cachedSnapshot = await getDocsFromCache(collection(db, "categories"));
            return cachedSnapshot.docs.map((categoryDoc) => ({ id: categoryDoc.id, ...categoryDoc.data() }));
        } catch (_) {
            return [];
        }
    }

    try {
        const querySnapshot = await getDocs(collection(db, "categories"));
        const categories = [];

        querySnapshot.forEach((categoryDoc) => {
            categories.push({
                id: categoryDoc.id,
                ...categoryDoc.data()
            });
        });

        return categories;
    } catch (error) {
        console.error('❌ Error al obtener categorías:', error);
        throw error;
    }
}

async function saveCategory(categoryData) {
    try {
        const id = String(categoryData.id || Date.now());
        const payload = sanitizeForFirestore({
            ...categoryData,
            id,
            updatedAt: new Date().toISOString()
        });

        await setDoc(doc(db, "categories", id), payload, { merge: true });
        return payload;
    } catch (error) {
        console.error('❌ Error al guardar categoría:', error);
        throw error;
    }
}

async function deleteCategory(categoryId) {
    try {
        await deleteDoc(doc(db, "categories", String(categoryId)));
        return true;
    } catch (error) {
        console.error('❌ Error al eliminar categoría:', error);
        throw error;
    }
}

async function getBrands() {
    try {
        const userLS = JSON.parse(localStorage.getItem('hairia_current_user') || 'null');
        const userSS = JSON.parse(sessionStorage.getItem('hairia_current_user') || 'null');
        const currentUser = userLS || userSS;
        const hasAdminRoleInSession = currentUser?.role === 'admin';
        let canUseAdminQuery = false;

        if (hasAdminRoleInSession && auth.currentUser?.uid) {
            canUseAdminQuery = await isUserAdmin(auth.currentUser.uid);
        }

        // Se leen todas (son pocas) y se ocultan solo las desactivadas a propósito: igual que el
        // admin, una marca sin el campo "active" cuenta como activa.
        const querySnapshot = await getDocs(collection(db, "brands"));
        const brands = [];

        querySnapshot.forEach((brandDoc) => {
            const data = brandDoc.data();
            if (!canUseAdminQuery && data.active === false) return;
            brands.push({
                id: brandDoc.id,
                ...data
            });
        });

        return brands;
    } catch (error) {
        const isPermissionError = error?.code === 'permission-denied' || error?.code === 'firestore/permission-denied';

        if (isPermissionError) {
            console.warn('⚠️ Permiso denegado en consulta admin de marcas, reintentando consulta publica...');
            try {
                const publicQuery = query(collection(db, "brands"), where("active", "==", true));
                const publicSnapshot = await getDocs(publicQuery);
                const publicBrands = [];

                publicSnapshot.forEach((brandDoc) => {
                    publicBrands.push({
                        id: brandDoc.id,
                        ...brandDoc.data()
                    });
                });

                return publicBrands;
            } catch (fallbackError) {
                console.error('❌ Error en fallback de marcas públicas:', fallbackError);
            }
        }

        console.error('❌ Error al obtener marcas:', error);
        throw error;
    }
}

async function saveBrand(brandData) {
    try {
        const id = String(brandData.id || Date.now()).toLowerCase();
        const payload = sanitizeForFirestore({
            ...brandData,
            id,
            updatedAt: new Date().toISOString()
        });

        await setDoc(doc(db, "brands", id), payload, { merge: true });
        return payload;
    } catch (error) {
        console.error('❌ Error al guardar marca:', error);
        throw error;
    }
}

async function uploadBrandLogo(dataUrl, brandId) {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) {
        return dataUrl || '';
    }

    // Resuelto 2026-09-28: el storage/unauthorized venía de que la cuenta de servicio
    // de Storage no tenía el rol IAM roles/firebaserules.firestoreServiceAgent, necesario
    // para que firestore.get() funcione dentro de storage.rules (isAdmin).
    const safeBrandId = String(brandId || 'brand').toLowerCase().replace(/[^a-z0-9-]/g, '-');
    const path = `brand-logos/${safeBrandId}/${Date.now()}.jpg`;
    const { storage, storageRef, uploadString, getDownloadURL } = await getStorageContext();
    const fileRef = storageRef(storage, path);
    // Se fuerza el contentType porque algunos navegadores/archivos reportan tipos
    // no estándar (ej: "image/jpg") que no coinciden con las reglas de Storage.
    await uploadString(fileRef, dataUrl, 'data_url', { contentType: 'image/jpeg' });
    return await getDownloadURL(fileRef);
}

/**
 * Sube la imagen de un producto a Storage y devuelve su URL pública.
 * Guardar solo la URL en Firestore evita que cada visita descargue la foto
 * completa en base64 junto con el catálogo.
 */
async function uploadProductImage(dataUrl) {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) {
        return dataUrl || '';
    }

    const mimeMatch = /^data:(image\/(?:jpeg|png|webp))[;,]/i.exec(dataUrl);
    const contentType = mimeMatch ? mimeMatch[1].toLowerCase() : 'image/jpeg';
    const extension = contentType === 'image/webp' ? 'webp' : contentType === 'image/png' ? 'png' : 'jpg';
    const randomPart = window.crypto?.randomUUID?.().replace(/-/g, '') || `${Date.now()}${Math.random().toString(16).slice(2)}`;
    const path = `product-images/${randomPart}.${extension}`;

    const { storage, storageRef, uploadString, getDownloadURL } = await getStorageContext();
    const fileRef = storageRef(storage, path);
    await uploadString(fileRef, dataUrl, 'data_url', {
        contentType,
        cacheControl: 'public, max-age=31536000, immutable'
    });
    return await getDownloadURL(fileRef);
}

async function deleteBrand(brandId) {
    try {
        await deleteDoc(doc(db, "brands", String(brandId).toLowerCase()));
        return true;
    } catch (error) {
        console.error('❌ Error al eliminar marca:', error);
        throw error;
    }
}

async function getDiscountCodes() {
    try {
        const querySnapshot = await getDocs(collection(db, "discountCodes"));
        const discounts = [];

        querySnapshot.forEach((discountDoc) => {
            discounts.push({
                id: discountDoc.id,
                ...discountDoc.data()
            });
        });

        return discounts;
    } catch (error) {
        console.error('❌ Error al obtener descuentos:', error);
        throw error;
    }
}

async function saveDiscountCode(discountData) {
    try {
        const id = String(discountData.id || discountData.code || Date.now()).toLowerCase();
        const payload = sanitizeForFirestore({
            ...discountData,
            id,
            updatedAt: new Date().toISOString()
        });

        await setDoc(doc(db, "discountCodes", id), payload, { merge: true });
        return payload;
    } catch (error) {
        console.error('❌ Error al guardar descuento:', error);
        throw error;
    }
}

async function deleteDiscountCode(discountId) {
    try {
        await deleteDoc(doc(db, "discountCodes", String(discountId).toLowerCase()));
        return true;
    } catch (error) {
        console.error('❌ Error al eliminar descuento:', error);
        throw error;
    }
}

// ========== HELPERS DE MIGRACIÓN (IDs DETERMINÍSTICOS) ==========

async function saveProductById(productData) {
    try {
        const id = String(productData.id || Date.now());
        const payload = sanitizeForFirestore({
            ...productData,
            id,
            updatedAt: new Date().toISOString()
        });

        await setDoc(doc(db, "products", id), payload, { merge: true });
        return payload;
    } catch (error) {
        console.error('❌ Error en saveProductById:', error);
        throw error;
    }
}

async function saveOrderById(orderData) {
    try {
        const id = String(orderData.id || Date.now());
        const payload = sanitizeForFirestore({
            ...orderData,
            id,
            updatedAt: new Date().toISOString()
        });

        await setDoc(doc(db, "orders", id), payload, { merge: true });
        return payload;
    } catch (error) {
        console.error('❌ Error en saveOrderById:', error);
        throw error;
    }
}

// ========== FUNCIONES AUXILIARES ==========

/**
 * Traducir errores de Firebase a mensajes amigables
 */
function getFirebaseErrorMessage(errorCode) {
    const errorMessages = {
        // Errores de registro
        'auth/email-already-in-use': 'Este correo electrónico ya está registrado.',
        'auth/invalid-email': 'El correo electrónico no es válido.',
        'auth/operation-not-allowed': 'El registro con email/contraseña no está habilitado.',
        'auth/weak-password': 'La contraseña es muy débil. Debe tener al menos 12 caracteres, 1 mayúscula, 1 número y 1 símbolo (ej: ! @ # $ % & * ? _).',
        'auth/password-does-not-meet-requirements': 'La contraseña debe tener al menos 12 caracteres, 1 mayúscula (A-Z), 1 número y 1 símbolo (ej: ! @ # $ % & * ? _).',
        'auth/requires-recent-login': 'Por seguridad, vuelve a verificar tu contraseña actual para continuar.',
        
        // Errores de login
        'auth/user-disabled': 'Esta cuenta ha sido deshabilitada.',
        'auth/user-not-found': 'No existe una cuenta con este correo electrónico.',
        'auth/wrong-password': 'La contraseña es incorrecta.',
        'auth/invalid-credential': 'Credenciales inválidas.',
        'auth/operation-not-allowed': 'Este método de inicio de sesión no está habilitado. Revisa Firebase Authentication > Sign-in method.',
        
        // Errores generales
        'auth/too-many-requests': 'Demasiados intentos fallidos. Intenta más tarde.',
        'auth/network-request-failed': 'Error de conexión. Verifica tu internet.',
        'auth/internal-error': 'Error interno del servidor.',
        'auth/popup-closed-by-user': 'Cerraste la ventana de Google antes de completar el inicio de sesión.',
        'auth/cancelled-popup-request': 'Se canceló el intento de inicio de sesión con Google.',
        'auth/popup-blocked': 'El navegador bloqueó la ventana emergente. Permite popups e inténtalo nuevamente.',
        'auth/account-exists-with-different-credential': 'Ya existe una cuenta con este correo usando otro método de acceso.',
        'auth/unauthorized-domain': 'Este dominio no está autorizado en Firebase. Agrega localhost/127.0.0.1 en Authentication > Settings > Authorized domains.',
        'auth/invalid-continue-uri': 'La URL de retorno no es válida. Verifica la configuración del dominio autorizado.',
        'auth/invalid-action-code': 'El enlace no es válido o ya fue usado.',
        'auth/expired-action-code': 'El enlace expiró. Solicita uno nuevo.',
        
        // Errores personalizados
        'unknown': 'Error desconocido. Por favor, intenta nuevamente.'
    };
    
    return errorMessages[errorCode] || 'Ocurrió un error inesperado. Intenta nuevamente.';
}

// ========== FUNCIONES DE CARRITO ==========

/**
 * Obtener carrito del usuario
 */
async function getCart(userId) {
    try {
        const cartRef = doc(db, "userCarts", userId);
        const cartSnap = await getDoc(cartRef);
        
        if (cartSnap.exists()) {
            console.log('✅ Carrito obtenido de Firebase');
            return cartSnap.data().items || [];
        } else {
            console.log('ℹ️ Carrito vacío');
            return [];
        }
    } catch (error) {
        console.error('❌ Error al obtener carrito:', error);
        throw error;
    }
}

/**
 * Guardar carrito del usuario
 */
async function saveCart(userId, cartItems) {
    try {
        const cartRef = doc(db, "userCarts", userId);
        await setDoc(cartRef, {
            items: cartItems,
            updatedAt: new Date().toISOString()
        }, { merge: true });
        
        console.log('✅ Carrito guardado en Firebase');
        return true;
    } catch (error) {
        console.error('❌ Error al guardar carrito:', error);
        throw error;
    }
}

// ========== FUNCIONES DE DATOS DE ENVÍO ==========

/**
 * Obtener datos de envío del usuario
 */
async function getShippingData(userId) {
    try {
        const shippingRef = doc(db, "shippingData", userId);
        const shippingSnap = await getDoc(shippingRef);
        
        if (shippingSnap.exists()) {
            console.log('✅ Datos de envío obtenidos de Firebase');
            return shippingSnap.data();
        } else {
            console.log('ℹ️ Sin datos de envío guardados');
            return null;
        }
    } catch (error) {
        console.error('❌ Error al obtener datos de envío:', error);
        throw error;
    }
}

/**
 * Guardar datos de envío del usuario
 */
async function saveShippingData(userId, shippingData) {
    try {
        const sanitizedData = sanitizeForFirestore(shippingData);
        const shippingRef = doc(db, "shippingData", userId);
        
        await setDoc(shippingRef, {
            ...sanitizedData,
            updatedAt: new Date().toISOString()
        }, { merge: true });
        
        console.log('✅ Datos de envío guardados en Firebase');
        return true;
    } catch (error) {
        console.error('❌ Error al guardar datos de envío:', error);
        throw error;
    }
}

function isStrongPassword(password) {
    const normalized = String(password || '');
    const hasUpper = /[A-Z]/.test(normalized);
    const hasNumber = /\d/.test(normalized);
    const hasSpecial = /[\^$*.[\]{}()?"!@#%&\/\\,><':;|_~]/.test(normalized);
    return normalized.length >= 12 && hasUpper && hasNumber && hasSpecial;
}

/**
 * Obtener configuración del feature de análisis capilar con IA
 */
// ========== ETIQUETAS IA DE PRODUCTOS ==========
// Colección iaProductTags/{productId}: puntajes 0-3 por dimensión que usa el
// recomendador del análisis capilar. Complementan/reemplazan al Excel base.

const IA_TAG_CONFIDENCE = ['Alta', 'Media', 'Baja'];

function sanitizeIaScores(scores) {
    const clean = {};
    Object.entries(scores || {}).forEach(([key, value]) => {
        const number = Math.round(Number(value));
        if (/^[a-z0-9_]{2,60}$/.test(key) && number >= 1 && number <= 3) clean[key] = number;
    });
    return clean;
}

async function getIaProductTags() {
    const snapshot = await getDocs(collection(db, "iaProductTags"));
    return snapshot.docs.map(tagDoc => ({ productId: tagDoc.id, ...tagDoc.data() }));
}

async function saveIaProductTags(productId, data = {}) {
    const id = String(productId || '').trim();
    if (!id) throw new Error('Falta el ID del producto');

    const payload = {
        productId: id,
        name: String(data.name || '').slice(0, 200),
        scores: sanitizeIaScores(data.scores),
        confidence: IA_TAG_CONFIDENCE.includes(data.confidence) ? data.confidence : 'Media',
        need: String(data.need || '').slice(0, 200),
        hairTypes: String(data.hairTypes || '').slice(0, 300),
        updatedAt: new Date().toISOString(),
        updatedBy: auth.currentUser?.email || ''
    };

    await setDoc(doc(db, "iaProductTags", id), payload);
    return payload;
}

async function deleteIaProductTags(productId) {
    await deleteDoc(doc(db, "iaProductTags", String(productId)));
    return true;
}

// ========== VIDEOS DEL INICIO ==========
// La configuración la publica el procesador de videos (media-worker); aquí solo se lee.
async function getHomeMediaConfig() {
    try {
        const snap = await getDoc(doc(db, "siteContent", "homeMedia"));
        return snap.exists() ? snap.data() : null;
    } catch (error) {
        console.warn('⚠️ No se pudo leer la configuración de videos del inicio:', error);
        return null;
    }
}

// Sube el video original (admin) para que el procesador lo recorte y optimice.
// onProgress recibe un número entre 0 y 1.
async function uploadHomeMediaSource(file, onProgress) {
    const extension = (/\.(mp4|mov|m4v|webm)$/i.exec(file?.name || '') || [, 'mp4'])[1].toLowerCase();
    const contentType = { mp4: 'video/mp4', mov: 'video/quicktime', m4v: 'video/x-m4v', webm: 'video/webm' }[extension];
    const randomPart = window.crypto?.randomUUID?.().replace(/-/g, '') || `${Date.now()}${Math.random().toString(16).slice(2)}`;
    const path = `home-media-uploads/${randomPart}.${extension}`;

    const { storage, storageRef, uploadBytesResumable } = await getStorageContext();
    const task = uploadBytesResumable(storageRef(storage, path), file, { contentType });
    await new Promise((resolve, reject) => {
        task.on('state_changed',
            snapshot => onProgress?.(snapshot.totalBytes ? snapshot.bytesTransferred / snapshot.totalBytes : 0),
            reject,
            resolve);
    });
    return path;
}

async function getHairAnalysisConfig() {
    try {
        const configRef = doc(db, "configuracion", "ia_cabello");
        const configSnap = await getDoc(configRef);

        if (configSnap.exists()) {
            return configSnap.data();
        }

        console.log('ℹ️ Sin configuración guardada para ia_cabello, se usan valores por defecto');
        return null;
    } catch (error) {
        console.error('❌ Error al obtener configuración de análisis capilar:', error);
        throw error;
    }
}

/**
 * Guardar configuración del feature de análisis capilar con IA
 */
async function saveHairAnalysisConfig(config) {
    try {
        const sanitizedConfig = sanitizeForFirestore(config);
        const configRef = doc(db, "configuracion", "ia_cabello");

        await setDoc(configRef, {
            ...sanitizedConfig,
            updatedAt: new Date().toISOString()
        }, { merge: true });

        console.log('✅ Configuración de análisis capilar guardada en Firebase');
        return true;
    } catch (error) {
        console.error('❌ Error al guardar configuración de análisis capilar:', error);
        throw error;
    }
}

/**
 * Obtener evidencia de consentimiento del análisis capilar de un usuario
 */
async function getHairAnalysisConsent(userId) {
    try {
        const consentRef = doc(db, "hairAnalysisConsents", userId);
        const consentSnap = await getDoc(consentRef);
        return consentSnap.exists() ? consentSnap.data() : null;
    } catch (error) {
        console.error('❌ Error al obtener consentimiento de análisis capilar:', error);
        throw error;
    }
}

/**
 * Guardar evidencia de consentimiento (análisis obligatorio + entrenamiento opcional)
 * Registra qué versión de los términos aceptó el usuario y cuándo, para poder
 * demostrarlo ante una eventual auditoría o solicitud del titular de los datos.
 */
async function saveHairAnalysisConsent(userId, consent) {
    try {
        const consentRef = doc(db, "hairAnalysisConsents", userId);
        await setDoc(consentRef, {
            ...sanitizeForFirestore(consent),
            updatedAt: new Date().toISOString()
        }, { merge: true });

        console.log('✅ Consentimiento de análisis capilar registrado');
        return true;
    } catch (error) {
        console.error('❌ Error al registrar consentimiento de análisis capilar:', error);
        throw error;
    }
}

/**
 * Subir fotos de cabello para entrenamiento de IA de forma anonimizada.
 * Solo debe llamarse cuando el usuario otorgó explícitamente el consentimiento
 * opcional de entrenamiento. No recibe ni guarda nombre, correo, RUT ni uid:
 * el identificador de la muestra es aleatorio y no se vincula con la identidad
 * del usuario, para evitar asociar innecesariamente el dataset con datos personales.
 */
const MAX_TRAINING_PHOTOS_PER_SAMPLE = 4;

// Respuestas válidas de las preguntas del análisis (las mismas que exigen las reglas)
function sanitizeTrainingAnswers(answers) {
    const clean = {};
    ['puntas', 'calor'].forEach(key => {
        const value = Number(answers?.[key]);
        if (Number.isInteger(value) && value >= 0 && value <= 3) clean[key] = value;
    });
    if (['no', 'tenido', 'decolorado', 'no_sabe'].includes(answers?.tenido)) clean.tenido = answers.tenido;
    // Confirmaciones del modelo de cuero cabelludo (beta)
    ['canas', 'caspa'].forEach(key => {
        if (answers?.[key] === 'si' || answers?.[key] === 'no') clean[key] = answers[key];
    });
    return clean;
}

// Predicción del modelo guardada junto a las fotos (sirve para comparar al reentrenar)
function sanitizeTrainingPrediction(prediction) {
    const clean = {};
    ['type', 'condition', 'frizz', 'scalp', 'chemical'].forEach(key => {
        const block = prediction?.[key];
        if (!block) return;
        const probabilities = {};
        Object.entries(block.probabilities || {}).slice(0, 8).forEach(([label, value]) => {
            const number = Number(value);
            if (/^[a-z_]{1,20}$/.test(label) && Number.isFinite(number)) probabilities[label] = Math.round(number * 1000) / 1000;
        });
        clean[key] = {
            // Cuero cabelludo: probabilidades de graso/caspa/baja densidad/canas y el nivel de canas como "predicción"
            prediction: String(block.rawPrediction || block.prediction || block.canas_nivel?.label || '').slice(0, 20),
            probabilities
        };
    });
    return clean;
}

/**
 * Guarda una muestra de entrenamiento: fotos + respuestas del cliente + predicción del modelo.
 * Cada cuenta puede aportar hasta 30 muestras (contador hairTrainingQuota, exigido por las reglas).
 */
async function uploadHairAnalysisTrainingSample(photos, metadata = {}) {
    const sampleId = generateAnonymousSampleId();
    const currentUser = auth.currentUser;
    if (!currentUser?.uid) {
        throw new Error('Debes iniciar sesión para aportar muestras de entrenamiento');
    }

    const sampleRef = doc(db, "hairAnalysisTrainingSamples", sampleId);
    const quotaRef = doc(db, "hairTrainingQuota", currentUser.uid);
    const answers = sanitizeTrainingAnswers(metadata.answers);
    const prediction = sanitizeTrainingPrediction(metadata.prediction);
    const nowIso = new Date().toISOString();

    await runTransaction(db, async transaction => {
        const quotaSnap = await transaction.get(quotaRef);
        const count = (quotaSnap.exists() ? Number(quotaSnap.data().count) || 0 : 0) + 1;
        if (count > 30) throw new Error('Se alcanzó el máximo de muestras de entrenamiento para esta cuenta');
        transaction.set(quotaRef, { count, updatedAt: nowIso });
        transaction.set(sampleRef, {
            sampleId,
            userId: currentUser.uid,
            photoCount: 0,
            storagePaths: [],
            createdAt: nowIso,
            ...(Object.keys(answers).length ? { answers } : {}),
            ...(Object.keys(prediction).length ? { prediction } : {}),
            ...(metadata.modelVersion ? { modelVersion: String(metadata.modelVersion).slice(0, 40) } : {})
        });
    });

    photos = (photos || []).slice(0, MAX_TRAINING_PHOTOS_PER_SAMPLE);

    const storagePaths = [];

    for (let index = 0; index < photos.length; index += 1) {
        const photo = photos[index];
        if (!photo?.dataUrl) continue;

        const fileName = `img_${sampleId}_${index}.jpg`;
        const path = `hair-analysis-training/${sampleId}/${fileName}`;
        const { storage, storageRef, uploadString } = await getStorageContext();
        const fileRef = storageRef(storage, path);
        await uploadString(fileRef, photo.dataUrl, 'data_url');
        storagePaths.push(path);
    }

    await setDoc(sampleRef, {
        photoCount: storagePaths.length,
        storagePaths
    }, { merge: true });

    console.log('✅ Muestra anonimizada de entrenamiento almacenada:', sampleId);
    return sampleId;
}

function generateAnonymousSampleId() {
    if (window.crypto?.randomUUID) {
        return window.crypto.randomUUID().replace(/-/g, '').slice(0, 16);
    }
    return `${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`;
}

// ========== EXPORTAR FUNCIONES ==========
// DEFINIR el objeto window.firebase con TODAS las funciones
window.firebase = {
    // Autenticación
    registerUser,
    loginUser,
    loginWithGoogle,
    getGoogleRedirectUser,
    logoutUser,
    getCurrentUser,
    signInAsGuest,
    isUserAdmin,
    isUserBodeguero,
    getUserRole,
    requestPasswordReset,
    confirmPasswordReset: confirmPasswordResetFunction,
    confirmEmailVerification,
    whenSessionChecked: () => authReady,
    verifyResetCode,
    updateCurrentUserName,
    verifyCurrentPassword,
    changeCurrentUserPassword,
    requestAccountDeletion,
    
    // Órdenes
    createOrder,
    getAllOrders,
    getOrdersForPanel,
    searchOrdersHistory,
    countOrdersByStatus,
    getUserOrders,
    trackPageVisit,
    getAnalyticsMetrics,
    updateOrderStatus,
    updateOrderWarehouseData,
    setProductWarehouseAvailability,
    
    // Productos
    getProducts,
    createProduct,
    updateProduct,
    deleteProduct,
    saveProductById,
    uploadProductImage,
    getProductsByCategory,
    getFeaturedProducts,

    // Categorías, marcas y descuentos
    getCategories,
    saveCategory,
    deleteCategory,
    getBrands,
    saveBrand,
    uploadBrandLogo,
    deleteBrand,
    getDiscountCodes,
    saveDiscountCode,
    deleteDiscountCode,

    // Carrito
    getCart,
    saveCart,
    
    // Envío
    getShippingData,
    saveShippingData,

    // Configuración de funciones del sitio (feature flags)
    getHairAnalysisConfig,
    saveHairAnalysisConfig,

    // Videos del inicio
    getHomeMediaConfig,
    uploadHomeMediaSource,

    // Etiquetas IA de productos (recomendador del análisis capilar)
    getIaProductTags,
    saveIaProductTags,
    deleteIaProductTags,

    // Consentimiento y entrenamiento del análisis capilar con IA
    getHairAnalysisConsent,
    saveHairAnalysisConsent,
    uploadHairAnalysisTrainingSample,
    
    // Instancias
    db,
    auth,
    
    // Funciones de Firestore (para admin-orders.js)
    getDocs,
    collection,
    
    // Utilidades
    getFirebaseErrorMessage,
    sanitizeForFirestore
};

console.log('✅ Firebase Config cargado - window.firebase disponible');
console.log('📋 Funciones disponibles:', Object.keys(window.firebase));
window.dispatchEvent(new CustomEvent('hairia:firebase-ready', {
    detail: {
        hasGetProducts: typeof window.firebase.getProducts === 'function',
        hasGetCategories: typeof window.firebase.getCategories === 'function'
    }
}));