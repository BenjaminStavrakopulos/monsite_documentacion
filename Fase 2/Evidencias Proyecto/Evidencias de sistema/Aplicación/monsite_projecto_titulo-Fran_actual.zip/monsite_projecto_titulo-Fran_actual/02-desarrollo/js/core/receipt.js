(function () {
    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatCLP(value) {
        return new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            maximumFractionDigits: 0
        }).format(Number(value) || 0);
    }

    // 187654321 -> 18.765.432-1
    function formatRut(rut) {
        const clean = String(rut || '').replace(/[^0-9kK]/g, '');
        if (clean.length < 2) return String(rut || '');
        const body = clean.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        return `${body}-${clean.slice(-1).toUpperCase()}`;
    }

    function formatDate(value) {
        const date = new Date(value || Date.now());
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleString('es-CL', {
            timeZone: 'America/Santiago',
            day: 'numeric',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function getTotals(order, items) {
        const totals = order.totals || {};
        const subtotal = Number(totals.subtotal) || items.reduce((sum, item) => sum + ((Number(item.price) || 0) * (Number(item.quantity) || 0)), 0);
        const shipping = Number(totals.shipping ?? order.shipping) || 0;
        const discount = Number(totals.discount ?? order.discount) || 0;
        const total = Number(totals.total ?? order.total) || (subtotal + shipping - discount);
        return { subtotal, shipping, discount, total };
    }

    const STATUS_LABELS = {
        paid: 'Pagado',
        shipped: 'Enviado',
        delivered: 'Entregado',
        refunded: 'Devuelto',
        cancelled: 'Cancelado'
    };

    const PAYMENT_METHODS = {
        mercado_pago: 'Mercado Pago',
        transbank_webpay: 'Webpay',
        webpay: 'Webpay'
    };

    function getStatusLabel(order) {
        const status = String(order.status || '').toLowerCase();
        if (STATUS_LABELS[status]) return STATUS_LABELS[status];
        return String(order.paymentStatus || '').toLowerCase() === 'approved' ? 'Pagado' : 'Pendiente';
    }

    // Abre la boleta para revisarla; imprimir o guardar como PDF es opcional
    // (botón dentro de la boleta). No se imprime automáticamente.
    function openOrderReceipt(order) {
        if (!order) return;

        const popup = window.open('', '_blank', 'width=860,height=940');
        if (!popup) {
            alert('El navegador bloqueó la ventana de la boleta. Permite ventanas emergentes para este sitio.');
            return;
        }

        // Número de orden que ve el cliente: el corto (MO-4827-1936) si existe
        const displayId = order.trackingCode || order.id || '';
        const items = Array.isArray(order.items) ? order.items : [];
        const totals = getTotals(order, items);
        const shipping = order.shippingData || {};
        const customerName = `${shipping.firstName || ''} ${shipping.lastName || ''}`.trim();
        const base = window.location.pathname.includes('/admin/') ? '../' : '';
        const logoUrl = new URL(`${base}images/logo.jpg`, window.location.href).href;
        const statusLabel = getStatusLabel(order);
        const statusKey = String(order.status || '').toLowerCase();
        const statusTone = ['cancelled', 'refunded'].includes(statusKey) ? 'muted' : (statusLabel === 'Pendiente' ? 'pending' : 'ok');
        const paymentMethod = PAYMENT_METHODS[String(order.paymentMethod || '').toLowerCase()] || '';
        const itemCount = items.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);

        const rows = items.map(item => {
            const quantity = Number(item.quantity) || 0;
            const price = Number(item.price) || 0;
            const image = item.image || item.imageUrl || '';
            return `<tr>
                <td>
                    <div class="product">
                        <span class="thumb">${image ? `<img src="${escapeHtml(image)}" alt="">` : ''}</span>
                        <span><strong>${escapeHtml(item.name || 'Producto')}</strong><small>${formatCLP(price)} c/u</small></span>
                    </div>
                </td>
                <td class="num">${quantity}</td>
                <td class="num">${formatCLP(price * quantity)}</td>
            </tr>`;
        }).join('');

        const receipt = `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Boleta #${escapeHtml(displayId)} · Monsite</title>
<style>
    * { box-sizing: border-box; }
    body { margin: 0; background: #f4f4f4; color: #111; font: 14px/1.5 'Segoe UI', -apple-system, BlinkMacSystemFont, Arial, sans-serif; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .toolbar { position: sticky; top: 0; z-index: 2; display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 12px 20px; background: rgba(255,255,255,.94); backdrop-filter: blur(6px); border-bottom: 1px solid #e8e8e8; }
    .toolbar span { font-size: 13px; color: #777; }
    .toolbar div { display: flex; gap: 8px; }
    .toolbar button { font: inherit; font-size: 13px; font-weight: 600; height: 38px; padding: 0 16px; border-radius: 999px; cursor: pointer; border: 1px solid #d4d4d4; background: #fff; color: #111; }
    .toolbar .primary { background: #111; border-color: #111; color: #fff; }
    .sheet { max-width: 720px; margin: 28px auto; background: #fff; border: 1px solid #e8e8e8; border-radius: 16px; overflow: hidden; }
    .hero { padding: 36px 40px 28px; border-bottom: 1px solid #efefef; }
    .top { display: flex; justify-content: space-between; align-items: center; gap: 16px; }
    .brand { display: flex; align-items: center; gap: 12px; }
    .brand img { width: 44px; height: 44px; object-fit: contain; border-radius: 10px; }
    .brand strong { display: block; font-size: 17px; letter-spacing: .02em; }
    .brand span { font-size: 12px; color: #888; }
    .chip { display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 12px; border-radius: 999px; font-size: 12px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
    .chip::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: currentColor; }
    .chip.ok { background: #111; color: #fff; }
    .chip.pending { background: #fff6e5; color: #9a6400; }
    .chip.muted { background: #f1f1f1; color: #666; }
    .title { margin-top: 30px; }
    .eyebrow { margin: 0; font-size: 11px; font-weight: 600; letter-spacing: .1em; text-transform: uppercase; color: #888; }
    h1 { margin: 4px 0 2px; font-size: 26px; line-height: 1.2; word-break: break-all; }
    .date { color: #777; font-size: 13px; }
    .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; padding: 24px 40px; background: #fafafa; border-bottom: 1px solid #efefef; }
    .grid h2 { margin: 0 0 6px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .08em; color: #888; }
    .grid p { margin: 0; font-size: 13px; color: #333; word-break: break-word; }
    .grid p strong { color: #111; }
    .items { padding: 8px 40px 0; }
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .08em; color: #888; font-weight: 600; padding: 16px 0 10px; border-bottom: 1px solid #e8e8e8; }
    td { padding: 14px 0; border-bottom: 1px solid #f2f2f2; vertical-align: middle; }
    .product { display: flex; align-items: center; gap: 12px; }
    .thumb { flex-shrink: 0; width: 44px; height: 44px; border: 1px solid #eee; border-radius: 8px; background: #f7f7f7; overflow: hidden; }
    .thumb img { width: 100%; height: 100%; object-fit: contain; padding: 3px; }
    .product strong { display: block; font-weight: 600; }
    .product small { color: #888; font-size: 12px; }
    .num { text-align: right; white-space: nowrap; padding-left: 16px; }
    .totals { margin: 20px 40px 0 auto; width: 300px; max-width: calc(100% - 80px); padding-bottom: 32px; }
    .totals div { display: flex; justify-content: space-between; padding: 5px 0; color: #555; }
    .totals .discount { color: #15803d; }
    .totals .total { margin-top: 8px; padding-top: 12px; border-top: 1px solid #111; color: #111; font-size: 20px; font-weight: 700; }
    footer { padding: 22px 40px 26px; border-top: 1px solid #efefef; background: #fafafa; color: #777; font-size: 12px; text-align: center; }
    footer strong { color: #111; }
    @media (max-width: 640px) {
        .toolbar span { display: none; }
        .toolbar div { width: 100%; }
        .toolbar button { flex: 1; }
        .sheet { margin: 0; border: 0; border-radius: 0; }
        .hero, .grid, .items, footer { padding-left: 18px; padding-right: 18px; }
        .grid { grid-template-columns: 1fr; gap: 16px; }
        .totals { margin: 16px 18px 0; width: auto; max-width: none; }
        h1 { font-size: 22px; }
    }
    @media print {
        body { background: #fff; }
        .toolbar { display: none; }
        .sheet { margin: 0; border: 0; border-radius: 0; max-width: none; }
    }
</style>
</head>
<body>
    <div class="toolbar">
        <span>Boleta de la orden #${escapeHtml(displayId)}</span>
        <div>
            <button type="button" id="receiptClose">Cerrar</button>
            <button type="button" class="primary" id="receiptPrint">Descargar PDF</button>
        </div>
    </div>
    <main class="sheet">
        <section class="hero">
            <div class="top">
                <div class="brand">
                    <img src="${escapeHtml(logoUrl)}" alt="">
                    <div><strong>MONSITE</strong><span>Belleza &amp; cuidado capilar</span></div>
                </div>
                <span class="chip ${statusTone}">${escapeHtml(statusLabel)}</span>
            </div>
            <div class="title">
                <p class="eyebrow">Boleta de compra</p>
                <h1>#${escapeHtml(displayId)}</h1>
                <div class="date">${escapeHtml(formatDate(order.paymentDate || order.createdAt))}</div>
            </div>
        </section>

        <section class="grid">
            <div>
                <h2>Cliente</h2>
                <p><strong>${escapeHtml(customerName || 'Cliente')}</strong></p>
                ${shipping.rut ? `<p>RUT ${escapeHtml(formatRut(shipping.rut))}</p>` : ''}
                ${order.userEmail || shipping.email ? `<p>${escapeHtml(order.userEmail || shipping.email)}</p>` : ''}
                ${shipping.phone ? `<p>${escapeHtml(shipping.phone)}</p>` : ''}
            </div>
            <div>
                <h2>Despacho</h2>
                <p>${escapeHtml(shipping.street || '—')}${shipping.apartment ? ', ' + escapeHtml(shipping.apartment) : ''}</p>
                <p>${escapeHtml([shipping.city, String(shipping.region || '').replace(/^Region\b/, 'Región')].filter(Boolean).join(', '))}</p>
            </div>
            <div>
                <h2>Pago</h2>
                <p><strong>${formatCLP(totals.total)}</strong></p>
                ${paymentMethod ? `<p>${escapeHtml(paymentMethod)}</p>` : ''}
                <p>${itemCount} ${itemCount === 1 ? 'producto' : 'productos'}</p>
            </div>
        </section>

        <section class="items">
            <table>
                <thead><tr><th>Producto</th><th class="num">Cant.</th><th class="num">Total</th></tr></thead>
                <tbody>${rows}</tbody>
            </table>
        </section>

        <div class="totals">
            <div><span>Subtotal</span><span>${formatCLP(totals.subtotal)}</span></div>
            <div><span>Envío</span><span>${totals.shipping > 0 ? formatCLP(totals.shipping) : 'Gratis'}</span></div>
            ${totals.discount > 0 ? `<div class="discount"><span>Descuento${order.discountCode ? ` (${escapeHtml(order.discountCode)})` : ''}</span><span>−${formatCLP(totals.discount)}</span></div>` : ''}
            <div class="total"><span>Total</span><span>${formatCLP(totals.total)}</span></div>
        </div>

        <footer>
            <strong>Gracias por comprar en Monsite.</strong><br>
            Vitacura 9540, Santiago · Instagram @monsitechile
        </footer>
    </main>
</body>
</html>`;

        popup.document.open();
        popup.document.write(receipt);
        popup.document.close();

        // Los botones y las fotos se enlazan desde aquí: sin atributos onclick/onerror en línea
        // (la política de seguridad de la página no permite scripts en línea).
        popup.document.getElementById('receiptClose')?.addEventListener('click', () => popup.close());
        popup.document.getElementById('receiptPrint')?.addEventListener('click', () => popup.print());
        popup.document.querySelectorAll('img').forEach(img => {
            const remove = () => img.remove();
            if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) remove();
            else img.addEventListener('error', remove, { once: true });
        });
    }

    window.openOrderReceipt = openOrderReceipt;
})();
