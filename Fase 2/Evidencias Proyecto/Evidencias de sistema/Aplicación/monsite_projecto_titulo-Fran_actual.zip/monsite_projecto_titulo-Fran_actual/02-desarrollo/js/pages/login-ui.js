// login-ui.js - Detalles de interfaz del login (la lógica de autenticación está en auth.js).
// - Cambia el título según la pestaña (Iniciar sesión / Crear cuenta) y marca aria-selected.
// - Marca en vivo los requisitos de la contraseña al crear cuenta.
// - Avisos bajo el nombre y el correo al crear cuenta (con la corrección sugerida: "¿gmail.com?").
// - Pantalla "Revisa tu correo" después de crear la cuenta y confirmación del enlace de verificación.
(function () {
    const TEXTS = {
        login: { title: 'Hola de nuevo', subtitle: 'Ingresa a tu cuenta Monsite.' },
        register: { title: 'Crea tu cuenta', subtitle: 'Toma menos de un minuto.' }
    };
    // Mismo criterio que isStrongPassword() de firebase-config.js
    const RULES = {
        length: value => value.length >= 12,
        upper: value => /[A-Z]/.test(value),
        number: value => /\d/.test(value),
        special: value => /[\^$*.[\]{}()?"!@#%&\/\\,><':;|_~]/.test(value)
    };
    const $ = id => document.getElementById(id);
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    function applyTab(name) {
        const text = TEXTS[name] || TEXTS.login;
        if ($('lgTitle')) $('lgTitle').textContent = text.title;
        if ($('lgSubtitle')) $('lgSubtitle').textContent = text.subtitle;
        document.querySelectorAll('.tab-btn').forEach(button => {
            button.setAttribute('aria-selected', button.dataset.tab === name ? 'true' : 'false');
        });
    }

    // ---------- Avisos bajo los campos ----------
    function fieldHint(input) {
        let hint = input.closest('.form-group')?.querySelector('.lg-hint');
        if (!hint) {
            hint = document.createElement('p');
            hint.className = 'lg-hint';
            hint.id = `${input.id}Hint`;
            hint.setAttribute('aria-live', 'polite');
            input.closest('.form-group').appendChild(hint);
            input.setAttribute('aria-describedby', hint.id);
        }
        return hint;
    }

    function setHint(input, result) {
        const hint = fieldHint(input);
        const invalid = result && !result.ok;
        input.classList.toggle('is-invalid', Boolean(invalid));
        input.setAttribute('aria-invalid', invalid ? 'true' : 'false');
        if (!invalid) {
            hint.hidden = true;
            hint.innerHTML = '';
            return;
        }
        hint.hidden = false;
        hint.innerHTML = result.suggestion
            ? `${esc(result.message)} <button type="button" class="lg-hint-fix" data-value="${esc(result.suggestion)}">Usar ${esc(result.suggestion)}</button>`
            : esc(result.message);
    }

    function validateField(input) {
        const V = window.MonsiteValidation;
        if (!V || !input.value.trim()) { setHint(input, null); return; }
        setHint(input, input.id === 'registerName' ? V.validateName(input.value) : V.checkEmail(input.value));
    }

    function showFieldErrors({ name, email } = {}) {
        if (name && $('registerName')) setHint($('registerName'), name);
        if (email && $('registerEmail')) setHint($('registerEmail'), email);
    }

    // ---------- "Revisa tu correo" ----------
    function showVerificationSent(email, sent) {
        const card = document.querySelector('.lg-card');
        if (!card) return;
        document.getElementById('custom-notification')?.remove(); // aviso de un intento anterior
        card.querySelectorAll(':scope > *').forEach(node => { node.hidden = true; });
        const panel = document.createElement('div');
        panel.className = 'lg-verify';
        panel.setAttribute('role', 'status');
        panel.innerHTML = `
            <span class="lg-verify-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M4 7l8 6 8-6"/></svg></span>
            <h1 class="lg-title" tabindex="-1">Revisa tu correo</h1>
            <p class="lg-subtitle">${sent
                ? `Te enviamos un enlace a <strong>${esc(email)}</strong> para confirmar que el correo es tuyo y activar tu cuenta.`
                : `Tu cuenta quedó creada, pero no pudimos enviar el correo de confirmación a <strong>${esc(email)}</strong>. Intenta iniciar sesión y te lo enviaremos de nuevo.`}</p>
            <ol class="lg-verify-steps">
                <li>Abre el correo de Monsite (revisa también spam o promociones).</li>
                <li>Presiona el enlace para confirmar tu correo.</li>
                <li>Vuelve aquí e inicia sesión.</li>
            </ol>
            <button type="button" class="auth-btn lg-verify-login"><span class="btn-text">Ya lo confirmé, iniciar sesión</span></button>
            <p class="lg-verify-help">¿No te llegó? Al intentar iniciar sesión te lo volvemos a enviar.</p>`;
        card.appendChild(panel);
        panel.querySelector('h1').focus();
        panel.querySelector('.lg-verify-login').addEventListener('click', () => {
            panel.remove();
            card.querySelectorAll(':scope > *').forEach(node => { node.hidden = false; });
            document.querySelector('.tab-btn[data-tab="login"]')?.click();
            if ($('loginEmail')) $('loginEmail').value = email;
            $('loginPassword')?.focus();
        });
    }

    // ---------- Enlace de verificación (auth-action.html → login.html?verificar=código) ----------
    async function handleVerificationLink() {
        const params = new URLSearchParams(window.location.search);
        const code = params.get('verificar');
        if (!code) return;
        history.replaceState(null, '', window.location.pathname);
        const guidance = $('authGuidance');
        const show = (html, tone) => {
            if (!guidance) return;
            guidance.innerHTML = html;
            guidance.classList.toggle('is-success', tone === 'ok');
            guidance.classList.toggle('is-error', tone === 'error');
            guidance.style.display = 'block';
        };
        show('Confirmando tu correo…');
        for (let i = 0; i < 30 && typeof window.firebase?.confirmEmailVerification !== 'function'; i += 1) {
            await new Promise(resolve => setTimeout(resolve, 200));
        }
        try {
            await window.firebase.confirmEmailVerification(code);
            show('<strong>¡Listo! Tu correo quedó confirmado.</strong> Ya puedes iniciar sesión.', 'ok');
            $('loginEmail')?.focus();
        } catch (error) {
            const used = error?.code === 'auth/invalid-action-code';
            show(used
                ? '<strong>Este enlace ya fue usado o no es válido.</strong> Si ya confirmaste tu correo, simplemente inicia sesión.'
                : '<strong>El enlace expiró.</strong> Inicia sesión y te enviaremos uno nuevo.', 'error');
        }
    }

    function init() {
        document.querySelectorAll('.tab-btn').forEach(button => {
            button.addEventListener('click', () => applyTab(button.dataset.tab));
        });

        const password = $('registerPassword');
        const rules = document.querySelectorAll('#passwordRules [data-rule]');
        password?.addEventListener('input', () => {
            rules.forEach(rule => rule.classList.toggle('is-ok', RULES[rule.dataset.rule](password.value)));
        });

        ['registerName', 'registerEmail'].forEach(id => {
            const input = $(id);
            if (!input) return;
            input.addEventListener('blur', () => validateField(input));
            // Al corregir, el aviso se actualiza en vivo
            input.addEventListener('input', () => { if (input.classList.contains('is-invalid')) validateField(input); });
        });
        document.addEventListener('click', event => {
            const fix = event.target.closest('.lg-hint-fix');
            if (!fix) return;
            const input = $('registerEmail');
            input.value = fix.dataset.value;
            validateField(input);
            input.focus();
        });

        handleVerificationLink();

        // Volviendo de "Nueva contraseña"
        const params = new URLSearchParams(window.location.search);
        if (params.get('reset') === 'ok' && $('authGuidance')) {
            $('authGuidance').innerHTML = '<strong>Contraseña actualizada.</strong> Ingresa con tu nueva contraseña.';
            $('authGuidance').classList.add('is-success');
        }
        // "Pedir un enlace nuevo": abre directo la recuperación
        if (params.get('recuperar') === '1') {
            setTimeout(() => document.querySelector('.forgot-password')?.click(), 400);
        }
    }

    window.MonsiteLoginUi = { showVerificationSent, showFieldErrors };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
