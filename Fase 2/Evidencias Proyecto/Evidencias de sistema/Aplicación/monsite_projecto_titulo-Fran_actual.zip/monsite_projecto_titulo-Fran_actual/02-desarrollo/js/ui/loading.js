// loading.js - Animaciones de carga del sitio del cliente.
// 1) Imágenes de productos, logos y miniaturas: fondo animado mientras cargan
//    y aparición suave al terminar.
// 2) Barra fina de progreso arriba al cambiar de página.
// Se carga en el <head> (sin defer) para escuchar las imágenes desde el inicio.
// Si este script no corre, todo se ve normal (la clase js-img-fade no se pone).
(function () {
    const SELECTOR = [
        '.product-real-image',
        '.brand-logo',
        '.brand-filter-logo',
        '#modalProductImage',
        '.cart-item-thumb img',
        '.sidebar-item-thumb img',
        '.pay-item-thumb img',
        '.hair-rec-image img',
        '.od-item-thumb img'
    ].join(', ');
    const root = document.documentElement;
    root.classList.add('js-img-fade');

    // ---------- 1. Imágenes ----------
    function markLoaded(img) {
        img.classList.add('is-loaded');
    }

    function refresh(img) {
        // Imagen sin src (popup vacío) o ya cargada desde caché
        if (!img.getAttribute('src') || (img.complete && img.naturalWidth > 0)) markLoaded(img);
    }

    // load y error no burbujean: se escuchan en fase de captura
    ['load', 'error'].forEach(type => document.addEventListener(type, event => {
        const target = event.target;
        if (target.tagName === 'IMG' && target.matches(SELECTOR)) markLoaded(target);
    }, true));

    new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            // El popup de producto reutiliza la misma imagen: al cambiar el src vuelve a animarse
            if (mutation.type === 'attributes') {
                const img = mutation.target;
                if (img.tagName === 'IMG' && img.matches(SELECTOR)) {
                    img.classList.remove('is-loaded');
                    refresh(img);
                }
                return;
            }
            mutation.addedNodes.forEach(node => {
                if (node.nodeType !== 1) return;
                if (node.matches(SELECTOR)) refresh(node);
                else node.querySelectorAll(SELECTOR).forEach(refresh);
            });
        });
    }).observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });

    // Respaldo por si algún evento se perdió
    window.addEventListener('load', () => setTimeout(() => {
        document.querySelectorAll(SELECTOR).forEach(img => { if (img.complete) markLoaded(img); });
    }, 1500));

    // ---------- 2. Barra de progreso entre páginas ----------
    let bar = null;
    let finishTimer = null;
    let safetyTimer = null;

    function getBar() {
        if (!bar) {
            bar = document.createElement('div');
            bar.className = 'page-progress';
            bar.setAttribute('aria-hidden', 'true');
            document.body.appendChild(bar);
        }
        return bar;
    }

    function startBar() {
        if (!document.body) return;
        const el = getBar();
        clearTimeout(finishTimer);
        el.classList.remove('is-done');
        // reinicia la animación
        el.classList.remove('is-active');
        void el.offsetWidth;
        el.classList.add('is-active');
        // Si la navegación no ocurre (descarga, respuesta vacía), la barra se retira sola
        clearTimeout(safetyTimer);
        safetyTimer = setTimeout(finishBar, 12000);
    }

    function finishBar() {
        if (!bar || !bar.classList.contains('is-active')) return;
        bar.classList.add('is-done');
        finishTimer = setTimeout(() => bar.classList.remove('is-active', 'is-done'), 450);
    }

    function isInternalNavigation(link, event) {
        if (!link || event.defaultPrevented || event.button !== 0) return false;
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return false;
        if (link.target && link.target !== '_self') return false;
        if (link.hasAttribute('download')) return false;
        const href = link.getAttribute('href') || '';
        if (!href || href.startsWith('#') || /^(mailto|tel|javascript):/i.test(href)) return false;
        const url = new URL(link.href, window.location.href);
        if (url.origin !== window.location.origin) return false;
        // Solo cambia el ancla dentro de la misma página
        if (url.pathname === window.location.pathname && url.search === window.location.search && url.hash) return false;
        return true;
    }

    document.addEventListener('click', event => {
        const link = event.target.closest && event.target.closest('a[href]');
        // Se decide después de los demás manejadores, por si alguno cancela la navegación
        if (link) setTimeout(() => { if (isInternalNavigation(link, event)) startBar(); }, 0);
    });

    // Navegaciones hechas por código (botón "Continuar compra", "Ver detalle"...)
    window.addEventListener('beforeunload', startBar);

    // Al volver con el botón "Atrás" (página restaurada desde caché) no debe quedar la barra
    window.addEventListener('pageshow', event => { if (event.persisted) finishBar(); });
})();
