// payment-result.js - Páginas de resultado del pago (éxito, pendiente, rechazado).
// El tipo de página viene en <main data-result="success|pending|failure">.
(function () {
    const main = document.querySelector('[data-result]');
    if (!main) return;

    const kind = main.dataset.result;
    const params = new URLSearchParams(window.location.search);
    const orderId = (params.get('orderId') || params.get('external_reference') || '').trim();
    const reason = (params.get('reason') || '').toLowerCase();
    // Mercado Pago agrega payment_id y status al volver
    const paymentId = params.get('payment_id') || params.get('collection_id');
    const gatewayStatus = (params.get('status') || params.get('collection_status') || '').toLowerCase();
    const runtime = window.hairiaPaymentRuntime;
    const BACKUP_KEY = 'monsite_checkout_backup';
    const BACKUP_MAX_AGE_MS = 3 * 24 * 60 * 60 * 1000;

    const $ = id => document.getElementById(id);

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatCLP(value) {
        return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(Number(value) || 0);
    }

    function formatDate(value) {
        const date = new Date(value || Date.now());
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleString('es-CL', { timeZone: 'America/Santiago', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
    }

    function isPaid(order) {
        const status = String(order?.status || '').toLowerCase();
        const payment = String(order?.paymentStatus || '').toLowerCase();
        return ['paid', 'shipped', 'delivered'].includes(status) || payment === 'approved';
    }

    // ---------- Sesión ----------
    function waitForAuthUser(maxWaitMs = 5000) {
        return new Promise(resolve => {
            const start = Date.now();
            (function check() {
                const user = window.firebase?.auth?.currentUser;
                if (user) return resolve(user);
                if (Date.now() - start >= maxWaitMs) return resolve(null);
                setTimeout(check, 150);
            })();
        });
    }

    function isRegisteredUser() {
        const user = window.firebase?.auth?.currentUser;
        return Boolean(user && !user.isAnonymous);
    }

    async function loadOrder() {
        if (!orderId || !runtime?.fetchOrderStatus) return null;
        const user = await waitForAuthUser();
        if (!user) return null;
        try {
            return await runtime.fetchOrderStatus(orderId);
        } catch (error) {
            console.warn('No se pudo cargar la orden:', error.message);
            return null;
        }
    }

    // ---------- Respaldo del carrito (lo guarda checkout.js antes de ir a pagar) ----------
    function readBackup() {
        try {
            const backup = JSON.parse(localStorage.getItem(BACKUP_KEY) || 'null');
            if (!backup || !Array.isArray(backup.items) || !backup.items.length) return null;
            if (Date.now() - Number(backup.savedAt || 0) > BACKUP_MAX_AGE_MS) return null;
            if (orderId && backup.orderId && backup.orderId !== orderId) return null;
            return backup;
        } catch (_) {
            return null;
        }
    }

    function clearBackup() {
        try { localStorage.removeItem(BACKUP_KEY); } catch (_) { /* sin almacenamiento */ }
    }

    function restoreCartFromBackup(backup) {
        const key = backup.cartKey || 'hairia_guest_cart';
        let current = [];
        try { current = JSON.parse(localStorage.getItem(key) || '[]') || []; } catch (_) { current = []; }
        const merged = [...current];
        backup.items.forEach(item => {
            const existing = merged.find(entry => String(entry.id) === String(item.id));
            if (existing) existing.quantity = Math.max(Number(existing.quantity) || 1, Number(item.quantity) || 1);
            else merged.push(item);
        });
        localStorage.setItem(key, JSON.stringify(merged));
        clearBackup();
    }

    // ---------- Piezas visuales ----------
    function renderTracker(order) {
        const status = String(order?.status || '').toLowerCase();
        const paid = isPaid(order);
        const steps = [
            { key: 'paid', label: 'Pago confirmado' },
            { key: 'shipped', label: 'Enviado' },
            { key: 'delivered', label: 'Entregado' }
        ];
        const reached = !paid ? -1 : Math.max(0, steps.findIndex(step => step.key === status));
        return `
            <ol class="pay-tracker" aria-label="Estado de tu pedido">
                ${steps.map((step, index) => {
                    const state = index <= reached ? 'done' : (index === reached + 1 ? 'next' : '');
                    return `<li class="${state}"><span class="pay-tracker-dot" aria-hidden="true"></span><span>${step.label}</span></li>`;
                }).join('')}
            </ol>`;
    }

    function renderItems(order) {
        const items = Array.isArray(order?.items) ? order.items : [];
        if (!items.length) return '';
        const totals = order.totals || {};
        return `
            <ul class="pay-items">
                ${items.map(item => `
                    <li>
                        <span class="pay-item-thumb">${item.image ? `<img src="${escapeHtml(item.image)}" alt="" loading="lazy">` : ''}</span>
                        <span class="pay-item-name">${escapeHtml(item.name)}<small>Cantidad: ${Number(item.quantity) || 0}</small></span>
                        <span class="pay-item-price">${formatCLP((Number(item.price) || 0) * (Number(item.quantity) || 0))}</span>
                    </li>`).join('')}
            </ul>
            <dl class="pay-totals">
                <div><dt>Subtotal</dt><dd>${formatCLP(totals.subtotal)}</dd></div>
                <div><dt>Envío</dt><dd>${Number(totals.shipping) > 0 ? formatCLP(totals.shipping) : 'Gratis'}</dd></div>
                ${Number(totals.discount) > 0 ? `<div class="is-discount"><dt>Descuento</dt><dd>−${formatCLP(totals.discount)}</dd></div>` : ''}
                <div class="is-total"><dt>Total</dt><dd>${formatCLP(totals.total)}</dd></div>
            </dl>`;
    }

    // Esqueleto del detalle mientras se consulta la orden
    function showOrderSkeleton() {
        const card = $('payOrder');
        if (!card || !orderId) return;
        const row = '<div class="skeleton-row"><span class="skeleton-box"></span><span><span class="skeleton-line w-90"></span><span class="skeleton-line w-50" style="margin:0"></span></span><span class="skeleton-line" style="margin:0"></span></div>';
        card.innerHTML = '<span class="skeleton-line w-30"></span><span class="skeleton-line w-50" style="height:18px"></span>' + row + row;
        card.classList.add('is-skeleton');
        card.setAttribute('aria-busy', 'true');
        card.hidden = false;
    }

    function hideOrderSkeleton() {
        const card = $('payOrder');
        if (!card || !card.classList.contains('is-skeleton')) return;
        card.classList.remove('is-skeleton');
        card.removeAttribute('aria-busy');
        card.innerHTML = '';
        card.hidden = true;
    }

    function renderOrderCard(order, { tracker = false } = {}) {
        const card = $('payOrder');
        if (!card || !order) return;
        card.classList.remove('is-skeleton');
        card.removeAttribute('aria-busy');
        const shipping = order.shippingData || {};
        const region = String(shipping.region || '').replace(/^Region\b/, 'Región');
        const address = [shipping.street, shipping.apartment, shipping.city, region].filter(Boolean).join(', ');
        card.innerHTML = `
            <div class="pay-order-head">
                <div>
                    <span class="pay-label">Número de orden</span>
                    <strong>${order.trackingCode ? escapeHtml(order.trackingCode) : `#${escapeHtml(order.id || orderId)}`}</strong>
                </div>
                <span class="pay-order-date">${escapeHtml(formatDate(order.paymentDate || order.createdAt))}</span>
            </div>
            ${tracker ? renderTracker(order) : ''}
            ${renderItems(order)}
            ${address ? `<p class="pay-address"><span class="pay-label">Despacho</span>${escapeHtml(address)}</p>` : ''}`;
        card.hidden = false;
    }

    function setText(id, text) {
        const el = $(id);
        if (el) el.textContent = text;
    }

    function setActions(html) {
        const el = $('payActions');
        if (el) el.innerHTML = html;
    }

    function bindReceipt(order) {
        const button = $('payReceiptBtn');
        if (!button) return;
        button.addEventListener('click', () => {
            if (typeof window.openOrderReceipt === 'function') window.openOrderReceipt(order);
        });
    }

    // ---------- Éxito ----------
    async function renderSuccess() {
        clearBackup();
        if (!orderId) {
            setText('payLead', 'Tu pago fue recibido. Revisa tu correo para ver el detalle de la compra.');
            return;
        }

        // Respaldo del webhook de Mercado Pago: confirmar al volver
        if (paymentId && runtime?.confirmMercadoPagoPayment) {
            await waitForAuthUser();
            try { await runtime.confirmMercadoPagoPayment(orderId, paymentId); } catch (error) {
                console.warn('Confirmación diferida:', error.message);
            }
        }

        let order = await loadOrder();
        // El medio de pago puede tardar unos segundos en confirmar
        for (let attempt = 0; order && !isPaid(order) && attempt < 4; attempt += 1) {
            await new Promise(resolve => setTimeout(resolve, 2500));
            order = await loadOrder() || order;
        }

        if (!order) {
            setText('payLead', 'Tu pago fue recibido. Te enviaremos la boleta con tu número de orden por correo.');
            return;
        }

        const name = order.shippingData?.firstName || order.shipping?.firstName || '';
        const email = order.userEmail || order.shippingData?.email || '';
        setText('payTitle', name ? `¡Gracias por tu compra, ${name}!` : '¡Gracias por tu compra!');
        setText('payLead', isPaid(order)
            ? (email ? `Te enviamos la boleta y el seguimiento del pedido a ${email}.` : 'Tu pedido quedó registrado y ya lo estamos preparando.')
            : 'Estamos terminando de confirmar tu pago. Te avisaremos por correo apenas quede listo.');

        renderOrderCard(order, { tracker: true });
        setActions(`
            <button type="button" class="pay-btn pay-btn--primary" id="payReceiptBtn">Ver boleta</button>
            ${isRegisteredUser()
                ? '<a class="pay-btn pay-btn--ghost" href="my-orders.html">Ver mis compras</a>'
                : `<a class="pay-btn pay-btn--ghost" href="seguimiento.html${order.trackingCode ? `?orden=${encodeURIComponent(order.trackingCode)}` : ''}">Sigue tu pedido</a>`}`);
        bindReceipt(order);

        if (!isRegisteredUser()) {
            const note = $('payNote');
            if (note) {
                // Invitado: con el número de orden y su correo o RUT puede ver el pedido sin cuenta
                note.innerHTML = order.trackingCode
                    ? `Compraste como invitado. Guarda tu número de orden <strong>${escapeHtml(order.trackingCode)}</strong>: con él y tu correo o RUT puedes ver el estado de tu pedido cuando quieras en <a href="seguimiento.html?orden=${encodeURIComponent(order.trackingCode)}">Sigue tu pedido</a>.`
                    : 'Compraste como invitado: el estado de tu pedido te llegará por correo.';
                note.hidden = false;
            }
        }
    }

    // ---------- Pendiente ----------
    async function renderPending() {
        const order = await loadOrder();
        if (!order) return;
        if (isPaid(order)) {
            window.location.replace(`payment-success.html?orderId=${encodeURIComponent(order.id || orderId)}`);
            return;
        }
        renderOrderCard(order);

        // Revisar cada 10 s durante 3 minutos por si el pago se confirma
        let checks = 0;
        const timer = setInterval(async () => {
            checks += 1;
            const latest = await loadOrder();
            if (latest && isPaid(latest)) {
                clearInterval(timer);
                window.location.replace(`payment-success.html?orderId=${encodeURIComponent(latest.id || orderId)}`);
            }
            if (checks >= 18) clearInterval(timer);
        }, 10000);
    }

    // ---------- Rechazado / cancelado ----------
    function describeFailure() {
        if (reason === 'aborted' || gatewayStatus === 'null' || (!reason && !gatewayStatus && paymentId === 'null')) {
            return {
                eyebrow: 'Pago cancelado',
                title: 'Cancelaste el pago',
                lead: 'No se hizo ningún cargo. Tus productos siguen guardados para que retomes la compra cuando quieras.'
            };
        }
        if (['commit_error', 'order_not_found', 'missing_token'].includes(reason)) {
            return {
                eyebrow: 'No pudimos confirmar el pago',
                title: 'Algo falló al confirmar tu pago',
                lead: 'Hubo un problema de comunicación con el medio de pago. Si ves un cargo en tu cuenta, escríbenos con tu número de orden y lo revisamos de inmediato.'
            };
        }
        return {
            eyebrow: 'Pago rechazado',
            title: 'Tu pago no fue aprobado',
            lead: 'El banco o el medio de pago no autorizó la transacción, así que no se hizo ningún cargo. Puedes intentarlo de nuevo con otra tarjeta o medio de pago.'
        };
    }

    async function renderFailure() {
        const copy = describeFailure();
        setText('payEyebrow', copy.eyebrow);
        setText('payTitle', copy.title);
        setText('payLead', copy.lead);

        const backup = readBackup();
        setActions(backup
            ? `<button type="button" class="pay-btn pay-btn--primary" id="payRetryBtn">Reintentar pago</button>
               <a class="pay-btn pay-btn--ghost" href="products.html">Seguir comprando</a>`
            : `<a class="pay-btn pay-btn--primary" href="checkout.html">Volver al checkout</a>
               <a class="pay-btn pay-btn--ghost" href="products.html">Seguir comprando</a>`);

        $('payRetryBtn')?.addEventListener('click', () => {
            restoreCartFromBackup(backup);
            window.location.href = 'checkout.html';
        });

        const order = await loadOrder();
        if (!order) return;
        // Si en realidad el pago sí quedó aprobado (doble retorno, recarga), mostrar el éxito
        if (isPaid(order)) {
            window.location.replace(`payment-success.html?orderId=${encodeURIComponent(order.id || orderId)}`);
            return;
        }
        renderOrderCard(order);
    }

    const renderers = { success: renderSuccess, pending: renderPending, failure: renderFailure };
    showOrderSkeleton();
    // Si la orden no se pudo cargar, se quita el esqueleto
    Promise.resolve((renderers[kind] || renderFailure)()).finally(hideOrderSkeleton);
})();
