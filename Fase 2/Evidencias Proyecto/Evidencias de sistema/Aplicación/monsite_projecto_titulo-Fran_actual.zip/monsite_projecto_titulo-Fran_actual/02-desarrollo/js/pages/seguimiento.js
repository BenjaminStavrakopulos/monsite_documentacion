// seguimiento.js - "Sigue tu pedido": ver el estado de una compra sin iniciar sesión.
// Se busca con el número de orden (MO-4827-1936) + el correo o RUT de la compra, o con el
// enlace firmado de los correos (?orden=MO-...&t=...). La búsqueda la hace el backend, que
// limita los intentos y devuelve la dirección, el correo y el teléfono parcialmente ocultos.
(function () {
    const $ = id => document.getElementById(id);
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const money = value => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(Number(value) || 0);
    const formatDate = value => {
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('es-CL', {
            timeZone: 'America/Santiago', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
        });
    };

    // Mismos textos que "Mis compras"
    const STATUS = {
        pending: { label: 'Pago pendiente', tone: 'warn', step: -1, message: 'El pago de esta compra no se completó, así que no se hizo ningún cargo. Si aún quieres los productos, puedes comprarlos de nuevo.' },
        paid: { label: 'Pagada', tone: 'ok', step: 0, message: 'Recibimos tu pago y estamos preparando tu pedido. Te avisaremos por correo cuando vaya en camino.' },
        shipped: { label: 'En camino', tone: 'ok', step: 1, message: 'Tu pedido ya salió y va rumbo a tu dirección.' },
        delivered: { label: 'Entregada', tone: 'ok', step: 2, message: 'Registramos la entrega de tu pedido. ¡Esperamos que lo disfrutes!' },
        refunded: { label: 'Devuelta', tone: 'muted', step: -1, message: 'Procesamos la devolución de esta compra. El reembolso puede tardar algunos días hábiles en verse en tu medio de pago.' },
        cancelled: { label: 'Cancelada', tone: 'muted', step: -1, message: 'Esta compra fue cancelada. Si se realizó un cobro, se reembolsa al mismo medio de pago.' }
    };
    const PAYMENT_METHODS = { mercado_pago: 'Mercado Pago', transbank_webpay: 'Webpay' };
    let lastOrder = null;

    // "mo4827" -> "MO-4827", "48271936" -> "MO-4827-1936"
    function formatCodeInput(value) {
        const clean = String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
        if (!clean) return '';
        const digits = clean.replace(/^M?O?/, '').replace(/\D/g, '').slice(0, 8);
        if (!digits) return clean.startsWith('M') ? clean.slice(0, 2) : 'MO';
        return `MO-${digits.slice(0, 4)}${digits.length > 4 ? `-${digits.slice(4)}` : ''}`;
    }

    const isValidCode = value => /^MO-\d{4}-\d{4}$/.test(value);

    function backendUrl() {
        return window.hairiaPaymentRuntime?.getBackendUrl?.() || 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app';
    }

    function showError(message) {
        const box = $('trackError');
        box.textContent = message;
        box.hidden = !message;
    }

    function setLoading(loading) {
        const button = $('trackSubmit');
        button.disabled = loading;
        button.textContent = loading ? 'Buscando…' : 'Ver mi pedido';
    }

    async function lookup(body) {
        setLoading(true);
        showError('');
        try {
            const response = await fetch(`${backendUrl()}/api/orders/track`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const payload = await response.json().catch(() => ({}));
            if (!response.ok || !payload.order) {
                showError(payload.error || 'No pudimos consultar tu pedido. Inténtalo de nuevo en unos minutos.');
                return false;
            }
            renderOrder(payload.order);
            return true;
        } catch (error) {
            showError('No pudimos conectarnos. Revisa tu conexión e inténtalo de nuevo.');
            return false;
        } finally {
            setLoading(false);
        }
    }

    function renderTracker(step) {
        const steps = ['Pago confirmado', 'En camino', 'Entregado'];
        return `<ol class="track-steps" aria-label="Etapas del pedido">${steps.map((label, index) => `
            <li class="${index <= step ? 'is-done' : ''}${index === step + 1 ? ' is-next' : ''}">
                <span class="track-steps-bar" aria-hidden="true"></span>
                <span>${index <= step ? '✓ ' : ''}${label}</span>
            </li>`).join('')}</ol>`;
    }

    function renderOrder(order) {
        lastOrder = order;
        const status = STATUS[order.status] || STATUS.pending;
        const items = Array.isArray(order.items) ? order.items : [];
        const totals = order.totals || {};
        const shipping = order.shipping || {};
        const units = items.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);
        const region = String(shipping.region || '').replace(/^Region\b/, 'Región');
        const paymentMethod = PAYMENT_METHODS[String(order.paymentMethod || '').toLowerCase()] || '';

        $('trackResult').innerHTML = `
            <div class="track-card track-order">
                <div class="track-order-head">
                    <div>
                        <p class="track-eyebrow">Tu pedido</p>
                        <h2>${esc(order.code)}</h2>
                        <p class="track-date">Comprado el ${esc(formatDate(order.createdAt))}</p>
                    </div>
                    <span class="track-chip track-chip--${status.tone}">${esc(status.label)}</span>
                </div>
                ${status.step >= 0 ? renderTracker(status.step) : ''}
                <p class="track-message">${esc(status.message)}</p>
                ${order.courier?.url ? `
                <p class="track-courier">Enviado por ${esc(order.courier.name)} · N° <strong>${esc(order.courier.code)}</strong>
                    <a href="${esc(order.courier.url)}" target="_blank" rel="noopener">Seguir en ${esc(order.courier.name)}</a></p>` : ''}
                ${order.updatedAt ? `<p class="track-updated">Última actualización: ${esc(formatDate(order.updatedAt))}</p>` : ''}

                <h3 class="track-section-title">${units} ${units === 1 ? 'producto' : 'productos'}</h3>
                <ul class="track-items">
                    ${items.map(item => `
                        <li>
                            <span class="track-thumb">${item.image ? `<img src="${esc(item.image)}" alt="" loading="lazy">` : ''}</span>
                            <span class="track-item-name"><strong>${esc(item.name)}</strong><small>${Number(item.quantity) || 0} × ${money(item.price)}</small></span>
                            <span class="track-item-total">${money((Number(item.price) || 0) * (Number(item.quantity) || 0))}</span>
                        </li>`).join('')}
                </ul>

                <dl class="track-totals">
                    <div><dt>Subtotal</dt><dd>${money(totals.subtotal)}</dd></div>
                    <div><dt>Envío</dt><dd>${totals.shipping > 0 ? money(totals.shipping) : 'Gratis'}</dd></div>
                    ${totals.discount > 0 ? `<div class="track-discount"><dt>Descuento${order.discountCode ? ` (${esc(order.discountCode)})` : ''}</dt><dd>−${money(totals.discount)}</dd></div>` : ''}
                    <div class="track-total"><dt>Total</dt><dd>${money(totals.total)}</dd></div>
                </dl>

                <div class="track-info">
                    <div>
                        <h3>Despacho</h3>
                        <p><strong>${esc(shipping.name || 'Cliente')}</strong></p>
                        <p>${esc(shipping.street || '')}${shipping.apartment ? `, ${esc(shipping.apartment)}` : ''}</p>
                        <p>${esc([shipping.city, region].filter(Boolean).join(', '))}</p>
                    </div>
                    <div>
                        <h3>Contacto</h3>
                        ${shipping.email ? `<p>${esc(shipping.email)}</p>` : ''}
                        ${shipping.phone ? `<p>${esc(shipping.phone)}</p>` : ''}
                    </div>
                    <div>
                        <h3>Pago</h3>
                        <p>${esc(paymentMethod || '—')}</p>
                        ${order.paymentDate ? `<p>${esc(formatDate(order.paymentDate))}</p>` : ''}
                    </div>
                </div>
                <p class="track-privacy">Por tu seguridad, parte de la dirección, del correo y del teléfono se muestran ocultos.</p>

                <div class="track-actions">
                    ${order.status !== 'pending' ? '<button type="button" class="pay-btn pay-btn--primary" data-action="receipt">Ver boleta</button>' : ''}
                    <button type="button" class="pay-btn pay-btn--ghost" data-action="again">Buscar otro pedido</button>
                    <a class="pay-btn pay-btn--ghost" href="products.html">Seguir comprando</a>
                </div>
                <p class="track-help">¿Algo no está bien? Escríbenos por Instagram a <a href="https://www.instagram.com/monsitechile" target="_blank" rel="noopener">@monsitechile</a> con tu número de orden.</p>
            </div>`;
        // Si la foto de un producto no carga se quita (sin atributos onerror en línea: la política de seguridad no los permite)
        $('trackResult').querySelectorAll('img').forEach(img => {
            const remove = () => img.remove();
            if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) remove();
            else img.addEventListener('error', remove, { once: true });
        });
        $('trackFormCard').hidden = true;
        $('trackResult').hidden = false;
        $('trackResult').querySelector('h2')?.setAttribute('tabindex', '-1');
        $('trackResult').querySelector('h2')?.focus({ preventScroll: true });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Boleta con los mismos datos (parcialmente ocultos) que muestra la página
    function openReceipt() {
        if (!lastOrder || typeof window.openOrderReceipt !== 'function') return;
        const shipping = lastOrder.shipping || {};
        window.openOrderReceipt({
            id: lastOrder.code,
            trackingCode: lastOrder.code,
            status: lastOrder.status,
            paymentMethod: lastOrder.paymentMethod,
            paymentDate: lastOrder.paymentDate,
            createdAt: lastOrder.createdAt,
            discountCode: lastOrder.discountCode,
            items: lastOrder.items,
            totals: lastOrder.totals,
            userEmail: shipping.email,
            shippingData: {
                firstName: shipping.name, street: shipping.street, apartment: shipping.apartment,
                city: shipping.city, region: shipping.region, phone: shipping.phone
            }
        });
    }

    function init() {
        const form = $('trackForm');
        const codeInput = $('trackCode');
        if (!form || !codeInput) return;

        codeInput.addEventListener('input', () => {
            const formatted = formatCodeInput(codeInput.value);
            if (formatted !== codeInput.value) codeInput.value = formatted;
        });

        form.addEventListener('submit', event => {
            event.preventDefault();
            const code = formatCodeInput(codeInput.value);
            const contact = $('trackContact').value.trim();
            codeInput.value = code;
            if (!isValidCode(code)) {
                showError('El número de orden tiene este formato: MO-4827-1936.');
                codeInput.focus();
                return;
            }
            if (!contact) {
                showError('Escribe el correo o el RUT con el que hiciste la compra.');
                $('trackContact').focus();
                return;
            }
            lookup({ code, contact });
        });

        $('trackResult').addEventListener('click', event => {
            const action = event.target.closest('[data-action]')?.dataset.action;
            if (action === 'receipt') openReceipt();
            if (action === 'again') {
                $('trackResult').hidden = true;
                $('trackFormCard').hidden = false;
                $('trackContact').value = '';
                codeInput.value = '';
                codeInput.focus();
            }
        });

        // Enlace de los correos: ?orden=MO-...&t=firma (abre el pedido directo)
        const params = new URLSearchParams(window.location.search);
        const code = formatCodeInput(params.get('orden') || '');
        const token = params.get('t');
        if (isValidCode(code)) {
            codeInput.value = code;
            if (token) {
                // La firma no queda en la barra de direcciones (ni en capturas o historial)
                history.replaceState(null, '', `${window.location.pathname}?orden=${code}`);
                lookup({ code, token });
            } else {
                $('trackContact').focus();
            }
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
