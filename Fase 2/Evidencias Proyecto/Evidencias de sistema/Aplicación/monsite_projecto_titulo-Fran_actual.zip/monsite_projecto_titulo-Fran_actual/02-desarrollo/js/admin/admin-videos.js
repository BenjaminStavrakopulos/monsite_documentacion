// admin-videos.js - Videos del inicio (portada y tutoriales "Aprende a usarlos").
// Flujo: el admin elige un video, lo recorta aquí mismo (vista previa local, sin subir nada),
// y al confirmar se sube el original a Storage y el backend lo manda a optimizar
// (media-worker). Los cambios quedan en borrador hasta "Publicar cambios", que guarda la
// configuración que lee index.html (Firestore siteContent/homeMedia).
// La portada es un carrusel: hero.slides se reproduce en orden, uno tras otro.
(function () {
    const API_BASE = 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app/api/home-media';
    const STORAGE_BASE = 'https://firebasestorage.googleapis.com/v0/b/monsite-85424.firebasestorage.app/o/';
    const media = file => `${STORAGE_BASE}${encodeURIComponent('home-media/' + file)}?alt=media`;
    const LIMITS = {
        hero: { min: 3, max: 15, label: 'portada', orientation: 'horizontal' },
        tutorial: { min: 5, max: 90, label: 'tutorial', orientation: 'vertical' }
    };
    const MAX_SOURCE_BYTES = 600 * 1024 * 1024;
    const MAX_TUTORIALS = 12;
    const MAX_SLIDES = 6;
    const MAX_PRODUCTS = 4;

    // Lo que muestra el inicio mientras no se haya publicado nada desde aquí
    const DEFAULT_CONFIG = {
        hero: {
            slides: [{
                video: 'portada.mp4', poster: 'portada.jpg',
                eyebrow: 'Marca destacada', title: 'American Crew',
                linkText: 'Ver la línea completa →', linkHref: 'products.html?brand=american-crew',
                alt: 'Presentación de productos American Crew'
            }]
        },
        tutorials: [
            { id: 'no-frizz', title: 'No Frizz Shampoo y Acondicionador', brand: 'Living Proof', duration: 53, match: ['No Frizz Shampoo 236', 'No Frizz Conditioner 236'] },
            { id: 'moisture-rescue', title: 'Moisture Rescue Mask', brand: 'Living Proof', duration: 45, match: ['Moisture Rescue'], featured: true },
            { id: 'flex-hairspray', title: 'Flex Hairspray', brand: 'Living Proof', duration: 37, match: ['Flex Hair Spray'] },
            { id: 'triple-bond', title: 'Triple Bond Complex', brand: 'Living Proof', duration: 32, match: ['Triple Bond Complex Tratamiento 45ml'] }
        ].map(item => ({
            video: `${item.id}.mp4`, poster: `${item.id}.jpg`, preview: `${item.id}-preview.mp4`,
            productIds: [], featured: false, ...item
        }))
    };

    const $ = id => document.getElementById(id);
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const clone = value => JSON.parse(JSON.stringify(value));
    const formatTime = seconds => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

    const state = {
        published: null,
        draft: null,
        products: [],
        brands: [],
        busy: false,
        trim: null // { kind, index, file, url, duration, width, height }
    };

    // ---------- Utilidades ----------
    function notify(message, isError = false) {
        document.querySelectorAll('.hm-toast').forEach(old => old.remove());
        const note = document.createElement('div');
        note.className = `hm-toast${isError ? ' hm-toast--error' : ''}`;
        note.setAttribute('role', 'status');
        note.textContent = message;
        document.body.appendChild(note);
        setTimeout(() => note.remove(), isError ? 6000 : 3500);
    }

    async function authHeaders() {
        const user = window.firebase?.auth?.currentUser;
        if (!user?.getIdToken) throw new Error('Tu sesión expiró. Vuelve a iniciar sesión.');
        return { 'Content-Type': 'application/json', Authorization: `Bearer ${await user.getIdToken()}` };
    }

    async function api(path, body) {
        const response = await fetch(`${API_BASE}${path}`, { method: 'POST', headers: await authHeaders(), body: JSON.stringify(body) });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload.error || `Error ${response.status}`);
        return payload;
    }

    async function checkAdminAuth() {
        const raw = localStorage.getItem('hairia_current_user') || sessionStorage.getItem('hairia_current_user');
        const user = raw ? JSON.parse(raw) : null;
        if (!user?.uid || typeof window.firebase?.isUserAdmin !== 'function') {
            window.location.href = '../login.html';
            return false;
        }
        try {
            if (await window.firebase.isUserAdmin(user.uid)) return true;
            window.location.href = '../index.html';
        } catch (error) {
            window.location.href = '../login.html';
        }
        return false;
    }

    const isDirty = () => JSON.stringify(state.draft) !== JSON.stringify(state.published);

    function updateDirty() {
        const dirty = isDirty();
        $('hmUnsaved').hidden = !dirty;
        $('hmPublishBtn').disabled = !dirty || state.busy;
    }

    // ---------- Portada (carrusel de videos) ----------
    function linkOptions(current) {
        const options = [{ value: 'products.html', label: 'Catálogo completo' }]
            .concat(state.brands.map(brand => ({ value: `products.html?brand=${encodeURIComponent(brand.id)}`, label: `Marca: ${brand.name || brand.id}` })));
        if (current && !options.some(option => option.value === current)) options.push({ value: current, label: current });
        return options.map(option => `<option value="${esc(option.value)}" ${option.value === (current || 'products.html') ? 'selected' : ''}>${esc(option.label)}</option>`).join('');
    }

    function renderSlides() {
        const slides = state.draft.hero.slides;
        $('hmSlideCount').textContent = `(${slides.length} ${slides.length === 1 ? 'video' : 'videos'})`;
        $('hmAddSlide').disabled = slides.length >= MAX_SLIDES || state.busy;
        $('hmSlides').innerHTML = slides.map((slide, index) => `
            <article class="hm-slide" data-slide="${index}">
                <div class="hm-slide-media">
                    <video muted loop playsinline preload="none" poster="${media(slide.poster)}" data-src="${media(slide.video)}"></video>
                    <span class="hm-slide-number">${index + 1}</span>
                </div>
                <div class="hm-slide-fields">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Etiqueta</label>
                            <input type="text" data-field="eyebrow" maxlength="40" value="${esc(slide.eyebrow)}" placeholder="Ej: Marca destacada">
                        </div>
                        <div class="form-group">
                            <label>Título</label>
                            <input type="text" data-field="title" maxlength="60" value="${esc(slide.title)}" placeholder="Ej: American Crew">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Texto del enlace</label>
                            <input type="text" data-field="linkText" maxlength="40" value="${esc(slide.linkText)}" placeholder="Ej: Ver la línea completa →">
                        </div>
                        <div class="form-group">
                            <label>El enlace lleva a</label>
                            <select data-field="linkHref">${linkOptions(slide.linkHref)}</select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Descripción del video <small>(para lectores de pantalla)</small></label>
                        <input type="text" data-field="alt" maxlength="120" value="${esc(slide.alt)}" placeholder="Ej: Presentación de productos American Crew">
                    </div>
                    <p class="hm-hint">Si dejas la etiqueta, el título y el enlace vacíos, el video se muestra sin texto.</p>
                    <div class="hm-tutorial-actions">
                        <button type="button" class="btn-secondary" data-action="up" ${index === 0 ? 'disabled' : ''} aria-label="Mover antes">↑</button>
                        <button type="button" class="btn-secondary" data-action="down" ${index === slides.length - 1 ? 'disabled' : ''} aria-label="Mover después">↓</button>
                        <button type="button" class="btn-secondary" data-action="replace" ${state.busy ? 'disabled' : ''}>Reemplazar video</button>
                        <button type="button" class="btn-secondary hm-danger" data-action="remove" ${slides.length <= 1 ? 'disabled title="La portada necesita al menos un video"' : ''}>Quitar</button>
                    </div>
                </div>
            </article>`).join('');

        // Vista previa al pasar el mouse
        $('hmSlides').querySelectorAll('.hm-slide-media video').forEach(video => {
            const box = video.parentElement;
            box.addEventListener('mouseenter', () => { if (!video.src) video.src = video.dataset.src; video.play().catch(() => {}); });
            box.addEventListener('mouseleave', () => video.pause());
        });
    }

    function bindSlides() {
        const container = $('hmSlides');
        const update = event => {
            const field = event.target.dataset.field;
            const card = event.target.closest('[data-slide]');
            if (!field || !card) return;
            state.draft.hero.slides[Number(card.dataset.slide)][field] = event.target.value;
            updateDirty();
        };
        container.addEventListener('input', update);
        container.addEventListener('change', update);
        container.addEventListener('click', event => {
            const button = event.target.closest('[data-action]');
            const card = event.target.closest('[data-slide]');
            if (!button || !card) return;
            const index = Number(card.dataset.slide);
            const list = state.draft.hero.slides;
            switch (button.dataset.action) {
                case 'up': [list[index - 1], list[index]] = [list[index], list[index - 1]]; break;
                case 'down': [list[index + 1], list[index]] = [list[index], list[index + 1]]; break;
                case 'replace': pickFile('hero', index); return;
                case 'remove':
                    if (list.length <= 1 || !window.confirm(`¿Quitar el video ${index + 1} de la portada?`)) return;
                    list.splice(index, 1);
                    break;
                default: return;
            }
            renderSlides();
            updateDirty();
        });
        $('hmAddSlide').addEventListener('click', () => pickFile('hero', null));
    }

    // ---------- Tutoriales ----------
    function productName(id) {
        return state.products.find(product => String(product.id) === String(id))?.name || 'Producto no encontrado';
    }

    function renderTutorials() {
        const list = state.draft.tutorials;
        $('hmTutorialCount').textContent = `(${list.length})`;
        $('hmAddTutorial').disabled = list.length >= MAX_TUTORIALS || state.busy;
        $('hmTutorials').innerHTML = list.map((item, index) => {
            const linked = item.productIds.length
                ? item.productIds.map(id => `<span class="hm-chip">${esc(productName(id))}<button type="button" data-action="unlink" data-id="${esc(id)}" aria-label="Quitar ${esc(productName(id))}">×</button></span>`).join('')
                : (item.match?.length ? `<span class="hm-chip hm-chip--auto" title="Se buscan productos cuyo nombre contenga: ${esc(item.match.join(', '))}">Automático: ${esc(item.match.join(', '))}</span>` : '<span class="hm-muted">Sin productos</span>');
            return `
            <article class="hm-tutorial${item.featured ? ' is-featured' : ''}" data-index="${index}">
                <div class="hm-tutorial-media">
                    <video muted loop playsinline preload="none" poster="${media(item.poster)}" data-src="${media(item.preview)}"></video>
                    <span class="hm-duration">${formatTime(item.duration)}</span>
                    <button type="button" class="hm-star" data-action="feature" aria-pressed="${item.featured}" title="${item.featured ? 'Aparece en el mosaico de la portada' : 'Mostrar en el mosaico de la portada'}">${item.featured ? '★' : '☆'}</button>
                </div>
                <div class="hm-tutorial-body">
                    <div class="form-group">
                        <label>Título</label>
                        <input type="text" data-field="title" maxlength="80" value="${esc(item.title)}" placeholder="Nombre del producto o tutorial">
                    </div>
                    <div class="form-group">
                        <label>Marca</label>
                        <input type="text" data-field="brand" maxlength="40" value="${esc(item.brand)}" placeholder="Ej: Living Proof" list="hmBrandsList">
                    </div>
                    <div class="form-group">
                        <label>Productos que se pueden comprar desde el video</label>
                        <div class="hm-chips">${linked}</div>
                        <input type="text" class="hm-product-search" data-action="link" list="hmProductsList" placeholder="${item.productIds.length >= MAX_PRODUCTS ? 'Máximo 4 productos' : 'Escribe para buscar un producto…'}" ${item.productIds.length >= MAX_PRODUCTS ? 'disabled' : ''}>
                    </div>
                    <div class="hm-tutorial-actions">
                        <button type="button" class="btn-secondary" data-action="up" ${index === 0 ? 'disabled' : ''} aria-label="Mover antes">↑</button>
                        <button type="button" class="btn-secondary" data-action="down" ${index === list.length - 1 ? 'disabled' : ''} aria-label="Mover después">↓</button>
                        <button type="button" class="btn-secondary" data-action="replace">Reemplazar video</button>
                        <button type="button" class="btn-secondary hm-danger" data-action="remove" ${list.length <= 1 ? 'disabled title="Debe quedar al menos un tutorial"' : ''}>Eliminar</button>
                    </div>
                </div>
            </article>`;
        }).join('');

        // Vista previa en movimiento al pasar el mouse
        $('hmTutorials').querySelectorAll('.hm-tutorial-media video').forEach(video => {
            const box = video.parentElement;
            box.addEventListener('mouseenter', () => { if (!video.src) video.src = video.dataset.src; video.play().catch(() => {}); });
            box.addEventListener('mouseleave', () => video.pause());
        });
    }

    function bindTutorials() {
        const container = $('hmTutorials');
        container.addEventListener('input', event => {
            const field = event.target.dataset.field;
            const card = event.target.closest('[data-index]');
            if (!field || !card) return;
            state.draft.tutorials[Number(card.dataset.index)][field] = event.target.value;
            updateDirty();
        });

        // Elegir un producto de la lista lo vincula
        container.addEventListener('change', event => {
            if (event.target.dataset.action !== 'link') return;
            const card = event.target.closest('[data-index]');
            const name = event.target.value.trim().toLowerCase();
            const product = state.products.find(item => String(item.name || '').trim().toLowerCase() === name);
            if (!product) {
                if (name) notify('Elige un producto de la lista', true);
                return;
            }
            const item = state.draft.tutorials[Number(card.dataset.index)];
            if (!item.productIds.includes(String(product.id)) && item.productIds.length < MAX_PRODUCTS) {
                item.productIds.push(String(product.id));
            }
            renderTutorials();
            updateDirty();
        });

        container.addEventListener('click', event => {
            const button = event.target.closest('[data-action]');
            const card = event.target.closest('[data-index]');
            if (!button || !card || button.dataset.action === 'link') return;
            const index = Number(card.dataset.index);
            const list = state.draft.tutorials;
            switch (button.dataset.action) {
                case 'up': [list[index - 1], list[index]] = [list[index], list[index - 1]]; break;
                case 'down': [list[index + 1], list[index]] = [list[index], list[index + 1]]; break;
                case 'feature': list.forEach((item, i) => { item.featured = i === index; }); break;
                case 'unlink': list[index].productIds = list[index].productIds.filter(id => id !== button.dataset.id); break;
                case 'replace': pickFile('tutorial', index); return;
                case 'remove':
                    if (list.length <= 1 || !window.confirm(`¿Quitar el tutorial "${list[index].title}" del inicio?`)) return;
                    if (list[index].featured) list[(index + 1) % list.length].featured = true;
                    list.splice(index, 1);
                    break;
                default: return;
            }
            renderTutorials();
            updateDirty();
        });

        $('hmAddTutorial').addEventListener('click', () => pickFile('tutorial', null));
    }

    // ---------- Recorte ----------
    function pickFile(kind, index) {
        if (state.busy) return;
        const input = $('hmFileInput');
        input.value = '';
        input.onchange = () => { if (input.files[0]) openTrim(kind, index, input.files[0]); };
        input.click();
    }

    function openTrim(kind, index, file) {
        if (file.size > MAX_SOURCE_BYTES) {
            notify('El video pesa más de 600 MB. Expórtalo en menor calidad e inténtalo de nuevo.', true);
            return;
        }
        if (!/\.(mp4|mov|m4v|webm)$/i.test(file.name)) {
            notify('Formato no admitido. Usa un video MP4, MOV o WebM.', true);
            return;
        }
        const limits = LIMITS[kind];
        const url = URL.createObjectURL(file);
        state.trim = { kind, index, file, url, duration: 0 };
        const video = $('hmTrimVideo');
        video.src = url;
        video.muted = kind === 'hero';
        $('hmTrimTitle').textContent = kind === 'hero'
            ? (index == null ? 'Nuevo video de portada' : `Reemplazar video ${index + 1} de la portada`)
            : (index == null ? 'Nuevo tutorial' : 'Reemplazar tutorial');
        $('hmTrimMedia').classList.toggle('is-vertical', kind === 'tutorial');
        $('hmTrimFile').textContent = `${file.name} · ${(file.size / 1048576).toFixed(0)} MB`;
        $('hmTrimWarning').hidden = true;
        $('hmProgress').hidden = true;
        $('hmTrimConfirm').disabled = true;
        $('hmTrimModal').hidden = false;
        document.body.style.overflow = 'hidden';

        video.onloadedmetadata = () => {
            const duration = video.duration || 0;
            state.trim.duration = duration;
            const vertical = video.videoHeight > video.videoWidth;
            const wrongOrientation = (kind === 'hero' && vertical) || (kind === 'tutorial' && !vertical);
            const warning = $('hmTrimWarning');
            if (wrongOrientation) {
                warning.textContent = `Este video es ${vertical ? 'vertical' : 'horizontal'}. La ${limits.label === 'portada' ? 'portada' : 'sección de tutoriales'} necesita un video ${limits.orientation}.`;
                warning.hidden = false;
            } else if (duration < limits.min) {
                warning.textContent = `El video dura ${duration.toFixed(1)} s y el mínimo es ${limits.min} s.`;
                warning.hidden = false;
            }
            const maxDuration = Math.min(limits.max, duration);
            const durationInput = $('hmTrimDuration');
            durationInput.min = String(Math.min(limits.min, maxDuration));
            durationInput.max = String(maxDuration);
            durationInput.value = String(maxDuration);
            $('hmTrimStart').value = '0';
            updateTrimUi();
            $('hmTrimConfirm').disabled = wrongOrientation || duration < limits.min;
        };
        video.onerror = () => {
            $('hmTrimWarning').textContent = 'Este navegador no puede mostrar el video. Prueba exportarlo como MP4 (H.264).';
            $('hmTrimWarning').hidden = false;
        };
    }

    function updateTrimUi() {
        const trim = state.trim;
        if (!trim?.duration) return;
        const startInput = $('hmTrimStart');
        const duration = Number($('hmTrimDuration').value);
        startInput.max = String(Math.max(0, trim.duration - duration));
        const start = Math.min(Number(startInput.value), Number(startInput.max));
        startInput.value = String(start);
        $('hmTrimStartLabel').textContent = formatTime(start);
        $('hmTrimDurationLabel').textContent = `${duration.toFixed(duration % 1 ? 1 : 0)} s`;
        $('hmTrimSummary').textContent = `Se usará desde ${formatTime(start)} hasta ${formatTime(start + duration)} de un video de ${formatTime(trim.duration)}.`;
        const win = $('hmTimelineWindow');
        win.style.left = `${(start / trim.duration) * 100}%`;
        win.style.width = `${(duration / trim.duration) * 100}%`;
    }

    function trimSelection() {
        const start = Number($('hmTrimStart').value);
        return { start, end: start + Number($('hmTrimDuration').value) };
    }

    function bindTrim() {
        const video = $('hmTrimVideo');
        $('hmTrimStart').addEventListener('input', () => {
            updateTrimUi();
            video.pause();
            video.currentTime = Number($('hmTrimStart').value);
        });
        $('hmTrimDuration').addEventListener('input', updateTrimUi);
        $('hmTrimPlay').addEventListener('click', () => {
            if (!video.paused) { video.pause(); return; }
            const { start, end } = trimSelection();
            if (video.currentTime < start || video.currentTime >= end - 0.1) video.currentTime = start;
            video.play().catch(() => {});
        });
        video.addEventListener('play', () => { $('hmTrimPlay').textContent = '❚❚ Pausar'; });
        video.addEventListener('pause', () => { $('hmTrimPlay').textContent = '▶ Ver selección'; });
        // La reproducción se queda dentro de la selección
        video.addEventListener('timeupdate', () => {
            if (!state.trim?.duration) return;
            const { start, end } = trimSelection();
            if (!video.paused && video.currentTime >= end) video.currentTime = start;
            $('hmTimelinePlayhead').style.left = `${(video.currentTime / state.trim.duration) * 100}%`;
        });
        $('hmTrimClose').addEventListener('click', closeTrim);
        $('hmTrimModal').addEventListener('click', event => { if (event.target === $('hmTrimModal')) closeTrim(); });
        document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('hmTrimModal').hidden) closeTrim(); });
        $('hmTrimConfirm').addEventListener('click', processTrim);
    }

    function closeTrim(force) {
        if (state.busy && force !== true) {
            notify('Espera a que termine de procesarse el video.', true);
            return;
        }
        const video = $('hmTrimVideo');
        video.pause();
        video.removeAttribute('src');
        video.load();
        if (state.trim?.url) URL.revokeObjectURL(state.trim.url);
        state.trim = null;
        $('hmTrimModal').hidden = true;
        document.body.style.overflow = '';
    }

    function setBusy(busy) {
        state.busy = busy;
        ['hmTrimConfirm', 'hmTrimStart', 'hmTrimDuration'].forEach(id => { $(id).disabled = busy; });
        $('hmTrimClose').hidden = busy;
        renderSlides();
        renderTutorials();
        updateDirty();
    }

    function setProgress(fraction, text) {
        $('hmProgress').hidden = false;
        $('hmProgressFill').style.width = `${Math.round(fraction * 100)}%`;
        $('hmProgressFill').classList.toggle('is-indeterminate', fraction < 0);
        $('hmProgressText').textContent = text;
    }

    async function processTrim() {
        const trim = state.trim;
        if (!trim || state.busy) return;
        const { start, end } = trimSelection();
        setBusy(true);
        $('hmTrimVideo').pause();
        try {
            setProgress(0, 'Subiendo el video… 0%');
            const source = await window.firebase.uploadHomeMediaSource(trim.file, fraction => {
                setProgress(fraction, `Subiendo el video… ${Math.round(fraction * 100)}%`);
            });
            setProgress(-1, trim.kind === 'hero'
                ? 'Optimizando el video… suele tardar menos de 1 minuto.'
                : 'Optimizando el video… puede tardar hasta 3 minutos. No cierres esta página.');
            const round = value => Math.round(value * 10) / 10;
            const result = await api('/process', { kind: trim.kind, source, start: round(start), duration: round(end - start) });

            if (trim.kind === 'hero') {
                const files = { video: result.video, poster: result.poster };
                if (trim.index == null) {
                    state.draft.hero.slides.push({ eyebrow: '', title: '', linkText: '', linkHref: 'products.html', alt: '', ...files });
                } else {
                    Object.assign(state.draft.hero.slides[trim.index], files);
                }
                renderSlides();
            } else {
                const files = { video: result.video, poster: result.poster, preview: result.preview, duration: result.duration };
                if (trim.index == null) {
                    const title = trim.file.name.replace(/\.[^.]+$/, '').replace(/^vertical[-_ ]*/i, '').replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
                    state.draft.tutorials.push({
                        id: `t${Date.now().toString(36)}`, title: title.slice(0, 80) || 'Nuevo tutorial', brand: '',
                        productIds: [], match: [], featured: false, ...files
                    });
                } else {
                    Object.assign(state.draft.tutorials[trim.index], files);
                }
            }
            setBusy(false);
            closeTrim(true);
            updateDirty();
            renderTutorials();
            notify(trim.kind === 'hero'
                ? 'Video listo. Agrega su texto (opcional) y presiona "Publicar cambios".'
                : 'Video listo. Completa el título y los productos, y presiona "Publicar cambios".');
        } catch (error) {
            console.error('Error procesando video:', error);
            setBusy(false);
            $('hmProgress').hidden = true;
            notify(error.message || 'No se pudo procesar el video', true);
        }
    }

    // ---------- Publicar ----------
    async function publish() {
        if (!isDirty() || state.busy) return;
        const untitled = state.draft.tutorials.findIndex(item => !String(item.title || '').trim());
        if (untitled >= 0) {
            notify(`El tutorial ${untitled + 1} necesita un título.`, true);
            return;
        }
        state.busy = true;
        $('hmPublishBtn').disabled = true;
        $('hmPublishBtn').textContent = 'Publicando…';
        try {
            await api('/config', { config: state.draft });
            state.published = clone(state.draft);
            notify('¡Listo! El inicio ya muestra los nuevos videos.');
        } catch (error) {
            notify(error.message || 'No se pudieron publicar los cambios', true);
        } finally {
            state.busy = false;
            $('hmPublishBtn').textContent = 'Publicar cambios';
            updateDirty();
        }
    }

    // ---------- Carga ----------
    function normalize(config) {
        const base = clone(DEFAULT_CONFIG);
        // Acepta el formato anterior de un solo video ({ hero: { video, ... } })
        const slides = Array.isArray(config?.hero?.slides) ? config.hero.slides : (config?.hero?.video ? [config.hero] : []);
        if (!slides.length || !Array.isArray(config.tutorials) || !config.tutorials.length) return base;
        return {
            hero: {
                slides: slides.map(slide => ({
                    video: slide.video, poster: slide.poster,
                    eyebrow: slide.eyebrow || '', title: slide.title || '', linkText: slide.linkText || '',
                    linkHref: slide.linkHref || 'products.html', alt: slide.alt || ''
                }))
            },
            tutorials: config.tutorials.map(item => ({
                id: item.id, title: item.title || '', brand: item.brand || '', duration: Number(item.duration) || 0,
                video: item.video, poster: item.poster, preview: item.preview,
                productIds: Array.isArray(item.productIds) ? item.productIds.map(String) : [],
                match: Array.isArray(item.match) ? item.match : [],
                featured: item.featured === true
            }))
        };
    }

    async function init() {
        if (!(await checkAdminAuth())) return;
        $('adminVideosViewStoreBtn').addEventListener('click', () => { window.location.href = '../index.html'; });

        const [config, products, brands] = await Promise.all([
            window.firebase.getHomeMediaConfig(),
            window.firebase.getProducts().catch(() => []),
            window.firebase.getBrands().catch(() => [])
        ]);
        state.products = (Array.isArray(products) ? products : []).filter(product => product?.id && product.name)
            .sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
        state.brands = (Array.isArray(brands) ? brands : []).filter(brand => brand?.id && brand.active !== false)
            .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id), 'es'));
        state.published = normalize(config);
        state.draft = clone(state.published);

        $('hmProductsList').innerHTML = state.products.map(product => `<option value="${esc(product.name)}"></option>`).join('');
        const brandsList = document.createElement('datalist');
        brandsList.id = 'hmBrandsList';
        brandsList.innerHTML = state.brands.map(brand => `<option value="${esc(brand.name || brand.id)}"></option>`).join('');
        document.body.appendChild(brandsList);

        bindSlides();
        bindTutorials();
        bindTrim();
        $('hmPublishBtn').addEventListener('click', publish);
        $('hmDiscardBtn').addEventListener('click', () => {
            if (!window.confirm('¿Descartar los cambios sin publicar?')) return;
            state.draft = clone(state.published);
            renderSlides();
            renderTutorials();
            updateDirty();
        });
        window.addEventListener('beforeunload', event => {
            if (isDirty() || state.busy) { event.preventDefault(); event.returnValue = ''; }
        });

        renderSlides();
        renderTutorials();
        updateDirty();
        $('hmLoading').hidden = true;
        $('hmHeroSection').hidden = false;
        $('hmTutorialsSection').hidden = false;
    }

    document.addEventListener('DOMContentLoaded', () => {
        init().catch(error => {
            console.error('Error cargando Videos del inicio:', error);
            $('hmLoading').textContent = 'No se pudieron cargar los videos. Recarga la página.';
        });
    });
})();
