// phone-country.js - Campo de teléfono con selector de país (bandera + código).
// Envuelve un <input type="tel"> existente: el input guarda solo el número local
// y el selector el código del país. Uso:
//   const field = window.MonsitePhone.attach(document.getElementById('phone'));
//   field.validate()  -> { ok, e164, error }
//   field.setValue('+56912345678')
(function () {
    // Chile primero; luego los países más frecuentes entre clientes en Chile.
    const COUNTRIES = [
        { iso: 'cl', name: 'Chile', dial: '56', pattern: /^[2-9]\d{8}$/, example: '9 1234 5678', hint: '9 dígitos' },
        { iso: 'ar', name: 'Argentina', dial: '54', min: 10, max: 11, example: '9 11 2345 6789' },
        { iso: 'pe', name: 'Perú', dial: '51', min: 9, max: 9, example: '912 345 678' },
        { iso: 'bo', name: 'Bolivia', dial: '591', min: 8, max: 8, example: '7123 4567' },
        { iso: 've', name: 'Venezuela', dial: '58', min: 10, max: 10, example: '412 123 4567' },
        { iso: 'co', name: 'Colombia', dial: '57', min: 10, max: 10, example: '321 123 4567' },
        { iso: 'ec', name: 'Ecuador', dial: '593', min: 9, max: 9, example: '99 123 4567' },
        { iso: 'ht', name: 'Haití', dial: '509', min: 8, max: 8, example: '34 12 3456' },
        { iso: 'do', name: 'Rep. Dominicana', dial: '1', min: 10, max: 10, example: '809 234 5678' },
        { iso: 'cu', name: 'Cuba', dial: '53', min: 8, max: 8, example: '5 123 4567' },
        { iso: 'uy', name: 'Uruguay', dial: '598', min: 8, max: 8, example: '94 231 234' },
        { iso: 'py', name: 'Paraguay', dial: '595', min: 9, max: 9, example: '961 456 789' },
        { iso: 'br', name: 'Brasil', dial: '55', min: 10, max: 11, example: '11 91234 5678' },
        { iso: 'mx', name: 'México', dial: '52', min: 10, max: 10, example: '222 123 4567' },
        { iso: 'us', name: 'Estados Unidos', dial: '1', min: 10, max: 10, example: '201 555 0123' },
        { iso: 'ca', name: 'Canadá', dial: '1', min: 10, max: 10, example: '506 234 5678' },
        { iso: 'es', name: 'España', dial: '34', min: 9, max: 9, example: '612 34 56 78' },
        { iso: 'fr', name: 'Francia', dial: '33', min: 9, max: 9, example: '6 12 34 56 78' },
        { iso: 'it', name: 'Italia', dial: '39', min: 9, max: 11, example: '312 345 6789' },
        { iso: 'de', name: 'Alemania', dial: '49', min: 10, max: 11, example: '1512 3456789' },
        { iso: 'gb', name: 'Reino Unido', dial: '44', min: 10, max: 10, example: '7400 123456' },
        { iso: 'cn', name: 'China', dial: '86', min: 11, max: 11, example: '131 2345 6789' }
    ];

    const FLAG_BASE = 'images/flags/';

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function normalizeText(value) {
        return String(value || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    }

    function findCountry(iso) {
        return COUNTRIES.find(country => country.iso === iso) || COUNTRIES[0];
    }

    // '+56912345678' -> { country: Chile, local: '912345678' }. Prefiere Chile ante empates.
    function parseFullNumber(value) {
        const raw = String(value || '').trim();
        const digits = raw.replace(/\D/g, '');
        if (!digits) return { country: COUNTRIES[0], local: '' };

        // Número chileno sin código (formato antiguo guardado: 912345678)
        if (!raw.startsWith('+') && digits.length === 9) {
            return { country: COUNTRIES[0], local: digits };
        }

        const byLongestDial = [...COUNTRIES].sort((a, b) => b.dial.length - a.dial.length);
        const match = byLongestDial.find(country => digits.startsWith(country.dial));
        if (!match) return { country: COUNTRIES[0], local: digits };

        const sameDial = COUNTRIES.filter(country => country.dial === match.dial);
        return { country: sameDial[0], local: digits.slice(match.dial.length) };
    }

    function validateLocal(country, local) {
        if (!local) return 'Ingresa tu número de teléfono';
        if (country.pattern) {
            if (!country.pattern.test(local)) {
                return `Ingresa un teléfono de ${country.hint || 'la longitud correcta'}, por ejemplo ${country.example}`;
            }
            return '';
        }
        if (local.length < country.min || local.length > country.max) {
            const size = country.min === country.max ? `${country.min}` : `${country.min} a ${country.max}`;
            return `El número de ${country.name} debe tener ${size} dígitos, por ejemplo ${country.example}`;
        }
        return '';
    }

    function attach(input) {
        if (!input || input.dataset.phoneCountry === 'ready') return input?.__phoneField || null;
        input.dataset.phoneCountry = 'ready';

        const wrapper = document.createElement('div');
        wrapper.className = 'phone-field';
        input.parentNode.insertBefore(wrapper, input);

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'phone-country-btn';
        button.setAttribute('aria-haspopup', 'listbox');
        button.setAttribute('aria-expanded', 'false');

        const panel = document.createElement('div');
        panel.className = 'phone-country-panel';
        panel.hidden = true;
        panel.innerHTML = `
            <input type="search" class="phone-country-search" placeholder="Buscar país o código" aria-label="Buscar país" autocomplete="off">
            <ul class="phone-country-list" role="listbox" aria-label="País del teléfono"></ul>`;

        wrapper.append(button, input, panel);
        input.classList.add('phone-field-input');
        input.setAttribute('autocomplete', 'tel-national');
        input.setAttribute('inputmode', 'tel');

        const search = panel.querySelector('.phone-country-search');
        const list = panel.querySelector('.phone-country-list');
        let current = COUNTRIES[0];
        let activeIndex = 0;
        let visible = COUNTRIES;

        function renderButton() {
            button.innerHTML = `
                <img src="${FLAG_BASE}${current.iso}.png" alt="" width="20" height="15">
                <span class="phone-country-dial">+${current.dial}</span>
                <svg class="phone-country-caret" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 4.5 6 7.5 9 4.5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
            button.setAttribute('aria-label', `País del teléfono: ${current.name} (+${current.dial}). Cambiar país`);
            input.placeholder = current.example;
        }

        function renderList() {
            const query = normalizeText(search.value).replace(/^\+/, '');
            visible = COUNTRIES.filter(country => !query
                || normalizeText(country.name).includes(query)
                || country.dial.startsWith(query.replace(/\D/g, '') || '#'));
            activeIndex = Math.max(0, visible.indexOf(current));
            list.innerHTML = visible.length
                ? visible.map((country, index) => `
                    <li role="option" id="phone-opt-${country.iso}" data-iso="${country.iso}"
                        aria-selected="${country === current}" class="${index === activeIndex ? 'is-active' : ''}">
                        <img src="${FLAG_BASE}${country.iso}.png" alt="" width="20" height="15" loading="lazy">
                        <span class="phone-country-name">${escapeHtml(country.name)}</span>
                        <span class="phone-country-code">+${country.dial}</span>
                    </li>`).join('')
                : '<li class="phone-country-empty">Sin resultados</li>';
        }

        function highlight(index) {
            const items = list.querySelectorAll('[role="option"]');
            if (!items.length) return;
            activeIndex = (index + items.length) % items.length;
            items.forEach((item, i) => item.classList.toggle('is-active', i === activeIndex));
            items[activeIndex].scrollIntoView({ block: 'nearest' });
            search.setAttribute('aria-activedescendant', items[activeIndex].id);
        }

        function open() {
            panel.hidden = false;
            wrapper.classList.add('is-open');
            button.setAttribute('aria-expanded', 'true');
            search.value = '';
            renderList();
            highlight(activeIndex);
            search.focus();
        }

        function close(focusInput) {
            if (panel.hidden) return;
            panel.hidden = true;
            wrapper.classList.remove('is-open');
            button.setAttribute('aria-expanded', 'false');
            if (focusInput) input.focus();
        }

        function select(country, focusInput = true) {
            current = country;
            renderButton();
            close(focusInput);
            input.dispatchEvent(new Event('phonecountrychange', { bubbles: true }));
        }

        button.addEventListener('click', () => (panel.hidden ? open() : close(false)));
        search.addEventListener('input', renderList);
        search.addEventListener('keydown', event => {
            if (event.key === 'ArrowDown') { event.preventDefault(); highlight(activeIndex + 1); }
            else if (event.key === 'ArrowUp') { event.preventDefault(); highlight(activeIndex - 1); }
            else if (event.key === 'Enter') {
                event.preventDefault();
                if (visible[activeIndex]) select(visible[activeIndex]);
            } else if (event.key === 'Escape') { event.preventDefault(); close(false); button.focus(); }
        });
        list.addEventListener('click', event => {
            const item = event.target.closest('[data-iso]');
            if (item) select(findCountry(item.dataset.iso));
        });
        document.addEventListener('click', event => {
            if (!wrapper.contains(event.target)) close(false);
        });

        // Si el cliente pega un número con código (+54 9 11...), se detecta el país.
        input.addEventListener('input', () => {
            const value = input.value.trim();
            if (!value.startsWith('+') && !value.startsWith('00')) return;
            const parsed = parseFullNumber(value.replace(/^00/, '+'));
            if (parsed.local.length >= 6) {
                current = parsed.country;
                renderButton();
                input.value = parsed.local;
            }
        });

        const field = {
            get country() { return current; },
            setValue(fullNumber) {
                const parsed = parseFullNumber(fullNumber);
                current = parsed.country;
                renderButton();
                input.value = parsed.local;
            },
            validate() {
                let local = input.value.replace(/\D/g, '');
                // Si escribieron el código dentro del número (56 9 1234 5678), se quita.
                if (local.startsWith(current.dial) && validateLocal(current, local)) {
                    const withoutDial = local.slice(current.dial.length);
                    if (!validateLocal(current, withoutDial)) local = withoutDial;
                }
                // Números con 0 inicial de marcación nacional (011..., 09...).
                if (local.startsWith('0') && validateLocal(current, local) && !validateLocal(current, local.slice(1))) {
                    local = local.slice(1);
                }
                const error = validateLocal(current, local);
                if (!error) input.value = local;
                return { ok: !error, error, e164: error ? '' : `+${current.dial}${local}`, country: current };
            }
        };

        renderButton();
        if (input.value) field.setValue(input.value);
        input.__phoneField = field;
        return field;
    }

    window.MonsitePhone = { attach, parseFullNumber, COUNTRIES };
})();
