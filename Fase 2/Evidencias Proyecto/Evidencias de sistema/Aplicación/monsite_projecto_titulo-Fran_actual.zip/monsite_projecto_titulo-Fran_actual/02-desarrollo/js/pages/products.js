// products.js - Sistema de búsqueda y filtros para products.html
document.addEventListener('DOMContentLoaded', function() {
    initializeProductsPage();
});

let productSearchIndex = [];
let categoryNameById = {};
let currentCategoryFilter = 'all';
let currentBrandFilter = 'all';
// Filtros que llegan desde el menú principal: grupo de categorías (?grupo=) y solo ofertas (?ofertas=1)
let currentGroupFilter = null;
let currentOffersOnly = false;
let searchDebounceTimer = null;
const SEARCH_DEBOUNCE_MS = 180;
let productsPageReadySubscribed = false;
let hasInvalidCatalogFilter = false;

// Paginación del catálogo: PRODUCTS_PAGE_SIZE productos por página. La página va en la URL
// (?page=3) junto con los filtros, así atrás/adelante, recargar y compartir el link funcionan.
const PRODUCTS_PAGE_SIZE = 24;
let currentProductsPage = 1;
let currentRenderedProducts = [];

function readPageFromUrl() {
    const page = Number.parseInt(new URLSearchParams(window.location.search).get('page'), 10);
    return Number.isInteger(page) && page > 0 ? page : 1;
}

// Escribe los filtros actuales y la página en la URL (push = nueva entrada en el historial)
function syncCatalogUrl({ push = false } = {}) {
    const params = new URLSearchParams(window.location.search);
    const setOrDelete = (key, value) => (value ? params.set(key, value) : params.delete(key));
    const term = (document.getElementById('searchInput')?.value || '').trim();

    setOrDelete('search', term);
    setOrDelete('category', currentCategoryFilter !== 'all' ? currentCategoryFilter : '');
    setOrDelete('brand', currentBrandFilter !== 'all' ? currentBrandFilter : '');
    setOrDelete('grupo', currentGroupFilter?.id || '');
    setOrDelete('ofertas', currentOffersOnly ? '1' : '');
    setOrDelete('page', currentProductsPage > 1 ? String(currentProductsPage) : '');

    const query = params.toString();
    const url = `${window.location.pathname}${query ? `?${query}` : ''}${window.location.hash}`;
    if (url === `${window.location.pathname}${window.location.search}${window.location.hash}`) return;
    window.history[push ? 'pushState' : 'replaceState'](null, '', url);
}

// Cualquier cambio de filtro o búsqueda vuelve a la página 1
function resetProductsPagination() {
    currentProductsPage = 1;
    syncCatalogUrl();
}

function goToProductsPage(page) {
    currentProductsPage = page;
    syncCatalogUrl({ push: true });
    const productsGrid = document.getElementById('productsGrid');
    if (productsGrid) {
        renderProducts(currentRenderedProducts, productsGrid);
    }
    scrollToCatalogTop();
}

// Sube al inicio del catálogo (no al inicio de la página), descontando un header fijo si lo hay
function scrollToCatalogTop() {
    const target = document.getElementById('productsTitle') || document.getElementById('productsGrid');
    if (!target) return;
    const header = document.querySelector('header');
    const headerPosition = header ? window.getComputedStyle(header).position : '';
    const offset = header && (headerPosition === 'fixed' || headerPosition === 'sticky') ? header.offsetHeight : 0;
    const top = target.getBoundingClientRect().top + window.scrollY - offset - 16;
    window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
}

// Botón atrás/adelante: se vuelven a leer filtros y página desde la URL
window.addEventListener('popstate', () => {
    if (!window.__hairiaCatalogRendered) return;
    checkUrlParams();
});

const BRANDS_LOGO_MAP = {
    'olaplex': 'images/olaplex.jpg',
    'kerastase': 'images/kerastase.jpg',
    'tigi': 'images/tigi.jpg',
    'k18': 'images/k18.jpg',
    'living-proof': 'images/livingprof.jpg',
    'revlon': 'images/revlon.jpg',
    'moroccanoil': 'images/Moroccanoil.jpg',
    'dabalash': 'images/Dabalash.jpg'
};

function isProductAvailable(product) {
    if (!product || product.active === false) return false;
    const stock = Number.parseInt(product.stock, 10);
    return Number.isFinite(stock) ? stock > 0 : true;
}

function isProductOutOfStock(product) {
    const stock = Number.parseInt(product?.stock, 10);
    return product?.active === false || (Number.isFinite(stock) && stock <= 0);
}

function escapeHtml(value) {
    const text = value == null ? '' : String(value);
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function sanitizeImageUrl(value) {
    if (typeof value !== 'string') return '';
    const trimmed = value.trim();
    if (!trimmed) return '';
    if (/^https?:\/\//i.test(trimmed) || /^data:image\//i.test(trimmed)) {
        // Comillas y <> no son válidas en una URL: se codifican para que no puedan salir del atributo src="..."
        return trimmed.replace(/"/g, '%22').replace(/'/g, '%27').replace(/</g, '%3C').replace(/>/g, '%3E').replace(/`/g, '%60');
    }
    return '';
}

function getDiscountedPrice(product) {
    const price = Number(product?.price) || 0;
    if (product?.discountType === 'percentage') {
        return Math.max(0, Math.round(price - (price * (Number(product.discountPercent) || 0) / 100)));
    }
    if (product?.discountType === 'amount') {
        return Math.max(0, price - (Number(product.discountAmount) || 0));
    }
    return price;
}

function getDiscountText(product) {
    if (product?.discountType === 'percentage' && Number(product.discountPercent) > 0) {
        return `${Number(product.discountPercent)}% OFF`;
    }
    if (product?.discountType === 'amount' && Number(product.discountAmount) > 0) {
        return `-${formatCLP(product.discountAmount)}`;
    }
    return '';
}

function renderPriceHtml(product) {
    const discountText = getDiscountText(product);

    // Estructura fija de 2 filas SIEMPRE (con o sin descuento) para que todos
    // los precios finales queden alineados a la izquierda y a la misma altura.
    const originalRow = discountText
        ? `<span class="original-price">${formatCLP(product.price)}</span>`
        : `<span class="original-price original-price-empty" aria-hidden="true"></span>`;

    const finalPrice = discountText ? getDiscountedPrice(product) : product.price;
    const badge = discountText ? `<span class="discount-badge">${escapeHtml(discountText)}</span>` : '';

    return `<div class="price-with-discount">
        ${originalRow}
        <div class="discount-price-row">
            <p class="product-price${discountText ? ' discounted' : ''}">${formatCLP(finalPrice)}</p>
            ${badge}
        </div>
    </div>`;
}

function normalizeText(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s-]/g, '')
        .trim();
}

function normalizeBrandKey(value) {
    return normalizeText(value).replace(/\s+/g, '-');
}

function getBrandLogoByKey(brandKey) {
    return sanitizeImageUrl(BRANDS_LOGO_MAP[brandKey] || '');
}

function getAvailableBrands() {
    const source = (window.productsData || []).filter(product => product && product.active !== false);
    const map = new Map();

    source.forEach(product => {
        const rawBrand = String(product.brand || '').trim();
        if (!rawBrand) return;

        const key = normalizeBrandKey(rawBrand);
        if (!key) return;

        if (!map.has(key)) {
            map.set(key, {
                key,
                // La marca viene guardada como clave (ej. "living-proof"); se muestra su nombre
                name: window.MonsiteNav?.brandName?.(key) || rawBrand,
                logo: getBrandLogoByKey(key)
            });
        }
    });

    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'es'));
}

function initializeProductsPage() {
    subscribeProductsDataReady();
    // Los nombres de marca escritos en el admin llegan después del catálogo
    window.addEventListener('monsite:brand-names-ready', () => {
        loadBrandFilters();
        // El título ("Marca: ...") también usa el nombre: se actualiza si hay una marca elegida
        if (window.__hairiaCatalogRendered && currentBrandFilter !== 'all') {
            applyProductFilters((document.getElementById('searchInput')?.value || '').toLowerCase().trim());
        }
    });
    setupSearch();
    // Hasta que llegue el catálogo se mantienen los esqueletos de carga;
    // al llegar, app.js emite 'hairia:data-ready' y se pinta todo.
    if (!window.__hairiaCatalogRendered) return;
    rebuildProductsPerformanceIndex();
    loadCategoriesFilters();
    loadBrandFilters();
    loadAllProducts();
    checkUrlParams();
}

function subscribeProductsDataReady() {
    if (productsPageReadySubscribed) return;
    productsPageReadySubscribed = true;

    window.addEventListener('hairia:data-ready', () => {
        rebuildProductsPerformanceIndex();
        loadCategoriesFilters();
        loadBrandFilters();
        loadAllProducts();
        checkUrlParams();
    });
}

function rebuildProductsPerformanceIndex() {
    categoryNameById = (window.categories || []).reduce((acc, category) => {
        acc[category.id] = category.name;
        return acc;
    }, {});

    productSearchIndex = (window.productsData || []).map(product => {
        const categoryName = categoryNameById[product.category] || product.category || '';
        return {
            id: String(product.id),
            text: `${product.name || ''} ${product.description || ''} ${categoryName} ${product.brand || ''}`.toLowerCase(),
            category: product.category
        };
    });
}

function checkUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchTerm = urlParams.get('search');
    const category = urlParams.get('category');
    const brand = urlParams.get('brand');
    const groupId = urlParams.get('grupo');
    hasInvalidCatalogFilter = false;
    currentProductsPage = readPageFromUrl();
    currentGroupFilter = groupId ? (window.MonsiteNav?.groups || []).find(group => group.id === groupId) || null : null;
    currentOffersOnly = urlParams.get('ofertas') === '1';

    const categoryButtons = Array.from(document.querySelectorAll('.filter-btn[data-category]'));
    const brandButtons = Array.from(document.querySelectorAll('.brand-filter-chip[data-brand]'));
    const hasLoadedCategoryOptions = categoryButtons.some(btn => (btn.dataset.category || '') !== 'all');
    const hasLoadedBrandOptions = brandButtons.some(btn => (btn.dataset.brand || '') !== 'all');

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.value = searchTerm || '';
    }

    const normalizedRequestedCategory = category ? String(category).trim() : 'all';
    const normalizedRequestedBrand = brand ? normalizeBrandKey(brand) : 'all';

    currentCategoryFilter = normalizedRequestedCategory || 'all';
    currentBrandFilter = normalizedRequestedBrand || 'all';

    if (category) {
        // Desde el menú puede llegar más de una categoría con el mismo nombre (?category=a,b)
        const categoryBtn = document.querySelector(`[data-category="${category.split(',')[0]}"]`);
        if (categoryBtn) {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            categoryBtn.classList.add('active');
        } else if (hasLoadedCategoryOptions) {
            hasInvalidCatalogFilter = true;
        }
    } else if (categoryButtons.length) {
        categoryButtons.forEach(b => b.classList.remove('active'));
        const allCategoryBtn = document.querySelector('.filter-btn[data-category="all"]');
        if (allCategoryBtn) {
            allCategoryBtn.classList.add('active');
        }
    }

    if (brand) {
        const normalizedBrand = normalizeBrandKey(brand);
        const brandBtn = Array.from(document.querySelectorAll('.brand-filter-chip[data-brand]'))
            .find(btn => normalizeBrandKey(btn.dataset.brand || '') === normalizedBrand);
        if (brandBtn) {
            document.querySelectorAll('.brand-filter-chip').forEach(b => b.classList.remove('active'));
            brandBtn.classList.add('active');
        } else if (hasLoadedBrandOptions) {
            hasInvalidCatalogFilter = true;
        }
    } else if (brandButtons.length) {
        brandButtons.forEach(b => b.classList.remove('active'));
        const allBrandBtn = document.querySelector('.brand-filter-chip[data-brand="all"]');
        if (allBrandBtn) {
            allBrandBtn.classList.add('active');
        }
    }

    if (hasInvalidCatalogFilter) {
        const productsGrid = document.getElementById('productsGrid');
        const productsTitle = document.getElementById('productsTitle');
        if (productsTitle) {
            productsTitle.textContent = 'Elemento no encontrado';
        }
        if (productsGrid) {
            productsGrid.innerHTML = '<p class="no-results">Elemento no encontrado.</p>';
        }
        return;
    }

    applyProductFilters(searchTerm ? searchTerm.toLowerCase().trim() : '');
}

function loadBrandFilters() {
    const brandsRail = document.getElementById('brandsRail');
    if (!brandsRail) return;

    const brands = getAvailableBrands();

    brandsRail.innerHTML = `
        <button class="brand-filter-chip ${currentBrandFilter === 'all' ? 'active' : ''}" data-brand="all" type="button">Todas las marcas</button>
        ${brands.map(brand => {
            const safeName = escapeHtml(brand.name);
            const safeKey = escapeHtml(brand.key);
            const safeLogo = escapeHtml(brand.logo);
            const initials = escapeHtml((brand.name || 'M').substring(0, 2).toUpperCase());
            const isActive = currentBrandFilter === brand.key;

            return `
            <button class="brand-filter-chip ${isActive ? 'active' : ''}" data-brand="${safeKey}" type="button" aria-label="Filtrar por ${safeName}">
                ${safeLogo
                    ? `<img src="${safeLogo}" alt="${safeName}" class="brand-filter-logo">`
                    : `<span class="brand-filter-initials">${initials}</span>`
                }
                <span class="brand-filter-name">${safeName}</span>
            </button>`;
        }).join('')}
    `;

    brandsRail.querySelectorAll('.brand-filter-chip').forEach(btn => {
        btn.addEventListener('click', function() {
            brandsRail.querySelectorAll('.brand-filter-chip').forEach(item => item.classList.remove('active'));
            this.classList.add('active');
            filterProductsByBrand(this.dataset.brand || 'all');
        });
    });
}

function loadCategoriesFilters() {
    const filtersContainer = document.getElementById('categoryFilters');
    if (!filtersContainer) return;

    const categories = (window.categories || []).map((category) => ({
        id: String(category?.id || '').trim(),
        name: String(category?.name || '').trim()
    })).filter(category => category.id && category.name);

    filtersContainer.innerHTML = `
        <button class="filter-btn ${currentCategoryFilter === 'all' ? 'active' : ''}" data-category="all">Todos</button>
        ${categories.map(category => {
            const safeId = escapeHtml(category.id);
            const safeName = escapeHtml(category.name);
            const isActive = currentCategoryFilter === category.id;
            return `
            <button class="filter-btn ${isActive ? 'active' : ''}" data-category="${safeId}">${safeName}</button>
        `;
        }).join('')}
    `;

    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.dataset.category;
            filterProductsByCategory(category);
        });
    });
}

function filterProductsByCategory(category) {
    hasInvalidCatalogFilter = false;
    currentCategoryFilter = category;
    currentGroupFilter = null; // elegir una categoría reemplaza el grupo del menú
    resetProductsPagination();
    const currentTerm = (document.getElementById('searchInput')?.value || '').toLowerCase().trim();
    applyProductFilters(currentTerm);
}

// Producto con descuento vigente y stock (mismo criterio que el menú y el inicio)
function isCatalogProductOnSale(product) {
    if (typeof window.MonsiteNav?.isOnSale === 'function') return window.MonsiteNav.isOnSale(product);
    const price = Number(product.price) || 0;
    let final = price;
    if (product.discountType === 'percentage') final = Math.round(price - price * (Number(product.discountPercent) || 0) / 100);
    if (product.discountType === 'amount') final = Math.max(0, price - (Number(product.discountAmount) || 0));
    return price > 0 && final < price && (Number.parseInt(product.stock, 10) || 0) > 0;
}

function filterProductsByBrand(brand) {
    hasInvalidCatalogFilter = false;
    currentBrandFilter = brand || 'all';
    resetProductsPagination();
    const currentTerm = (document.getElementById('searchInput')?.value || '').toLowerCase().trim();
    applyProductFilters(currentTerm);
}

function loadAllProducts() {
    currentProductsPage = readPageFromUrl();
    const productsGrid = document.getElementById('productsGrid');
    if (productsGrid) {
        renderProducts(window.productsData || [], productsGrid);
    }
}

function ensureProductsPaginationContainer(container) {
    let wrapper = document.getElementById('productsPagination');
    if (wrapper) return wrapper;

    wrapper = document.createElement('div');
    wrapper.id = 'productsPagination';
    wrapper.className = 'products-pagination';
    container.insertAdjacentElement('afterend', wrapper);
    return wrapper;
}

// Números a mostrar: primera, última y vecinas de la actual; '…' donde se saltan páginas.
// En pantallas chicas solo la actual (‹ 1 … 4 … 8 ›) para que quepa en una línea.
function getPaginationItems(current, total) {
    const siblings = window.matchMedia('(max-width: 480px)').matches ? 0 : 1;
    const pages = new Set([1, total]);
    for (let page = current - siblings; page <= current + siblings; page += 1) {
        if (page > 1 && page < total) pages.add(page);
    }
    // Si el salto es de una sola página, se muestra el número en vez de '…'
    const sorted = Array.from(pages).sort((a, b) => a - b);
    const items = [];
    sorted.forEach((page, index) => {
        const previous = sorted[index - 1];
        if (previous && page - previous === 2) items.push(previous + 1);
        else if (previous && page - previous > 2) items.push('…');
        items.push(page);
    });
    return items;
}

function renderProductsPagination(container, totalCount) {
    const wrapper = ensureProductsPaginationContainer(container);
    const totalPages = Math.ceil(totalCount / PRODUCTS_PAGE_SIZE);

    if (totalCount === 0) {
        wrapper.innerHTML = '';
        wrapper.style.display = 'none';
        return;
    }

    const first = (currentProductsPage - 1) * PRODUCTS_PAGE_SIZE + 1;
    const last = Math.min(currentProductsPage * PRODUCTS_PAGE_SIZE, totalCount);
    const info = `<p class="products-pagination-info">Mostrando ${first}–${last} de ${totalCount} producto${totalCount === 1 ? '' : 's'}</p>`;

    wrapper.style.display = '';
    if (totalPages <= 1) {
        wrapper.innerHTML = info;
        return;
    }

    const isFirst = currentProductsPage === 1;
    const isLast = currentProductsPage === totalPages;
    const pageButtons = getPaginationItems(currentProductsPage, totalPages).map(item => {
        if (item === '…') return '<span class="pager-ellipsis" aria-hidden="true">…</span>';
        const isCurrent = item === currentProductsPage;
        return `<button type="button" class="pager-btn${isCurrent ? ' active' : ''}" data-page="${item}" aria-label="Página ${item}"${isCurrent ? ' aria-current="page"' : ''}>${item}</button>`;
    }).join('');

    wrapper.innerHTML = `
        <nav class="products-pager" aria-label="Páginas del catálogo">
            <button type="button" class="pager-btn pager-arrow" data-page="${currentProductsPage - 1}" aria-label="Página anterior"${isFirst ? ' disabled' : ''}>‹</button>
            ${pageButtons}
            <button type="button" class="pager-btn pager-arrow" data-page="${currentProductsPage + 1}" aria-label="Página siguiente"${isLast ? ' disabled' : ''}>›</button>
        </nav>
        ${info}
    `;

    if (wrapper.dataset.listener !== 'true') {
        wrapper.addEventListener('click', (event) => {
            const button = event.target.closest('button[data-page]');
            if (!button || button.disabled) return;
            const page = Number.parseInt(button.dataset.page, 10);
            const pages = Math.ceil(currentRenderedProducts.length / PRODUCTS_PAGE_SIZE);
            if (page >= 1 && page <= pages && page !== currentProductsPage) {
                goToProductsPage(page);
            }
        });
        wrapper.dataset.listener = 'true';
    }
}

function renderProducts(products, container) {
    container.removeAttribute('aria-busy');
    const emojis = {
        'shampoo': '🧴',
        'acondicionador': '💧', 
        'tratamiento': '🎭',
        'peinado': '💇',
        'mascarilla': '🫧',
        'serum': '✨',
        'proteccion-termica': '🔥',
        'aceite': '💧',
        'otros': '🛍️'
    };

    if (products.length === 0) {
        container.innerHTML = '<p class="no-results">No se encontraron productos.</p>';
        currentRenderedProducts = [];
        renderProductsPagination(container, 0);
        return;
    }

    currentRenderedProducts = products;
    // Página fuera de rango (p. ej. ?page=9 con menos productos): se ajusta a la última
    const totalPages = Math.ceil(products.length / PRODUCTS_PAGE_SIZE);
    if (currentProductsPage > totalPages) {
        currentProductsPage = totalPages;
        syncCatalogUrl();
    }
    const pageStart = (currentProductsPage - 1) * PRODUCTS_PAGE_SIZE;
    const visibleProducts = products.slice(pageStart, pageStart + PRODUCTS_PAGE_SIZE);

    container.innerHTML = visibleProducts.map(product => {
        const safeName = escapeHtml(product.name || 'Producto');
        const safeCategory = escapeHtml(product.category || '');
        const safeProductId = escapeHtml(String(product.id));
        const safeImage = sanitizeImageUrl(product.image);
        const safeCategoryName = escapeHtml(categoryNameById[product.category] || product.category || '');
        const isOutOfStock = isProductOutOfStock(product);

        return `
        <div class="product-card${isOutOfStock ? ' product-card-out-of-stock' : ''}" data-category="${safeCategory}" data-action="open-product" data-product-id="${safeProductId}" style="cursor: pointer;">
            <div class="product-image">
                ${safeImage ? 
                    `<img src="${safeImage}" alt="${safeName}" class="product-real-image" loading="lazy" decoding="async">` :
                    `<div class="image-placeholder">
                        <span class="product-emoji">${emojis[product.category] || '🛍️'}</span>
                        <span class="product-text">${escapeHtml((product.name || '').split(' ')[0] || '')}</span>
                    </div>`
                }
                ${product.featured ? '<span class="featured-badge">⭐ Destacado</span>' : ''}
            </div>
            <div class="product-info">
                <h3>${safeName}</h3>
                ${renderPriceHtml(product)}
                <div class="product-category">${safeCategoryName}</div>
                <button class="add-to-cart${isOutOfStock ? ' out-of-stock-button' : ''}" data-action="${isOutOfStock ? 'out-of-stock' : 'add-to-cart'}" data-product-id="${safeProductId}" ${isOutOfStock ? 'disabled' : ''}>
                    ${isOutOfStock ? 'Agotado' : 'Agregar al Carrito'}
                </button>
            </div>
        </div>
    `;
    }).join('');

    renderProductsPagination(container, products.length);

    if (container.dataset.listener !== 'true') {
        container.addEventListener('click', (event) => {
            const cartButton = event.target.closest('button[data-action="add-to-cart"][data-product-id]');
            if (cartButton) {
                event.stopPropagation();
                addToCartFromButton(cartButton.dataset.productId);
                return;
            }

            if (event.target.closest('button[data-action="out-of-stock"]')) {
                event.stopPropagation();
                return;
            }

            const card = event.target.closest('[data-action="open-product"][data-product-id]');
            if (card) {
                openProductModal(card.dataset.productId);
            }
        });
        container.dataset.listener = 'true';
    }
}

function applyProductFilters(searchTerm = '') {
    const productsGrid = document.getElementById('productsGrid');
    const productsTitle = document.getElementById('productsTitle');

    if (!productsGrid || !productsTitle) {
        return;
    }

    let filteredProducts = window.productsData || [];

    const categorySet = new Set(currentCategoryFilter.split(','));
    if (currentCategoryFilter !== 'all') {
        filteredProducts = filteredProducts.filter(product => categorySet.has(product.category));
    }

    if (currentBrandFilter !== 'all') {
        filteredProducts = filteredProducts.filter(product => normalizeBrandKey(product.brand) === currentBrandFilter);
    }

    if (currentGroupFilter && currentCategoryFilter === 'all') {
        const groupCategories = new Set(currentGroupFilter.categories);
        filteredProducts = filteredProducts.filter(product => groupCategories.has(product.category));
    }

    if (currentOffersOnly) {
        filteredProducts = filteredProducts.filter(isCatalogProductOnSale);
    }

    if (searchTerm) {
        const idSet = new Set(
            productSearchIndex
                .filter(entry => (currentCategoryFilter === 'all' || categorySet.has(entry.category)) && entry.text.includes(searchTerm))
                .map(entry => entry.id)
        );
        filteredProducts = filteredProducts.filter(product => idSet.has(String(product.id)));
    }

    if (searchTerm) {
        if (filteredProducts.length > 0) {
            productsTitle.textContent = `Resultados para: "${searchTerm}" (${filteredProducts.length})`;
            renderProducts(filteredProducts, productsGrid);
        } else {
            productsTitle.textContent = `No se encontraron resultados para: "${searchTerm}"`;
            productsGrid.innerHTML = '<p class="no-results">No se encontraron productos que coincidan con tu búsqueda.</p>';
            currentRenderedProducts = [];
            renderProductsPagination(productsGrid, 0);
        }
        return;
    }

    const selectedBrandButton = document.querySelector(`.brand-filter-chip[data-brand="${currentBrandFilter}"] .brand-filter-name`);
    const selectedBrandName = currentBrandFilter === 'all'
        ? ''
        : (selectedBrandButton?.textContent || currentBrandFilter.replace(/-/g, ' '));

    const groupName = currentGroupFilter && currentCategoryFilter === 'all' ? currentGroupFilter.name : '';
    let title;
    const firstCategory = currentCategoryFilter.split(',')[0];
    if (currentCategoryFilter !== 'all' && currentBrandFilter !== 'all') {
        title = `${categoryNameById[firstCategory] || firstCategory} · ${selectedBrandName}`;
    } else if (currentCategoryFilter !== 'all') {
        title = categoryNameById[firstCategory] || firstCategory;
    } else if (groupName && currentBrandFilter !== 'all') {
        title = `${groupName} · ${selectedBrandName}`;
    } else if (groupName) {
        title = groupName;
    } else if (currentBrandFilter !== 'all') {
        title = `Marca: ${selectedBrandName}`;
    } else {
        title = currentOffersOnly ? '' : 'Todos los Productos';
    }
    if (currentOffersOnly) title = title ? `Ofertas · ${title}` : 'Ofertas';
    productsTitle.textContent = currentOffersOnly || groupName ? `${title} (${filteredProducts.length})` : title;

    renderProducts(filteredProducts, productsGrid);
}

function setupSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    
    if (!searchInput || !searchButton) return;

    function performSearch(searchTerm = null) {
        const term = searchTerm !== null ? searchTerm : searchInput.value.toLowerCase().trim();

        resetProductsPagination();

        if (term === '') {
            applyProductFilters('');
            return;
        }

        applyProductFilters(term);
    }

    searchButton.addEventListener('click', () => performSearch());
    searchInput.addEventListener('input', function() {
        if (searchDebounceTimer) {
            clearTimeout(searchDebounceTimer);
        }
        searchDebounceTimer = setTimeout(() => performSearch(), SEARCH_DEBOUNCE_MS);
    });
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    // Hacer la función global para checkUrlParams
    window.performSearch = performSearch;
}

/**
 * Agregar producto al carrito desde el botón
 * @param {string|number} productId - ID del producto (string para Firebase, número para local)
 */
function addToCartFromButton(productId) {
    console.log('➕ Agregando producto al carrito (ID:', productId, ')');
    
    // Asegurarse de que productId es el tipo correcto para comparar
    const product = window.productsData.find(p => String(p.id) === String(productId));
    
    if (!product) {
        console.error('❌ Producto no encontrado:', productId);
        showNotification('Error: Producto no encontrado');
        return;
    }
    
    // Llamar a la función global addToCart desde app.js
    if (typeof window.addToCart === 'function') {
        window.addToCart(product);
        console.log('✅ Producto agregado:', product.name);
    } else {
        console.error('❌ Función addToCart no disponible');
        showNotification('Error al agregar al carrito');
    }
}
