// carousel.js - Flechas de los carruseles horizontales (destacados, productos por marca).
// - "›" avanza una página (las tarjetas que caben) y siempre llega a la última tarjeta;
//   estando al final vuelve al inicio (y "‹" al inicio va al final).
// - Si todo cabe en pantalla, las flechas se ocultan.
// - El deslizamiento con el dedo/rueda lo hace el propio navegador (overflow-x + scroll-snap).
(function () {
    const EDGE = 4; // tolerancia en px para considerar inicio/fin

    function getStep(track, itemSelector) {
        const items = track.querySelectorAll(itemSelector);
        if (!items.length) return track.clientWidth;
        const styles = window.getComputedStyle(track);
        const gap = Number.parseFloat(styles.columnGap || styles.gap) || 0;
        const cardWidth = items[0].getBoundingClientRect().width + gap;
        if (!cardWidth) return track.clientWidth;
        const perPage = Math.max(1, Math.floor((track.clientWidth + gap) / cardWidth));
        return perPage * cardWidth;
    }

    function attach(track, prevBtn, nextBtn, { itemSelector = ':scope > *' } = {}) {
        if (!track || !prevBtn || !nextBtn) return;
        if (track.__carousel) {
            track.__carousel.update();
            return track.__carousel;
        }

        const maxScroll = () => Math.max(0, track.scrollWidth - track.clientWidth);

        function update() {
            const scrollable = maxScroll() > EDGE;
            [prevBtn, nextBtn].forEach(button => {
                button.hidden = !scrollable;
                button.setAttribute('aria-hidden', scrollable ? 'false' : 'true');
                button.tabIndex = scrollable ? 0 : -1;
            });
            track.classList.toggle('is-scrollable', scrollable);
        }

        function move(direction) {
            const max = maxScroll();
            if (max <= EDGE) return;
            const current = track.scrollLeft;
            let target;
            if (direction > 0) {
                target = current >= max - EDGE ? 0 : Math.min(max, current + getStep(track, itemSelector));
            } else {
                target = current <= EDGE ? max : Math.max(0, current - getStep(track, itemSelector));
            }
            track.scrollTo({ left: target, behavior: 'smooth' });
        }

        prevBtn.addEventListener('click', event => { event.preventDefault(); move(-1); });
        nextBtn.addEventListener('click', event => { event.preventDefault(); move(1); });
        prevBtn.setAttribute('aria-label', prevBtn.getAttribute('aria-label') || 'Ver anteriores');
        nextBtn.setAttribute('aria-label', nextBtn.getAttribute('aria-label') || 'Ver siguientes');

        // Recalcular cuando cambia el tamaño o llegan/cambian las tarjetas
        if ('ResizeObserver' in window) new ResizeObserver(update).observe(track);
        new MutationObserver(() => requestAnimationFrame(update)).observe(track, { childList: true });
        window.addEventListener('load', update);
        update();

        track.__carousel = { update, move };
        return track.__carousel;
    }

    function initFeatured() {
        attach(
            document.getElementById('featuredCarousel'),
            document.getElementById('carouselPrev'),
            document.getElementById('carouselNext'),
            { itemSelector: '.product-card' }
        );
    }

    window.MonsiteCarousel = { attach };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initFeatured);
    else initFeatured();
})();
