// Menu Hamburguesa Mejorado
const menuToggle = document.getElementById('menuToggle');
const mobileNav = document.getElementById('mobileNav');
const mobileOverlay = document.getElementById('mobileOverlay');
const mobileClose = document.getElementById('mobileClose');

function normalizeNavText(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim();
}

// Con el menú nuevo (site-nav.js) el menú lateral lo arma ese script
const hasSiteNav = () => Boolean(document.querySelector('.header .nav .nav-mega'));

function ensureMobileNavPrimaryLinks() {
    if (!mobileNav || hasSiteNav()) {
        return;
    }

    const navHeader = mobileNav.querySelector('.mobile-nav-header');
    const navLinks = Array.from(mobileNav.querySelectorAll('.nav-link'));

    const findLink = (matcher) => navLinks.find((link) => matcher(normalizeNavText(link.textContent)));

    let inicioLink = findLink((text) => text === 'inicio');
    let productosLink = findLink((text) => text.includes('producto') || text.includes('catalogo'));
    let quienesLink = findLink((text) => text.includes('quienes somos') || text.includes('nosotros'));

    const createLink = (text, href) => {
        const link = document.createElement('a');
        link.className = 'nav-link';
        link.href = href;
        link.textContent = text;
        return link;
    };

    if (!inicioLink) {
        inicioLink = createLink('Inicio', 'index.html');
    }
    if (!productosLink) {
        productosLink = createLink('Productos', 'products.html');
    }
    if (!quienesLink) {
        quienesLink = createLink('Quienes somos', 'index.html#nosotros');
    }

    inicioLink.href = 'index.html';
    inicioLink.textContent = 'Inicio';
    productosLink.href = 'products.html';
    productosLink.textContent = 'Productos';
    quienesLink.href = 'index.html#nosotros';
    quienesLink.textContent = 'Quienes somos';

    if (navHeader) {
        navHeader.insertAdjacentElement('afterend', quienesLink);
        navHeader.insertAdjacentElement('afterend', productosLink);
        navHeader.insertAdjacentElement('afterend', inicioLink);
    } else {
        mobileNav.prepend(quienesLink);
        mobileNav.prepend(productosLink);
        mobileNav.prepend(inicioLink);
    }
}

function setupMobileCatalogMenu() {
    if (!mobileNav || hasSiteNav()) {
        return;
    }

    const desktopCatalogDropdown = document.querySelector('.nav-catalog .catalog-dropdown');
    const mobileCatalogTrigger = Array.from(mobileNav.querySelectorAll('.nav-link')).find((link) => {
        const text = (link.textContent || '').trim().toLowerCase();
        return text.includes('catálogo') || text.includes('catalogo');
    });

    if (!desktopCatalogDropdown || !mobileCatalogTrigger) {
        return;
    }

    if (mobileNav.querySelector('.mobile-catalog-submenu')) {
        return;
    }

    mobileCatalogTrigger.dataset.mobileCatalogToggle = 'true';
    mobileCatalogTrigger.setAttribute('aria-expanded', 'false');
    mobileCatalogTrigger.setAttribute('aria-haspopup', 'true');

    const submenu = document.createElement('div');
    submenu.className = 'mobile-catalog-submenu';

    const columns = desktopCatalogDropdown.querySelectorAll('.catalog-column');
    columns.forEach((column) => {
        const section = document.createElement('div');
        section.className = 'mobile-catalog-section';

        const title = column.querySelector('h4');
        if (title) {
            const heading = document.createElement('h4');
            heading.textContent = title.textContent || '';
            section.appendChild(heading);
        }

        const links = column.querySelectorAll('a[href]');
        links.forEach((sourceLink) => {
            const link = document.createElement('a');
            link.className = sourceLink.className || 'catalog-link';
            link.href = sourceLink.href;
            link.textContent = sourceLink.textContent || '';
            link.addEventListener('click', closeMenu);
            section.appendChild(link);
        });

        submenu.appendChild(section);
    });

    mobileCatalogTrigger.insertAdjacentElement('afterend', submenu);

    mobileCatalogTrigger.addEventListener('click', (event) => {
        event.preventDefault();
        const isOpen = submenu.classList.toggle('active');
        mobileCatalogTrigger.classList.toggle('active', isOpen);
        mobileCatalogTrigger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
}

function toggleMenu() {
    if (!menuToggle || !mobileNav || !mobileOverlay) {
        return;
    }

    menuToggle.classList.toggle('active');
    mobileNav.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    menuToggle.setAttribute('aria-expanded', mobileNav.classList.contains('active') ? 'true' : 'false');
    
    // Prevenir scroll cuando el menú está abierto
    document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
}

function closeMenu() {
    if (!menuToggle || !mobileNav || !mobileOverlay) {
        return;
    }

    menuToggle.classList.remove('active');
    mobileNav.classList.remove('active');
    mobileOverlay.classList.remove('active');
    menuToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
}

function setupLogoHomeNavigation() {
    if (window.location.pathname.includes('/admin/')) {
        return;
    }

    const goHome = () => {
        window.location.href = 'index.html';
    };

    document.querySelectorAll('.logo, .mobile-nav-logo').forEach((logo) => {
        if (logo.closest('a[href]')) {
            return;
        }

        logo.style.cursor = 'pointer';
        logo.setAttribute('tabindex', '0');
        logo.setAttribute('role', 'button');
        logo.setAttribute('aria-label', 'Ir al inicio');

        logo.addEventListener('click', goHome);
        logo.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                goHome();
            }
        });
    });
}

if (menuToggle && mobileNav && mobileOverlay && mobileClose) {
    ensureMobileNavPrimaryLinks();
    setupMobileCatalogMenu();

    menuToggle.addEventListener('click', toggleMenu);
    mobileOverlay.addEventListener('click', closeMenu);
    mobileClose.addEventListener('click', closeMenu);

    // Cerrar menú al hacer clic en un enlace
    const navLinks = document.querySelectorAll('.mobile-nav .nav-link');
    navLinks.forEach(link => {
        if (link.dataset.mobileCatalogToggle === 'true') {
            return;
        }

        link.addEventListener('click', closeMenu);
    });

    // Cerrar menú con tecla ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobileNav.classList.contains('active')) {
            closeMenu();
        }
    });
    
    console.log('✅ Menú hamburguesa mejorado configurado');
}

window.closeMobileMenu = closeMenu;
setupLogoHomeNavigation();

function isInternalNavigableLink(anchor) {
    if (!anchor) return false;
    if (anchor.hasAttribute('download')) return false;
    if (anchor.target && anchor.target.toLowerCase() === '_blank') return false;

    const href = anchor.getAttribute('href') || '';
    if (!href || href.startsWith('#')) return false;

    try {
        const targetUrl = new URL(anchor.href, window.location.href);
        const currentUrl = new URL(window.location.href);
        return targetUrl.origin === currentUrl.origin;
    } catch (_) {
        return false;
    }
}

function getClosestAnchorFromTarget(target) {
    if (!target || typeof target.closest !== 'function') {
        return null;
    }

    return target.closest('a[href]');
}

function setupSmoothPageNavigation() {
    if (document.body?.dataset.navTransitionReady === 'true') return;

    window.addEventListener('pageshow', () => {
        document.documentElement.classList.remove('is-page-leaving');
        document.body.classList.remove('is-page-leaving');
    });

    window.addEventListener('pagehide', () => {
        document.documentElement.classList.remove('is-page-leaving');
        document.body.classList.remove('is-page-leaving');
    });

    document.addEventListener('click', (event) => {
        const anchor = getClosestAnchorFromTarget(event.target);
        if (!isInternalNavigableLink(anchor)) return;

        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        const current = new URL(window.location.href);
        const next = new URL(anchor.href, window.location.href);
        if (current.href === next.href) return;

        closeMenu();
    });

    document.body.dataset.navTransitionReady = 'true';
}

setupSmoothPageNavigation();

function setupShippingBanner() {
if (document.body?.dataset.shippingBannerReady === 'true') return;

const shippingBanner = document.getElementById('shippingBanner');
const shippingBannerClose = document.getElementById('shippingBannerClose');
const header = document.querySelector('.header');

if (!header) return;

// Si la página NO tiene banner, el header debe pegarse al tope (top: 0)
// para que no quede un hueco ni corte el contenido de páginas sin banner.
if (!shippingBanner) {
    header.classList.add('banner-closed');
    document.body.classList.add('no-shipping-banner');
    document.body.dataset.shippingBannerReady = 'true';
    syncContentOffsetWithHeader(header, null);
    return;
}

buildShippingMarquee(shippingBanner);

if (shippingBannerClose) {
    shippingBannerClose.addEventListener('click', function () {
        shippingBanner.classList.add('hidden');
        header.classList.add('banner-closed');
        syncContentOffsetWithHeader(header, shippingBanner);
    });
}

// Posicionar el contenido según la altura real de banner + header desde el inicio,
// para que no haya salto visual al cargar la página.
syncContentOffsetWithHeader(header, shippingBanner);

document.body.dataset.shippingBannerReady = 'true';

}

// Mensajes de la cinta superior: se repiten en bucle continuo y sin cortes.
const SHIPPING_MESSAGES = [
    { icon: 'truck', text: 'Envío gratis en compras sobre $50.000' },
    { icon: 'bag', text: 'También nos encuentras en Mercado Libre' }
];
const SHIPPING_SPEED = 45; // píxeles por segundo

// Íconos de línea (heredan el color del texto)
const SHIPPING_ICONS = {
    truck: '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
    bag: '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>'
};

// Convierte el <p> del banner en una cinta: dos copias idénticas del grupo de
// mensajes que se desplazan juntas, así al llegar a la mitad vuelve al inicio sin salto.
function buildShippingMarquee(banner) {
    const track = banner.querySelector('p');
    if (!track) return;

    const makeGroup = (hidden) => {
        const group = document.createElement('span');
        group.className = 'shipping-group';
        if (hidden) group.setAttribute('aria-hidden', 'true');
        return group;
    };
    const fillGroup = (group, times) => {
        group.textContent = '';
        for (let i = 0; i < times; i += 1) {
            SHIPPING_MESSAGES.forEach(({ icon, text }) => {
                const item = document.createElement('span');
                item.className = 'shipping-item';
                if (SHIPPING_ICONS[icon]) {
                    item.insertAdjacentHTML('afterbegin', `<svg class="shipping-icon" viewBox="0 0 24 24" aria-hidden="true">${SHIPPING_ICONS[icon]}</svg>`);
                }
                item.append(text);
                group.appendChild(item);
            });
        }
    };

    const first = makeGroup(false);
    const second = makeGroup(true);
    track.textContent = '';
    track.append(first, second);
    track.classList.add('is-marquee');
    banner.setAttribute('aria-label', SHIPPING_MESSAGES.map((m) => m.text).join('. '));

    const layout = () => {
        // Cada grupo debe ser al menos tan ancho como la pantalla para que nunca quede un hueco
        let times = 1;
        fillGroup(first, times);
        while (first.scrollWidth < window.innerWidth && times < 12) {
            times += 1;
            fillGroup(first, times);
        }
        fillGroup(second, times);
        const seconds = Math.max(20, first.scrollWidth / SHIPPING_SPEED);
        track.style.setProperty('--shipping-duration', `${seconds.toFixed(1)}s`);
    };

    layout();
    let resizeTimer = null;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(layout, 200);
    }, { passive: true });
}

// Mide la altura real del header (y del banner si está visible) y expone
// --header-height con el total, para que el contenido de cada página quede
// justo debajo, sin cortarse ni saltar.
// Ejecuta la medición una sola vez por cuadro durante un redimensionado (sin forzar layout en cada evento)
function onResizeFrame(callback) {
    let frame = null;
    window.addEventListener('resize', () => {
        if (frame !== null) return;
        frame = requestAnimationFrame(() => {
            frame = null;
            callback();
        });
    }, { passive: true });
}

function syncContentOffsetWithHeader(header, shippingBanner) {
const applyOffset = () => {
    let total = Math.ceil(header.getBoundingClientRect().height);
    if (shippingBanner && !shippingBanner.classList.contains('hidden')) {
        total += Math.ceil(shippingBanner.getBoundingClientRect().height);
    }
    if (total > 0) {
        document.documentElement.style.setProperty('--header-height', `${total}px`);
    }
};
applyOffset();
onResizeFrame(applyOffset);
}

// La barra de búsqueda de products.html queda fija bajo el header (position: fixed);
// medimos su altura real para exponer --search-bar-height y correr el contenido
// siguiente (filtros/marcas/productos) justo debajo, sin que quede tapado.
function syncSearchBarOffset() {
const searchContainer = document.querySelector('.search-container');
if (!searchContainer) return;

const applyOffset = () => {
    const height = Math.ceil(searchContainer.getBoundingClientRect().height);
    if (height > 0) {
        document.documentElement.style.setProperty('--search-bar-height', `${height}px`);
    }
};
applyOffset();
onResizeFrame(applyOffset);
}

syncSearchBarOffset();

if (document.readyState === 'loading') {
document.addEventListener('DOMContentLoaded', setupShippingBanner);
} else {
setupShippingBanner();
}

