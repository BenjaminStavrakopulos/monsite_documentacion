// admin-products.js - Sistema de administración de productos
document.addEventListener('DOMContentLoaded', function() {
    initializeAdminProducts();
});

// Variables globales
window.productsData = [];
window.categories = [];
let currentImageData = '';
let adminProductsSearchIndex = [];
let productFilterDebounceTimer = null;
let visibleProductsLimit = 15;
let filteredProductsCache = [];
let productsScrollListenerReady = false;
const PRODUCT_FILTER_DEBOUNCE_MS = 180;
const PRODUCT_SKU_MAX_LENGTH = 30;
const PRODUCT_DESCRIPTION_MAX_LENGTH = 350;
const CUSTOM_CATEGORIES_STORAGE_KEY = 'hairia_custom_categories';
const CUSTOM_BRANDS_STORAGE_KEY = 'hairia_custom_brands';
const SKU_COUNTER_STORAGE_KEY = 'hairia_sku_counter';
const SAMPLE_PRODUCTS_PURGE_KEY = 'hairia_sample_products_purged_v1';
const LEGACY_SAMPLE_PRODUCT_NAMES = new Set([
    'Shampoo Kerastase Premium',
    'Acondicionador Intenso',
    'Mascarilla Reparadora',
    'Shampoo Reparador Intenso',
    'Acondicionador Hidratante'
]);

const FIXED_CATEGORIES = Object.freeze([
    { id: 'shampoo', name: 'Shampoo', color: '#1a1a1a', description: 'Limpieza y cuidado diario del cabello' },
    { id: 'acondicionador', name: 'Acondicionador', color: '#2d2d2d', description: 'Hidratación y suavidad para el cabello' },
    { id: 'tratamiento', name: 'Tratamiento capilar', color: '#404040', description: 'Reparación y nutrición intensiva' },
    { id: 'peinado', name: 'Peinado', color: '#555555', description: 'Definición y fijación del peinado' },
    { id: 'mascarilla', name: 'Mascarilla capilar', color: '#6b7280', description: 'Hidratación profunda semanal' },
    { id: 'serum', name: 'Sérum capilar', color: '#4b5563', description: 'Brillo y protección para puntas' },
    { id: 'proteccion-termica', name: 'Protección térmica', color: '#374151', description: 'Protección frente al calor de secador o plancha' },
    { id: 'aceite', name: 'Aceite capilar', color: '#1f2937', description: 'Nutrición y control del frizz' },
    { id: 'otros', name: 'Otros', color: '#111827', description: 'Productos adicionales de cuidado capilar' }
]);

const FIXED_BRANDS = Object.freeze([
    { id: 'olaplex', name: 'Olaplex', logo: 'images/olaplex.jpg', searchTerms: ['olaplex'] },
    { id: 'kerastase', name: 'Kérastase', logo: 'images/kerastase.jpg', searchTerms: ['kerastase', 'kérastase'] },
    { id: 'tigi', name: 'Tigi', logo: 'images/tigi.jpg', searchTerms: ['tigi'] },
    { id: 'k18', name: 'K18', logo: 'images/k18.jpg', searchTerms: ['k18'] },
    { id: 'living-proof', name: 'Living Proof', logo: 'images/livingprof.jpg', searchTerms: ['living proof', 'livingproof', 'living prof'] },
    { id: 'revlon', name: 'Revlon', logo: 'images/revlon.jpg', searchTerms: ['revlon'] },
    { id: 'moroccanoil', name: 'Moroccanoil', logo: 'images/Moroccanoil.jpg', searchTerms: ['moroccanoil', 'moroccan oil'] },
    { id: 'dabalash', name: 'Dabalash', logo: 'images/Dabalash.jpg', searchTerms: ['dabalash'] }
]);

function getFixedCategories() {
    return FIXED_CATEGORIES.map(category => ({ ...category }));
}

function escapeRegex(text) {
    return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function normalizeCategoryIdFromName(name) {
    return String(name || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}

function loadCustomCategories() {
    try {
        const stored = JSON.parse(localStorage.getItem(CUSTOM_CATEGORIES_STORAGE_KEY) || '[]');
        if (!Array.isArray(stored)) return [];
        return stored
            .filter(item => item && typeof item.id === 'string' && typeof item.name === 'string')
            .map(item => ({
                id: item.id,
                name: item.name,
                color: item.color || '#111827',
                description: item.description || ''
            }));
    } catch (error) {
        console.warn('⚠️ No se pudieron cargar categorías personalizadas:', error);
        return [];
    }
}

function saveCustomCategories(customCategories) {
    localStorage.setItem(CUSTOM_CATEGORIES_STORAGE_KEY, JSON.stringify(customCategories));
}

function getFixedCategoryIds() {
    return new Set(getFixedCategories().map(category => category.id));
}

function getMergedCategories(remoteCategories = null) {
    const fixed = getFixedCategories();
    const fixedIds = new Set(fixed.map(category => category.id));
    const source = Array.isArray(remoteCategories) ? remoteCategories : loadCustomCategories();
    const remoteById = new Map(source.filter(Boolean).map(category => [category.id, category]));

    // Las categorías base pueden ser editadas (nombre/color) desde el panel de gestión;
    // si existe una versión guardada en Firestore, esa sobreescribe los valores por defecto.
    const merged = fixed.map(category => ({ ...category, ...(remoteById.get(category.id) || {}) }));
    const customCategories = source.filter(category => category && !fixedIds.has(category.id));
    merged.push(...customCategories);
    return merged;
}

function getFixedBrands() {
    return FIXED_BRANDS.map(brand => ({ ...brand }));
}

function normalizeBrandIdFromName(name) {
    return String(name || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}

function loadCustomBrands() {
    try {
        const stored = JSON.parse(localStorage.getItem(CUSTOM_BRANDS_STORAGE_KEY) || '[]');
        if (!Array.isArray(stored)) return [];
        return stored
            .filter(item => item && typeof item.id === 'string' && typeof item.name === 'string')
            .map(item => ({
                id: item.id,
                name: item.name,
                logo: item.logo || '',
                searchTerms: Array.isArray(item.searchTerms) && item.searchTerms.length > 0
                    ? item.searchTerms
                    : [item.id],
                isCustom: true
            }));
    } catch (error) {
        console.warn('⚠️ No se pudieron cargar marcas personalizadas:', error);
        return [];
    }
}

function saveCustomBrands(customBrands) {
    try {
        localStorage.setItem(CUSTOM_BRANDS_STORAGE_KEY, JSON.stringify(customBrands));
        return true;
    } catch (error) {
        console.error('❌ No se pudieron guardar marcas personalizadas:', error);
        showNotification('❌ No se pudo guardar la marca. El logo es muy pesado, usa una imagen más liviana.');
        return false;
    }
}

function getMergedBrands(remoteBrands = null) {
    const fixed = getFixedBrands();
    const fixedIds = new Set(fixed.map(brand => brand.id));
    const source = Array.isArray(remoteBrands) ? remoteBrands : loadCustomBrands();
    const remoteById = new Map(source.filter(Boolean).map(brand => [brand.id, brand]));

    // Las marcas base pueden ser editadas (nombre/logo) desde el panel de gestión;
    // si existe una versión guardada en Firestore, esa sobreescribe los valores por defecto.
    const merged = fixed.map(brand => ({ ...brand, ...(remoteById.get(brand.id) || {}) }));
    const customBrands = source.filter(brand => brand && !fixedIds.has(brand.id));
    merged.push(...customBrands);
    return merged;
}

function getFixedBrandIds() {
    return new Set(getFixedBrands().map(brand => brand.id));
}

function rebuildAdminProductsSearchIndex() {
    adminProductsSearchIndex = (window.productsData || []).map(product => ({
        id: String(product.id),
        category: product.category,
        text: `${product.name || ''} ${product.sku || ''} ${product.description || ''} ${product.brand || ''}`.toLowerCase()
    }));
}

function escapeHtml(value) {
    const text = value == null ? '' : String(value);
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
}

function sanitizeImageUrl(value) {
    if (typeof value !== 'string') return '';
    const trimmed = value.trim();
    if (!trimmed) return '';
    if (/^https?:\/\//i.test(trimmed) || /^data:image\//i.test(trimmed)) {
        // Comillas y <> no son válidas en una URL: se codifican para que no puedan salir del atributo src="..."
        return trimmed.replace(/"/g, '%22').replace(/'/g, '%27').replace(/</g, '%3C').replace(/>/g, '%3E').replace(/`/g, '%60');
    }
    return '';
}

// Las marcas base del sistema (FIXED_BRANDS) guardan su logo como ruta relativa
// (ej: "images/olaplex.jpg") pensada para la raíz del sitio. Desde /admin/ hay que
// subir un nivel para que la imagen realmente cargue.
function resolveManagedBrandLogoUrl(value) {
    if (typeof value !== 'string') return '';
    const trimmed = value.trim();
    if (!trimmed) return '';
    if (/^https?:\/\//i.test(trimmed) || /^data:image\//i.test(trimmed)) {
        // Se usa dentro de src="..." en innerHTML: las comillas y <> no pueden cerrar el atributo
        return trimmed.replace(/["'<>`]/g, char => encodeURIComponent(char));
    }
    if (/^[a-z0-9_\-./]+\.(jpe?g|png|webp|gif|svg)$/i.test(trimmed) && !trimmed.startsWith('//')) {
        return `../${trimmed}`;
    }
    return '';
}

function normalizeProductId(value) {
    return String(value ?? '').trim();
}

function truncateText(value, maxLength) {
    const text = value == null ? '' : String(value);
    if (text.length <= maxLength) {
        return text;
    }
    return `${text.slice(0, maxLength)}…`;
}

function buildHyphenatedNameHtml(name, chunkSize = 12) {
    const rawText = name == null ? '' : String(name);
    const tokens = rawText.split(/(\s+)/);

    return tokens.map((token) => {
        if (/^\s+$/.test(token) || token.length <= chunkSize) {
            return escapeHtml(token);
        }

        const parts = [];
        let cursor = 0;
        while (cursor < token.length) {
            parts.push(token.slice(cursor, cursor + chunkSize));
            cursor += chunkSize;
        }

        return parts.map(escapeHtml).join('&shy;');
    }).join('');
}

function computeMaxSkuSequence(products) {
    return (products || []).reduce((maxValue, product) => {
        const sku = String(product?.sku || '');
        const match = sku.match(/(\d+)$/);
        if (!match) {
            return maxValue;
        }

        const sequence = Number.parseInt(match[1], 10);
        return Number.isFinite(sequence) ? Math.max(maxValue, sequence) : maxValue;
    }, 0);
}

function generateNextSku() {
    const maxFromProducts = computeMaxSkuSequence(window.productsData || []);
    const storedCounter = Number.parseInt(localStorage.getItem(SKU_COUNTER_STORAGE_KEY) || '0', 10);
    const nextSequence = Math.max(Number.isFinite(storedCounter) ? storedCounter : 0, maxFromProducts) + 1;

    localStorage.setItem(SKU_COUNTER_STORAGE_KEY, String(nextSequence));
    return `PRD-${String(nextSequence).padStart(5, '0')}`;
}

async function persistProductCreate(newProductData) {
    if (!window.firebaseData?.saveProduct) {
        return {
            id: String(Date.now()),
            ...newProductData,
            createdAt: new Date().toISOString()
        };
    }

    const savedProduct = await window.firebaseData.saveProduct(newProductData);
    return {
        ...newProductData,
        ...(savedProduct || {}),
        id: savedProduct?.id || String(savedProduct?.id || ''),
        createdAt: savedProduct?.createdAt || newProductData.createdAt || new Date().toISOString()
    };
}

async function persistProductUpdate(productId, updatedProductData) {
    if (!window.firebaseData?.saveProduct) {
        return true;
    }

    await window.firebaseData.saveProduct({
        ...updatedProductData,
        id: productId
    });

    return true;
}

function renderProductRow(product) {
    const productId = String(product.id ?? '');
    const fullName = String(product.name || '');
    const safeNameHtml = buildHyphenatedNameHtml(fullName);
    const safeFullName = escapeAttr(fullName);
    const safeSku = escapeHtml(truncateText(product.sku || 'N/A', 14));
    const safeCategoryName = escapeHtml(getCategoryName(product.category) || '');
    const safeImage = sanitizeImageUrl(product.image);
    const stock = Number(product.stock) || 0;

    return `
        <tr>
            <td>
                <div class="product-image-small">
                    ${safeImage ?
                        `<img src="${safeImage}" alt="${escapeAttr(fullName)}" loading="lazy" decoding="async">` :
                        '<div class="no-image">📷</div>'
                    }
                </div>
            </td>
            <td>
                <strong class="product-cell-title" title="${safeFullName}">${safeNameHtml}</strong>
                ${product.featured ? '<span class="featured-indicator">⭐</span>' : ''}
            </td>
            <td>${safeSku}</td>
            <td>
                ${product.discountType !== 'none' ?
                    `<div class="price-with-discount">
                        <span class="original-price">${formatCLP(product.price)}</span>
                        <span class="discount-badge">${escapeHtml(getDiscountText(product))}</span>
                        <strong class="discounted-price">${formatCLP(getDiscountedPrice(product))}</strong>
                    </div>` :
                    `<strong>${formatCLP(product.price)}</strong>`
                }
            </td>
            <td>
                <span class="category-tag" title="${escapeAttr(getCategoryName(product.category) || '')}">${safeCategoryName}</span>
            </td>
            <td>
                <div class="stock-info">
                    <span>${stock}</span>
                    <span class="status-badge ${getStockStatus(stock, product.minStock)}">
                        ${getStockText(stock, product.minStock)}
                    </span>
                </div>
            </td>
            <td>
                <span class="status-badge ${product.active !== false ? 'status-active' : 'status-inactive'}">
                    ${product.active !== false ? 'Activo' : 'Inactivo'}
                </span>
            </td>
            <td>
                <div class="table-actions">
                    <button class="table-actions-btn" data-action="edit" data-product-id="${escapeAttr(productId)}" title="Editar" aria-label="Editar producto">&#9998;</button>
                    <button class="table-actions-btn" data-action="toggle" data-product-id="${escapeAttr(productId)}" title="${product.active !== false ? 'Desactivar' : 'Activar'}">
                        ${product.active !== false ? '&#128065;' : '&#128683;'}
                    </button>
                    <button class="table-actions-btn delete-btn" data-action="delete" data-product-id="${escapeAttr(productId)}" title="Eliminar" aria-label="Eliminar producto">&#128465;</button>
                </div>
            </td>
        </tr>
    `;
}

async function initializeAdminProducts() {
    const hasAccess = await checkAdminAuth();
    if (!hasAccess) {
        return;
    }

    // CARGAR DATOS DE FORMA ASÍNCRONA
    loadGlobalData().then(() => {
        rebuildAdminProductsSearchIndex();
        loadProductsTable();
        loadCategoriesDropdown();
        loadBrandsDropdown();
        updateStats();
        setupEventListeners();
        setupProductsProgressiveLoading();
        setupDiscountCalculations();
        setupModalClose();
        setupImageOptimizationButton();
    }).catch(error => {
        console.error('❌ Error en inicialización:', error);
    });
}

// FUNCIÓN MEJORADA: Cargar datos globales desde Firebase
async function loadGlobalData() {
    console.log('📥 Cargando datos desde Firebase...');

    try {
        const [products, categories, brands] = await Promise.all([
            window.firebaseData?.loadProducts?.() || Promise.resolve([]),
            window.firebaseData?.loadCategories?.() || Promise.resolve([]),
            window.firebaseData?.loadBrands?.() || Promise.resolve([])
        ]);
        window.productsData = products;
        window.categories = getMergedCategories(categories);
        window.brandsData = getMergedBrands(brands);

        scheduleLegacySampleCleanup();

        console.log('✅ Datos cargados:', {
            productos: window.productsData.length,
            categorias: window.categories.length
        });

    } catch (error) {
        console.error('❌ Error cargando datos:', error);

        window.productsData = [];
        window.categories = getFixedCategories();
        window.brandsData = getFixedBrands();
    }
}

function scheduleLegacySampleCleanup() {
    if (localStorage.getItem(SAMPLE_PRODUCTS_PURGE_KEY) === 'true') return;
    const runCleanup = () => purgeLegacySampleProducts().catch(error => {
        console.warn('No se pudo completar la limpieza de productos antiguos');
    });
    if ('requestIdleCallback' in window) {
        window.requestIdleCallback(runCleanup, { timeout: 2500 });
    } else {
        setTimeout(runCleanup, 800);
    }
}

async function purgeLegacySampleProducts() {
    const wasPurged = localStorage.getItem(SAMPLE_PRODUCTS_PURGE_KEY) === 'true';
    if (wasPurged) {
        return;
    }

    const products = Array.isArray(window.productsData) ? window.productsData : [];
    const sampleProducts = products.filter(product => LEGACY_SAMPLE_PRODUCT_NAMES.has(String(product?.name || '').trim()));

    if (!sampleProducts.length) {
        localStorage.setItem(SAMPLE_PRODUCTS_PURGE_KEY, 'true');
        return;
    }

    if (window.firebaseData?.deleteProduct) {
        for (const sampleProduct of sampleProducts) {
            try {
                await window.firebaseData.deleteProduct(sampleProduct.id);
            } catch (error) {
                console.warn('⚠️ No se pudo eliminar producto de muestra en Firebase:', sampleProduct?.name, error);
            }
        }
    }

    window.productsData = products.filter(product => !LEGACY_SAMPLE_PRODUCT_NAMES.has(String(product?.name || '').trim()));
    saveProducts();
    localStorage.setItem(SAMPLE_PRODUCTS_PURGE_KEY, 'true');
}

function initializeSampleProducts() {
    window.productsData = [
        {
            id: 1,
            name: "Shampoo Reparador Intenso",
            price: 19990,
            category: "shampoo",
            brand: "kerastase",
            featured: true,
            description: "Shampoo con keratina para cabello dañado y quebradizo",
            image: "",
            stock: 50,
            sku: "SHR-001",
            active: true,
            discountType: "none",
            discountPercent: null,
            discountAmount: null,
            createdAt: new Date().toISOString()
        },
        {
            id: 2,
            name: "Acondicionador Hidratante",
            price: 14990,
            category: "acondicionador",
            brand: "olaplex",
            featured: false,
            description: "Acondicionador profundo con aceite de argán",
            image: "",
            stock: 45,
            sku: "ACH-001",
            active: true,
            discountType: "none",
            discountPercent: null,
            discountAmount: null,
            createdAt: new Date().toISOString()
        }
    ];
    saveProducts();
}

async function checkAdminAuth() {
    const userLS = JSON.parse(localStorage.getItem('hairia_current_user') || 'null');
    const userSS = JSON.parse(sessionStorage.getItem('hairia_current_user') || 'null');
    const user = userLS || userSS;

    if (!user || !user.uid) {
        console.log('⚠️ No hay usuario, redirigiendo a login...');
        window.location.href = '../login.html';
        return false;
    }

    if (!window.firebase || typeof window.firebase.isUserAdmin !== 'function') {
        console.error('❌ Verificación admin no disponible');
        showNotification('No se pudo verificar permisos de administrador', 'error');
        window.location.href = '../login.html';
        return false;
    }

    try {
        const isAdmin = await window.firebase.isUserAdmin(user.uid);
        if (!isAdmin) {
            console.log('❌ Usuario no es admin, redirigiendo a inicio...');
            showNotification('Acceso denegado: solo administradores pueden acceder', 'error');
            setTimeout(() => {
                window.location.href = '../index.html';
            }, 1200);
            return false;
        }

        if (user.role !== 'admin') {
            user.role = 'admin';
            if (userLS) {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
                localStorage.removeItem('hairia_current_user');
            } else {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
            }
        }

        console.log('✅ Usuario admin verificado en Firebase');
        return true;
    } catch (error) {
        console.warn('⚠️ No se pudo verificar admin en Firebase:', error);
        showNotification('Error verificando permisos de administrador', 'error');
        window.location.href = '../login.html';
        return false;
    }
}

// FUNCIÓN MEJORADA: Cargar tabla de productos
function loadProductsTable() {
    const tableBody = document.getElementById('productsTableBody');
    if (!tableBody) return;

    const products = window.productsData || [];
    filteredProductsCache = products;
    visibleProductsLimit = 15;

    if (products.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="8" class="no-products">
                    <p>No hay productos registrados</p>
                    <button class="btn-primary" data-action="create-first">Crear Primer Producto</button>
                </td>
            </tr>
        `;
        return;
    }

    renderVisibleProducts(tableBody);
}

function renderVisibleProducts(tableBody = document.getElementById('productsTableBody')) {
    if (!tableBody) return;
    const visibleProducts = filteredProductsCache.slice(0, visibleProductsLimit);
    tableBody.innerHTML = visibleProducts.map(renderProductRow).join('');
    if (visibleProducts.length < filteredProductsCache.length) {
        tableBody.insertAdjacentHTML('beforeend', `<tr class="products-load-more-row"><td colspan="8">Desplázate para cargar más productos (${visibleProducts.length}/${filteredProductsCache.length})</td></tr>`);
    }
}

function loadMoreProductsIfNeeded() {
    if (visibleProductsLimit >= filteredProductsCache.length) return;
    if (document.documentElement.scrollHeight - (window.innerHeight + window.scrollY) > 500) return;
    visibleProductsLimit += 15;
    renderVisibleProducts();
}

function setupProductsProgressiveLoading() {
    if (productsScrollListenerReady) return;
    window.addEventListener('scroll', loadMoreProductsIfNeeded, { passive: true });
    productsScrollListenerReady = true;
}

// FUNCIONES AUXILIARES PARA PRECIOS
function getDiscountedPrice(product) {
    if (product.discountType === 'percentage' && product.discountPercent) {
        return product.price - (product.price * product.discountPercent / 100);
    } else if (product.discountType === 'amount' && product.discountAmount) {
        return product.price - product.discountAmount;
    }
    return product.price;
}

function getDiscountText(product) {
    if (product.discountType === 'percentage' && product.discountPercent) {
        return `-${product.discountPercent}%`;
    } else if (product.discountType === 'amount' && product.discountAmount) {
        return `-${formatCLP(product.discountAmount)}`;
    }
    return '';
}

function getCategoryName(categoryId) {
    const category = window.categories.find(cat => cat.id === categoryId);
    return category ? category.name : categoryId;
}

function getStockStatus(stock, minStock = 5) {
    if (stock === 0) return 'status-out-of-stock';
    if (stock <= minStock) return 'status-low-stock';
    return 'status-active';
}

function getStockText(stock, minStock = 5) {
    if (stock === 0) return 'Sin Stock';
    if (stock <= minStock) return 'Stock Bajo';
    return 'En Stock';
}

function loadCategoriesDropdown() {
    const categorySelect = document.getElementById('productCategory');
    const categoryFilter = document.getElementById('categoryFilter');

    if (categorySelect) {
        categorySelect.innerHTML = `
            <option value="">Seleccionar categoría</option>
            ${window.categories.map(category => `
                <option value="${escapeAttr(category.id)}">${escapeHtml(category.name)}</option>
            `).join('')}
            <option value="__new__">Otros (crear nueva categoría)</option>
        `;
        console.log('✅ Dropdown de categorías cargado:', window.categories.length, 'categorías');
    }

    if (categoryFilter) {
        categoryFilter.innerHTML = `
            <option value="">Todas las categorías</option>
            ${window.categories.map(category => `
                <option value="${escapeAttr(category.id)}">${escapeHtml(category.name)}</option>
            `).join('')}
        `;

        categoryFilter.addEventListener('change', filterProductsTable);
    }
}

function loadCustomCategoryDeleteDropdown() {
    const deleteSelect = document.getElementById('customCategoryDeleteSelect');
    if (!deleteSelect) return;

    const fixedIds = getFixedCategoryIds();
    const customCategories = (window.categories || []).filter(category => !fixedIds.has(category.id));

    deleteSelect.innerHTML = `
        <option value="">Seleccionar categoría personalizada</option>
        ${customCategories.map(category => `
            <option value="${escapeAttr(category.id)}">${escapeHtml(category.name)}</option>
        `).join('')}
    `;
}

function loadCategoryManagerOptions(selectedId = '') {
    const select = document.getElementById('categoryManagerSelect');
    if (!select) return;
    select.innerHTML = `<option value="__new__">Nueva categoría</option>${(window.categories || []).map(category => `<option value="${escapeAttr(category.id)}">${escapeHtml(category.name)}</option>`).join('')}`;
    select.value = selectedId && (window.categories || []).some(category => category.id === selectedId) ? selectedId : '__new__';
    syncCategoryManagerFields();
}

function syncCategoryManagerFields() {
    const select = document.getElementById('categoryManagerSelect');
    const input = document.getElementById('newCategoryName');
    const colorInput = document.getElementById('newCategoryColor');
    const hint = document.getElementById('categoryManagerHint');
    if (!select || !input) return;
    if (select.value === '__new__') {
        input.value = '';
        input.placeholder = 'Ej: Ampollas capilares';
        if (colorInput) colorInput.value = '#1a1a1a';
        if (hint) hint.textContent = '';
        return;
    }
    const category = (window.categories || []).find(item => item.id === select.value);
    input.value = category?.name || '';
    input.placeholder = 'Nombre de la categoría';
    if (colorInput) colorInput.value = category?.color || '#1a1a1a';
    if (hint) {
        hint.textContent = getFixedCategoryIds().has(select.value)
            ? 'Categoría base del sistema: puedes cambiar su nombre y color, pero no eliminarla.'
            : '';
    }
}

function showCategoryManagerModal() {
    const modal = document.getElementById('categoryManagerModal');
    if (!modal) return;

    loadCategoryManagerOptions(document.getElementById('productCategory')?.value || '');
    loadCustomCategoryDeleteDropdown();
    modal.classList.add('active');

    const input = document.getElementById('newCategoryName');
    if (input) setTimeout(() => input.focus(), 0);
}

function hideCategoryManagerModal() {
    const modal = document.getElementById('categoryManagerModal');
    if (!modal) return;
    modal.classList.remove('active');

    const productCategory = document.getElementById('productCategory');
    if (productCategory && productCategory.value === '__new__') {
        productCategory.value = '';
    }
}

async function saveCategoryManagerSelection() {
    const input = document.getElementById('newCategoryName');
    const colorInput = document.getElementById('newCategoryColor');
    const categorySelect = document.getElementById('productCategory');
    if (!input || !categorySelect) return;

    const categoryName = (input.value || '').trim();
    const categoryColor = colorInput?.value || '#1a1a1a';
    if (!categoryName) {
        showNotification('❌ Debes escribir un nombre de categoría');
        return;
    }

    if (categoryName.length < 3) {
        showNotification('❌ El nombre de la categoría debe tener al menos 3 caracteres');
        return;
    }

    const managerId = document.getElementById('categoryManagerSelect')?.value || '__new__';
    if (managerId !== '__new__') {
        const existingCategory = (window.categories || []).find(category => category.id === managerId);
        await window.firebaseData.saveCategory({ ...existingCategory, id: managerId, name: categoryName, color: categoryColor });
        window.categories = getMergedCategories(await window.firebaseData.loadCategories());
        loadCategoriesDropdown();
        loadCategoryManagerOptions(managerId);
        document.getElementById('productCategory').value = managerId;
        showNotification('✅ Categoría actualizada');
        return;
    }

    const existingByName = (window.categories || []).find(category => {
        const pattern = new RegExp(`^${escapeRegex(categoryName)}$`, 'i');
        return pattern.test(category.name || '');
    });

    if (existingByName) {
        categorySelect.value = existingByName.id;
        hideCategoryManagerModal();
        showNotification('✅ Esa categoría ya existe y fue seleccionada');
        return;
    }

    let nextId = normalizeCategoryIdFromName(categoryName);
    if (!nextId) {
        showNotification('❌ El nombre ingresado no es válido');
        return;
    }

    const existingIds = new Set((window.categories || []).map(category => category.id));
    let suffix = 2;
    const baseId = nextId;
    while (existingIds.has(nextId)) {
        nextId = `${baseId}-${suffix}`;
        suffix += 1;
    }

    const newCategory = {
        id: nextId,
        name: categoryName,
        color: categoryColor,
        description: 'Categoría personalizada'
    };

    if (!window.firebaseData?.saveCategory) {
        showNotification('❌ Firebase no está disponible para guardar la categoría');
        return;
    }

    await window.firebaseData.saveCategory(newCategory);

    window.categories = getMergedCategories(await window.firebaseData.loadCategories());
    loadCategoriesDropdown();
    loadCustomCategoryDeleteDropdown();
    categorySelect.value = newCategory.id;
    hideCategoryManagerModal();
    showNotification('✅ Categoría agregada correctamente');
}

async function deleteCustomCategorySelected() {
    const deleteSelect = document.getElementById('customCategoryDeleteSelect');
    const categorySelect = document.getElementById('productCategory');
    if (!deleteSelect) return;

    const categoryId = (deleteSelect.value || '').trim();
    if (!categoryId) {
        showNotification('❌ Debes seleccionar una categoría personalizada para eliminar');
        return;
    }

    const fixedIds = getFixedCategoryIds();
    if (fixedIds.has(categoryId)) {
        showNotification('❌ No se puede eliminar una categoría base del sistema');
        return;
    }

    const categoryInUse = (window.productsData || []).some(product => product.category === categoryId);
    if (categoryInUse) {
        showNotification('❌ No se puede eliminar: hay productos usando esta categoría');
        return;
    }

    if (!window.firebaseData?.deleteCategory) {
        showNotification('❌ Firebase no está disponible para eliminar la categoría');
        return;
    }

    await window.firebaseData.deleteCategory(categoryId);
    window.categories = getMergedCategories(await window.firebaseData.loadCategories());
    loadCategoriesDropdown();
    loadCustomCategoryDeleteDropdown();

    if (categorySelect && categorySelect.value === categoryId) {
        categorySelect.value = '';
    }

    deleteSelect.value = '';
    showNotification('✅ Categoría personalizada eliminada correctamente');
}

function loadBrandsDropdown() {
    const brandSelect = document.getElementById('productBrand');
    if (!brandSelect) {
        return;
    }

    brandSelect.innerHTML = `
        <option value="">Seleccionar marca</option>
        ${(window.brandsData || []).map(brand => `
            <option value="${escapeAttr(brand.id)}">${escapeHtml(brand.name)}</option>
        `).join('')}
        <option value="__new_brand__">Otros (agregar nueva marca)</option>
    `;

    console.log('✅ Dropdown de marcas cargado:', (window.brandsData || []).length, 'marcas');
}

function loadCustomBrandDeleteDropdown() {
    const deleteSelect = document.getElementById('customBrandDeleteSelect');
    if (!deleteSelect) return;

    const fixedBrandIds = getFixedBrandIds();
    const customBrands = (window.brandsData || []).filter(brand => !fixedBrandIds.has(brand.id));

    deleteSelect.innerHTML = `
        <option value="">Seleccionar marca personalizada</option>
        ${customBrands.map(brand => `
            <option value="${escapeAttr(brand.id)}">${escapeHtml(brand.name)}</option>
        `).join('')}
    `;
}

function showBrandManagerModal() {
    const modal = document.getElementById('brandManagerModal');
    if (!modal) return;

    const logoInput = document.getElementById('newBrandLogo');
    const brandManagerSelect = document.getElementById('brandManagerSelect');
    if (brandManagerSelect) {
        brandManagerSelect.innerHTML = `<option value="__new_brand__">Nueva marca</option>${(window.brandsData || []).map(brand => `<option value="${escapeAttr(brand.id)}">${escapeHtml(brand.name)}</option>`).join('')}`;
        brandManagerSelect.value = document.getElementById('productBrand')?.value || '__new_brand__';
    }

    if (logoInput) logoInput.value = '';
    modal.dataset.logoData = '';
    syncBrandManagerFields();
    loadCustomBrandDeleteDropdown();
    modal.classList.add('active');

    const brandNameInput = document.getElementById('newBrandName');
    if (brandNameInput) {
        setTimeout(() => brandNameInput.focus(), 0);
    }
}

function syncBrandManagerFields() {
    const id = document.getElementById('brandManagerSelect')?.value;
    const brand = (window.brandsData || []).find(item => item.id === id);
    const input = document.getElementById('newBrandName');
    const preview = document.getElementById('newBrandLogoPreview');
    const hint = document.getElementById('brandManagerHint');
    if (input) input.value = brand?.name || '';
    if (preview) {
        preview.innerHTML = brand?.logo ? `<img src="${resolveManagedBrandLogoUrl(brand.logo)}" alt="Logo de marca">` : '<span>Haz clic para subir el logo</span>';
        preview.classList.toggle('has-image', Boolean(brand?.logo));
    }
    if (hint) {
        hint.textContent = id && getFixedBrandIds().has(id)
            ? 'Marca base del sistema: puedes cambiar su nombre y logo, pero no eliminarla.'
            : '';
    }
}

function hideBrandManagerModal() {
    const modal = document.getElementById('brandManagerModal');
    if (!modal) return;
    modal.classList.remove('active');

    const productBrand = document.getElementById('productBrand');
    if (productBrand && productBrand.value === '__new_brand__') {
        productBrand.value = '';
    }
}

function setupBrandLogoUpload() {
    const logoInput = document.getElementById('newBrandLogo');
    const logoPreview = document.getElementById('newBrandLogoPreview');
    const modal = document.getElementById('brandManagerModal');

    if (!logoInput || !logoPreview || !modal || logoInput.dataset.listener === 'true') {
        return;
    }

    logoPreview.addEventListener('click', function() {
        logoInput.click();
    });

    logoPreview.addEventListener('keydown', function(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            logoInput.click();
        }
    });

    logoInput.addEventListener('change', function(event) {
        const file = event.target.files?.[0];
        if (!file) return;

        const maxLogoBytes = 700 * 1024;
        if (file.size > maxLogoBytes) {
            logoInput.value = '';
            modal.dataset.logoData = '';
            logoPreview.innerHTML = '<span>🖼️ Haz clic para subir el logo</span>';
            logoPreview.classList.remove('has-image');
            showNotification('❌ El logo es muy pesado. Usa una imagen menor a 700 KB.');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            const imageData = typeof e.target?.result === 'string' ? e.target.result : '';
            if (!imageData) return;

            modal.dataset.logoData = imageData;
            const safeLogo = sanitizeImageUrl(imageData);
            logoPreview.innerHTML = safeLogo
                ? `<img src="${safeLogo}" alt="Logo marca">`
                : '<span>🖼️ Haz clic para subir el logo</span>';
            logoPreview.classList.add('has-image');
        };
        reader.readAsDataURL(file);
    });

    logoInput.dataset.listener = 'true';
}

async function saveCustomBrandFromModal() {
    const modal = document.getElementById('brandManagerModal');
    const brandSelect = document.getElementById('productBrand');
    const brandNameInput = document.getElementById('newBrandName');
    if (!modal || !brandSelect || !brandNameInput) return;

    const brandName = (brandNameInput.value || '').trim();
    const brandLogo = modal.dataset.logoData || '';
    const selectedBrandId = document.getElementById('brandManagerSelect')?.value || '__new_brand__';
    if (!brandName) {
        showNotification('❌ Debes ingresar el nombre de la marca');
        return;
    }

    if (brandName.length < 2) {
        showNotification('❌ El nombre de la marca debe tener al menos 2 caracteres');
        return;
    }

    if (selectedBrandId === '__new_brand__' && !brandLogo) {
        showNotification('❌ Debes subir el logo de la marca');
        return;
    }

    const saveBtn = document.getElementById('saveNewBrandBtn');
    if (saveBtn) saveBtn.disabled = true;

    try {
        if (selectedBrandId !== '__new_brand__') {
            const existingBrand = (window.brandsData || []).find(brand => brand.id === selectedBrandId);
            let storedLogo = brandLogo || existingBrand?.logo || '';
            if (brandLogo && window.firebase?.uploadBrandLogo) storedLogo = await window.firebase.uploadBrandLogo(brandLogo, selectedBrandId);
            await window.firebaseData.saveBrand({ ...existingBrand, id: selectedBrandId, name: brandName, logo: storedLogo, active: true });
            window.brandsData = getMergedBrands(await window.firebaseData.loadBrands());
            loadBrandsDropdown();
            document.getElementById('productBrand').value = selectedBrandId;
            hideBrandManagerModal();
            showNotification('✅ Marca actualizada');
            return;
        }

        const existingByName = (window.brandsData || []).find(brand => {
            const pattern = new RegExp(`^${escapeRegex(brandName)}$`, 'i');
            return pattern.test(brand.name || '');
        });

        if (existingByName) {
            brandSelect.value = existingByName.id;
            hideBrandManagerModal();
            showNotification('✅ Esa marca ya existe y fue seleccionada');
            return;
        }

        let newBrandId = normalizeBrandIdFromName(brandName);
        if (!newBrandId) {
            showNotification('❌ El nombre de marca no es válido');
            return;
        }

        const existingIds = new Set((window.brandsData || []).map(brand => brand.id));
        const baseId = newBrandId;
        let suffix = 2;
        while (existingIds.has(newBrandId)) {
            newBrandId = `${baseId}-${suffix}`;
            suffix += 1;
        }

        let storedLogo = brandLogo;
        if (window.firebase?.uploadBrandLogo) {
            storedLogo = await window.firebase.uploadBrandLogo(brandLogo, newBrandId);
        }

        const newCustomBrand = {
            id: newBrandId,
            name: brandName,
            logo: storedLogo,
            active: true,
            searchTerms: [newBrandId, normalizeBrandIdFromName(brandName)],
            isCustom: true
        };

        if (!window.firebaseData?.saveBrand) {
            showNotification('❌ Firebase no está disponible para guardar la marca');
            return;
        }

        await window.firebaseData.saveBrand(newCustomBrand);
        window.brandsData = getMergedBrands(await window.firebaseData.loadBrands());
        loadBrandsDropdown();
        loadCustomBrandDeleteDropdown();
        brandSelect.value = newCustomBrand.id;
        hideBrandManagerModal();
        showNotification('✅ Marca agregada correctamente');
    } catch (error) {
        console.error('❌ Error al guardar la marca:', error);
        showNotification(`❌ No se pudo guardar la marca: ${error?.message || 'error desconocido'}`);
    } finally {
        if (saveBtn) saveBtn.disabled = false;
    }
}

async function deleteCustomBrandSelected() {
    const deleteSelect = document.getElementById('customBrandDeleteSelect');
    const productBrandSelect = document.getElementById('productBrand');
    if (!deleteSelect) return;

    const brandId = (deleteSelect.value || '').trim();
    if (!brandId) {
        showNotification('❌ Debes seleccionar una marca personalizada para eliminar');
        return;
    }

    const fixedBrandIds = getFixedBrandIds();
    if (fixedBrandIds.has(brandId)) {
        showNotification('❌ No se puede eliminar una marca base del sistema');
        return;
    }

    const brandInUse = (window.productsData || []).some(product => product.brand === brandId);
    if (brandInUse) {
        showNotification('❌ No se puede eliminar: hay productos usando esta marca');
        return;
    }

    if (!window.firebaseData?.deleteBrand) {
        showNotification('❌ Firebase no está disponible para eliminar la marca');
        return;
    }

    await window.firebaseData.deleteBrand(brandId);
    window.brandsData = getMergedBrands(await window.firebaseData.loadBrands());
    loadBrandsDropdown();
    loadCustomBrandDeleteDropdown();

    if (productBrandSelect && productBrandSelect.value === brandId) {
        productBrandSelect.value = '';
    }

    deleteSelect.value = '';
    showNotification('✅ Marca personalizada eliminada correctamente');
}

function setupEventListeners() {
    console.log('⚙️ Configurando event listeners...');

    const viewStoreBtn = document.getElementById('adminProductsViewStoreBtn');
    if (viewStoreBtn && viewStoreBtn.dataset.listener !== 'true') {
        viewStoreBtn.addEventListener('click', () => {
            window.location.href = '../index.html';
        });
        viewStoreBtn.dataset.listener = 'true';
    }

    const newProductBtn = document.getElementById('newProductBtn');
    if (newProductBtn) {
        newProductBtn.addEventListener('click', () => showProductForm());
    }

    const productModalCloseBtn = document.getElementById('productModalCloseBtn');
    if (productModalCloseBtn) {
        productModalCloseBtn.addEventListener('click', hideProductForm);
    }

    const productModalCancelBtn = document.getElementById('productModalCancelBtn');
    if (productModalCancelBtn) {
        productModalCancelBtn.addEventListener('click', hideProductForm);
    }

    // Form submit - Configurar en la inicialización
    const productForm = document.getElementById('productForm');
    if (productForm) {
        console.log('✅ Formulario encontrado, configurando listener de submit');
        productForm.addEventListener('submit', handleProductSubmit);

        // Agregar listener directo al botón de guardar como alternativa
        const submitBtn = productForm.querySelector('button[type="submit"]');
        if (submitBtn) {
            console.log('✅ Botón de guardar encontrado, agregando listener directo');
            submitBtn.addEventListener('click', function(e) {
                console.log('🖱️ Click en botón guardar - previniendo default y llamando handleProductSubmit');
                e.preventDefault();
                handleProductSubmit(e);
            });
        }
    } else {
        console.error('❌ Formulario #productForm no encontrado');
    }

    // Image upload
    const imageInput = document.getElementById('productImage');
    const imagePreview = document.getElementById('imagePreview');

    if (imageInput && imagePreview) {
        imagePreview.addEventListener('click', () => imageInput.click());
        imagePreview.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                imageInput.click();
            }
        });
        imageInput.addEventListener('change', handleImageUpload);
    }

    const descriptionInput = document.getElementById('productDescription');
    if (descriptionInput) {
        descriptionInput.addEventListener('input', updateDescriptionCounter);
    }

    // Search
    const searchInput = document.getElementById('productSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            if (productFilterDebounceTimer) {
                clearTimeout(productFilterDebounceTimer);
            }
            productFilterDebounceTimer = setTimeout(filterProductsTable, PRODUCT_FILTER_DEBOUNCE_MS);
        });
    }

    const categorySelect = document.getElementById('productCategory');
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            if (categorySelect.value === '__new__') {
                showCategoryManagerModal();
            }
        });
    }

    document.getElementById('openCategoryManagerBtn')?.addEventListener('click', showCategoryManagerModal);
    document.getElementById('categoryManagerSelect')?.addEventListener('change', syncCategoryManagerFields);

    const saveCategoryManagerBtn = document.getElementById('saveCategoryManagerBtn');
    if (saveCategoryManagerBtn) {
        saveCategoryManagerBtn.addEventListener('click', saveCategoryManagerSelection);
    }

    const deleteCategoryBtn = document.getElementById('deleteCustomCategoryBtn');
    if (deleteCategoryBtn) {
        deleteCategoryBtn.addEventListener('click', deleteCustomCategorySelected);
    }

    const categoryManagerCloseBtn = document.getElementById('categoryManagerCloseBtn');
    if (categoryManagerCloseBtn) {
        categoryManagerCloseBtn.addEventListener('click', hideCategoryManagerModal);
    }

    const categoryManagerCancelBtn = document.getElementById('categoryManagerCancelBtn');
    if (categoryManagerCancelBtn) {
        categoryManagerCancelBtn.addEventListener('click', hideCategoryManagerModal);
    }

    const categoryManagerModal = document.getElementById('categoryManagerModal');
    if (categoryManagerModal) {
        categoryManagerModal.addEventListener('click', function(event) {
            if (event.target === categoryManagerModal) {
                hideCategoryManagerModal();
            }
        });
    }

    const productBrandSelect = document.getElementById('productBrand');
    if (productBrandSelect) {
        productBrandSelect.addEventListener('change', function() {
            if (productBrandSelect.value === '__new_brand__') {
                showBrandManagerModal();
            }
        });
    }

    document.getElementById('openBrandManagerBtn')?.addEventListener('click', showBrandManagerModal);
    document.getElementById('brandManagerSelect')?.addEventListener('change', syncBrandManagerFields);

    const saveNewBrandBtn = document.getElementById('saveNewBrandBtn');
    if (saveNewBrandBtn) {
        saveNewBrandBtn.addEventListener('click', saveCustomBrandFromModal);
    }

    const deleteCustomBrandBtn = document.getElementById('deleteCustomBrandBtn');
    if (deleteCustomBrandBtn) {
        deleteCustomBrandBtn.addEventListener('click', deleteCustomBrandSelected);
    }

    const brandManagerCloseBtn = document.getElementById('brandManagerCloseBtn');
    if (brandManagerCloseBtn) {
        brandManagerCloseBtn.addEventListener('click', hideBrandManagerModal);
    }

    const brandManagerCancelBtn = document.getElementById('brandManagerCancelBtn');
    if (brandManagerCancelBtn) {
        brandManagerCancelBtn.addEventListener('click', hideBrandManagerModal);
    }

    const brandManagerModal = document.getElementById('brandManagerModal');
    if (brandManagerModal) {
        brandManagerModal.addEventListener('click', function(event) {
            if (event.target === brandManagerModal) {
                hideBrandManagerModal();
            }
        });
    }

    setupBrandLogoUpload();

    setupProductsTableActions();

    console.log('✅ Event listeners configurados');
}

function setupProductsTableActions() {
    const tableBody = document.getElementById('productsTableBody');
    if (!tableBody || tableBody.dataset.listener === 'true') {
        return;
    }

    tableBody.addEventListener('click', function(event) {
        const actionButton = event.target.closest('button[data-action]');
        if (!actionButton) {
            return;
        }

        const action = actionButton.dataset.action;

        if (action === 'create-first') {
            showProductForm();
            return;
        }

        const productId = actionButton.dataset.productId;
        if (!productId) {
            return;
        }

        if (action === 'edit') {
            editProduct(productId);
        } else if (action === 'toggle') {
            toggleProductStatus(productId);
        } else if (action === 'delete') {
            deleteProduct(productId);
        }
    });

    tableBody.dataset.listener = 'true';
}

// NUEVA FUNCIÓN: Configurar cálculos de descuento
function setupDiscountCalculations() {
    const inputs = [
        'productPrice',
        'productDiscountPercent',
        'productDiscountAmount'
    ];

    inputs.forEach(inputId => {
        const input = document.getElementById(inputId);
        if (input) {
            input.addEventListener('input', calculateFinalPrice);
        }
    });

    const discountType = document.getElementById('discountType');
    if (discountType) {
        discountType.addEventListener('change', function() {
            toggleDiscountFields();
            calculateFinalPrice();
        });
    }
}

// Las fotos se reducen antes de guardarse: una foto de celular (3-5 MB) queda
// en ~50-150 KB, suficiente para las tarjetas y el modal del catálogo.
const PRODUCT_IMAGE_MAX_SIZE_PX = 1000;
const PRODUCT_IMAGE_QUALITY = 0.82;

function loadImageElement(src) {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('No se pudo leer la imagen'));
        image.src = src;
    });
}

async function compressImageDataUrl(dataUrl) {
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) return dataUrl;

    const image = await loadImageElement(dataUrl);
    const scale = Math.min(1, PRODUCT_IMAGE_MAX_SIZE_PX / Math.max(image.naturalWidth, image.naturalHeight));
    const width = Math.max(1, Math.round(image.naturalWidth * scale));
    const height = Math.max(1, Math.round(image.naturalHeight * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');

    const webpDataUrl = (() => {
        context.drawImage(image, 0, 0, width, height);
        const result = canvas.toDataURL('image/webp', PRODUCT_IMAGE_QUALITY);
        return result.startsWith('data:image/webp') ? result : null;
    })();

    let compressed = webpDataUrl;
    if (!compressed) {
        // Navegador sin WebP: JPEG con fondo blanco (JPEG no soporta transparencia).
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, width, height);
        context.drawImage(image, 0, 0, width, height);
        compressed = canvas.toDataURL('image/jpeg', PRODUCT_IMAGE_QUALITY);
    }

    return compressed.length < dataUrl.length ? compressed : dataUrl;
}

// Sube la imagen a Storage y devuelve la URL. Si Storage falla (reglas, red),
// se guarda la versión comprimida para no bloquear el guardado del producto.
async function resolveProductImageForSave(imageValue) {
    if (typeof imageValue !== 'string' || !imageValue.startsWith('data:image/')) {
        return imageValue || '';
    }

    const compressed = await compressImageDataUrl(imageValue).catch(() => imageValue);

    if (window.firebaseData?.uploadProductImage) {
        try {
            return await window.firebaseData.uploadProductImage(compressed);
        } catch (error) {
            console.warn('⚠️ No se pudo subir la imagen a Storage; se guarda comprimida en Firestore:', error);
        }
    }

    return compressed;
}

function handleImageUpload(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('imagePreview');

    if (file) {
        const reader = new FileReader();
        reader.onload = async function(e) {
            try {
                currentImageData = await compressImageDataUrl(e.target.result);
            } catch (error) {
                console.warn('⚠️ No se pudo comprimir la imagen, se usa la original:', error);
                currentImageData = e.target.result;
            }
            const safeImage = sanitizeImageUrl(currentImageData);
            preview.innerHTML = safeImage ? `<img src="${safeImage}" alt="Preview">` : '<span>📷 Haz clic para subir imagen</span>';
            preview.classList.add('has-image');
        };
        reader.readAsDataURL(file);
    }
}

function getProductsWithEmbeddedImages() {
    return (window.productsData || []).filter(product =>
        typeof product.image === 'string' && product.image.startsWith('data:image/'));
}

// Migra las imágenes antiguas guardadas en base64 dentro de Firestore:
// las comprime, las sube a Storage y deja solo la URL en el producto.
function setupImageOptimizationButton() {
    const actions = document.querySelector('.admin-actions');
    if (!actions || document.getElementById('optimizeImagesBtn')) return;

    const button = document.createElement('button');
    button.id = 'optimizeImagesBtn';
    button.type = 'button';
    button.className = 'btn-secondary';
    actions.insertBefore(button, actions.firstChild);

    const refreshLabel = () => {
        const pending = getProductsWithEmbeddedImages().length;
        button.style.display = pending ? '' : 'none';
        button.textContent = `⚡ Optimizar imágenes (${pending})`;
    };
    refreshLabel();

    button.addEventListener('click', async () => {
        const pendingProducts = getProductsWithEmbeddedImages();
        if (!pendingProducts.length) return;
        if (!confirm(`Se optimizarán ${pendingProducts.length} imágenes para que la tienda cargue más rápido. ¿Continuar?`)) return;

        button.disabled = true;
        let optimized = 0;
        let failed = 0;

        for (const [index, product] of pendingProducts.entries()) {
            button.textContent = `Optimizando ${index + 1}/${pendingProducts.length}...`;
            try {
                const newImage = await resolveProductImageForSave(product.image);
                if (newImage && newImage !== product.image) {
                    await window.firebase.updateProduct(product.id, { image: newImage });
                    product.image = newImage;
                    optimized += 1;
                }
            } catch (error) {
                failed += 1;
                console.error('❌ No se pudo optimizar la imagen de', product.name, error);
            }
        }

        button.disabled = false;
        saveProducts();
        loadProductsTable();
        refreshLabel();
        // Si Storage rechazó la subida, la imagen queda comprimida en Firestore
        // y el botón sigue visible para reintentar cuando Storage funcione.
        const stillEmbedded = getProductsWithEmbeddedImages().length;
        showNotification(failed
            ? `⚠️ ${optimized} imágenes optimizadas, ${failed} con error (ver consola)`
            : stillEmbedded
                ? `✅ ${optimized} imágenes comprimidas. ${stillEmbedded} siguen en Firestore porque Storage rechazó la subida.`
                : `✅ ${optimized} imágenes optimizadas y movidas a Storage`);
    });
}

function showProductForm(productId = null) {
    console.log('🎯 Abriendo formulario para producto ID:', productId);

    const modal = document.getElementById('productFormModal');
    const formTitle = document.getElementById('productFormTitle');
    const form = document.getElementById('productForm');

    console.log('Modal existe:', !!modal, 'Formulario existe:', !!form);

    if (!modal || !form) {
        console.error('❌ Modal o formulario no encontrados');
        return;
    }

    // Resetear variables
    currentImageData = '';
    const imagePreview = document.getElementById('imagePreview');
    const imageInput = document.getElementById('productImage');
    if (imagePreview) {
        imagePreview.innerHTML = '<span>📷 Haz clic para subir imagen</span>';
        imagePreview.classList.remove('has-image');
    }
    if (imageInput) imageInput.value = '';

    const formSubtitle = document.getElementById('productFormSubtitle');

    if (productId) {
        formTitle.textContent = 'Editar producto';
        hideCategoryManagerModal();
        loadCustomCategoryDeleteDropdown();
        loadProductData(productId);
        const product = (window.productsData || []).find(item => normalizeProductId(item.id) === normalizeProductId(productId));
        if (formSubtitle) {
            formSubtitle.textContent = product?.sku
                ? `SKU ${product.sku} · Los cambios se verán en la tienda al guardar.`
                : 'Los cambios se verán en la tienda al guardar.';
        }
    } else {
        formTitle.textContent = 'Nuevo producto';
        form.reset();
        document.getElementById('productId').value = '';
        document.getElementById('discountType').value = 'none';
        hideCategoryManagerModal();
        loadCustomCategoryDeleteDropdown();
        toggleDiscountFields();
        calculateFinalPrice();
        if (formSubtitle) formSubtitle.textContent = 'Completa los datos y guarda para publicarlo en la tienda.';
    }

    updateDescriptionCounter();
    modal.classList.add('active');
    const modalBody = modal.querySelector('.pf-body');
    if (modalBody) modalBody.scrollTop = 0;
    console.log('✅ Modal abierto');

    // Prevenir que el click dentro del modal lo cierre
    const modalContent = modal.querySelector('.modal-content');
    if (modalContent) {
        modalContent.removeEventListener('click', stopPropagation);
        modalContent.addEventListener('click', stopPropagation);
    }
}

function stopPropagation(e) {
    e.stopPropagation();
}

function updateDescriptionCounter() {
    const input = document.getElementById('productDescription');
    const counter = document.getElementById('productDescriptionCounter');
    if (!input || !counter) return;
    const max = Number(input.getAttribute('maxlength')) || PRODUCT_DESCRIPTION_MAX_LENGTH;
    counter.textContent = `${input.value.length} / ${max}`;
    counter.classList.toggle('is-near-limit', input.value.length >= max - 20);
}

function hideProductForm() {
    const modal = document.getElementById('productFormModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

// Asignar funciones a window para que funcionen los onclick
window.showProductForm = showProductForm;
window.hideProductForm = hideProductForm;

function loadProductData(productId) {
    const normalizedId = normalizeProductId(productId);
    const product = window.productsData.find(p => normalizeProductId(p.id) === normalizedId);
    if (!product) return;

    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productPrice').value = product.price;
    const categorySelect = document.getElementById('productCategory');
    const brandSelect = document.getElementById('productBrand');
    const categoryValue = resolveSelectValue(categorySelect, product.category, window.categories);
    const brandValue = resolveSelectValue(brandSelect, product.brand, window.brandsData);
    categorySelect.value = categoryValue;
    brandSelect.value = brandValue;
    document.getElementById('productStock').value = product.stock;
    document.getElementById('productQuantity').value = product.quantity || '';
    document.getElementById('productUnit').value = product.unit || 'ml';
    document.getElementById('productDescription').value = product.description;
    document.getElementById('productIngredients').value = product.ingredients || '';
    document.getElementById('productUsage').value = product.usage || '';

    // Cargar datos de descuento
    document.getElementById('discountType').value = product.discountType || 'none';
    if (product.discountPercent) {
        document.getElementById('productDiscountPercent').value = product.discountPercent;
    }
    if (product.discountAmount) {
        document.getElementById('productDiscountAmount').value = product.discountAmount;
    }

    // Imagen
    const preview = document.getElementById('imagePreview');
    if (preview) {
        preview.innerHTML = '<span>📷 Haz clic para subir imagen</span>';
        preview.classList.remove('has-image');
    }
    if (product.image) {
        const safeImage = sanitizeImageUrl(product.image);
        preview.innerHTML = safeImage ? `<img src="${safeImage}" alt="Preview">` : '<span>📷 Haz clic para subir imagen</span>';
        preview.classList.add('has-image');
        currentImageData = safeImage;
    }

    toggleDiscountFields();
    calculateFinalPrice();
}

function resolveSelectValue(select, rawValue, options) {
    const value = String(rawValue || '').trim();
    if (!select || !value) return '';
    const direct = Array.from(select.options).find(option => option.value === value);
    if (direct) return direct.value;

    const normalized = value.toLowerCase();
    const match = (options || []).find(option => (
        String(option.id || '').toLowerCase() === normalized
        || String(option.name || '').trim().toLowerCase() === normalized
    ));
    return match ? String(match.id) : '';
}

async function handleProductSubmit(event) {
    if (event) {
        event.preventDefault();
    }

    try {
        const requiredFields = [
            { id: 'productName', label: 'Nombre del Producto' },
            { id: 'productPrice', label: 'Precio' },
            { id: 'productCategory', label: 'Categoría' },
            { id: 'productBrand', label: 'Marca' },
            { id: 'productStock', label: 'Stock' },
            { id: 'productDescription', label: 'Descripción' }
        ];

        const errors = [];

        const selectedCategory = document.getElementById('productCategory')?.value || '';
        if (selectedCategory === '__new__') {
            errors.push('Debes crear y seleccionar una categoría válida');
        }

        const selectedBrand = document.getElementById('productBrand')?.value || '';
        if (selectedBrand === '__new_brand__') {
            errors.push('Debes crear y seleccionar una marca válida');
        }

        requiredFields.forEach(field => {
            const input = document.getElementById(field.id);
            const value = input ? input.value : '';

            if (!input || !value || value.trim() === '') {
                errors.push(`${field.label} es obligatorio`);
                if (input) {
                    input.style.borderColor = '#ef4444';
                    input.style.backgroundColor = '#fee2e2';
                    input.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.2)';
                    setTimeout(() => {
                        input.style.borderColor = '';
                        input.style.backgroundColor = '';
                        input.style.boxShadow = '';
                    }, 5000);
                }
            }
        });

        const priceInput = document.getElementById('productPrice');
        const parsedPrice = parseInt(priceInput.value, 10);
        if (isNaN(parsedPrice) || parsedPrice < 0) {
            errors.push('Precio debe ser un número válido y mayor a 0');
            priceInput.style.borderColor = '#ef4444';
            priceInput.style.backgroundColor = '#fee2e2';
            priceInput.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.2)';
            setTimeout(() => {
                priceInput.style.borderColor = '';
                priceInput.style.backgroundColor = '';
                priceInput.style.boxShadow = '';
            }, 5000);
        }

        const stockInput = document.getElementById('productStock');
        const parsedStock = parseInt(stockInput.value, 10);
        if (isNaN(parsedStock) || parsedStock < 0) {
            errors.push('Stock debe ser un número válido y mayor o igual a 0');
            stockInput.style.borderColor = '#ef4444';
            stockInput.style.backgroundColor = '#fee2e2';
            stockInput.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.2)';
            setTimeout(() => {
                stockInput.style.borderColor = '';
                stockInput.style.backgroundColor = '';
                stockInput.style.boxShadow = '';
            }, 5000);
        }

        if (errors.length > 0) {
            showNotification('❌ ' + errors.join(' | '));
            return;
        }

        const productId = document.getElementById('productId').value;
        const discountType = document.getElementById('discountType').value;

        let discountPercent = null;
        let discountAmount = null;
        if (discountType === 'percentage') {
            discountPercent = parseInt(document.getElementById('productDiscountPercent').value, 10) || 0;
        } else if (discountType === 'amount') {
            discountAmount = parseInt(document.getElementById('productDiscountAmount').value, 10) || 0;
        }

        const productData = {
            name: (document.getElementById('productName').value || '').trim(),
            price: parsedPrice || 0,
            discountType,
            discountPercent,
            discountAmount,
            category: document.getElementById('productCategory').value,
            brand: document.getElementById('productBrand').value,
            stock: parsedStock || 0,
            minStock: 5,
            quantity: document.getElementById('productQuantity').value
                ? parseFloat(document.getElementById('productQuantity').value)
                : null,
            unit: document.getElementById('productUnit').value,
            description: (document.getElementById('productDescription').value || '').trim().slice(0, PRODUCT_DESCRIPTION_MAX_LENGTH),
            ingredients: document.getElementById('productIngredients').value,
            usage: document.getElementById('productUsage').value,
            featured: false,
            active: true,
            trackStock: true,
            image: await resolveProductImageForSave(currentImageData),
            updatedAt: new Date().toISOString()
        };

        if (productId) {
            await updateProduct(productId, productData);
            return;
        }

        await createProduct(productData);
    } catch (error) {
        console.error('❌ Error en handleProductSubmit:', error);
        showNotification('❌ Error al procesar: ' + error.message);
    }
}

async function createProduct(productData) {
    console.log('➕ Creando nuevo producto:', productData);
    const newProductData = {
        ...productData,
        sku: generateNextSku().slice(0, PRODUCT_SKU_MAX_LENGTH),
        createdAt: new Date().toISOString()
    };

    try {
        const savedProduct = await persistProductCreate(newProductData);
        window.productsData.push(savedProduct);
        rebuildAdminProductsSearchIndex();
        saveProducts();

        loadProductsTable();
        updateStats();
        hideProductForm();
        showNotification('✅ Producto creado exitosamente');
        console.log('✅ Producto guardado');
    } catch (error) {
        console.error('❌ Error guardando producto:', error);
        showNotification('❌ No se pudo guardar el producto en Firebase');
    }
}

async function updateProduct(productId, productData) {
    console.log('✏️ Actualizando producto ID:', productId);
    const normalizedId = normalizeProductId(productId);
    const index = window.productsData.findIndex(p => normalizeProductId(p.id) === normalizedId);
    if (index !== -1) {
        const updatedProduct = {
            ...window.productsData[index],
            ...productData,
            sku: window.productsData[index].sku || productData.sku || generateNextSku().slice(0, PRODUCT_SKU_MAX_LENGTH)
        };

        try {
            await persistProductUpdate(updatedProduct.id, updatedProduct);

            window.productsData[index] = updatedProduct;
            rebuildAdminProductsSearchIndex();
            saveProducts();

            loadProductsTable();
            updateStats();
            hideProductForm();
            showNotification('✅ Producto actualizado exitosamente');
            console.log('✅ Producto actualizado');
        } catch (error) {
            console.error('❌ Error actualizando producto en Firebase:', error);
            showNotification('❌ No se pudo actualizar el producto en Firebase');
        }
    } else {
        console.error('❌ Producto no encontrado con ID:', productId);
        showNotification('❌ No se encontró el producto para actualizar');
    }
}

// Funciones expuestas globalmente para los botones de la tabla
window.editProduct = function(productId) {
    showProductForm(productId);
};

window.toggleProductStatus = async function(productId) {
    const normalizedId = normalizeProductId(productId);
    const product = window.productsData.find(p => normalizeProductId(p.id) === normalizedId);
    if (product) {
        const previousActive = product.active !== false;
        const updatedProduct = { ...product, active: !previousActive };

        try {
            await persistProductUpdate(updatedProduct.id, updatedProduct);
            Object.assign(product, updatedProduct);
            rebuildAdminProductsSearchIndex();
            saveProducts();
            loadProductsTable();
            updateStats();
            showNotification(`✅ Producto ${updatedProduct.active ? 'activado' : 'desactivado'}`);
        } catch (error) {
            console.error('❌ Error actualizando visibilidad del producto:', error);
            showNotification('❌ No se pudo actualizar la visibilidad en Firebase');
        }
    }
};

window.deleteProduct = async function(productId) {
    if (confirm('¿Estás seguro de que quieres eliminar este producto? Esta acción no se puede deshacer.')) {
        const normalizedId = normalizeProductId(productId);
        // Obtener el producto antes de eliminarlo (para obtener su ID de Firebase si existe)
        const product = window.productsData.find(p => normalizeProductId(p.id) === normalizedId);

        window.productsData = window.productsData.filter(p => normalizeProductId(p.id) !== normalizedId);
        rebuildAdminProductsSearchIndex();

        // Eliminar de Firebase si está disponible
        if (window.firebaseData?.deleteProduct && product?.id) {
            try {
                await window.firebaseData.deleteProduct(product.id);
            } catch (error) {
                console.error('❌ Error eliminando de Firebase:', error);
                // Pero continuar con localStorage (ya se eliminó arriba)
            }
        }

        saveProducts();

        loadProductsTable();
        updateStats();
        showNotification('✅ Producto eliminado exitosamente');
    }
};

function filterProductsTable() {
    const searchTerm = document.getElementById('productSearch')?.value.toLowerCase() || '';
    const categoryFilter = document.getElementById('categoryFilter')?.value || '';

    let filteredProducts = window.productsData || [];

    if (searchTerm) {
        const matchingIds = new Set(
            adminProductsSearchIndex
                .filter(item => item.text.includes(searchTerm))
                .map(item => item.id)
        );
        filteredProducts = filteredProducts.filter(product => matchingIds.has(String(product.id)));
    }

    if (categoryFilter) {
        filteredProducts = filteredProducts.filter(product => product.category === categoryFilter);
    }

    filteredProductsCache = filteredProducts;
    visibleProductsLimit = 15;

    const tableBody = document.getElementById('productsTableBody');
    if (tableBody) {
        if (filteredProducts.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="no-results">
                        No se encontraron productos que coincidan con los filtros
                    </td>
                </tr>
            `;
        } else {
            renderVisibleProducts(tableBody);
        }
    }
}

function updateStats() {
    const products = window.productsData || [];

    document.getElementById('totalProducts').textContent = products.length;
    document.getElementById('featuredProducts').textContent = products.filter(p => p.featured).length;
    document.getElementById('lowStockProducts').textContent = products.filter(p => p.stock <= (p.minStock || 5)).length;
    document.getElementById('discountProducts').textContent = products.filter(p => p.discountType !== 'none').length;
}

function saveProducts() {
    const lightweightProducts = (window.productsData || []).map(product => ({
        ...product,
        image: typeof product.image === 'string' && product.image.startsWith('data:image/')
            ? ''
            : (product.image || '')
    }));

    try {
        localStorage.setItem('hairia_products', JSON.stringify(lightweightProducts));
        console.log('💾 Caché local de productos actualizada:', lightweightProducts.length);
    } catch (error) {
        if (error?.name === 'QuotaExceededError') {
            console.warn('⚠️ Caché local llena; Firebase conserva los productos.');
            return false;
        }
        console.warn('⚠️ No se pudo actualizar la caché local de productos.');
        return false;
    }

    return true;
}

function saveCategories() {
    localStorage.setItem('hairia_categories', JSON.stringify(window.categories));
    console.log('💾 Categorías guardadas:', window.categories.length);
}

function saveBrands() {
    const brandsToStore = (window.brandsData || []).map(brand => ({
        id: brand.id,
        name: brand.name,
        searchTerms: Array.isArray(brand.searchTerms) ? brand.searchTerms : []
    }));

    try {
        localStorage.setItem('hairia_brands', JSON.stringify(brandsToStore));
        console.log('💾 Marcas guardadas:', brandsToStore.length);
    } catch (error) {
        console.warn('⚠️ No se pudieron guardar marcas en localStorage:', error);
    }
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--primary-black);
        color: var(--primary-white);
        padding: 1rem 1.5rem;
        border-radius: 6px;
        z-index: 3000;
        box-shadow: var(--shadow);
    `;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// FUNCIONES DE DESCUENTO
function toggleDiscountFields() {
    const discountType = document.getElementById('discountType').value;
    const discountFields = document.getElementById('discountFields');
    const percentageField = document.getElementById('percentageField');
    const amountField = document.getElementById('amountField');

    if (discountType === 'none') {
        discountFields.style.display = 'none';
        // Limpiar campos de descuento
        document.getElementById('productDiscountPercent').value = '';
        document.getElementById('productDiscountAmount').value = '';
    } else {
        discountFields.style.display = 'flex';
        if (discountType === 'percentage') {
            percentageField.style.display = 'block';
            amountField.style.display = 'none';
            document.getElementById('productDiscountAmount').value = '';
        } else {
            percentageField.style.display = 'none';
            amountField.style.display = 'block';
            document.getElementById('productDiscountPercent').value = '';
        }
    }
    calculateFinalPrice();
}

// Exponer toggleDiscountFields globalmente para el onchange del HTML
window.toggleDiscountFields = toggleDiscountFields;

function calculateFinalPrice() {
    const priceInput = document.getElementById('productPrice');
    const discountType = document.getElementById('discountType').value;
    const discountPercentInput = document.getElementById('productDiscountPercent');
    const discountAmountInput = document.getElementById('productDiscountAmount');
    const finalPriceInput = document.getElementById('finalPrice');

    if (!priceInput || !finalPriceInput) return;

    const price = parseInt(priceInput.value) || 0;
    const discountPercent = parseInt(discountPercentInput?.value) || 0;
    const discountAmount = parseInt(discountAmountInput?.value) || 0;

    let finalPrice = price;

    if (discountType === 'percentage' && discountPercent > 0) {
        finalPrice = Math.max(0, price - (price * discountPercent / 100));
    } else if (discountType === 'amount' && discountAmount > 0) {
        finalPrice = Math.max(0, price - discountAmount);
    }

    finalPriceInput.value = formatCLP(finalPrice);
}

function formatCLP(amount) {
    if (!amount && amount !== 0) return '$0';

    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// ========== MEJORAS DE MODAL ==========

function setupModalClose() {
    const modal = document.getElementById('productFormModal');
    const modalContent = modal?.querySelector('.modal-content');

    if (modal && modalContent) {
        modalContent.removeEventListener('click', stopPropagation);
        modalContent.addEventListener('click', stopPropagation);

        // Cerrar al hacer click fuera del contenido
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                hideProductForm();
            }
        });

        // Cerrar con tecla ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.classList.contains('active')) {
                hideProductForm();
            }
        });

        console.log('✅ Modal close events configured');
    }
}

