// Configura el backend segun el entorno actual.
window.BACKEND_URL = window.BACKEND_URL || (
    ['localhost', '127.0.0.1'].includes(window.location.hostname)
        ? 'http://localhost:3000'
    : 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app'
);
