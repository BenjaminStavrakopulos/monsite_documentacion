// firebase-data.js - MÓDULO UNIFICADO FIREBASE-ONLY
// Responsable de: Productos, Órdenes, Carrito, Envíos, Categorías, Marcas y Descuentos

console.log('🔥 firebase-data.js cargado - modo Firebase-only');

function ensureFirebaseFunction(functionName) {
    if (!window.firebase || typeof window.firebase[functionName] !== 'function') {
        throw new Error(`Firebase no disponible: falta función ${functionName}`);
    }
}

// ============================================
// PRODUCTOS
// ============================================

// Si varias partes de la página piden productos a la vez (app.js, checkout,
// marcas...), comparten una sola consulta en vuelo en vez de repetirla.
// `var` (no `let`): algunas páginas incluyen este script dos veces.
var productsRequestInFlight = null;

async function loadProducts() {
    ensureFirebaseFunction('getProducts');

    if (!productsRequestInFlight) {
        productsRequestInFlight = window.firebase.getProducts()
            .then((products) => {
                window.productsData = Array.isArray(products) ? products : [];
                return window.productsData;
            })
            .finally(() => {
                productsRequestInFlight = null;
            });
    }

    return productsRequestInFlight;
}

// Lectura inmediata desde la caché local de Firestore (sin red). No toca
// window.productsData: quien la usa decide si pinta con estos datos.
async function loadProductsFromCache() {
    if (!window.firebase || typeof window.firebase.getProducts !== 'function') return [];
    try {
        const products = await window.firebase.getProducts({ source: 'cache' });
        return Array.isArray(products) ? products : [];
    } catch (_) {
        return [];
    }
}

async function uploadProductImage(dataUrl) {
    ensureFirebaseFunction('uploadProductImage');
    return await window.firebase.uploadProductImage(dataUrl);
}

async function createDefaultProducts() {
    ensureFirebaseFunction('createProduct');

    const defaultProducts = [
        {
            name: 'Shampoo Kerastase Premium',
            price: 29990,
            category: 'shampoo',
            featured: true,
            description: 'Shampoo premium con keratina y argan',
            image: '',
            stock: 50,
            sku: 'KERASTASE-001',
            active: true
        },
        {
            name: 'Acondicionador Intenso',
            price: 24990,
            category: 'acondicionador',
            featured: false,
            description: 'Acondicionador profundo hidratante',
            image: '',
            stock: 45,
            sku: 'ACOND-001',
            active: true
        },
        {
            name: 'Mascarilla Reparadora',
            price: 19990,
            category: 'tratamiento',
            featured: true,
            description: 'Tratamiento intensivo para cabello dañado',
            image: '',
            stock: 30,
            sku: 'MASK-001',
            active: true
        }
    ];

    for (const product of defaultProducts) {
        await window.firebase.createProduct(product);
    }

    return loadProducts();
}

async function saveProduct(product) {
    if (!product) return false;

    if (product.id) {
        ensureFirebaseFunction('updateProduct');
        await window.firebase.updateProduct(product.id, product);
        return product;
    }

    ensureFirebaseFunction('createProduct');
    return await window.firebase.createProduct(product);
}

async function updateProductStock(productId, stock, active = false) {
    ensureFirebaseFunction('updateProduct');
    return await window.firebase.updateProduct(productId, {
        stock: Math.max(0, Number.parseInt(stock, 10) || 0),
        active: active !== false,
        updatedAt: new Date().toISOString()
    });
}

async function deleteProduct(productId) {
    ensureFirebaseFunction('deleteProduct');
    await window.firebase.deleteProduct(productId);
    return true;
}

// ============================================
// ÓRDENES
// ============================================

// Solo admin y bodega leen órdenes de todos los clientes
function isStaffSession() {
    let user = window.hairiaSession?.getCurrentUser?.() || null;
    if (!user) {
        try {
            user = JSON.parse(localStorage.getItem('hairia_current_user') || sessionStorage.getItem('hairia_current_user') || 'null');
        } catch (_) {
            user = null;
        }
    }
    return user?.role === 'admin' || user?.role === 'bodeguero';
}

// Paneles: órdenes de un rango de fechas + pagadas pendientes de envío.
// options: { sinceDays, since, until, includePendingShipment }
async function loadOrdersForPanel(options = {}) {
    if (!isStaffSession()) return { orders: [], truncated: false };
    ensureFirebaseFunction('getOrdersForPanel');
    const since = options.since !== undefined
        ? options.since
        : (Number.isFinite(options.sinceDays) ? new Date(Date.now() - options.sinceDays * 86400000).toISOString() : null);
    return window.firebase.getOrdersForPanel({
        since,
        until: options.until || null,
        includePendingShipment: options.includePendingShipment !== false
    });
}

async function searchOrdersHistory(term) {
    if (!isStaffSession()) return [];
    ensureFirebaseFunction('searchOrdersHistory');
    return window.firebase.searchOrdersHistory(term);
}

async function countOrdersByStatus() {
    if (!isStaffSession()) return null;
    ensureFirebaseFunction('countOrdersByStatus');
    return window.firebase.countOrdersByStatus();
}

async function loadOrders(userId = null) {
    if (userId) {
        ensureFirebaseFunction('getUserOrders');
        return await window.firebase.getUserOrders(userId);
    }

    let currentUser = window.hairiaSession?.getCurrentUser?.() || null;

    if (!currentUser) {
        try {
            const fromLocal = JSON.parse(localStorage.getItem('hairia_current_user') || 'null');
            const fromSession = JSON.parse(sessionStorage.getItem('hairia_current_user') || 'null');
            currentUser = fromLocal || fromSession;
        } catch (error) {
            currentUser = null;
        }
    }

    const isAdminSession = currentUser?.role === 'admin' || currentUser?.role === 'bodeguero';

    if (!isAdminSession) {
        // Public pages should not try to read all orders from Firestore.
        return [];
    }

    ensureFirebaseFunction('getAllOrders');
    return await window.firebase.getAllOrders();
}

async function trackPageVisit() {
    ensureFirebaseFunction('trackPageVisit');
    return await window.firebase.trackPageVisit();
}

async function loadAnalyticsMetrics(startDate, endDate) {
    ensureFirebaseFunction('getAnalyticsMetrics');
    return await window.firebase.getAnalyticsMetrics(startDate, endDate);
}

async function saveOrder(order) {
    if (window.firebase && typeof window.firebase.saveOrderById === 'function') {
        return await window.firebase.saveOrderById(order);
    }

    ensureFirebaseFunction('createOrder');
    return await window.firebase.createOrder(order);
}

async function updateOrderStatus(orderId, newStatus, extra = {}) {
    if (newStatus === 'cancelled') {
        await cancelOrderOnServer(orderId);
    } else {
        ensureFirebaseFunction('updateOrderStatus');
        await window.firebase.updateOrderStatus(orderId, newStatus, extra);
    }
    const email = await notifyOrderStatusEmail(orderId, newStatus);
    return { updated: true, email };
}

function getStaffBackendUrl() {
    return window.BACKEND_URL || (['localhost', '127.0.0.1'].includes(window.location.hostname)
        ? 'http://localhost:3000'
        : 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app');
}

// Cancelar lo hace el backend: cambia el estado y devuelve el stock del pedido (si ya se había
// descontado) en una sola transacción.
async function cancelOrderOnServer(orderId) {
    const firebaseUser = window.firebase?.auth?.currentUser;
    if (!firebaseUser?.getIdToken) throw new Error('Sesión no disponible');
    const response = await fetch(`${getStaffBackendUrl()}/api/orders/${encodeURIComponent(orderId)}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${await firebaseUser.getIdToken()}` },
        body: '{}'
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    return data;
}

async function notifyOrderStatusEmail(orderId, status) {
    try {
        const firebaseUser = window.firebase?.auth?.currentUser;
        if (!firebaseUser?.getIdToken) return false;

        const backendUrl = getStaffBackendUrl();
        const token = await firebaseUser.getIdToken();
        const response = await fetch(`${backendUrl}/api/notifications/send-order-status-email`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ orderId, status })
        });
        const data = await response.json().catch(() => ({}));
        return response.ok ? data : { sent: false, reason: 'error' };
    } catch (error) {
        console.warn('No se pudo solicitar email de estado:', error.message);
        return { sent: false, reason: 'error' };
    }
}

async function updateOrderWarehouseData(orderId, updateData) {
    if (updateData?.status === 'cancelled') {
        await cancelOrderOnServer(orderId);
        const { status, ...rest } = updateData;
        if (Object.keys(rest).some(key => key !== 'warehouseUpdatedBy')) {
            ensureFirebaseFunction('updateOrderWarehouseData');
            await window.firebase.updateOrderWarehouseData(orderId, rest);
        }
        return { updated: true, email: await notifyOrderStatusEmail(orderId, 'cancelled') };
    }
    ensureFirebaseFunction('updateOrderWarehouseData');
    await window.firebase.updateOrderWarehouseData(orderId, updateData);
    const email = updateData?.status ? await notifyOrderStatusEmail(orderId, updateData.status) : null;
    return { updated: true, email };
}

async function setProductWarehouseAvailability(productId, available) {
    ensureFirebaseFunction('setProductWarehouseAvailability');
    return window.firebase.setProductWarehouseAvailability(productId, available);
}

// ============================================
// CARRITO
// ============================================

async function loadCart(userId) {
    ensureFirebaseFunction('getCart');
    return await window.firebase.getCart(userId);
}

async function saveCart(userId, cart) {
    ensureFirebaseFunction('saveCart');
    await window.firebase.saveCart(userId, cart);
    return true;
}

// ============================================
// DATOS DE ENVÍO
// ============================================

async function loadShippingData(userId) {
    ensureFirebaseFunction('getShippingData');
    return await window.firebase.getShippingData(userId);
}

async function saveShippingData(userId, shippingData) {
    ensureFirebaseFunction('saveShippingData');
    await window.firebase.saveShippingData(userId, shippingData);
    return true;
}

// ============================================
// CATEGORÍAS, MARCAS, DESCUENTOS
// ============================================

async function loadCategories() {
    ensureFirebaseFunction('getCategories');
    const categories = await window.firebase.getCategories();
    window.categories = Array.isArray(categories) ? categories : [];
    return window.categories;
}

async function loadCategoriesFromCache() {
    if (!window.firebase || typeof window.firebase.getCategories !== 'function') return [];
    try {
        const categories = await window.firebase.getCategories({ source: 'cache' });
        return Array.isArray(categories) ? categories : [];
    } catch (_) {
        return [];
    }
}

async function saveCategory(category) {
    ensureFirebaseFunction('saveCategory');
    return await window.firebase.saveCategory(category);
}

async function deleteCategory(categoryId) {
    ensureFirebaseFunction('deleteCategory');
    await window.firebase.deleteCategory(categoryId);
    return true;
}

async function loadBrands() {
    ensureFirebaseFunction('getBrands');
    const brands = await window.firebase.getBrands();
    window.brandsData = Array.isArray(brands) ? brands : [];
    return window.brandsData;
}

async function saveBrand(brand) {
    ensureFirebaseFunction('saveBrand');
    return await window.firebase.saveBrand(brand);
}

async function deleteBrand(brandId) {
    ensureFirebaseFunction('deleteBrand');
    await window.firebase.deleteBrand(brandId);
    return true;
}

async function loadDiscountCodes() {
    ensureFirebaseFunction('getDiscountCodes');
    return await window.firebase.getDiscountCodes();
}

async function saveDiscountCode(discount) {
    ensureFirebaseFunction('saveDiscountCode');
    return await window.firebase.saveDiscountCode(discount);
}

async function deleteDiscountCode(discountId) {
    ensureFirebaseFunction('deleteDiscountCode');
    await window.firebase.deleteDiscountCode(discountId);
    return true;
}

// ============================================
// CONFIGURACIÓN DE FUNCIONES DEL SITIO (FEATURE FLAGS)
// ============================================

async function loadHairAnalysisConfig() {
    ensureFirebaseFunction('getHairAnalysisConfig');
    return await window.firebase.getHairAnalysisConfig();
}

async function saveHairAnalysisConfig(config) {
    ensureFirebaseFunction('saveHairAnalysisConfig');
    return await window.firebase.saveHairAnalysisConfig(config);
}

async function loadIaProductTags() {
    ensureFirebaseFunction('getIaProductTags');
    return await window.firebase.getIaProductTags();
}

async function saveIaProductTags(productId, data) {
    ensureFirebaseFunction('saveIaProductTags');
    return await window.firebase.saveIaProductTags(productId, data);
}

async function deleteIaProductTags(productId) {
    ensureFirebaseFunction('deleteIaProductTags');
    return await window.firebase.deleteIaProductTags(productId);
}

async function loadHairAnalysisConsent(userId) {
    ensureFirebaseFunction('getHairAnalysisConsent');
    return await window.firebase.getHairAnalysisConsent(userId);
}

async function saveHairAnalysisConsent(userId, consent) {
    ensureFirebaseFunction('saveHairAnalysisConsent');
    return await window.firebase.saveHairAnalysisConsent(userId, consent);
}

async function uploadHairAnalysisTrainingSample(photos, metadata) {
    ensureFirebaseFunction('uploadHairAnalysisTrainingSample');
    return await window.firebase.uploadHairAnalysisTrainingSample(photos, metadata);
}

// ============================================
// EXPORTAR
// ============================================

window.firebaseData = {
    loadProducts,
    loadProductsFromCache,
    uploadProductImage,
    loadCategoriesFromCache,
    createDefaultProducts,
    saveProduct,
    updateProductStock,
    deleteProduct,
    loadOrders,
    loadOrdersForPanel,
    searchOrdersHistory,
    countOrdersByStatus,
    trackPageVisit,
    loadAnalyticsMetrics,
    saveOrder,
    updateOrderStatus,
    updateOrderWarehouseData,
    setProductWarehouseAvailability,
    loadCart,
    saveCart,
    loadShippingData,
    saveShippingData,
    loadCategories,
    saveCategory,
    deleteCategory,
    loadBrands,
    saveBrand,
    deleteBrand,
    loadDiscountCodes,
    saveDiscountCode,
    deleteDiscountCode,
    loadHairAnalysisConfig,
    saveHairAnalysisConfig,
    loadIaProductTags,
    saveIaProductTags,
    deleteIaProductTags,
    loadHairAnalysisConsent,
    saveHairAnalysisConsent,
    uploadHairAnalysisTrainingSample
};

console.log('✅ window.firebaseData exportado (Firebase-only)');
window.dispatchEvent(new CustomEvent('hairia:firebase-data-ready', {
    detail: {
        hasLoadProducts: typeof window.firebaseData.loadProducts === 'function',
        hasLoadCategories: typeof window.firebaseData.loadCategories === 'function'
    }
}));
