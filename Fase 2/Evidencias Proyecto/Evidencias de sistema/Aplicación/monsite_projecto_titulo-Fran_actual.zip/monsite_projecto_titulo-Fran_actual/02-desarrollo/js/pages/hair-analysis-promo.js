// hair-analysis-promo.js - Muestra/retira la tarjeta de promoción de IA en index.html
// También muestra el enlace "Análisis de cabello" del pie solo si la función es visible para quien
// navega (si no, la página del análisis lo devolvería al inicio sin explicación).
document.addEventListener('DOMContentLoaded', async () => {
    const section = document.getElementById('hairAnalysisSection');
    const footerLinks = document.querySelectorAll('[data-hair-analysis-link]');
    if (!section && !footerLinks.length) return;

    const hide = () => {
        section?.remove();
        footerLinks.forEach(link => link.remove());
    };

    const config = await (window.hairAnalysisConfig?.load() || Promise.resolve(window.hairAnalysisConfig?.getDefaults?.() || { habilitada: true, mostrarEnInicio: true, visibilidad: 'publico' }));

    if (!config.habilitada) {
        hide();
        return;
    }

    // Mientras la funcionalidad está en desarrollo, solo el admin debe verla.
    if (config.visibilidad === 'solo_admin') {
        const currentUser = window.hairiaSession?.getCurrentUser?.();
        if (currentUser?.role !== 'admin') {
            hide();
            return;
        }
    }

    footerLinks.forEach(link => { link.hidden = false; });
    if (!section) return;
    if (!config.mostrarEnInicio) {
        section.remove();
        return;
    }
    section.classList.remove('hair-analysis-pending');
});

