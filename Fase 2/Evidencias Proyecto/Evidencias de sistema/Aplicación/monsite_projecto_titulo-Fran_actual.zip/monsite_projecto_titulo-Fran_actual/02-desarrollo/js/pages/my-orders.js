// my-orders.js - Visualizar y gestionar órdenes del usuario
console.log('📦 my-orders.js cargado');

function escapeOrdersHtml(value) {
    const text = value == null ? '' : String(value);
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function sanitizeOrdersImageUrl(value) {
    if (typeof value !== 'string') return '';
    const trimmed = value.trim();
    if (!trimmed) return '';
    if (/^https?:\/\//i.test(trimmed) || /^data:image\//i.test(trimmed)) {
        return escapeOrdersHtml(trimmed);
    }
    return '';
}

// Variables globales
let currentFilter = 'all';
let userOrders = [];
let userOrdersById = new Map();
let currentUser = null;
const CHILE_TIMEZONE = 'America/Santiago';
const clpFormatter = new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
});

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeOrdersPage);
} else {
    // Si el documento ya se cargó, inicializar inmediatamente
    initializeOrdersPage();
}

async function initializeOrdersPage() {
    console.log('🔄 Inicializando página de órdenes...');
    
    // Verificar autenticación
    const user = window.hairiaSession?.getCurrentUser() || null;
    
    if (!user || (!user.id && !user.uid)) {
        // Respaldo de account-guard.js (normalmente la página ni se llega a mostrar)
        window.location.replace('login.html?redirect=my-orders');
        return;
    }

    currentUser = user;

    // Cargar órdenes del usuario
    await loadUserOrders(user.uid || user.id);

    // Setup de filtros
    setupFilters();

    // Setup del modal
    setupOrderModal();
}

// ========== CARGAR ÓRDENES DEL USUARIO ==========
async function loadUserOrders(userId) {
    try {
        console.log('📦 Cargando órdenes del usuario');

        if (!window.firebaseData?.loadOrders) {
            throw new Error('firebaseData.loadOrders no disponible');
        }

        // Sincronizar órdenes pendientes con Mercado Pago: marca como pagadas las que
        // MP confirme, aunque el cliente no haya esperado en la página de éxito.
        if (window.hairiaPaymentRuntime?.syncPendingOrders) {
            try {
                const syncResult = await window.hairiaPaymentRuntime.syncPendingOrders();
                if (syncResult?.synced > 0) {
                    console.log(`🔄 ${syncResult.synced} orden(es) sincronizadas como pagadas`);
                }
            } catch (syncError) {
                console.warn('⚠️ No se pudieron sincronizar las órdenes pendientes:', syncError.message);
            }
        }

        const allOrders = await window.firebaseData.loadOrders(userId);
        userOrders = allOrders.filter(order => String(order.userId) === String(userId));
        console.log('✅ Órdenes cargadas:', userOrders.length);

        // Ordenar por fecha descendente
        userOrders = userOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        userOrdersById = new Map(userOrders.map(order => [String(order.id), order]));

        // Renderizar
        displayOrders(userOrders);
    } catch (error) {
        console.error('❌ Error cargando órdenes:', error);
        userOrders = [];
        userOrdersById = new Map();
        displayOrders(userOrders);
    }
}

function displayOrders(orders) {
    const ordersContent = document.getElementById('ordersContent');
    const emptyOrders = document.getElementById('emptyOrders');
    ordersContent.removeAttribute('aria-busy');

    if (orders.length === 0) {
        ordersContent.innerHTML = '';
        emptyOrders.style.display = 'flex';
        return;
    }

    emptyOrders.style.display = 'none';
    ordersContent.innerHTML = orders.map(order => createOrderCard(order)).join('');
    if (ordersContent.dataset.detailListener !== 'true') {
        ordersContent.addEventListener('click', event => {
            const button = event.target.closest('.btn-details[data-order-id]');
            if (button) openOrderDetail(button.dataset.orderId);
        });
        ordersContent.dataset.detailListener = 'true';
    }
}

function createOrderCard(order) {
    const date = new Date(order.createdAt);
    const formattedDate = date.toLocaleDateString('es-CL', {
        timeZone: CHILE_TIMEZONE,
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });

    const statusLabel = getStatusLabel(order.status);
    const statusClass = getStatusClass(order.status);

    return `
        <article class="order-card">
            <div class="order-header">
                <div class="order-info">
                    <span class="order-label">Compra</span>
                    <h3 class="order-id">${order.trackingCode ? escapeOrdersHtml(order.trackingCode) : `#${escapeOrdersHtml(order.id)}`}</h3>
                    <p class="order-date">${formattedDate}</p>
                </div>
                <span class="order-status ${statusClass}">${statusLabel}</span>
            </div>

            <div class="order-footer">
                <span class="order-total">${formatCLP(order.totals.total)}</span>
                <button class="btn-details" type="button" data-order-id="${escapeOrdersHtml(order.id)}">Ver detalle</button>
            </div>
        </article>
    `;
}

function getStatusLabel(status) {
    const labels = {
        pending: 'Pendiente de Pago',
        paid: 'Pagada',
        shipped: 'En camino',
        delivered: 'Entregada',
        refunded: 'Devuelta',
        cancelled: 'Cancelada'
    };
    return labels[status] || 'En proceso';
}

function getStatusClass(status) {
    // Solo clases conocidas: el estado viene de la base de datos y termina en el HTML
    return /^[a-z_]{1,30}$/.test(String(status || '')) ? `status-${status}` : 'status-unknown';
}

// ========== FILTROS ==========
function setupFilters() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');

            currentFilter = this.dataset.filter;
            filterOrders();
        });
    });
}

function filterOrders() {
    if (currentFilter === 'all') {
        displayOrders(userOrders);
    } else {
        const filtered = userOrders.filter(order => order.status === currentFilter);
        displayOrders(filtered);
    }
}

// ========== MODAL DE DETALLES ==========
function setupOrderModal() {
    const modal = document.getElementById('orderModal');
    if (!modal || modal.dataset.ready === 'true') return;
    modal.dataset.ready = 'true';

    modal.addEventListener('click', function (event) {
        if (event.target.classList.contains('modal-overlay') || event.target.closest('[data-od-close]')) {
            closeOrderDetail();
            return;
        }

        const addButton = event.target.closest('[data-od-add]');
        if (addButton) {
            const order = userOrdersById.get(String(modal.dataset.orderId));
            const item = order?.items?.[Number(addButton.dataset.odAdd)];
            if (item) addOrderItemToCart(item);
            return;
        }

        if (event.target.closest('[data-od-add-all]')) {
            const order = userOrdersById.get(String(modal.dataset.orderId));
            (order?.items || []).forEach(item => addOrderItemToCart(item));
            showNotification('Agregamos los productos a tu carrito');
            return;
        }

        const payButton = event.target.closest('[data-od-pay]');
        if (payButton) {
            const order = userOrdersById.get(String(modal.dataset.orderId));
            if (order) resumeOrderPayment(order, payButton);
            return;
        }

        if (event.target.closest('[data-od-receipt]')) {
            const order = userOrdersById.get(String(modal.dataset.orderId));
            if (order && typeof window.openOrderReceipt === 'function') window.openOrderReceipt(order);
        }
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && modal.classList.contains('active')) closeOrderDetail();
    });
}

// Estado de la compra: etiqueta, mensaje para el cliente y etapa del seguimiento
const ORDER_DETAIL_STATUS = {
    pending: { label: 'Pago pendiente', tone: 'warn', step: -1, message: 'El pago de esta compra no se completó, así que no se hizo ningún cargo. Puedes continuar con el pago o volver a comprar los productos.' },
    paid: { label: 'Pagada', tone: 'ok', step: 0, message: 'Recibimos tu pago y estamos preparando tu pedido. Te avisaremos por correo cuando vaya en camino.' },
    shipped: { label: 'En camino', tone: 'ok', step: 1, message: 'Tu pedido ya salió y va rumbo a tu dirección.' },
    delivered: { label: 'Entregada', tone: 'ok', step: 2, message: 'Registramos la entrega de tu pedido. ¡Esperamos que lo disfrutes!' },
    refunded: { label: 'Devuelta', tone: 'muted', step: -1, message: 'Procesamos la devolución de esta compra. El reembolso puede tardar algunos días hábiles en verse en tu medio de pago.' },
    cancelled: { label: 'Cancelada', tone: 'muted', step: -1, message: 'Esta compra fue cancelada. Si se realizó un cobro, se reembolsa al mismo medio de pago.' }
};

const ORDER_PAYMENT_METHODS = { mercado_pago: 'Mercado Pago', transbank_webpay: 'Webpay' };

function formatOrderDate(value, withTime = true) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    return date.toLocaleString('es-CL', {
        timeZone: CHILE_TIMEZONE,
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {})
    });
}

function formatOrderRut(rut) {
    const clean = String(rut || '').replace(/[^0-9kK]/g, '');
    if (clean.length < 2) return String(rut || '');
    return `${clean.slice(0, -1).replace(/\B(?=(\d{3})+(?!\d))/g, '.')}-${clean.slice(-1).toUpperCase()}`;
}

function renderOrderTracker(step) {
    const steps = ['Pago confirmado', 'En camino', 'Entregado'];
    return `
        <ol class="od-tracker" aria-label="Seguimiento del pedido">
            ${steps.map((label, index) => `
                <li class="${index <= step ? 'is-done' : ''}${index === step + 1 ? ' is-next' : ''}">
                    <span class="od-tracker-bar" aria-hidden="true"></span>
                    <span>${index <= step ? '✓ ' : ''}${label}</span>
                </li>`).join('')}
        </ol>`;
}

function openOrderDetail(orderId) {
    const order = userOrdersById.get(String(orderId));
    if (!order) return;

    const modal = document.getElementById('orderModal');
    const dialog = document.getElementById('modalBody');
    const status = ORDER_DETAIL_STATUS[order.status] || ORDER_DETAIL_STATUS.pending;
    const items = Array.isArray(order.items) ? order.items : [];
    const totals = order.totals || {};
    const shipping = order.shippingData || {};
    const itemCount = items.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);
    const paymentMethod = ORDER_PAYMENT_METHODS[String(order.paymentMethod || '').toLowerCase()] || '';
    const region = String(shipping.region || '').replace(/^Region\b/, 'Región');
    const hasReceipt = order.status !== 'pending';
    const esc = escapeOrdersHtml;

    const itemsHtml = items.map((item, index) => {
        const catalogProduct = (window.productsData || []).find(product => String(product.id) === String(item.id));
        const image = sanitizeOrdersImageUrl(item.image || catalogProduct?.image || '');
        const quantity = Number(item.quantity) || 0;
        const price = Number(item.price) || 0;
        const original = Number(item.originalPrice) || 0;
        return `
            <li class="od-item">
                <span class="od-item-thumb">${image ? `<img src="${image}" alt="" loading="lazy">` : ''}</span>
                <span class="od-item-info">
                    <span class="od-item-name">${esc(item.name || 'Producto')}</span>
                    <span class="od-item-meta">${quantity} × ${original > price ? `<del>${formatCLP(original)}</del> ` : ''}${formatCLP(price)}</span>
                    <button type="button" class="od-link" data-od-add="${index}">Agregar al carrito</button>
                </span>
                <span class="od-item-total">${formatCLP(price * quantity)}</span>
            </li>`;
    }).join('');

    dialog.innerHTML = `
        <header class="od-header">
            <div>
                <p class="od-eyebrow">Compra</p>
                <h2 class="od-title" id="orderDetailTitle">${order.trackingCode ? esc(order.trackingCode) : `#${esc(order.id)}`}</h2>
                <p class="od-date">${esc(formatOrderDate(order.createdAt))}</p>
            </div>
            <button type="button" class="od-close" data-od-close aria-label="Cerrar detalle">&times;</button>
        </header>

        <div class="od-body">
            <section class="od-status od-status--${status.tone}">
                <span class="od-chip od-chip--${status.tone}">${status.label}</span>
                <p>${status.message}</p>
                ${status.step >= 0 ? renderOrderTracker(status.step) : ''}
                ${order.courier === 'starken' && /^[A-Z0-9-]{4,40}$/.test(String(order.courierTrackingCode || '')) ? `
                <p class="od-courier">Enviado por Starken · N° <strong>${esc(order.courierTrackingCode)}</strong>
                    <a href="https://www.starken.cl/seguimiento?codigo=${encodeURIComponent(order.courierTrackingCode)}" target="_blank" rel="noopener">Seguir en Starken</a></p>` : ''}
            </section>

            <section class="od-section">
                <h3 class="od-section-title">Productos <span>${itemCount} ${itemCount === 1 ? 'unidad' : 'unidades'}</span></h3>
                <ul class="od-items">${itemsHtml}</ul>
                <dl class="od-totals">
                    <div><dt>Subtotal</dt><dd>${formatCLP(totals.subtotal)}</dd></div>
                    <div><dt>Envío</dt><dd>${Number(totals.shipping) > 0 ? formatCLP(totals.shipping) : 'Gratis'}</dd></div>
                    ${Number(totals.discount) > 0 ? `<div class="is-discount"><dt>Descuento${order.discountCode ? ` (${esc(order.discountCode)})` : ''}</dt><dd>−${formatCLP(totals.discount)}</dd></div>` : ''}
                    <div class="is-total"><dt>Total</dt><dd>${formatCLP(totals.total)}</dd></div>
                </dl>
            </section>

            <section class="od-info">
                <div class="od-card">
                    <h3 class="od-section-title">Despacho</h3>
                    <p><strong>${esc(`${shipping.firstName || ''} ${shipping.lastName || ''}`.trim() || 'Cliente')}</strong></p>
                    <p>${esc([shipping.street, shipping.apartment].filter(Boolean).join(', ') || '—')}</p>
                    <p>${esc([shipping.city, region].filter(Boolean).join(', '))}</p>
                    ${shipping.phone ? `<p>${esc(shipping.phone)}</p>` : ''}
                    ${shipping.notes ? `<p class="od-note">“${esc(shipping.notes)}”</p>` : ''}
                </div>
                <div class="od-card">
                    <h3 class="od-section-title">Pago</h3>
                    <p><strong>${formatCLP(totals.total)}</strong></p>
                    ${paymentMethod ? `<p>${esc(paymentMethod)}</p>` : ''}
                    ${order.paymentDate ? `<p>${esc(formatOrderDate(order.paymentDate))}</p>` : ''}
                    ${shipping.rut ? `<p>RUT ${esc(formatOrderRut(shipping.rut))}</p>` : ''}
                </div>
            </section>
        </div>

        <footer class="od-footer">
            ${hasReceipt ? '<button type="button" class="od-btn od-btn--primary" data-od-receipt>Ver boleta</button>' : ''}
            ${canResumePayment(order) ? '<button type="button" class="od-btn od-btn--primary" data-od-pay>Continuar con el pago</button>' : ''}
            <button type="button" class="od-btn ${hasReceipt || canResumePayment(order) ? 'od-btn--ghost' : 'od-btn--primary'}" data-od-add-all>Volver a comprar todo</button>
        </footer>
    `;

    modal.dataset.orderId = String(order.id);
    modal.classList.add('active');
    dialog.scrollTop = 0;
    document.body.style.overflow = 'hidden';
    dialog.querySelector('.od-close')?.focus({ preventScroll: true });
}

function closeOrderDetail() {
    const modal = document.getElementById('orderModal');
    if (!modal) return;
    modal.classList.remove('active');
    document.body.style.overflow = '';
    // Devolver el foco al botón que abrió el detalle
    document.querySelector(`.btn-details[data-order-id="${CSS.escape(String(modal.dataset.orderId || ''))}"]`)?.focus({ preventScroll: true });
}

// ========== CONTINUAR CON EL PAGO ==========
// Un pedido de Mercado Pago que quedó sin pagar (por ejemplo, el cliente volvió a la tienda
// sin pagar) se puede pagar directamente, sin rearmar el carrito: se crea una preferencia nueva
// para el MISMO pedido y se vuelve a Mercado Pago.
const RESUME_PAYMENT_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

function canResumePayment(order) {
    const method = String(order?.paymentMethod || 'mercado_pago').toLowerCase();
    const createdAt = Date.parse(order?.createdAt || '');
    return order?.status === 'pending'
        && method === 'mercado_pago'
        && Number.isFinite(createdAt)
        && Date.now() - createdAt < RESUME_PAYMENT_MAX_AGE_MS;
}

async function resumeOrderPayment(order, button) {
    const runtime = window.hairiaPaymentRuntime;
    if (!runtime?.getBackendUrl) {
        showNotification('No se pudo iniciar el pago. Recarga la página e inténtalo de nuevo.');
        return;
    }
    const label = button.textContent;
    button.disabled = true;
    button.textContent = 'Abriendo Mercado Pago...';
    try {
        const shipping = order.shippingData || {};
        const response = await fetch(`${runtime.getBackendUrl()}/api/payment/create-preference`, {
            method: 'POST',
            headers: await runtime.buildAuthHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({
                items: (order.items || []).map(item => ({ id: item.id, quantity: Number(item.quantity) || 1, price: Number(item.price) || 0 })),
                email: order.userEmail || shipping.email || '',
                firstName: shipping.firstName || 'Cliente',
                lastName: shipping.lastName || '',
                phone: shipping.phone || '',
                address: shipping.street || '',
                city: shipping.city || 'Santiago',
                orderId: order.id
            })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || 'No se pudo iniciar el pago');
        const useSandbox = runtime.getConfig?.().useSandboxCheckout === true;
        const redirectUrl = useSandbox ? (data.sandbox_init_point || data.init_point) : (data.init_point || data.sandbox_init_point);
        if (!redirectUrl) throw new Error('Mercado Pago no devolvió el enlace de pago');
        window.location.href = redirectUrl;
    } catch (error) {
        showNotification(`No se pudo iniciar el pago: ${error.message || 'inténtalo de nuevo'}`);
        button.disabled = false;
        button.textContent = label;
    }
}

// ========== FUNCIONES DEL CARRITO ==========
// Agrega un producto de una compra anterior al carrito compartido (app.js + cart.js).
// Usa el producto del catálogo si está disponible para tener foto, precio vigente y stock.
function addOrderItemToCart(item) {
    const catalogProduct = (window.productsData || []).find(product => String(product.id) === String(item.id));
    const product = catalogProduct || { id: item.id, name: item.name, price: Number(item.price) || 0, image: item.image || '' };
    if (typeof window.addToCart === 'function') {
        window.addToCart(product);
        window.updateCartUI?.();
    }
}

// ========== FUNCIONES AUXILIARES ==========
function formatCLP(amount) {
    if (typeof amount !== 'number') {
        amount = parseFloat(amount) || 0;
    }

    return clpFormatter.format(amount);
}

// Los avisos usan showNotification() de app.js (un solo aviso a la vez, con el estilo de la tienda)

// ========== FUNCIONES GLOBALES ==========
window.openOrderDetail = openOrderDetail;
window.closeOrderDetail = closeOrderDetail;
window.formatCLP = formatCLP;

console.log('✅ my-orders.js completamente inicializado');