// account-validation.js - Validaciones de la cuenta (registro y cambio de nombre).
// - Nombre: nombre y apellido reales (solo letras, sin números ni símbolos).
// - Correo: formato válido, sin errores típicos de escritura (gmial.com) ni correos desechables.
//   Que el correo exista de verdad se confirma después con el enlace de verificación.
(function () {
    const LETTERS = 'A-Za-zÀ-ÖØ-öø-ÿ';
    // Palabras de al menos 2 letras; se permiten apóstrofo y guion dentro (O'Higgins, Pérez-Cotapos)
    const WORD = new RegExp(`^[${LETTERS}](?:[${LETTERS}]|['’-](?=[${LETTERS}]))*$`);

    function validateName(rawName) {
        const value = String(rawName || '').trim().replace(/\s+/g, ' ');
        if (!value) return { ok: false, message: 'Escribe tu nombre y apellido.' };
        if (/\d/.test(value)) return { ok: false, message: 'El nombre no puede tener números.' };
        if (value.length > 60) return { ok: false, message: 'El nombre es demasiado largo (máximo 60 caracteres).' };
        const words = value.split(' ');
        if (words.some(word => !WORD.test(word))) {
            return { ok: false, message: 'Usa solo letras en tu nombre (sin símbolos ni emojis).' };
        }
        if (words.length < 2) return { ok: false, message: 'Escribe tu nombre y tu apellido.' };
        if (words.some(word => word.replace(/['’-]/g, '').length < 2)) {
            return { ok: false, message: 'Escribe tu nombre y apellido completos (sin iniciales).' };
        }
        if (/(.)\1\1/i.test(value.replace(/\s/g, ''))) {
            return { ok: false, message: 'Revisa tu nombre: tiene letras repetidas.' };
        }
        return { ok: true, value };
    }

    // Dominios comunes y sus errores de escritura más frecuentes
    const DOMAIN_TYPOS = {
        'gmail.com': ['gmial.com', 'gmal.com', 'gmai.com', 'gnail.com', 'gamil.com', 'gmail.co', 'gmail.cl', 'gmail.con', 'gmaill.com', 'gmali.com', 'g-mail.com', 'gmil.com'],
        'hotmail.com': ['hotmial.com', 'hotmal.com', 'hotmai.com', 'hotmail.co', 'hotmail.con', 'hormail.com', 'hotamil.com', 'homail.com', 'hotmil.com', 'htmail.com'],
        'outlook.com': ['outlok.com', 'outllok.com', 'outlook.co', 'outlook.con', 'otulook.com', 'outloo.com'],
        'yahoo.com': ['yaho.com', 'yahooo.com', 'yahoo.co', 'yahoo.con', 'yhoo.com'],
        'icloud.com': ['iclod.com', 'icloud.co', 'icoud.com', 'icloud.con'],
        'live.com': ['live.co', 'live.con', 'lve.com']
    };
    const TYPO_TO_DOMAIN = Object.entries(DOMAIN_TYPOS).reduce((map, [domain, typos]) => {
        typos.forEach(typo => { map[typo] = domain; });
        return map;
    }, {});

    // Correos temporales/desechables: no sirven para recuperar la cuenta ni recibir boletas
    const DISPOSABLE = new Set([
        'mailinator.com', 'yopmail.com', '10minutemail.com', 'guerrillamail.com', 'guerrillamail.net', 'sharklasers.com',
        'tempmail.com', 'temp-mail.org', 'tempmailo.com', 'trashmail.com', 'getnada.com', 'maildrop.cc', 'dispostable.com',
        'fakeinbox.com', 'throwawaymail.com', 'mintemail.com', 'emailondeck.com', 'mohmal.com', 'tempail.com', 'moakt.com',
        'mailnesia.com', 'spamgourmet.com', 'discard.email', 'burnermail.io', 'tempr.email', 'emailfake.com', 'mailpoof.com'
    ]);

    function checkEmail(rawEmail) {
        const value = String(rawEmail || '').trim().toLowerCase();
        if (!value) return { ok: false, message: 'Escribe tu correo electrónico.' };
        const match = /^([a-z0-9._%+-]+)@([a-z0-9-]+(?:\.[a-z0-9-]+)+)$/.exec(value);
        if (!match || /\.\./.test(value) || /^\.|\.@/.test(value)) {
            return { ok: false, message: 'Revisa tu correo: debe tener la forma nombre@dominio.com.' };
        }
        const [, user, domain] = match;
        if (TYPO_TO_DOMAIN[domain]) {
            const suggestion = `${user}@${TYPO_TO_DOMAIN[domain]}`;
            return { ok: false, suggestion, message: `¿Quisiste decir ${suggestion}?` };
        }
        if (DISPOSABLE.has(domain)) {
            return { ok: false, message: 'Usa un correo personal: los correos temporales no sirven para recuperar tu cuenta ni recibir tus boletas.' };
        }
        if (domain.split('.').pop().length < 2) return { ok: false, message: 'Revisa el final de tu correo (por ejemplo .com o .cl).' };
        return { ok: true, value, domain };
    }

    window.MonsiteValidation = { validateName, checkEmail };
})();
