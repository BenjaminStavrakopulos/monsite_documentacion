// hair-recommender.js - Recomienda productos reales según el resultado de la IA capilar.
//
// 1. El resultado de la IA (tipo de cabello + condición, con sus probabilidades) se convierte
//    en un "perfil de necesidades": cuánto importa cada dimensión del Excel para ese cabello.
// 2. Cada producto tiene puntajes 0-3 por dimensión (data/hair-ia-matrix.json, generado desde
//    el Excel con backend/scripts/build-hair-ia-matrix.js).
// 3. Compatibilidad = suma(importancia × puntaje) / máximo posible, menos penalizaciones por
//    rasgos que perjudican a ese cabello, ajustada por la confianza de catalogación.
// 4. "Sirve para tu cabello" = compatibilidad >= MIN_SCORE y cubre al menos una necesidad
//    principal con evidencia clara (puntaje >= 2). Se ordena de mejor a menos buena.
(function (global) {
    // Ruta absoluta: la usan tanto analisis-cabello.html como admin/admin-desarrollo.html
    const MATRIX_URL = '/data/hair-ia-matrix.json?v=20261014a';
    const MIN_SCORE = 0.30;
    const STRONG_WEIGHT = 2;
    const STRONG_EVIDENCE = 2;

    // Importancia de cada dimensión según el tipo de cabello detectado
    const TYPE_PROFILE = {
        straight: { ligereza_no_apelmaza: 2, brillo: 1.5, suavidad: 1, manejabilidad: 1, volumen: 1, cabello_fino_plano: 1, alisado_pulido: 1 },
        wavy: { definicion_rizos_ondas: 3, cabello_rizado_ondulado: 3, anti_frizz: 2, anti_humedad: 1.5, ligereza_no_apelmaza: 1, hidratacion: 1, textura: 1 },
        curly: { definicion_rizos_ondas: 3, cabello_rizado_ondulado: 3, anti_frizz: 2.5, hidratacion: 2, nutricion_lipidos: 2, anti_humedad: 1.5, desenredo: 1, elasticidad: 1 },
        kinky: { nutricion_lipidos: 3, hidratacion: 3, cabello_rizado_ondulado: 3, definicion_rizos_ondas: 2, desenredo: 2, elasticidad: 2, anti_frizz: 2, cabello_grueso: 1.5, anti_quiebre: 1 },
        dreadlocks: { cuidado_cuero_cabelludo: 3, limpieza: 2, control_olor_refresco: 2, limpieza_profunda_clarificante: 1, hidratacion: 1, ligereza_no_apelmaza: 1 }
    };

    // Importancia según la condición visible
    const CONDITION_PROFILE = {
        seco: { hidratacion: 3, cabello_seco_deshidratado: 3, nutricion_lipidos: 2.5, suavidad: 1.5, anti_frizz: 1.5, elasticidad: 1, brillo: 1, puntas_abiertas: 1 },
        normal: { uso_frecuente_diario: 2, limpieza: 1.5, brillo: 1, suavidad: 1, manejabilidad: 1, ligereza_no_apelmaza: 1 }
    };

    // ==========================================================
// IMPORTANCIA SEGÚN FRIZZ
// ==========================================================

    const FRIZZ_PROFILE = {

        con_frizz: {

            anti_frizz:
                3,

            anti_humedad:
                2.5,

            control_estatica_flyaways:
                1.5,

            suavidad:
                1,

            manejabilidad:
                1

        },


        sin_frizz: {

            manejabilidad:
                0.25

        }

    };

    // ==========================================================
// NECESIDADES DEVUELTAS POR LA TRIPLE IA
// ==========================================================

    const NEED_PROFILE = {

        'hidratacion cabello seco': {

            hidratacion:
                3,

            cabello_seco_deshidratado:
                3,

            nutricion_lipidos:
                2

        },


        'brillo suavidad': {

            brillo:
                2.5,

            suavidad:
                2.5,

            manejabilidad:
                1

        },


        'control de frizz': {

            anti_frizz:
                3,

            anti_humedad:
                2,

            control_estatica_flyaways:
                1.5,

            manejabilidad:
                1

        },


        'rizos ondas': {

            definicion_rizos_ondas:
                3,

            cabello_rizado_ondulado:
                3,

            elasticidad:
                1

        },


        mantenimiento: {

            uso_frecuente_diario:
                1.5,

            limpieza:
                1,

            suavidad:
                0.5

        }

    };
    // Rasgos que no convienen (se restan): ej. limpieza clarificante en cabello seco
    const PENALTIES = {
        seco: { limpieza_profunda_clarificante: 1.5, control_grasa_sebo: 1.5 },
        curly: { alisado_pulido: 1 },
        kinky: { alisado_pulido: 1, ligereza_no_apelmaza: 0.5 },
        straight: { cabello_grueso: 0.5 }
    };

    const CONFIDENCE_FACTOR = { Alta: 1, Media: 0.9, Baja: 0.8 };

    // Textos cortos para explicar por qué se recomienda cada producto
    const REASON_LABELS = {
        hidratacion: 'Hidratación',
        nutricion_lipidos: 'Nutrición',
        cabello_seco_deshidratado: 'Para cabello seco',
        definicion_rizos_ondas: 'Define rizos y ondas',
        cabello_rizado_ondulado: 'Ideal para rizos y ondas',
        anti_frizz: 'Controla el frizz',
        anti_humedad: 'Resiste la humedad',
        ligereza_no_apelmaza: 'Ligero, no apelmaza',
        brillo: 'Aporta brillo',
        suavidad: 'Suavidad',
        manejabilidad: 'Manejabilidad',
        volumen: 'Volumen',
        cabello_fino_plano: 'Para cabello fino',
        alisado_pulido: 'Acabado pulido',
        textura: 'Textura',
        desenredo: 'Desenreda',
        elasticidad: 'Elasticidad',
        cabello_grueso: 'Para cabello grueso',
        anti_quiebre: 'Evita el quiebre',
        cuidado_cuero_cabelludo: 'Cuida el cuero cabelludo',
        limpieza: 'Limpieza',
        control_olor_refresco: 'Refresca',
        limpieza_profunda_clarificante: 'Limpieza profunda',
        uso_frecuente_diario: 'Uso diario',
        puntas_abiertas: 'Puntas abiertas',
        control_estatica_flyaways: 'Controla pelitos sueltos'
    };

    function normalizeName(name) {
        return String(name || '')
            .normalize('NFD').replace(/[̀-ͯ]/g, '')
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, ' ')
            .trim();
    }

    function normalizeClassKey(
        value
    ) {

        return String(
            value || ''
        )
            .trim()
            .toLowerCase()
            .replace(
                /-/g,
                '_'
            );

    }
    function getProbabilities(block) {
        if (!block) return {};
        if (block.probabilities && typeof block.probabilities === 'object') return block.probabilities;
        return block.prediction ? { [block.prediction]: Number(block.confidence) || 1 } : {};
    }

    // Perfil ponderado por las probabilidades de la IA (no solo la clase ganadora)
    function buildProfile(
        apiResult
    ) {

        const weights = {};

        const penalties = {};


        const add = (
            target,
            table,
            probability = 1
        ) => {

            Object.entries(
                table || {}
            ).forEach(
                ([
                    dimension,
                    value
                ]) => {

                    target[
                        dimension
                    ] = (

                        target[
                            dimension
                        ]
                        ||
                        0

                    )
                    +
                    (
                        value
                        *
                        probability
                    );

                }
            );

        };


        // ======================================================
        // TIPO DE CABELLO
        // ======================================================

        Object.entries(
            getProbabilities(
                apiResult?.type
            )
        ).forEach(
            ([
                type,
                probability
            ]) => {

                const key =
                    normalizeClassKey(
                        type
                    );


                add(
                    weights,

                    TYPE_PROFILE[
                        key
                    ],

                    probability
                );


                add(
                    penalties,

                    PENALTIES[
                        key
                    ],

                    probability
                );

            }
        );


        // ======================================================
        // CONDICIÓN
        // ======================================================

        Object.entries(
            getProbabilities(
                apiResult?.condition
            )
        ).forEach(
            ([
                condition,
                probability
            ]) => {

                const key =
                    normalizeClassKey(
                        condition
                    );


                add(
                    weights,

                    CONDITION_PROFILE[
                        key
                    ],

                    probability
                );


                add(
                    penalties,

                    PENALTIES[
                        key
                    ],

                    probability
                );

            }
        );


        // ======================================================
        // FRIZZ
        // ======================================================

        Object.entries(
            getProbabilities(
                apiResult?.frizz
            )
        ).forEach(
            ([
                frizz,
                probability
            ]) => {

                const key =
                    normalizeClassKey(
                        frizz
                    );


                add(
                    weights,

                    FRIZZ_PROFILE[
                        key
                    ],

                    probability
                );

            }
        );


        // ======================================================
        // NECESIDADES GENERADAS POR LA IA
        //
        // Refuerzan las dimensiones correspondientes sin
        // reemplazar tipo/condición/frizz.
        // ======================================================

        const needs =
            Array.isArray(
                apiResult
                    ?.analysis
                    ?.needs
            )

                ?

                apiResult
                    .analysis
                    .needs

                :

                [];


        needs.forEach(
            need => {

                const needKey =
                    normalizeName(
                        need
                    );


                add(
                    weights,

                    NEED_PROFILE[
                        needKey
                    ],

                    0.75
                );

            }
        );


        return {
            weights,
            penalties
        };

    }

    function scoreProduct(scores, confidence, profile) {
        const { weights, penalties } = profile;
        const totalWeight = Object.values(weights).reduce((sum, value) => sum + value, 0);
        if (!totalWeight) return { score: 0, strongHits: 0, reasons: [] };

        const contributions = Object.entries(weights)
            .map(([dimension, weight]) => ({ dimension, value: weight * (scores[dimension] || 0), evidence: scores[dimension] || 0, weight }))
            .filter(item => item.value > 0);

        const gain = contributions.reduce((sum, item) => sum + item.value, 0);
        const loss = Object.entries(penalties).reduce((sum, [dimension, weight]) => sum + weight * (scores[dimension] || 0), 0);
        const score = Math.max(0, (gain - loss) / (3 * totalWeight)) * (CONFIDENCE_FACTOR[confidence] || 0.9);

        const strongHits = contributions.filter(item => item.weight >= STRONG_WEIGHT && item.evidence >= STRONG_EVIDENCE).length;
        const reasons = contributions
            .filter(item => item.evidence >= STRONG_EVIDENCE && REASON_LABELS[item.dimension])
            .sort((a, b) => b.value - a.value)
            .slice(0, 3)
            .map(item => REASON_LABELS[item.dimension]);

        return { score, strongHits, reasons };
    }

    function getLevel(score) {
        if (score >= 0.45) return { key: 'top', label: 'Muy recomendado' };
        if (score >= 0.35) return { key: 'high', label: 'Recomendado' };
        return { key: 'ok', label: 'Compatible' };
    }

    function isAvailable(product) {
        if (!product || product.active === false) return false;
        const stock = Number.parseInt(product.stock, 10);
        return Number.isFinite(stock) ? stock > 0 : true;
    }

    /**
     * @returns {{ items: Array<{product, score, level, reasons, matrix}>, partial: boolean }}
     *   items: todos los productos que sirven, de mejor a menos bueno.
     *   partial: true si ninguno llegó al umbral y se devuelven los más cercanos.
     */
    function recommend(apiResult, catalogProducts, matrix) {
        const profile = buildProfile(apiResult);
        const catalog = (catalogProducts || []).filter(isAvailable);
        const byId = new Map(catalog.map(product => [String(product.id), product]));
        const byName = new Map(catalog.map(product => [normalizeName(product.name), product]));
        const oily = hasOilyScalp(apiResult);

        const scored = [];
        (matrix?.products || []).forEach(entry => {
            const product = (entry.productId && byId.get(String(entry.productId))) || byName.get(normalizeName(entry.name));
            if (!product) return; // no se vende o está agotado
            if (oily && (isHeavyProduct(entry) || HEAVY_NAME.test(product.name || ''))) return; // cuero cabelludo graso: nada pesado
            const result = scoreProduct(entry.scores || {}, entry.confidence, profile);
            scored.push({ product, matrix: entry, ...result, level: getLevel(result.score) });
        });

        scored.sort((a, b) => b.score - a.score || b.strongHits - a.strongHits);

        const matches = scored.filter(item => item.score >= MIN_SCORE && item.strongHits >= 1);
        const sections = groupByCare(apiResult, scored);
        const tabs = buildTabs(apiResult, scored);
        if (matches.length) return { items: matches, partial: false, sections, tabs };

        return { items: scored.filter(item => item.score > 0).slice(0, 3), partial: true, sections, tabs };
    }

    // ---------- Secciones por cuidado y nivel de intensidad ----------
    // La IA entrega porcentajes; cada cuidado se traduce a un nivel 1-3 que se empareja con la
    // intensidad de la etiqueta principal del producto para ese cuidado (puntaje 0-3):
    //   0-30 % -> nivel 1 (suave) · 31-70 % -> nivel 2 (medio) · 71-100 % -> nivel 3 (intenso).
    // Un producto entra en la sección solo si su intensidad para ese cuidado es EXACTAMENTE el
    // nivel pedido; si no hay ninguno, la sección no se muestra.
    const CARES = {
        hidratacion: { title: 'Hidratación', tag: 'hidratacion', measure: 'sequedad' },
        // El modelo de condición (normal/seco) es el que mide el daño visible en la foto del cuerpo
        reparacion: { title: 'Reparación', tag: 'reparacion', measure: 'sequedad' },
        frizz: { title: 'Control de frizz', tag: 'anti_frizz', measure: 'frizz' },
        definicion: { title: 'Definición de rizos y ondas', tag: 'definicion_rizos_ondas', measure: 'rizo u onda' },
        cuero: { title: 'Cuidado del cuero cabelludo', tag: 'cuidado_cuero_cabelludo', measure: 'rastas' },
        // Según las respuestas del cliente (no se ven bien en una foto)
        termico: { title: 'Protección térmica', tag: 'proteccion_termica' },
        color: { title: 'Cuidado del color', tag: 'proteccion_color_anti_desvanecimiento' },
        // Modelo de cuero cabelludo (beta): lo que se ve en la foto de la raíz
        canas: { title: 'Cuidado de canas', tag: 'cuidado_canas', measure: 'canas' },
        // Caspa: nunca se nombra. Si el modelo la sospecha se suma esta sección con título neutro.
        //  - sospecha leve: productos suaves de cuero cabelludo (sirven igual si es falsa alarma);
        //  - sospecha alta (≥ 75 %): etiqueta "anticaspa", primero los que tienen ingredientes activos.
        caspa: { title: 'Cuero cabelludo equilibrado', tag: 'anticaspa', fallbackTag: 'cuidado_cuero_cabelludo', measure: 'caspa' },
        // También silenciosos (no se nombran; títulos neutros):
        //  - grasa: productos que controlan el sebo sin cargar la raíz;
        //  - baja densidad: densidad/anticaída o, si no, volumen y cuerpo (el puntaje es el mayor de los tres).
        grasa: { title: 'Frescura y ligereza', tag: 'control_grasa_sebo', measure: 'grasa' },
        densidad: { title: 'Volumen y cuerpo', tag: ['densidad_anticaida', 'volumen', 'cuerpo_grosor_visual'], measure: 'densidad' }
    };
    // Nombre corto para las pestañas del resultado (los silenciosos siguen sin nombrar el problema)
    const CARE_TAB_LABELS = {
        hidratacion: 'Hidratación', reparacion: 'Reparación', frizz: 'Frizz', definicion: 'Rizos y ondas',
        cuero: 'Cuero cabelludo', termico: 'Calor', color: 'Color', canas: 'Canas',
        caspa: 'Cuero equilibrado', grasa: 'Ligereza', densidad: 'Volumen'
    };

    // Cuero cabelludo graso: la hidratación lo empeora. Si el modelo lo sospecha no se pide la
    // sección de hidratación y se sacan de TODAS las secciones los productos pesados: hidratación 3,
    // nutrición/lípidos, fórmulas para cabello seco, y toda mascarilla, aceite o fórmula
    // hidratante/nutritiva (por el nombre).
    // Sin excepciones: en la matriz hay mascarillas y aceites marcados con "control de grasa".
    // (Casi todo el catálogo tiene hidratación 2, por eso no se excluye todo lo que hidrata.)
    const HEAVY_NAME = /mascar|mask|m.scara|aceite|\boil\b|manteca|butter|hidrat|hydrat|moisture|nutri/i;

    function hasOilyScalp(apiResult) {
        return apiResult?.scalp?.detected?.graso === true;
    }

    function isHeavyProduct(entry) {
        const value = key => Number(entry?.scores?.[key]) || 0;
        return value('hidratacion') >= 3 || value('nutricion_lipidos') >= 2 || value('cabello_seco_deshidratado') >= 3
            || HEAVY_NAME.test(entry?.name || '');
    }
    // Ingredientes anticaspa (etiqueta 1-3 = el producto lo contiene): en la sección de caspa van primero
    const ANTICASPA_INGREDIENTS = ['piritionato_zinc', 'ketoconazol', 'sulfuro_selenio', 'acido_salicilico'];
    const LEVEL_NAMES = { 1: 'suave', 2: 'media', 3: 'intensa' };
    const MAX_ITEMS_PER_SECTION = 3;

    function levelFromPercent(probability) {
        const percent = Math.round((Number(probability) || 0) * 100);
        if (percent <= 30) return 1;
        if (percent <= 70) return 2;
        return 3;
    }

    function topClass(block) {
        const entries = Object.entries(getProbabilities(block));
        if (!entries.length) return null;
        return normalizeClassKey(entries.sort((a, b) => b[1] - a[1])[0][0]);
    }

    function probabilityOf(block, classes) {
        const probabilities = getProbabilities(block);
        return Object.entries(probabilities)
            .filter(([label]) => classes.includes(normalizeClassKey(label)))
            .reduce((sum, [, value]) => sum + (Number(value) || 0), 0);
    }

    const fromPercent = (key, probability) => ({
        key, source: 'ia', percent: Math.round(probability * 100), level: levelFromPercent(probability)
    });
    const fromAnswer = (key, level) => ({ key, source: 'respuesta', level });

    // Cuidados con su nivel. Hidratación y frizz salen de la IA y van siempre (son una escala);
    // definición solo si el cabello es ondulado/rizado/afro, cuero cabelludo si son rastas.
    // Lo que no se ve bien en una foto sale de las respuestas del cliente (apiResult.answers):
    //  - puntas abiertas/quiebre (0-3) define Reparación; sin respuesta se usa la sequedad;
    //  - uso de plancha (1-3) suma Protección térmica (el secador no se pregunta: lo usa casi todo el mundo);
    //  - teñido (nivel 2) o decolorado (nivel 3) suma Cuidado del color.
    // Canas y caspa salen del modelo de cuero cabelludo (apiResult.scalp), según lo que detectó.
    //  (Si algún día se vuelve a preguntar, una respuesta "si"/"no" en answers manda sobre la IA.)
    //  - canas: nivel 3 si la IA ve presencia alta; si no, 2 (leve y moderada se juntan: el modelo
    //    todavía no distingue bien la presencia leve).
    //  - caspa: nivel 3 si la probabilidad es alta (≥ 75 %); si no, 2.
    function scalpCare(key, label, apiResult, answer, levelFor) {
        if (answer === 'no') return null;
        const scalp = apiResult?.scalp;
        const probability = Number(scalp?.probabilities?.[label]) || 0;
        const detected = scalp?.detected?.[label] === true;
        if (answer === 'si') return fromAnswer(key, levelFor(scalp, detected));
        if (!detected) return null;
        return { key, source: 'ia', percent: Math.round(probability * 100), level: levelFor(scalp, detected) };
    }

    const canasLevel = (scalp, detected) => (detected && Number(scalp?.canas_nivel?.level) === 3 ? 3 : 2);

    // Sequedad/daño: el modelo de condición da probabilidades bajas (dañado ~30 % de mediana, sano ~2 %),
    // así que se usan los mismos cortes que el resultado: < 25 % nivel 1, 25-40 % nivel 2, ≥ 40 % nivel 3
    const DAMAGE_MILD_FROM = 0.25;
    const DAMAGE_STRONG_FROM = 0.4;
    const damageLevel = probability => (probability >= DAMAGE_STRONG_FROM ? 3 : probability >= DAMAGE_MILD_FROM ? 2 : 1);
    const fromDamage = (key, probability) => ({
        key, source: 'ia', percent: Math.round(probability * 100), level: damageLevel(probability)
    });

    // Caspa (silenciosa): se suma desde 15 puntos bajo el umbral del modelo, porque una falsa alarma
    // solo agrega productos suaves de cuero cabelludo. Nivel 3 (ingredientes anticaspa) desde 75 %.
    const CASPA_MARGIN = 0.15;
    const CASPA_STRONG_FROM = 0.75;

    function silentCaspaCare(apiResult, answer) {
        if (answer === 'no') return null;
        const scalp = apiResult?.scalp;
        const probability = Number(scalp?.probabilities?.caspa_irritacion) || 0;
        const threshold = Number(scalp?.thresholds?.caspa_irritacion) || 0.5;
        if (answer !== 'si' && probability < threshold - CASPA_MARGIN) return null;
        return {
            key: 'caspa',
            source: answer === 'si' ? 'respuesta' : 'ia',
            percent: Math.round(probability * 100),
            level: probability >= CASPA_STRONG_FROM ? 3 : 2
        };
    }

    // Nivel 1-3 a partir de un porcentaje, o null si el cuidado no hace falta (bajo "desde")
    const levelOrNone = (probability, from) => (probability <= from ? null : levelFromPercent(probability));

    function neededCares(apiResult) {
        const answers = apiResult?.answers || {};
        const dryness = probabilityOf(apiResult?.condition, ['seco']);
        const frizz = probabilityOf(apiResult?.frizz, ['con_frizz']);
        const type = topClass(apiResult?.type);

        const oily = hasOilyScalp(apiResult);
        // Hidratación siempre (si se ve hidratado, nivel 1 = fórmulas ligeras para mantenerlo),
        // salvo cuero cabelludo graso: ahí la hidratación empeora las cosas
        const cares = oily ? [] : [fromDamage('hidratacion', dryness)];

        // Reparación: por la respuesta de puntas; sin respuesta, solo si se ve algo de sequedad
        const puntas = Number.isInteger(answers.puntas) ? answers.puntas : null;
        if (puntas !== null) {
            if (puntas > 0) cares.push(fromAnswer('reparacion', puntas));
        } else if (dryness >= DAMAGE_MILD_FROM) {
            cares.push(fromDamage('reparacion', dryness));
        }

        // Frizz: solo si se ve frizz (antes se recomendaba aunque no hubiera)
        if (levelOrNone(frizz, 0.3)) cares.push(fromPercent('frizz', frizz));

        if (['wavy', 'curly', 'kinky'].includes(type)) {
            cares.push(fromPercent('definicion', probabilityOf(apiResult?.type, ['wavy', 'curly', 'kinky'])));
        }
        const caspa = silentCaspaCare(apiResult, answers.caspa);
        // La caspa y las rastas usan la misma etiqueta de producto: si hay caspa, manda la caspa
        if (type === 'dreadlocks' && !caspa) {
            cares.push(fromPercent('cuero', probabilityOf(apiResult?.type, ['dreadlocks'])));
        }
        if (Number.isInteger(answers.calor) && answers.calor > 0) {
            cares.push(fromAnswer('termico', answers.calor));
        }
        if (answers.tenido === 'tenido') cares.push(fromAnswer('color', 2));
        else if (answers.tenido === 'decolorado') cares.push(fromAnswer('color', 3));
        else if (answers.tenido !== 'no') {
            // Sin respuesta: lo que vio el modelo químico en la foto del cuerpo (mechas o color -> nivel 2;
            // el modelo junta teñido y decolorado, así que no se distingue el nivel 3). No concluyente -> nada.
            const chemical = apiResult?.chemical;
            const prediction = chemical?.inconclusive ? null : chemical?.prediction;
            if (prediction === 'mechas' || prediction === 'color') {
                cares.push({ key: 'color', source: 'ia', percent: Math.round((Number(chemical.confidence) || 0) * 100), level: 2 });
            }
        }

        const canas = scalpCare('canas', 'canas', apiResult, answers.canas, canasLevel);
        if (canas) cares.push(canas);
        if (caspa) cares.push(caspa);

        // Silenciosos del cuero cabelludo (se detectan con los umbrales del modelo, no se nombran)
        const scalpProbability = label => Math.round((Number(apiResult?.scalp?.probabilities?.[label]) || 0) * 100);
        if (oily) cares.push({ key: 'grasa', source: 'ia', percent: scalpProbability('graso'), level: 2 });
        if (apiResult?.scalp?.detected?.baja_densidad === true) {
            cares.push({ key: 'densidad', source: 'ia', percent: scalpProbability('baja_densidad'), level: 2 });
        }

        return cares;
    }

    // Intensidad del producto para un cuidado: el puntaje (0-3) de su etiqueta principal.
    // (Tomar el máximo de varias etiquetas inflaba casi todo a 3.)
    function productIntensity(scores, care, tag = CARES[care].tag) {
        const tags = Array.isArray(tag) ? tag : [tag];
        return Math.max(0, ...tags.map(key => Math.round(Number(scores?.[key]) || 0)));
    }

    const ingredientCount = scores => ANTICASPA_INGREDIENTS.filter(key => Number(scores?.[key]) > 0).length;

    function levelText(care) {
        if (care.key === 'color' && care.source === 'ia') {
            return `Nivel ${care.level} · lo notamos en la foto de tu cabello`;
        }
        if (care.key === 'canas') {
            return care.source === 'respuesta'
                ? `Nivel ${care.level} · confirmado por ti`
                : 'Nos pareció ver algunas canas en la foto de tu raíz; cuidarlas es opcional';
        }
        if (care.key === 'grasa') {
            return 'Fórmulas livianas que limpian sin cargar la raíz';
        }
        if (care.key === 'densidad') {
            return 'Fórmulas que dan cuerpo y grosor visual al cabello';
        }
        if (care.key === 'caspa') {
            // Sin nombrar la caspa
            return care.level === 3
                ? 'Fórmulas que limpian a fondo y calman el cuero cabelludo'
                : 'Fórmulas suaves que limpian y equilibran el cuero cabelludo';
        }
        if (care.key === 'hidratacion' && care.level === 1) {
            return 'Se ve hidratado: fórmulas ligeras para mantenerlo sin apelmazar';
        }
        if ((care.key === 'hidratacion' || care.key === 'reparacion') && care.source === 'ia') {
            return `Nivel ${care.level} · tu cabello se ve ${care.level === 3 ? 'seco o dañado' : 'algo reseco'}`;
        }
        return care.source === 'respuesta'
            ? `Nivel ${care.level} · según tu respuesta`
            : `Nivel ${care.level} · ${care.percent} % de ${CARES[care.key].measure}`;
    }

    // Qué intensidades de producto sirven para cada nivel pedido (la exacta va primero):
    //   nivel 1 (suave)  -> 1 o 2 (nunca 3: sería demasiado pesado para un cabello que está bien)
    //   nivel 2 (media)  -> 2, 3 o 1
    //   nivel 3 (intensa)-> 3 o 2
    const ACCEPTED_INTENSITY = { 1: [1, 2], 2: [2, 3, 1], 3: [3, 2] };

    function careTitle(care) {
        if (care.key === 'hidratacion' && care.level === 1) return 'Hidratación ligera';
        if (['caspa', 'grasa', 'densidad'].includes(care.key)) return CARES[care.key].title;
        return `${CARES[care.key].title} · intensidad ${LEVEL_NAMES[care.level]}`;
    }

    /**
     * Secciones de recomendados (3 productos por sección):
     *  1) "Cubren N de tus cuidados": productos que sirven para varios cuidados a la vez, de más a
     *     menos cuidados cubiertos (una sección por cantidad: 4, 3, 2...).
     *  2) Una sección por cuidado (Hidratación, Reparación, Frizz, Color, Canas, Caspa...) con los
     *     productos individuales que mejor calzan con el nivel pedido.
     * Cada producto aparece una sola vez. Dentro de cada sección: primero la intensidad exacta y
     * luego el puntaje general del recomendador. Las secciones vacías no se muestran.
     */
    // Qué tan bien sirve un producto para un cuidado: 0 = intensidad exacta, 1-2 = cercana,
    // null = no sirve. (Lo usan las secciones y las pestañas del resultado.)
    function careMatcher(list) {
        // Etiqueta con que se mide cada cuidado (la de respaldo si aún ningún producto tiene la principal)
        const tagFor = care => {
            const config = CARES[care.key];
            if (care.key === 'caspa' && care.level < 3) return config.fallbackTag;
            if (Array.isArray(config.tag)) return config.tag;
            const anyTagged = list.some(item => Number(item.matrix?.scores?.[config.tag]) > 0);
            return config.fallbackTag && !anyTagged ? config.fallbackTag : config.tag;
        };
        // Sospecha leve de caspa: nada medicado (ketoconazol o sulfuro de selenio resecan a quien no lo necesita)
        const isMedicated = item => Number(item.matrix?.scores?.ketoconazol) > 0 || Number(item.matrix?.scores?.sulfuro_selenio) > 0;
        return (item, care) => {
            if (care.key === 'caspa' && care.level < 3 && isMedicated(item)) return null;
            const intensity = productIntensity(item.matrix?.scores, care.key, tagFor(care));
            const position = (ACCEPTED_INTENSITY[care.level] || []).indexOf(intensity);
            return position === -1 ? null : position;
        };
    }

    const MAX_TOP_ITEMS = 5;
    const MAX_ITEMS_PER_TAB = 5;

    /**
     * Pestañas del resultado (carrusel):
     *  - "Top": hasta 5 productos que cubren más cuidados a la vez (de más a menos; luego los más
     *    cercanos a la intensidad pedida). Cada uno dice qué cubre y qué le falta.
     *  - Una pestaña por cuidado: hasta 5 productos que sirven para ese cuidado (primero la intensidad
     *    que mejor calza, luego los que además cubren otros cuidados). Ningún producto se repite entre
     *    el Top y las pestañas ni entre pestañas. Las pestañas vacías no van.
     *  - missing = ningún producto del Top cubre ese cuidado (se marca en la pestaña).
     */
    function buildTabs(apiResult, scored) {
        const cares = neededCares(apiResult);
        const list = scored || [];
        const distance = careMatcher(list);
        const titleOf = care => CARES[care.key].title;

        const coverage = list.map((item, index) => {
            const covered = cares.filter(care => distance(item, care) !== null);
            const closeness = covered.reduce((sum, care) => sum + distance(item, care), 0);
            return { item, index, covered, closeness };
        });
        const decorate = entry => ({
            ...entry.item,
            covers: entry.covered.map(titleOf),
            lacks: cares.filter(care => !entry.covered.includes(care)).map(titleOf)
        });

        const top = coverage
            .filter(entry => entry.covered.length > 0)
            .sort((a, b) => b.covered.length - a.covered.length || a.closeness - b.closeness || a.index - b.index)
            .slice(0, MAX_TOP_ITEMS);
        const topIds = new Set(top.map(entry => entry.item.product.id));

        // Ningún producto se repite: ni el Top en las pestañas, ni entre pestañas. Eligen primero
        // los cuidados que el Top no cubre; dentro de cada una, primero la intensidad que mejor calza
        // con ese cuidado y después los que además cubren otros cuidados tuyos.
        const used = new Set(topIds);
        const isMissing = care => !top.some(entry => entry.covered.includes(care));
        const pickOrder = [...cares].sort((a, b) => Number(isMissing(b)) - Number(isMissing(a)));
        const itemsByCare = new Map();
        pickOrder.forEach(care => {
            let candidates = coverage
                .filter(entry => !used.has(entry.item.product.id) && distance(entry.item, care) !== null)
                .map(entry => ({ ...entry, careCloseness: distance(entry.item, care) }))
                .sort((a, b) => a.careCloseness - b.careCloseness || b.covered.length - a.covered.length
                    || a.closeness - b.closeness || a.index - b.index);
            if (care.key === 'caspa' && care.level === 3) {
                // Sospecha alta: primero las fórmulas con ingredientes anticaspa
                candidates = candidates
                    .map(entry => ({ ...entry, ingredients: ingredientCount(entry.item.matrix?.scores) }))
                    .sort((a, b) => b.ingredients - a.ingredients || a.careCloseness - b.careCloseness || b.covered.length - a.covered.length);
            }
            const picked = candidates.slice(0, MAX_ITEMS_PER_TAB);
            picked.forEach(entry => used.add(entry.item.product.id));
            itemsByCare.set(care, picked);
        });

        const tabs = cares.map(care => ({
            key: care.key,
            label: CARE_TAB_LABELS[care.key] || titleOf(care),
            title: careTitle(care),
            description: `${levelText(care)}.`,
            missing: isMissing(care),
            items: itemsByCare.get(care).map(decorate)
        })).filter(tab => tab.items.length);

        return { careCount: cares.length, top: top.map(decorate), tabs };
    }

    function groupByCare(apiResult, scored) {
        const cares = neededCares(apiResult);
        const list = scored || [];

        // Etiqueta con que se mide cada cuidado (la de respaldo si aún ningún producto tiene la principal)
        const tagFor = care => {
            const config = CARES[care.key];
            if (care.key === 'caspa' && care.level < 3) return config.fallbackTag;
            if (Array.isArray(config.tag)) return config.tag;
            const anyTagged = list.some(item => Number(item.matrix?.scores?.[config.tag]) > 0);
            return config.fallbackTag && !anyTagged ? config.fallbackTag : config.tag;
        };
        // 0 = intensidad exacta, 1-2 = cercana, null = no sirve para ese cuidado
        // Sospecha leve de caspa: nada medicado (ketoconazol o sulfuro de selenio resecan a quien no lo necesita)
        const isMedicated = item => Number(item.matrix?.scores?.ketoconazol) > 0 || Number(item.matrix?.scores?.sulfuro_selenio) > 0;
        const distance = (item, care) => {
            if (care.key === 'caspa' && care.level < 3 && isMedicated(item)) return null;
            const intensity = productIntensity(item.matrix?.scores, care.key, tagFor(care));
            const position = (ACCEPTED_INTENSITY[care.level] || []).indexOf(intensity);
            return position === -1 ? null : position;
        };

        const sections = [];
        const used = new Set();
        const take = (candidates, limit = MAX_ITEMS_PER_SECTION) => candidates
            .filter(entry => !used.has(entry.item.product.id))
            .slice(0, limit)
            .map(entry => { used.add(entry.item.product.id); return entry; });

        // ---- 1) Productos que cubren varios cuidados ----
        const coverage = list.map((item, index) => {
            const covered = cares.filter(care => distance(item, care) !== null);
            const closeness = covered.reduce((sum, care) => sum + distance(item, care), 0);
            return { item, index, covered, closeness };
        });

        if (cares.length > 1) {
            const maxCovered = Math.max(0, ...coverage.map(entry => entry.covered.length));
            for (let count = maxCovered; count >= 2; count -= 1) {
                const candidates = coverage
                    .filter(entry => entry.covered.length === count)
                    .sort((a, b) => a.closeness - b.closeness || a.index - b.index);
                const picked = take(candidates);
                if (!picked.length) continue;
                sections.push({
                    key: `combo-${count}`,
                    title: count === cares.length
                        ? 'Cubren todos tus cuidados'
                        : `Cubren ${count} de tus ${cares.length} cuidados`,
                    description: 'Un solo producto que atiende varias necesidades a la vez.',
                    level: null,
                    items: picked.map(entry => ({
                        ...entry.item,
                        reasons: [entry.covered.map(care => CARES[care.key].title).join(' · ')]
                    }))
                });
            }
        }

        // ---- 2) Productos individuales por cuidado ----
        cares.forEach(care => {
            let candidates = coverage
                .filter(entry => distance(entry.item, care) !== null)
                .map(entry => ({ ...entry, closeness: distance(entry.item, care) }))
                .sort((a, b) => a.closeness - b.closeness || a.index - b.index);
            if (care.key === 'caspa' && care.level === 3) {
                // Sospecha alta: primero las fórmulas con ingredientes anticaspa (zinc, ketoconazol, selenio, salicílico)
                candidates = candidates
                    .map(entry => ({ ...entry, ingredients: ingredientCount(entry.item.matrix?.scores) }))
                    .sort((a, b) => b.ingredients - a.ingredients || a.closeness - b.closeness || a.index - b.index);
            }
            const picked = take(candidates);
            if (!picked.length) return;
            sections.push({
                key: care.key,
                title: careTitle(care),
                description: `${levelText(care)}.`,
                level: care.level,
                items: picked.map(entry => entry.item)
            });
        });

        return sections;
    }

    // Etiquetas guardadas desde el admin (Firestore iaProductTags) reemplazan al Excel
    // para ese producto; los productos nuevos que solo existen ahí se agregan.
    function mergeAdminTags(matrix, adminTags) {
        const products = (matrix?.products || []).map(entry => ({ ...entry, source: 'excel' }));
        const indexById = new Map(products.map((entry, index) => [String(entry.productId || ''), index]));

        (adminTags || []).forEach(tag => {
            if (!tag?.productId) return;
            const entry = {
                name: tag.name || '',
                productId: String(tag.productId),
                confidence: tag.confidence || 'Media',
                need: tag.need || '',
                hairTypes: tag.hairTypes || '',
                scores: tag.scores || {},
                source: 'admin',
                updatedAt: tag.updatedAt || ''
            };
            const index = indexById.get(entry.productId);
            if (index != null) {
                products[index] = { ...products[index], ...entry, name: entry.name || products[index].name };
            } else {
                products.push(entry);
            }
        });

        return { ...(matrix || {}), products };
    }

    let baseMatrixPromise = null;
    function loadBaseMatrix() {
        if (!baseMatrixPromise) {
            baseMatrixPromise = fetch(MATRIX_URL)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    return response.json();
                })
                .catch(error => {
                    baseMatrixPromise = null;
                    throw error;
                });
        }
        return baseMatrixPromise;
    }

    async function loadAdminTags() {
        try {
            if (typeof global.firebaseData?.loadIaProductTags !== 'function') return [];
            return await global.firebaseData.loadIaProductTags();
        } catch (error) {
            console.warn('No se pudieron leer las etiquetas IA del admin; se usa solo el Excel:', error);
            return [];
        }
    }

    // Excel base + etiquetas del admin
    async function loadMatrix() {
        const [base, adminTags] = await Promise.all([loadBaseMatrix(), loadAdminTags()]);
        return mergeAdminTags(base, adminTags);
    }

    // Grupos para el editor de etiquetas del admin (las 42 dimensiones del Excel + las agregadas para el modelo
    // de cuero cabelludo: cuidado_canas, anticaspa y sus ingredientes)
    const DIMENSION_GROUPS = [
        { title: 'Tratamiento', keys: ['hidratacion', 'nutricion_lipidos', 'reparacion', 'reconstruccion_de_enlaces', 'fortalecimiento', 'anti_quiebre', 'puntas_abiertas', 'elasticidad'] },
        { title: 'Acabado y manejo', keys: ['suavidad', 'brillo', 'desenredo', 'manejabilidad', 'anti_frizz', 'anti_humedad', 'alisado_pulido', 'control_estatica_flyaways', 'ligereza_no_apelmaza'] },
        { title: 'Styling y forma', keys: ['volumen', 'cuerpo_grosor_visual', 'textura', 'definicion_rizos_ondas', 'fijacion'] },
        { title: 'Limpieza y cuero cabelludo', keys: ['limpieza', 'limpieza_profunda_clarificante', 'control_grasa_sebo', 'control_olor_refresco', 'cuidado_cuero_cabelludo', 'densidad_anticaida'] },
        // Anticaspa: intensidad del producto y si contiene cada ingrediente activo (cualquier nivel = lo contiene)
        { title: 'Anticaspa e ingredientes', keys: ['anticaspa', 'piritionato_zinc', 'ketoconazol', 'sulfuro_selenio', 'acido_salicilico'] },
        { title: 'Protección y color', keys: ['proteccion_termica', 'proteccion_uv_ambiental', 'proteccion_color_anti_desvanecimiento', 'neutralizacion_amarillos', 'cuidado_canas'] },
        { title: 'Daño que trata', keys: ['dano_quimico_decoloracion', 'dano_termico', 'dano_mecanico'] },
        { title: 'Tipo de cabello y uso', keys: ['cabello_seco_deshidratado', 'cabello_danado', 'cabello_fino_plano', 'cabello_grueso', 'cabello_rizado_ondulado', 'cabello_tenido_decolorado', 'uso_frecuente_diario'] }
    ];

    // Perfiles de referencia (resultado "puro" de la IA) para previsualizar dónde se recomendaría un producto
    const REFERENCE_PROFILES = ['straight', 'wavy', 'curly', 'kinky', 'dreadlocks'].flatMap(type => ['normal', 'seco'].map(condition => ({
        type,
        condition,
        apiResult: { type: { probabilities: { [type]: 1 } }, condition: { probabilities: { [condition]: 1 } } }
    })));

    const api = {
        recommend,
        groupByCare,
        buildTabs,
        neededCares,
        buildProfile,
        scoreProduct,
        loadMatrix,
        loadBaseMatrix,
        mergeAdminTags,
        normalizeName,
        isAvailable,
        DIMENSION_GROUPS,
        REFERENCE_PROFILES,
        MIN_SCORE
    };
    global.hairRecommender = api;
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
