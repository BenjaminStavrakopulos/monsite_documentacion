// reset-password.js - Crear una nueva contraseña desde el enlace del correo
// (auth-action.html → reset-password.html?oobCode=...).
// - Revisa el enlace al abrir: si venció o ya se usó, lo dice y ofrece pedir otro.
// - Exige las mismas reglas que al crear la cuenta (12 caracteres, mayúscula, número y símbolo).
(function () {
    // Mismo criterio que isStrongPassword() de firebase-config.js
    const RULES = {
        length: value => value.length >= 12,
        upper: value => /[A-Z]/.test(value),
        number: value => /\d/.test(value),
        special: value => /[\^$*.[\]{}()?"!@#%&\/\\,><':;|_~]/.test(value)
    };
    const $ = id => document.getElementById(id);
    let oobCode = '';
    let busy = false;

    function showState(id) {
        ['rpChecking', 'rpForm', 'rpDone', 'rpInvalid'].forEach(stateId => { $(stateId).hidden = stateId !== id; });
        const heading = $(id).querySelector('h1');
        if (id !== 'rpChecking' && id !== 'rpForm') heading?.focus();
    }

    function getCode() {
        const params = new URLSearchParams(window.location.search);
        let code = params.get('oobCode');
        if (!code && window.location.hash) code = new URLSearchParams(window.location.hash.slice(1)).get('oobCode');
        // El código queda en memoria: se quita de la barra de direcciones y del historial
        if (code) {
            try { history.replaceState(null, '', window.location.pathname); } catch (_) { /* sin historial disponible */ }
        }
        return code || '';
    }

    async function waitForFirebase() {
        for (let i = 0; i < 50 && typeof window.firebase?.verifyResetCode !== 'function'; i += 1) {
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        return typeof window.firebase?.verifyResetCode === 'function';
    }

    function evaluate() {
        const password = $('newPassword').value;
        const confirm = $('confirmPassword').value;
        const results = Object.fromEntries(Object.entries(RULES).map(([key, test]) => [key, test(password)]));
        document.querySelectorAll('#passwordRules [data-rule]').forEach(rule => rule.classList.toggle('is-ok', results[rule.dataset.rule]));
        const strong = Object.values(results).every(Boolean);
        const hint = $('matchHint');
        if (confirm && confirm !== password) {
            hint.textContent = 'Las contraseñas no coinciden.';
            hint.hidden = false;
        } else {
            hint.hidden = true;
        }
        $('submitBtn').disabled = busy || !strong || !confirm || confirm !== password;
        return strong && confirm === password;
    }

    function showError(message) {
        const box = $('rpError');
        box.textContent = message;
        box.hidden = !message;
    }

    async function submit(event) {
        event.preventDefault();
        if (busy || !evaluate()) return;
        busy = true;
        showError('');
        const button = $('submitBtn');
        button.disabled = true;
        button.classList.add('loading');
        try {
            const result = await window.firebase.confirmPasswordReset(oobCode, $('newPassword').value);
            if (result?.success) {
                showState('rpDone');
                return;
            }
            if (result?.code === 'auth/expired-action-code' || result?.code === 'auth/invalid-action-code') {
                showState('rpInvalid');
                return;
            }
            showError(result?.message || 'No se pudo cambiar la contraseña. Inténtalo de nuevo.');
        } catch (error) {
            showError('No se pudo cambiar la contraseña. Revisa tu conexión e inténtalo de nuevo.');
        } finally {
            busy = false;
            button.classList.remove('loading');
            evaluate();
        }
    }

    async function init() {
        oobCode = getCode();
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', () => {
                const input = $(button.dataset.target);
                const show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                button.textContent = show ? 'Ocultar' : 'Ver';
                button.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña');
            });
        });
        $('newPassword').addEventListener('input', evaluate);
        $('confirmPassword').addEventListener('input', evaluate);
        $('rpForm').addEventListener('submit', submit);

        if (!oobCode) {
            $('rpInvalidText').textContent = 'Para cambiar tu contraseña, abre el enlace que te enviamos por correo o pide uno nuevo.';
            showState('rpInvalid');
            return;
        }
        if (!(await waitForFirebase())) {
            showState('rpForm');
            return;
        }
        try {
            const email = await window.firebase.verifyResetCode(oobCode);
            $('rpAccount').textContent = `Para la cuenta ${email}. Elige una contraseña segura.`;
            showState('rpForm');
            $('newPassword').focus();
        } catch (error) {
            showState('rpInvalid');
        }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
