// admin-desarrollo.js - Panel de funciones en desarrollo (feature flags)
document.addEventListener('DOMContentLoaded', function() {
    initializeAdminDesarrollo();
});

async function initializeAdminDesarrollo() {
    const hasAccess = await checkAdminAuth();
    if (!hasAccess) {
        return;
    }
    setupPageActions();
    initHairAnalysisCard();
    // Etiquetas IA de productos (no bloquea el resto del panel)
    window.initIaTagsSection?.();
    setupSecurityPanel();
    await loadSecurityEvents({ reset: true });
}

const SECURITY_EVENTS_API_URL = 'https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app/api/security-events';
const SECURITY_PAGE_SIZE = 15;
const securityState = { events: [], nextCursor: null, loading: false, requestId: 0, observer: null };

async function getAdminApiHeaders() {
    const user = window.firebase?.auth?.currentUser;
    if (!user?.getIdToken) throw new Error('Sesión administrativa no disponible');
    return { Authorization: `Bearer ${await user.getIdToken()}` };
}

// Qué significa cada tipo de evento, en palabras simples
const SECURITY_TYPES = {
    order_tracking_limit: {
        label: 'Muchos intentos en "Sigue tu pedido"',
        severity: 'medium',
        lead: 'Alguien probó varios números de orden o correos que no coinciden en la página "Sigue tu pedido" y se bloqueó por 15 minutos.',
        advice: 'Suele ser un cliente que se equivocó varias veces. Si se repite mucho desde el mismo origen, puede ser alguien intentando adivinar números de orden: no lo logrará (hay 100 millones de combinaciones y además debe acertar el correo o RUT), pero conviene revisarlo.'
    },
    payment_webhook_rejected: {
        label: 'Aviso de Mercado Pago rechazado',
        severity: 'high',
        lead: 'Mercado Pago avisó sobre un pago y el servidor rechazó el aviso porque la firma no coincidió (o era un aviso antiguo sin firma). No es un ataque: es una configuración por revisar.',
        advice: 'Los pagos se siguen confirmando cuando el cliente vuelve a la tienda, pero conviene arreglarlo: en Mercado Pago → Tus integraciones → Webhooks, copia la "clave secreta" y verifica que sea la misma configurada en el servidor (MERCADOPAGO_WEBHOOK_SECRET). Si también tienes activas las notificaciones IPN (avisos "Feed"), desactívalas: no traen firma y siempre se rechazan.'
    },
    cors_blocked: {
        label: 'Origen no permitido',
        severity: 'low',
        lead: 'Una página que no está en la lista de sitios autorizados intentó usar el backend y fue bloqueada.',
        advice: 'Es normal si viene de una vista previa o de un sitio de prueba. Si el origen es un dominio tuyo en producción, hay que agregarlo a la lista de orígenes permitidos del backend.'
    },
    session_missing: {
        label: 'Consulta de orden sin sesión',
        severity: 'low',
        lead: 'Alguien consultó el estado de una orden sin una sesión válida, por ejemplo, un cliente al que se le venció la sesión al volver del pago.',
        advice: 'No requiere acción. Solo preocupa si se repite muchas veces desde el mismo origen en poco tiempo.'
    },
    sensitive_path_scan: {
        label: 'Escaneo de archivos sensibles',
        severity: 'high',
        lead: 'Un bot buscó archivos o paneles sensibles (.env, .git, wp-admin...). La solicitud fue bloqueada.',
        advice: 'El servidor no expone esos archivos. Si se repite desde el mismo origen, se puede bloquear esa IP con una regla de firewall en Cloud Run.'
    },
    credential_attack: {
        label: 'Intento de acceso rechazado',
        severity: 'high',
        lead: 'Un intento de iniciar sesión o autenticarse fue rechazado.',
        advice: 'Si hay varios seguidos desde el mismo origen, puede ser un intento de adivinar contraseñas. Revisa que las cuentas de administración tengan contraseñas fuertes.'
    },
    rate_limit: {
        label: 'Límite de peticiones',
        severity: 'medium',
        lead: 'Un origen hizo demasiadas peticiones seguidas y el servidor aplicó el límite de uso.',
        advice: 'El límite protege al servidor. Si afecta a clientes reales, se puede ajustar; si viene de un bot, no requiere acción.'
    },
    server_error: {
        label: 'Error interno del servidor',
        severity: 'high',
        lead: 'El servidor falló al procesar una solicitud.',
        advice: 'Revisa los registros de Cloud Run buscando el ID de solicitud de este evento para ver el detalle del error.'
    },
    unauthorized_access: {
        label: 'Acceso sin permisos',
        severity: 'low',
        lead: 'Una solicitud llegó a una ruta protegida sin sesión o sin los permisos necesarios, y fue rechazada.',
        advice: 'Normalmente es alguien sin sesión o con la sesión vencida. Revisa solo si se repite mucho desde el mismo origen.'
    }
};

const SEVERITY_LABELS = { critical: 'Crítica', high: 'Alta', medium: 'Media', low: 'Baja' };

// Los eventos antiguos se guardaron con una clasificación genérica: se reinterpretan aquí.
function classifySecurityEvent(event) {
    const path = String(event.path || '');
    const agent = String(event.userAgent || '');
    let type = event.attackType;
    if (/mercadopago/i.test(agent) && (/mercadopago|webhook/i.test(path))) type = 'payment_webhook_rejected';
    else if (Number(event.status) === 403 && event.method === 'OPTIONS') type = 'cors_blocked';
    else if (Number(event.status) === 403 && /origen-no-autorizado|\.web\.app|localhost|127\.0\.0\.1/i.test(String(event.origin || ''))) type = 'cors_blocked';
    else if (/\/order-status\//i.test(path) && Number(event.status) === 401) type = 'session_missing';
    else if (type === 'cors_probe') type = 'cors_blocked';
    const meta = SECURITY_TYPES[type] || SECURITY_TYPES.unauthorized_access;
    const storedSeverity = String(event.severity || '');
    const severity = type === event.attackType && SEVERITY_LABELS[storedSeverity] ? storedSeverity : meta.severity;
    return { type, meta, severity };
}

function describeSecuritySource(event) {
    const agent = String(event.userAgent || '');
    if (/mercadopago/i.test(agent)) return 'Mercado Pago';
    if (/curl|wget|python|go-http|okhttp|postman/i.test(agent)) return 'Script / herramienta';
    if (/bot|crawler|spider/i.test(agent)) return 'Bot';
    if (/mozilla/i.test(agent)) return 'Navegador';
    return 'Desconocido';
}

function setSecurityText(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
}

function setupSecurityPanel() {
    const refresh = document.getElementById('refreshSecurityEventsBtn');
    if (refresh && refresh.dataset.listener !== 'true') {
        refresh.addEventListener('click', () => loadSecurityEvents({ reset: true }));
        refresh.dataset.listener = 'true';
    }

    const category = document.getElementById('securityEventCategory');
    if (category && category.dataset.listener !== 'true') {
        category.addEventListener('change', () => loadSecurityEvents({ reset: true }));
        category.dataset.listener = 'true';
    }

    const body = document.getElementById('securityEventsBody');
    if (body && body.dataset.listener !== 'true') {
        const open = target => {
            const row = target.closest('[data-event-id]');
            if (row) showSecurityEventDetail(securityState.events.find(event => event.id === row.dataset.eventId));
        };
        body.addEventListener('click', event => open(event.target));
        body.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(event.target); }
        });
        body.dataset.listener = 'true';
    }

    const modal = document.getElementById('securityEventModal');
    if (modal && modal.dataset.listener !== 'true') {
        modal.addEventListener('click', event => {
            if (event.target === modal || event.target.closest('[data-security-close]')) closeSecurityEventDetail();
        });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && modal.classList.contains('active')) closeSecurityEventDetail();
        });
        modal.dataset.listener = 'true';
    }
}

// reset=true: primera página (con resumen). reset=false: siguiente tanda al hacer scroll.
async function loadSecurityEvents({ reset = true } = {}) {
    const body = document.getElementById('securityEventsBody');
    if (!body) return;
    if (!reset && (securityState.loading || !securityState.nextCursor)) return;

    const requestId = ++securityState.requestId;
    securityState.loading = true;
    const refresh = document.getElementById('refreshSecurityEventsBtn');
    if (reset) {
        if (refresh) refresh.disabled = true;
        body.innerHTML = '<tr><td colspan="6" class="sec-muted"><span class="orders-load-more-spinner" aria-hidden="true"></span> Cargando eventos...</td></tr>';
    }

    try {
        const params = new URLSearchParams({ limit: String(SECURITY_PAGE_SIZE) });
        const category = document.getElementById('securityEventCategory')?.value || '';
        if (category) params.set('category', category);
        if (!reset) params.set('cursor', securityState.nextCursor);

        const response = await fetch(`${SECURITY_EVENTS_API_URL}?${params}`, { headers: await getAdminApiHeaders() });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const payload = await response.json();
        if (requestId !== securityState.requestId) return; // llegó una respuesta vieja

        const events = Array.isArray(payload.events) ? payload.events : [];
        securityState.events = reset ? events : securityState.events.concat(events);
        securityState.nextCursor = payload.nextCursor || null;
        if (reset && payload.summary) renderSecuritySummary(payload.summary);
        renderSecurityEvents();
    } catch (error) {
        console.warn('No se pudieron cargar eventos de seguridad:', error.message);
        if (reset) {
            setSecurityText('securityEventSummary', '');
            body.innerHTML = '<tr><td colspan="6" class="sec-muted">No se pudo cargar el registro. Revisa tu conexión y presiona "Actualizar".</td></tr>';
        } else {
            const sentinel = body.querySelector('[data-security-sentinel] td');
            if (sentinel) sentinel.textContent = 'No se pudieron cargar más eventos. Presiona "Actualizar" para reintentar.';
        }
    } finally {
        if (requestId === securityState.requestId) {
            securityState.loading = false;
            if (refresh) refresh.disabled = false;
        }
    }
}

function renderSecurityEvents() {
    const body = document.getElementById('securityEventsBody');
    if (!body) return;
    const events = securityState.events;

    setSecurityText('securityEventSummary', events.length
        ? `Mostrando ${events.length}${securityState.nextCursor ? '+' : ''} ${events.length === 1 ? 'evento' : 'eventos'}`
        : '');

    if (!events.length) {
        body.innerHTML = '<tr><td colspan="6" class="sec-muted">No hay eventos registrados con este filtro. 👍</td></tr>';
        return;
    }

    body.innerHTML = events.map(event => {
        const { meta, severity } = classifySecurityEvent(event);
        return `<tr class="sec-row" data-event-id="${escapeSecurityText(event.id)}" tabindex="0" title="Ver detalle">
            <td class="sec-date">${escapeSecurityText(formatSecurityEventDate(event.timestamp))}</td>
            <td><strong>${escapeSecurityText(meta.label)}</strong></td>
            <td><span class="sec-sev sec-sev--${escapeSecurityText(severity)}">${escapeSecurityText(SEVERITY_LABELS[severity] || 'Baja')}</span></td>
            <td class="sec-path"><code>${escapeSecurityText(event.method)} ${escapeSecurityText(event.path)}</code></td>
            <td>${escapeSecurityText(describeSecuritySource(event))}</td>
            <td><span class="sec-status">${Number(event.status) || '—'}</span></td>
        </tr>`;
    }).join('') + (securityState.nextCursor
        ? '<tr class="orders-load-more" data-security-sentinel><td colspan="6"><span class="orders-load-more-spinner" aria-hidden="true"></span> Cargando más eventos…</td></tr>'
        : '');

    observeSecuritySentinel(body);
}

function observeSecuritySentinel(body) {
    if (securityState.observer) securityState.observer.disconnect();
    const sentinel = body.querySelector('[data-security-sentinel]');
    if (!sentinel || !('IntersectionObserver' in window)) return;
    // La tabla vive en un cuadro con su propia barra: se cargan más eventos al acercarse al
    // final de ese cuadro (no al bajar por la página)
    const scrollBox = body.closest('.sec-table-scroll');
    securityState.observer = new IntersectionObserver(entries => {
        if (entries.some(entry => entry.isIntersecting)) loadSecurityEvents({ reset: false });
    }, { root: scrollBox || null, rootMargin: scrollBox ? '0px 0px 150px 0px' : '300px 0px' });
    securityState.observer.observe(sentinel);
}

function renderSecuritySummary(summary) {
    const bySeverity = summary.bySeverity || {};
    setSecurityText('securityMetricEvents', summary.last24h || 0);
    setSecurityText('securityMetricBlocked', summary.blocked || 0);
    setSecurityText('securityMetricHigh', (bySeverity.critical || 0) + (bySeverity.high || 0));
    setSecurityText('securityMetricIps', summary.suspiciousIps || 0);

    const breakdown = document.getElementById('securitySeverityBreakdown');
    if (breakdown) {
        breakdown.innerHTML = ['critical', 'high', 'medium', 'low'].map(level => `
            <span class="sec-sev sec-sev--${level}"><strong>${Number(bySeverity[level]) || 0}</strong> ${SEVERITY_LABELS[level]}</span>`).join('');
    }

    const causes = document.getElementById('securityCauses');
    if (causes) {
        const entries = Object.entries(summary.byAttackType || {}).sort((a, b) => b[1] - a[1]).slice(0, 5);
        causes.innerHTML = entries.length
            ? entries.map(([type, count]) => `<li><span>${escapeSecurityText((SECURITY_TYPES[type] || SECURITY_TYPES.unauthorized_access).label)}</span><strong>${Number(count) || 0}</strong></li>`).join('')
            : '<li class="sec-muted">Sin actividad sospechosa en las últimas 24 horas.</li>';
    }

    const alert = document.getElementById('securityAlert');
    if (alert) {
        const webhookIssues = Number(summary.byAttackType?.payment_webhook_rejected) || 0;
        alert.hidden = !webhookIssues;
        alert.textContent = webhookIssues
            ? `Hay ${webhookIssues} ${webhookIssues === 1 ? 'aviso' : 'avisos'} de Mercado Pago rechazados: revisa la clave del webhook (abre uno de esos eventos para ver cómo).`
            : '';
    }
}

function showSecurityEventDetail(event) {
    if (!event) return;
    const modal = document.getElementById('securityEventModal');
    const grid = document.getElementById('securityDetailGrid');
    if (!modal || !grid) return;
    const { meta, severity } = classifySecurityEvent(event);

    setSecurityText('securityDetailTitle', meta.label);
    setSecurityText('securityDetailSubtitle', `${formatSecurityEventDate(event.timestamp)} · Prioridad ${SEVERITY_LABELS[severity] || 'Baja'}`);
    setSecurityText('securityDetailLead', meta.lead);
    setSecurityText('securityRecommendation', meta.advice);
    grid.innerHTML = [
        ['Solicitud', `${event.method} ${event.path}`],
        ['Respuesta del servidor', `${event.status} · ${event.blocked ? 'Bloqueada' : 'Registrada para revisión'}`],
        ['Origen', describeSecuritySource(event)],
        ['Sitio de origen', event.origin || 'Sin encabezado de origen'],
        ['IP anonimizada', event.ipHash || 'No disponible'],
        ['ID de solicitud', event.requestId || event.id],
        ['Navegador / agente', event.userAgent || 'No informado']
    ].map(([label, value]) => `<div><dt>${escapeSecurityText(label)}</dt><dd>${escapeSecurityText(value)}</dd></div>`).join('');

    modal.classList.add('active');
    modal.querySelector('.close-modal')?.focus();
}

function closeSecurityEventDetail() {
    document.getElementById('securityEventModal')?.classList.remove('active');
}

function formatSecurityEventDate(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime())
        ? 'Fecha desconocida'
        : date.toLocaleString('es-CL', { timeZone: 'America/Santiago', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function escapeSecurityText(value) {
    return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function setupPageActions() {
    const viewStoreBtn = document.getElementById('adminDesarrolloViewStoreBtn');
    if (viewStoreBtn && viewStoreBtn.dataset.listener !== 'true') {
        viewStoreBtn.addEventListener('click', () => {
            window.location.href = '../index.html';
        });
        viewStoreBtn.dataset.listener = 'true';
    }

}

function notifyAdminDesarrollo(message, isError = false) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${isError ? 'var(--admin-error)' : 'var(--admin-success)'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        z-index: 3000;
        box-shadow: var(--admin-shadow-lg);
    `;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function updateHairAnalysisBadge(state) {
    const badge = document.getElementById('hairAnalysisStatusBadge');
    if (!badge) return;

    if (state === 'oculto') {
        badge.textContent = 'No visible';
        badge.style.background = '#ef4444';
        return;
    }

    if (state === 'solo_admin') {
        badge.textContent = 'Visible solo admin';
        badge.style.background = '#f59e0b';
        return;
    }

    badge.textContent = 'Visible';
    badge.style.background = '#10b981';
}

// Deriva el estado simple (visible/solo_admin/oculto) desde la configuración
// guardada en Firestore, que internamente sigue usando habilitada/visibilidad.
function getSimpleStateFromConfig(config) {
    if (config.habilitada === false) return 'oculto';
    if (config.visibilidad === 'solo_admin') return 'solo_admin';
    return 'visible';
}

function buildConfigFromSimpleState(state) {
    if (state === 'oculto') {
        return { habilitada: false, visibilidad: 'publico', mostrarEnInicio: false };
    }
    if (state === 'solo_admin') {
        return { habilitada: true, visibilidad: 'solo_admin', mostrarEnInicio: true };
    }
    return { habilitada: true, visibilidad: 'publico', mostrarEnInicio: true };
}

async function initHairAnalysisCard() {
    const stateSelect = document.getElementById('hairAnalysisVisibilityState');
    const saveBtn = document.getElementById('hairAnalysisSaveBtn');

    if (!stateSelect || !saveBtn) {
        return;
    }

    if (!window.firebaseData?.loadHairAnalysisConfig) {
        console.warn('⚠️ firebaseData.loadHairAnalysisConfig no está disponible');
        return;
    }

    let currentConfig = { habilitada: true, visibilidad: 'publico', mostrarEnInicio: true };

    try {
        const remoteConfig = await window.firebaseData.loadHairAnalysisConfig();
        currentConfig = { ...currentConfig, ...(remoteConfig || {}) };
    } catch (error) {
        console.warn('⚠️ No se pudo cargar configuración de análisis capilar:', error.message);
    }

    const simpleState = getSimpleStateFromConfig(currentConfig);
    stateSelect.value = simpleState;
    updateHairAnalysisBadge(simpleState);

    if (saveBtn.dataset.listener === 'true') {
        return;
    }

    saveBtn.addEventListener('click', async () => {
        const nextConfig = buildConfigFromSimpleState(stateSelect.value);

        saveBtn.disabled = true;
        try {
            await window.firebaseData.saveHairAnalysisConfig(nextConfig);
            updateHairAnalysisBadge(stateSelect.value);
            notifyAdminDesarrollo('✅ Configuración guardada correctamente');
        } catch (error) {
            console.error('❌ Error guardando configuración de análisis capilar:', error);
            notifyAdminDesarrollo('❌ No se pudo guardar la configuración', true);
        } finally {
            saveBtn.disabled = false;
        }
    });

    saveBtn.dataset.listener = 'true';
}

async function checkAdminAuth() {
    const userLS = JSON.parse(localStorage.getItem('hairia_current_user') || 'null');
    const userSS = JSON.parse(sessionStorage.getItem('hairia_current_user') || 'null');
    const user = userLS || userSS;

    if (!user || !user.uid) {
        console.log('⚠️ No hay usuario, redirigiendo a login...');
        window.location.href = '../login.html';
        return false;
    }

    if (!window.firebase || typeof window.firebase.isUserAdmin !== 'function') {
        console.error('❌ Verificación admin no disponible');
        window.location.href = '../login.html';
        return false;
    }

    try {
        const isAdmin = await window.firebase.isUserAdmin(user.uid);
        if (!isAdmin) {
            console.log('❌ Usuario no es admin, redirigiendo a inicio...');
            window.location.href = '../index.html';
            return false;
        }

        if (user.role !== 'admin') {
            user.role = 'admin';
            if (userLS) {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
                localStorage.removeItem('hairia_current_user');
            } else {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
            }
        }

        return true;
    } catch (error) {
        console.warn('⚠️ No se pudo verificar admin en Firebase:', error);
        window.location.href = '../login.html';
        return false;
    }
}


