// admin-orders.js - Gestión de Órdenes para Admin
console.log('🔥 admin-orders.js cargado');

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM cargado');
    initializeAdminOrders();
});

let allOrders = [];
let filterDebounceTimer = null;
const FILTER_DEBOUNCE_MS = 180;
const CHILE_TIMEZONE = 'America/Santiago';
let selectedOrdersWeek = '';

// Estados que el admin gestiona. 'pending' (carritos nunca pagados) no se lista.
const ORDER_STATUS_META = {
    paid: { label: 'Pagada', hint: 'Lista para preparar y enviar' },
    shipped: { label: 'Enviada', hint: 'En camino al cliente' },
    delivered: { label: 'Entregada', hint: 'El cliente recibió su pedido' },
    cancelled: { label: 'Cancelada', hint: 'La orden fue anulada' },
    refunded: { label: 'Devuelta', hint: 'Se reembolsó el pago' }
};
const ORDER_FLOW_STEPS = ['paid', 'shipped', 'delivered'];

// Este mismo archivo sirve el panel de Bodega (admin/bodeguero.html, <body data-panel="warehouse">):
// mismas órdenes, popup, etiqueta y boleta, pero sin ingresos y guardando el estado con la
// escritura restringida de bodega (las reglas de Firestore limitan qué campos puede tocar).
const IS_WAREHOUSE_PANEL = document.body?.dataset?.panel === 'warehouse';

// Bodega prepara y despacha (igual que firestore.rules): parte de un pedido pagado, enviado o
// entregado y puede llevarlo a esos estados o cancelarlo. Reembolsar o reactivar un pedido
// cancelado lo hace el administrador desde su panel.
const WAREHOUSE_EDITABLE_FROM = ['paid', 'shipped', 'delivered'];
const WAREHOUSE_ALLOWED_TO = ['paid', 'shipped', 'delivered', 'cancelled'];

function getSelectableStatuses(currentStatus) {
    const all = Object.keys(ORDER_STATUS_META);
    if (!IS_WAREHOUSE_PANEL) return all;
    if (!WAREHOUSE_EDITABLE_FROM.includes(currentStatus)) return [];
    return all.filter(value => WAREHOUSE_ALLOWED_TO.includes(value));
}

// Carga por tandas: se pintan 15 órdenes y, al llegar al final de la tabla, 15 más.
const ORDERS_PAGE_SIZE = 15;
let ordersRenderLimit = ORDERS_PAGE_SIZE;
let lastDisplayedOrders = [];
let ordersScrollObserver = null;

// Período cargado: por defecto los últimos 30 días + todas las pagadas por enviar.
// El historial completo sigue en Firestore; se consulta por período o búsqueda.
const ORDERS_PERIOD_DAYS = { '30': 30, '90': 90, '365': 365 };
let statusCounts = null;
let lastSearchTerm = '';
const PANEL_TITLE = IS_WAREHOUSE_PANEL ? 'Bodega' : 'Monsite Admin';

function isVisibleOrder(order) {
    const status = String(order?.status || '').toLowerCase();
    const paymentStatus = String(order?.paymentStatus || '').toLowerCase();
    return Object.prototype.hasOwnProperty.call(ORDER_STATUS_META, status) || paymentStatus === 'approved';
}

function normalizeOrderStatus(status) {
    return ORDER_STATUS_META[status] ? status : 'paid';
}

function formatCLPAdmin(value) {
    return `$${(Number(value) || 0).toLocaleString('es-CL')}`;
}

function getOrderTotals(order) {
    if (order.totals) {
        return {
            subtotal: Number(order.totals.subtotal) || 0,
            shipping: Number(order.totals.shipping) || 0,
            discount: Number(order.totals.discount) || 0,
            total: Number(order.totals.total) || 0
        };
    }

    const subtotal = (order.items || []).reduce((sum, item) => sum + ((Number(item.price) || 0) * (Number(item.quantity) || 0)), 0);
    const shipping = Number(order.shipping) || 0;
    const discount = Number(order.discount) || 0;
    return { subtotal, shipping, discount, total: subtotal + shipping - discount };
}

// Enlace mailto solo para direcciones simples: un "?" o "&" en el correo del cliente podría
// rellenar asunto, cc o cuerpo en el programa de correo del admin.
function mailtoLink(email) {
    const value = String(email || '').trim();
    if (!value) return '—';
    if (!/^[^s@?&#%]+@[^s@?&#%]+$/.test(value)) return escapeHtml(value);
    return `<a href="mailto:${escapeAttr(value)}">${escapeHtml(value)}</a>`;
}

function escapeHtml(value) {
    const text = value == null ? '' : String(value);
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function escapeAttr(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
}

function sanitizeImageUrl(value) {
    if (typeof value !== 'string') {
        return '';
    }

    const trimmed = value.trim();
    if (!trimmed) {
        return '';
    }

    if (/^https?:\/\//i.test(trimmed) || /^data:image\//i.test(trimmed)) {
        // Comillas y <> no son válidas en una URL: se codifican para que no puedan salir del atributo src="..."
        return trimmed.replace(/"/g, '%22').replace(/'/g, '%27').replace(/</g, '%3C').replace(/>/g, '%3E').replace(/`/g, '%60');
    }

    return '';
}

// "2026-10-04" -> instante en que empieza ese día en Chile (respeta el horario de verano)
function chileMidnightIso(dateKey) {
    const [year, month, day] = String(dateKey).split('-').map(Number);
    const target = Date.UTC(year, month - 1, day);
    let timestamp = target;
    for (let attempt = 0; attempt < 2; attempt += 1) {
        const parts = new Intl.DateTimeFormat('en-US', {
            timeZone: CHILE_TIMEZONE, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'
        }).formatToParts(new Date(timestamp)).reduce((result, part) => ({ ...result, [part.type]: Number(part.value) }), {});
        const wall = Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute);
        timestamp -= wall - target;
    }
    // El día que empieza el horario de verano no existe la medianoche (de 23:59 se pasa a 01:00):
    // se avanza hasta el primer instante que ya pertenece a ese día
    while (getChileDateKey(new Date(timestamp)) < dateKey) timestamp += 60 * 60 * 1000;
    return new Date(timestamp).toISOString();
}

function getChileDateKey(dateInput) {
    const date = dateInput ? new Date(dateInput) : new Date();
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: CHILE_TIMEZONE,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(date);
}

function readOrdersFromStorage() {
    return Array.isArray(allOrders) ? allOrders : [];
}

function persistOrdersToStorage(orders) {
    allOrders = Array.isArray(orders) ? orders : [];
}

async function initializeAdminOrders() {
    console.log('🚀 Inicializando gestión de órdenes...');
    const hasAccess = await checkAdminAuth();
    if (!hasAccess) {
        return;
    }
    loadOrders();
    setupFilters();
    setupOrdersTableDelegation();
    setupOrderPageActions();
    console.log('✅ Gestión de órdenes inicializada');
}

function setupOrderPageActions() {
    const bindings = [
        { id: 'adminOrdersViewStoreBtn', handler: () => { window.location.href = '../index.html'; } },
        { id: 'orderDetailsCloseBtn', handler: hideOrderDetails },
        { id: 'orderDetailsCloseActionBtn', handler: hideOrderDetails },
        { id: 'orderPrintBtn', handler: printOrder },
        { id: 'orderReceiptBtn', handler: openAdminOrderReceipt }
    ];

    bindings.forEach(({ id, handler }) => {
        const element = document.getElementById(id);
        if (!element || element.dataset.listener === 'true') return;
        element.addEventListener('click', handler);
        element.dataset.listener = 'true';
    });

    setupModalOverlayClose();
}

function setupModalOverlayClose() {
    const modal = document.getElementById('orderDetailsModal');
    if (!modal || modal.dataset.overlayListener === 'true') return;

    modal.addEventListener('click', (event) => {
        if (event.target === modal) hideOrderDetails();
    });

    // Gestión de estado dentro del mismo popup de detalle
    modal.addEventListener('change', (event) => {
        if (event.target.id !== 'newOrderStatus') return;
        const saveButton = document.getElementById('orderStatusSaveBtn');
        const currentStatus = modal.dataset.currentStatus || '';
        if (saveButton) saveButton.disabled = event.target.value === currentStatus;
        // Al pasar a "Enviado": N° de Starken opcional (vacío si lo entregan ustedes)
        const courierField = document.getElementById('orderCourierField');
        if (courierField) courierField.hidden = !(event.target.value === 'shipped' && currentStatus !== 'shipped');
    });

    modal.addEventListener('click', (event) => {
        if (event.target.closest('#orderStatusSaveBtn')) updateOrderStatus();
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('active')) hideOrderDetails();
    });

    modal.dataset.overlayListener = 'true';
}

// Toda la fila abre el detalle de la orden (el botón "Ver" es solo un atajo visible)
function setupOrdersTableDelegation() {
    const tbody = document.getElementById('ordersTableBody');
    if (!tbody || tbody.dataset.delegated === 'true') {
        return;
    }

    tbody.addEventListener('click', (event) => {
        if (event.target.closest('[data-history-search]')) {
            searchOrdersInHistory(event.target.closest('[data-history-search]'));
            return;
        }
        const row = event.target.closest('tr[data-order-id]');
        if (!row) return;

        const orderId = decodeURIComponent(row.dataset.orderId || '');
        if (orderId) viewOrderDetails(orderId);
    });

    tbody.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter') return;
        const row = event.target.closest('tr[data-order-id]');
        if (row) viewOrderDetails(decodeURIComponent(row.dataset.orderId || ''));
    });

    tbody.dataset.delegated = 'true';
}

// Busca una orden antigua (número exacto o correo) y la suma a la lista cargada
async function searchOrdersInHistory(button) {
    const term = lastSearchTerm;
    if (!term || !window.firebaseData?.searchOrdersHistory) return;
    button.disabled = true;
    button.textContent = 'Buscando...';
    try {
        const found = await window.firebaseData.searchOrdersHistory(term);
        const visible = (found || []).filter(isVisibleOrder);
        if (!visible.length) {
            button.closest('td').innerHTML = `<strong>Sin resultados</strong><span>No hay ninguna orden pagada con el número o correo "${escapeHtml(term)}".</span>`;
            return;
        }
        const known = new Set(allOrders.map(order => String(order.id)));
        visible.forEach(order => { if (!known.has(String(order.id))) allOrders.push(enhanceOrderForList(order)); });
        // Mostrar exactamente lo encontrado, aunque el texto buscado no coincida parcialmente
        const ids = new Set(visible.map(order => String(order.id)));
        displayOrders(allOrders.filter(order => ids.has(String(order.id))));
        showNotification(`${visible.length} ${visible.length === 1 ? 'orden encontrada' : 'órdenes encontradas'} en el historial`);
    } catch (error) {
        console.error('Error buscando en el historial:', error);
        button.disabled = false;
        button.textContent = 'Reintentar búsqueda';
        showNotification('No se pudo buscar en el historial', 'error');
    }
}

async function checkAdminAuth() {
    const userLS = JSON.parse(localStorage.getItem('hairia_current_user') || 'null');
    const userSS = JSON.parse(sessionStorage.getItem('hairia_current_user') || 'null');
    const user = userLS || userSS;

    if (!user || !user.uid) {
        console.warn('⚠️ No hay sesión activa, redirigiendo a login');
        window.location.href = '../login.html';
        return false;
    }

    if (IS_WAREHOUSE_PANEL) {
        return checkWarehouseAuth(user);
    }

    if (!window.firebase || typeof window.firebase.isUserAdmin !== 'function') {
        console.error('❌ Verificación admin no disponible');
        showNotification('❌ No se pudo verificar permisos de administrador');
        window.location.href = '../login.html';
        return false;
    }

    try {
        const isAdmin = await window.firebase.isUserAdmin(user.uid);
        if (!isAdmin) {
            showNotification('❌ Acceso denegado: solo administradores');
            setTimeout(() => {
                window.location.href = '../index.html';
            }, 1200);
            return false;
        }

        if (user.role !== 'admin') {
            user.role = 'admin';
            if (userLS) {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
                localStorage.removeItem('hairia_current_user');
            } else {
                sessionStorage.setItem('hairia_current_user', JSON.stringify(user));
            }

        }

        console.log('✅ Acceso admin verificado desde Firebase');
        return true;
    } catch (error) {
        console.warn('⚠️ No se pudo verificar admin en Firebase:', error);
        showNotification('❌ Error verificando permisos de administrador');
        window.location.href = '../login.html';
        return false;
    }
}

// Bodega: pueden entrar bodegueros y administradores. La sesión se mantiene donde
// estaba (no se borra de localStorage) para poder ir y volver desde la tienda.
async function checkWarehouseAuth(user) {
    if (!window.firebase || typeof window.firebase.getUserRole !== 'function') {
        showNotification('No se pudo verificar el acceso', 'error');
        window.location.href = '../login.html';
        return false;
    }

    try {
        const role = await window.firebase.getUserRole(user.uid);
        if (role !== 'bodeguero' && role !== 'admin') {
            showNotification('Esta cuenta no tiene acceso a la bodega', 'error');
            setTimeout(() => { window.location.href = '../index.html'; }, 1200);
            return false;
        }

        if (user.role !== role) {
            const nextUser = JSON.stringify({ ...user, role });
            if (localStorage.getItem('hairia_current_user')) localStorage.setItem('hairia_current_user', nextUser);
            sessionStorage.setItem('hairia_current_user', nextUser);
        }
        return true;
    } catch (error) {
        console.error('❌ Error verificando acceso a bodega:', error);
        window.location.href = '../login.html';
        return false;
    }
}

function openAdminOrderReceipt() {
    const orderId = document.getElementById('orderDetailsModal')?.dataset?.orderId;
    const order = allOrders.find(item => String(item.id) === String(orderId));
    if (order && typeof window.openOrderReceipt === 'function') {
        window.openOrderReceipt(order);
    }
}

// Cargar órdenes desde Firebase o localStorage
// Rango de fechas elegido en el selector "Período"
function getSelectedOrdersRange() {
    const period = document.getElementById('ordersPeriod')?.value || '30';
    if (ORDERS_PERIOD_DAYS[period]) {
        return { sinceDays: ORDERS_PERIOD_DAYS[period], label: period === '365' ? 'los últimos 12 meses' : `los últimos ${period} días` };
    }
    if (period === 'all') return { since: null, label: 'todo el historial' };

    const from = document.getElementById('ordersFrom')?.value;
    const to = document.getElementById('ordersTo')?.value;
    // Los días se cuentan en hora de Chile, sin importar la zona horaria del computador
    const since = from ? chileMidnightIso(from) : null;
    let until = null;
    if (to) {
        const [year, month, day] = to.split('-').map(Number);
        const next = new Date(Date.UTC(year, month - 1, day + 1));
        until = chileMidnightIso(next.toISOString().slice(0, 10));
    }
    const format = value => new Date(`${value}T12:00:00`).toLocaleDateString('es-CL', { day: 'numeric', month: 'short', year: 'numeric' });
    const label = from && to ? `del ${format(from)} al ${format(to)}` : from ? `desde el ${format(from)}` : to ? `hasta el ${format(to)}` : 'todo el historial';
    // Con fechas elegidas se muestra exactamente ese período (sin sumar pendientes de hoy)
    return { since, until, label, includePendingShipment: false };
}

function updatePeriodNote(range, truncated) {
    const note = document.getElementById('ordersPeriodNote');
    if (!note) return;
    note.textContent = truncated
        ? `Se muestran las 2.000 órdenes más recientes de ${range.label}. Acota el período para ver las demás.`
        : `Mostrando ${range.label}${range.includePendingShipment === false || (range.since === null && !range.until) ? '' : ', más todos los pedidos pagados que faltan por enviar'}. ¿Buscas una venta anterior? Cambia el período o busca por número de orden o correo.`;
}

async function loadOrders() {
    console.log('📥 Cargando órdenes...');
    
    try {
        if (!window.firebaseData?.loadOrders) {
            throw new Error('firebaseData.loadOrders no disponible');
        }

        const range = getSelectedOrdersRange();
        if (window.firebaseData.loadOrdersForPanel) {
            const [result, counts] = await Promise.all([
                window.firebaseData.loadOrdersForPanel(range),
                window.firebaseData.countOrdersByStatus ? window.firebaseData.countOrdersByStatus().catch(() => null) : null
            ]);
            allOrders = result.orders || [];
            statusCounts = counts;
            updatePeriodNote(range, result.truncated);
        } else {
            allOrders = await window.firebaseData.loadOrders();
        }
        console.log('✅ Órdenes cargadas:', allOrders.length);

        allOrders = allOrders.map(enhanceOrderForList);
        
        console.log('📊 Total órdenes cargadas:', allOrders.length);
        setupOrdersWeekFilter();
        updateStats();
        applyFilters();
        window.dispatchEvent(new CustomEvent('monsite:orders-loaded', { detail: { orders: allOrders } }));
        
    } catch (error) {
        console.error('❌ Error cargando órdenes:', error);
        allOrders = [];
        updateStats();
        displayOrders(allOrders);
    }
}

function getOrderTotal(order) {
    if (order.totals?.total) {
        return order.totals.total;
    }

    if (order.total) {
        return order.total;
    }

    const itemsTotal = (order.items || []).reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = order.shipping || order.totals?.shipping || 0;
    const discount = order.discount || order.totals?.discount || 0;

    return itemsTotal + shipping - discount;
}

function enhanceOrderForList(order) {
    const firstName = order.shippingData?.firstName || '';
    const lastName = order.shippingData?.lastName || '';
    const email = order.userEmail || order.shippingData?.email || '';
    const phone = order.shippingData?.phone || '';
    // El número corto se indexa con y sin guiones (MO-4827-1936 / mo48271936)
    const code = String(order.trackingCode || '');
    const searchIndex = `${order.id || ''} ${code} ${code.replace(/-/g, '')} ${firstName} ${lastName} ${email} ${phone}`.toLowerCase();
    const sortTimestamp = order.createdAt ? new Date(order.createdAt).getTime() : 0;

    return {
        ...order,
        _searchIndex: searchIndex,
        _sortTimestamp: Number.isFinite(sortTimestamp) ? sortTimestamp : 0,
        _computedTotal: getOrderTotal(order)
    };
}

// Actualizar estadísticas
function updateStats() {
    // Excluir órdenes pendientes de las estadísticas
    const paidOrders = allOrders.filter(o => o.status !== 'pending');
    
    const total = paidOrders.length;
    const pending = 0; // Ya no mostramos pendientes
    const completed = paidOrders.filter(o => o.status === 'delivered').length;
    
    // Calcular ingresos totales (solo órdenes pagadas)
    const revenue = paidOrders
        .filter(o => o.status !== 'cancelled' && o.status !== 'refunded')
        .filter(o => !selectedOrdersWeek || getOrdersWeekStart(o.createdAt) === selectedOrdersWeek)
        .reduce((sum, o) => {
            // Intentar obtener el total de varias formas
            return sum + (o._computedTotal ?? getOrderTotal(o));
        }, 0);
    
    const setStat = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
    // Con statusCounts los contadores son de toda la base, no solo del período cargado
    const counts = statusCounts || {
        paid: paidOrders.filter(o => o.status === 'paid').length,
        shipped: paidOrders.filter(o => o.status === 'shipped').length,
        delivered: completed
    };
    const allTimeTotal = statusCounts ? Object.values(statusCounts).reduce((sum, value) => sum + (Number(value) || 0), 0) : total;
    setStat('totalOrders', allTimeTotal);
    setStat('pendingOrders', counts.paid || 0); // Pagadas pero no enviadas
    setStat('shippedOrders', counts.shipped || 0);
    setStat('completedOrders', counts.delivered || 0);
    setStat('totalRevenue', `$${revenue.toLocaleString('es-CL')}`);

    // Contar solo órdenes PAGADAS (que requieren ser enviadas)
    const needsAttention = counts.paid || 0;
    
    // Actualizar badge en el sidebar
    updateOrdersBadge(needsAttention);
    
    // Actualizar título del navegador si hay órdenes pagadas
    if (needsAttention > 0) {
        document.title = `(${needsAttention}) ${IS_WAREHOUSE_PANEL ? 'Por preparar' : 'Órdenes Pagadas'} - ${PANEL_TITLE}`;
    } else {
        document.title = `${IS_WAREHOUSE_PANEL ? 'Pedidos' : 'Gestión de Órdenes'} - ${PANEL_TITLE}`;
    }
}

function getOrdersWeekStart(dateInput) {
    const date = new Date(dateInput || Date.now());
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: CHILE_TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date).reduce((result, part) => ({ ...result, [part.type]: part.value }), {});
    const localDate = new Date(Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day)));
    const day = localDate.getUTCDay();
    localDate.setUTCDate(localDate.getUTCDate() - (day === 0 ? 6 : day - 1));
    return localDate.toISOString().slice(0, 10);
}

function formatOrdersWeek(weekStart) {
    const start = new Date(`${weekStart}T12:00:00Z`);
    const end = new Date(start);
    end.setUTCDate(start.getUTCDate() + 6);
    const format = date => date.toLocaleDateString('es-CL', { timeZone: CHILE_TIMEZONE, day: 'numeric', month: 'short' });
    return `${format(start)} - ${format(end)}`;
}

function setupOrdersWeekFilter() {
    const select = document.getElementById('ordersWeekFilter');
    if (!select) return;
    const weeks = [...new Set(allOrders.map(order => getOrdersWeekStart(order.createdAt)))];
    const currentWeek = getOrdersWeekStart();
    // Con un período antiguo cargado, "Esta semana" daría $0: se elige la semana más reciente cargada
    if (!weeks.length) weeks.push(currentWeek);
    weeks.sort().reverse();
    select.innerHTML = weeks.map(week => `<option value="${week}">${week === currentWeek ? 'Esta semana' : formatOrdersWeek(week)}</option>`).join('');
    selectedOrdersWeek = weeks[0];
    select.value = selectedOrdersWeek;
    if (select.dataset.listener !== 'true') {
        select.addEventListener('change', () => { selectedOrdersWeek = select.value; updateStats(); });
        select.dataset.listener = 'true';
    }
}

// Actualizar badge de notificaciones en el sidebar
function updateOrdersBadge(count) {
    // Buscar el enlace de órdenes en el sidebar
    const ordersLink = document.querySelector('a[href="admin-orders.html"], #warehouseNavOrders');
    if (!ordersLink) return;
    
    // Eliminar badge anterior si existe
    const existingBadge = ordersLink.querySelector('.notification-badge');
    if (existingBadge) {
        existingBadge.remove();
    }
    
    // Si hay órdenes pendientes, agregar badge
    if (count > 0) {
        const badge = document.createElement('span');
        badge.className = 'notification-badge';
        badge.textContent = count > 99 ? '99+' : count;
        ordersLink.appendChild(badge);
    }
    
    // Actualizar badge en todas las páginas admin (localStorage para compartir)
    if (IS_WAREHOUSE_PANEL) return;
    localStorage.setItem('hairia_pending_orders_count', count.toString());
    
    // Disparar evento personalizado para actualizar en otras páginas
    window.dispatchEvent(new CustomEvent('ordersCountUpdated', { detail: { count } }));
}

// Mostrar órdenes en la tabla
function displayOrders(orders) {
    const tbody = document.getElementById('ordersTableBody');
    if (!tbody) return;
    lastDisplayedOrders = orders || [];

    const visibleOrders = (orders || []).filter(isVisibleOrder);

    if (visibleOrders.length === 0) {
        const canSearchHistory = lastSearchTerm.length >= 6 || lastSearchTerm.includes('@');
        tbody.innerHTML = canSearchHistory
            ? `
            <tr>
                <td colspan="8" class="orders-empty">
                    <strong>No está en el período cargado</strong>
                    <span>Puedes buscar "${escapeHtml(lastSearchTerm)}" en todo el historial (número de orden exacto o correo del cliente).</span>
                    <button type="button" class="btn-secondary orders-history-btn" data-history-search>Buscar en todo el historial</button>
                </td>
            </tr>`
            : `
            <tr>
                <td colspan="8" class="orders-empty">
                    <strong>No hay órdenes para mostrar</strong>
                    <span>${lastSearchTerm ? 'Prueba con otra búsqueda o cambia el período.' : 'Cuando entre una compra pagada aparecerá aquí.'}</span>
                </td>
            </tr>
        `;
        return;
    }

    // Más recientes primero, agrupadas por día (hora de Chile). Los conteos por día
    // usan todas las órdenes; solo se pintan las primeras ordersRenderLimit.
    const sortedOrders = [...visibleOrders].sort((a, b) => (b._sortTimestamp || 0) - (a._sortTimestamp || 0));
    const dayStats = {};
    sortedOrders.forEach(order => {
        const dateKey = getChileDateKey(order.createdAt);
        const stats = dayStats[dateKey] = dayStats[dateKey] || { count: 0, total: 0 };
        stats.count += 1;
        if (order.status !== 'cancelled' && order.status !== 'refunded') {
            stats.total += order._computedTotal ?? getOrderTotal(order);
        }
    });
    const renderedOrders = sortedOrders.slice(0, ordersRenderLimit);
    const ordersByDate = {};
    renderedOrders.forEach(order => {
        const dateKey = getChileDateKey(order.createdAt);
        (ordersByDate[dateKey] = ordersByDate[dateKey] || []).push(order);
    });

    const todayKey = getChileDateKey(new Date());
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = getChileDateKey(yesterday);

    let html = '';
    Object.keys(ordersByDate).sort().reverse().forEach(dateKey => {
        const ordersInDay = ordersByDate[dateKey];
        const referenceDate = new Date(ordersInDay[0]?.createdAt || Date.now());
        const longDate = referenceDate.toLocaleDateString('es-CL', { timeZone: CHILE_TIMEZONE, weekday: 'long', day: 'numeric', month: 'long' });
        const prefix = dateKey === todayKey ? 'Hoy · ' : dateKey === yesterdayKey ? 'Ayer · ' : '';
        const dayCount = dayStats[dateKey].count;
        const dayTotal = dayStats[dateKey].total;

        html += `
            <tr class="date-separator">
                <td colspan="8">
                    <span class="date-separator-label">${escapeHtml(prefix + longDate)}</span>
                    <span class="date-separator-meta">${dayCount} orden${dayCount !== 1 ? 'es' : ''}${IS_WAREHOUSE_PANEL ? '' : ` · ${formatCLPAdmin(dayTotal)}`}</span>
                </td>
            </tr>
        `;

        ordersInDay.forEach(order => {
            const orderTotal = order._computedTotal ?? getOrderTotal(order);
            const orderId = String(order.id || '');
            const encodedOrderId = encodeURIComponent(orderId);
            const fullName = `${order.shippingData?.firstName || ''} ${order.shippingData?.lastName || ''}`.trim() || 'Cliente';
            const email = order.userEmail || order.shippingData?.email || 'Sin email';
            const phone = order.shippingData?.phone || '—';
            const itemsCount = (order.items || []).reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);

            html += `
            <tr class="order-row" data-order-id="${encodedOrderId}" tabindex="0" title="Ver detalle de la orden">
                <td><span class="order-id-chip" title="${escapeAttr(orderId)}">${order.trackingCode ? escapeHtml(order.trackingCode) : `#${escapeHtml(orderId.slice(0, 10))}`}</span>${order.billing?.documentType === 'factura' ? ' <span class="order-invoice-badge" title="El cliente pidió factura">Factura</span>' : ''}</td>
                <td>
                    <div class="order-customer-name" title="${escapeAttr(fullName)}">${escapeHtml(fullName)}</div>
                    <div class="order-customer-email" title="${escapeAttr(email)}">${escapeHtml(email)}</div>
                </td>
                <td><span class="order-phone" title="${escapeAttr(phone)}">${escapeHtml(phone)}</span></td>
                <td>${itemsCount} ${itemsCount === 1 ? 'unidad' : 'unidades'}</td>
                <td><strong>${formatCLPAdmin(orderTotal)}</strong></td>
                <td>${getStatusBadge(order.status)}</td>
                <td>${formatTime(order.createdAt)}</td>
                <td><button type="button" class="order-view-btn" tabindex="-1">Ver <span aria-hidden="true">→</span></button></td>
            </tr>
            `;
        });
    });

    const remaining = sortedOrders.length - renderedOrders.length;
    if (remaining > 0) {
        html += `
            <tr class="orders-load-more" data-orders-sentinel>
                <td colspan="8"><span class="orders-load-more-spinner" aria-hidden="true"></span> Cargando más órdenes… <small>(${remaining} restantes)</small></td>
            </tr>`;
    }

    tbody.innerHTML = html;
    observeOrdersSentinel(tbody);
}

// Al ver la fila "Cargando más…" (300 px antes), se pintan 15 órdenes más
function observeOrdersSentinel(tbody) {
    if (ordersScrollObserver) ordersScrollObserver.disconnect();
    const sentinel = tbody.querySelector('[data-orders-sentinel]');
    if (!sentinel || !('IntersectionObserver' in window)) return;

    ordersScrollObserver = new IntersectionObserver(entries => {
        if (!entries.some(entry => entry.isIntersecting)) return;
        ordersScrollObserver.disconnect();
        ordersRenderLimit += ORDERS_PAGE_SIZE;
        displayOrders(lastDisplayedOrders);
    }, { rootMargin: '300px 0px' });
    ordersScrollObserver.observe(sentinel);
}

// Formatear solo la hora (para órdenes del mismo día)
function formatTime(dateString) {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleTimeString('es-CL', {
        timeZone: CHILE_TIMEZONE,
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Pastilla de estado (colores definidos en admin-refresh.css)
function getStatusBadge(status) {
    const normalized = normalizeOrderStatus(status);
    return `<span class="order-status order-status--${normalized}">${ORDER_STATUS_META[normalized].label}</span>`;
}

// Formatear fecha
function formatDate(dateString) {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleDateString('es-CL', {
        timeZone: CHILE_TIMEZONE,
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function renderOrderProgress(status) {
    if (status === 'cancelled' || status === 'refunded') {
        return `<div class="order-progress-note order-progress-note--${status}">
            <strong>${ORDER_STATUS_META[status].label}</strong> · ${ORDER_STATUS_META[status].hint}
        </div>`;
    }

    const currentIndex = ORDER_FLOW_STEPS.indexOf(status);
    return `<ol class="order-progress">
        ${ORDER_FLOW_STEPS.map((step, index) => `
            <li class="order-progress-step${index < currentIndex ? ' is-done' : ''}${index === currentIndex ? ' is-current' : ''}">
                <span class="order-progress-dot">${index < currentIndex ? '✓' : index + 1}</span>
                <span class="order-progress-text">
                    <strong>${ORDER_STATUS_META[step].label}</strong>
                    <small>${ORDER_STATUS_META[step].hint}</small>
                </span>
            </li>
        `).join('')}
    </ol>`;
}

// Ver detalles de orden (único popup: detalle + gestión de estado + documentos)
function viewOrderDetails(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (!order) return;

    const status = normalizeOrderStatus(order.status);
    const shipping = order.shippingData || {};
    const totals = getOrderTotals(order);
    const fullName = `${shipping.firstName || ''} ${shipping.lastName || ''}`.trim() || 'Cliente';
    const email = order.userEmail || shipping.email || '';
    const phone = shipping.phone || '';
    const phoneDigits = String(phone).replace(/[^\d+]/g, '');
    const whatsappNumber = phoneDigits.replace(/^\+/, '');

    const modal = document.getElementById('orderDetailsModal');
    const content = document.getElementById('orderDetailsContent');
    if (!modal || !content) return;

    modal.dataset.orderId = order.id || '';
    modal.dataset.currentStatus = status;

    const title = document.getElementById('orderModalTitle');
    if (title) {
        title.innerHTML = `Orden <span class="order-id-chip" title="${escapeAttr(String(order.id || ''))}">${order.trackingCode ? escapeHtml(order.trackingCode) : `#${escapeHtml(String(order.id || '').slice(0, 12))}`}</span> ${getStatusBadge(status)}`;
    }
    const subtitle = document.getElementById('orderModalSubtitle');
    if (subtitle) subtitle.textContent = `Comprada el ${formatDate(order.createdAt)}`;

    content.innerHTML = `
        <section class="order-section">
            <div class="order-section-head">
                <h4>Estado del pedido</h4>
            </div>
            ${renderOrderProgress(status)}
            ${(() => {
                const selectable = getSelectableStatuses(status);
                if (!selectable.length) {
                    return `<p class="order-status-locked">Este pedido está <strong>${escapeHtml(ORDER_STATUS_META[status]?.label || status)}</strong>: solo un administrador puede cambiar su estado.</p>`;
                }
                return `
            <div class="order-status-editor">
                <label for="newOrderStatus">Cambiar a</label>
                <select id="newOrderStatus">
                    ${selectable.map(value => `
                        <option value="${value}"${value === status ? ' selected' : ''}>${ORDER_STATUS_META[value].label} — ${ORDER_STATUS_META[value].hint}</option>
                    `).join('')}
                </select>
                <button type="button" id="orderStatusSaveBtn" class="btn-primary" disabled>Guardar estado</button>
            </div>
            ${selectable.includes('shipped') && status !== 'shipped' ? `
            <div class="order-courier-field" id="orderCourierField" hidden>
                <label for="orderCourierCode">N° de seguimiento Starken <span>(opcional)</span></label>
                <input type="text" id="orderCourierCode" maxlength="40" autocomplete="off" spellcheck="false" placeholder="Ej: 123456789">
                <small>Si va por Starken, el cliente recibe el enlace directo para seguirlo. Si lo entregan ustedes, déjalo vacío.</small>
            </div>` : ''}`;
            })()}
        </section>

        <div class="order-info-grid">
            <section class="order-section order-card">
                <h4>Cliente</h4>
                <dl class="order-dl">
                    <div><dt>Nombre</dt><dd>${escapeHtml(fullName)}</dd></div>
                    <div><dt>RUT</dt><dd>${escapeHtml(shipping.rut ? formatRut(shipping.rut) : '—')}</dd></div>
                    <div><dt>Email</dt><dd>${mailtoLink(email)}</dd></div>
                    <div><dt>Teléfono</dt><dd>${phone
                        ? `<a href="tel:${escapeAttr(phoneDigits)}">${escapeHtml(phone)}</a>${whatsappNumber ? ` · <a href="https://wa.me/${escapeAttr(whatsappNumber)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}`
                        : '—'}</dd></div>
                </dl>
            </section>

            <section class="order-section order-card">
                <h4>Envío</h4>
                <p class="order-address">
                    <strong>${escapeHtml(shipping.street || 'Dirección no indicada')}${shipping.apartment ? ', ' + escapeHtml(shipping.apartment) : ''}</strong>
                    <span>${escapeHtml(shipping.city || 'Comuna no indicada')}, ${escapeHtml(shipping.region || 'Región no indicada')}</span>
                </p>
                ${shipping.notes ? `<p class="order-notes"><span>Nota del cliente</span>${escapeHtml(shipping.notes)}</p>` : ''}
                ${order.courier === 'starken' && order.courierTrackingCode ? `<p class="order-notes"><span>Enviado por Starken</span><a href="${escapeAttr(starkenTrackingUrl(order.courierTrackingCode))}" target="_blank" rel="noopener">N° ${escapeHtml(order.courierTrackingCode)}</a></p>` : ''}
            </section>
        </div>

        ${order.billing?.documentType === 'factura' ? `
        <section class="order-section order-card order-invoice">
            <h4>Factura solicitada</h4>
            <dl class="order-dl">
                <div><dt>Razón social</dt><dd>${escapeHtml(order.billing.businessName || '—')}</dd></div>
                <div><dt>RUT empresa</dt><dd>${escapeHtml(order.billing.rut || '—')}</dd></div>
                <div><dt>Giro</dt><dd>${escapeHtml(order.billing.businessActivity || '—')}</dd></div>
                <div><dt>Dirección</dt><dd>${escapeHtml([order.billing.address, order.billing.city].filter(Boolean).join(', ') || '—')}</dd></div>
                <div><dt>Enviar a</dt><dd>${mailtoLink(order.billing.email)}</dd></div>
            </dl>
        </section>` : ''}

        <section class="order-section">
            <div class="order-section-head">
                <h4>Productos</h4>
                <span class="order-section-meta">${(order.items || []).length} ${((order.items || []).length === 1) ? 'producto' : 'productos'}</span>
            </div>
            <ul class="order-items">
                ${(order.items || []).map(item => {
                    const safeItemName = escapeHtml(item.name || 'Producto');
                    const safeItemImage = sanitizeImageUrl(item.image);
                    const quantity = Number(item.quantity) || 0;
                    const price = Number(item.price) || 0;
                    return `
                    <li class="order-item">
                        ${safeItemImage
                            ? `<img src="${safeItemImage}" alt="${safeItemName}" class="order-item-thumb" loading="lazy">`
                            : '<span class="order-item-thumb order-item-thumb--empty" aria-hidden="true">📦</span>'}
                        <div class="order-item-info">
                            <strong>${safeItemName}</strong>
                            <small>${item.sku ? `SKU ${escapeHtml(item.sku)} · ` : ''}${quantity} × ${formatCLPAdmin(price)}</small>
                        </div>
                        <strong class="order-item-total">${formatCLPAdmin(price * quantity)}</strong>
                    </li>`;
                }).join('')}
            </ul>

            <dl class="order-summary">
                <div><dt>Subtotal</dt><dd>${formatCLPAdmin(totals.subtotal)}</dd></div>
                <div><dt>Envío</dt><dd>${totals.shipping > 0 ? formatCLPAdmin(totals.shipping) : 'Gratis'}</dd></div>
                ${totals.discount > 0 ? `<div class="order-summary-discount"><dt>Descuento</dt><dd>−${formatCLPAdmin(totals.discount)}</dd></div>` : ''}
                <div class="order-summary-total"><dt>Total pagado</dt><dd>${formatCLPAdmin(totals.total)}</dd></div>
            </dl>
        </section>
    `;

    modal.classList.add('active');
    document.body.classList.add('modal-open');
}

// Función auxiliar para imprimir por ID
function printOrderById(orderId) {
    const order = allOrders.find(o => o.id === orderId);
    if (order) {
        generateShippingLabel(order);
    }
}

function hideOrderDetails() {
    const modal = document.getElementById('orderDetailsModal');
    if (!modal) return;

    modal.classList.remove('active');
    document.body.classList.remove('modal-open');
    delete modal.dataset.orderId;
    delete modal.dataset.currentStatus;
}

// Seguimiento de Starken con el número del envío
const STARKEN_CODE_PATTERN = /^[A-Z0-9-]{4,40}$/;
const starkenTrackingUrl = code => `https://www.starken.cl/seguimiento?codigo=${encodeURIComponent(code)}`;

// Texto corto sobre el correo al cliente tras cambiar el estado
function describeEmailResult(email) {
    if (!email) return '';
    if (email.sent) return ' · Le avisamos al cliente por correo';
    if (email.skipped) return ' · El cliente ya había recibido este aviso';
    if (email.reason === 'email_disabled') return ' · El envío de correos no está configurado';
    return ' · No se pudo enviar el correo al cliente';
}

// Cambiar estado desde el popup de detalle. Actualiza Firebase y la vista local
// sin volver a descargar todas las órdenes.
async function updateOrderStatus() {
    const modal = document.getElementById('orderDetailsModal');
    const orderId = modal?.dataset?.orderId;
    const select = document.getElementById('newOrderStatus');
    const saveButton = document.getElementById('orderStatusSaveBtn');
    const newStatus = select?.value;

    const order = allOrders.find(o => o.id === orderId);
    if (!order || !newStatus || newStatus === order.status) return;
    if (!getSelectableStatuses(order.status).includes(newStatus)) return;

    // N° de Starken (opcional): solo al pasar a "Enviado"
    const courierTrackingCode = newStatus === 'shipped'
        ? String(document.getElementById('orderCourierCode')?.value || '').toUpperCase().replace(/\s+/g, '')
        : '';
    if (courierTrackingCode && !STARKEN_CODE_PATTERN.test(courierTrackingCode)) {
        showNotification('El N° de Starken solo puede tener letras, números y guiones (4 a 40).', 'error');
        document.getElementById('orderCourierCode')?.focus();
        return;
    }
    const courierData = courierTrackingCode ? { courierTrackingCode } : {};

    if ((newStatus === 'cancelled' || newStatus === 'refunded')
        && !confirm(`¿Marcar la orden como "${ORDER_STATUS_META[newStatus].label}"? El cliente verá este estado en su cuenta.`)) {
        select.value = order.status;
        if (saveButton) saveButton.disabled = true;
        return;
    }

    if (saveButton) {
        saveButton.disabled = true;
        saveButton.textContent = 'Guardando...';
    }

    try {
        let result = null;
        if (IS_WAREHOUSE_PANEL) {
            // Bodega: solo cambia el estado (y quién lo hizo); no toca pago ni totales
            const sessionUser = JSON.parse(localStorage.getItem('hairia_current_user') || sessionStorage.getItem('hairia_current_user') || 'null');
            result = await window.firebaseData.updateOrderWarehouseData(orderId, {
                status: newStatus,
                warehouseUpdatedBy: window.firebase?.auth?.currentUser?.uid || sessionUser?.uid || '',
                ...courierData
            });
        } else if (window.firebaseData?.updateOrderStatus) {
            result = await window.firebaseData.updateOrderStatus(orderId, newStatus, courierData);
        }

        order.status = newStatus;
        if (courierTrackingCode) Object.assign(order, { courier: 'starken', courierTrackingCode });
        order.updatedAt = new Date().toISOString();

        updateStats();
        applyFilters({ keepLimit: true });
        viewOrderDetails(orderId);
        showNotification(`Estado actualizado: ${ORDER_STATUS_META[newStatus].label}${describeEmailResult(result?.email)}`,
            result?.email && !result.email.sent && !result.email.skipped ? 'warning' : 'success');
    } catch (error) {
        console.error('❌ Error actualizando estado:', error);
        showNotification('No se pudo actualizar el estado. Inténtalo de nuevo.', 'error');
        if (saveButton) {
            saveButton.disabled = false;
            saveButton.textContent = 'Guardar estado';
        }
    }
}

// Imprimir etiqueta de envío de la orden abierta en el popup
function printOrder() {
    const orderId = document.getElementById('orderDetailsModal')?.dataset?.orderId;
    const order = allOrders.find(o => o.id === orderId);
    if (!order) {
        showNotification('No se pudo identificar la orden', 'error');
        return;
    }

    generateShippingLabel(order);
}

// Generar etiqueta de envío
function generateShippingLabel(order) {
    // Calcular total
    let orderTotal = 0;
    if (order.totals?.total) {
        orderTotal = order.totals.total;
    } else if (order.total) {
        orderTotal = order.total;
    } else {
        const itemsTotal = (order.items || []).reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const shipping = order.shipping || order.totals?.shipping || 0;
        const discount = order.discount || order.totals?.discount || 0;
        orderTotal = itemsTotal + shipping - discount;
    }
    
    // La ventana se abre YA (dentro del clic); si se abre después de una descarga
    // asíncrona, el navegador la bloquea como popup no solicitado.
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    if (!printWindow) {
        showNotification('El navegador bloqueó la ventana de impresión. Permite ventanas emergentes para este sitio.', 'error');
        return;
    }
    printWindow.document.write('<p style="font-family:sans-serif;padding:2rem;color:#555">Preparando etiqueta de envío…</p>');

    // Cargar el logo como base64
    const logoUrl = new URL('../images/logo.jpg', window.location.href).href;
    fetch(logoUrl)
        .then(response => response.blob())
        .then(blob => {
            const reader = new FileReader();
            reader.onloadend = function() {
                const logoBase64 = reader.result;
                generateLabelHTML(order, orderTotal, logoBase64);
            };
            reader.readAsDataURL(blob);
        })
        .catch(() => {
            // Si falla cargar la imagen, generar sin logo
            generateLabelHTML(order, orderTotal, null);
        });

    function generateLabelHTML(order, orderTotal, logoBase64) {
        if (printWindow.closed) return;
        printWindow.document.open();

        const safeOrderId = escapeHtml(String(order.id || 'N/A'));
        const safeOrderIdShort = escapeHtml(String(order.id || 'N/A').substring(0, 12));
        const safeFirstName = escapeHtml(String(order.shippingData?.firstName || 'CLIENTE'));
        const safeLastName = escapeHtml(String(order.shippingData?.lastName || ''));
        const safeStreet = escapeHtml(String(order.shippingData?.street || 'Dirección'));
        const safeApartment = escapeHtml(String(order.shippingData?.apartment || ''));
        const safeRut = escapeHtml(String(formatRut(order.shippingData?.rut)));
        const safePhone = escapeHtml(String(order.shippingData?.phone || 'N/A'));
        const safeCity = escapeHtml(String(order.shippingData?.city || 'Ciudad'));
        const safeRegion = escapeHtml(String(order.shippingData?.region || 'Región'));
        const safeStatusText = escapeHtml(String(getStatusText(order.status)));
        const safeLogo = typeof logoBase64 === 'string' && /^data:image\//i.test(logoBase64) ? logoBase64 : '';

        const safeItems = (order.items || []).map(item => ({
            quantity: Number(item.quantity) || 0,
            name: escapeHtml(String(item.name || 'Producto'))
        }));
        
        const labelHTML = `
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Etiqueta de Envío - ${safeOrderId}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            width: 100%;
            height: 100%;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            margin: 0;
        }
        
        .shipping-label {
            /* Tamaño de etiqueta compacta: 80x120mm */
            width: 80mm;
            height: 120mm;
            border: 2px solid #000;
            padding: 4mm;
            background: white;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            font-size: 10px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 4mm;
            padding-bottom: 3mm;
            border-bottom: 2px solid #000;
            gap: 3mm;
        }
        
        .logo {
            width: 18mm;
            height: auto;
            max-height: 16mm;
            flex-shrink: 0;
        }
        
        .header-right {
            text-align: right;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 2mm;
        }
        
        .delivery-date {
            font-size: 9px;
        }
        
        .delivery-date .label {
            display: block;
            font-size: 7px;
            color: #666;
        }
        
        .delivery-date .value {
            font-size: 12px;
            font-weight: bold;
        }
        
        .order-id {
            font-weight: bold;
        }
        
        .order-id .label {
            font-size: 7px;
            display: block;
            color: #666;
        }
        
        .order-id .value {
            border: 1px solid #000;
            padding: 1mm 2mm;
            display: inline-block;
            font-size: 8px;
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }
        
        .from-section {
            font-size: 8px;
            margin-bottom: 3mm;
            padding: 2mm 3mm;
            border: 1px solid #999;
            background: #f8f8f8;
            line-height: 1.2;
        }
        
        .from-title {
            font-weight: bold;
            font-size: 7px;
            text-transform: uppercase;
            margin-bottom: 1mm;
        }
        
        .recipient-section {
            flex: 1;
            display: flex;
            flex-direction: column;
            margin-bottom: 3mm;
            min-height: 0;
        }
        
        .recipient-title {
            font-weight: bold;
            font-size: 7px;
            text-transform: uppercase;
            margin-bottom: 1mm;
        }
        
        .recipient-box {
            border: 1px solid #000;
            padding: 3mm;
            background: white;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow: hidden;
        }
        
        .recipient-name {
            font-size: 11px;
            font-weight: bold;
            margin-bottom: 2mm;
            line-height: 1.1;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .recipient-address {
            font-size: 8px;
            line-height: 1.2;
            overflow: hidden;
        }
        
        .recipient-city {
            font-size: 8px;
            font-weight: bold;
            border-top: 1px solid #ddd;
            padding-top: 1mm;
            margin-top: 1mm;
        }
        
        .contents {
            font-size: 7px;
            line-height: 1.2;
            padding: 2mm;
            border: 1px solid #999;
            background: #fafafa;
            margin-bottom: 3mm;
            max-height: 18mm;
            overflow-y: auto;
        }
        
        .contents-title {
            font-weight: bold;
            font-size: 7px;
            text-transform: uppercase;
            margin-bottom: 1mm;
        }
        
        .contents-item {
            margin-bottom: 0.5mm;
        }
        
        .tracking-box {
            text-align: center;
            border: 2px dashed #000;
            padding: 3mm 2mm;
            margin-bottom: 2mm;
            flex-shrink: 0;
        }
        
        .tracking-label {
            font-size: 7px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 1mm;
        }
        
        .tracking-code {
            font-size: 13px;
            font-weight: bold;
            letter-spacing: 0.5px;
            font-family: 'Courier New', monospace;
            margin-bottom: 1mm;
            word-break: break-all;
        }
        
        .tracking-status {
            font-size: 7px;
            font-weight: bold;
        }
        
        .footer {
            text-align: center;
            font-size: 6px;
            color: #666;
            border-top: 1px solid #999;
            padding-top: 1mm;
        }
        
        @media print {
            body {
                padding: 0;
                margin: 0;
                background: white;
            }
            
            .shipping-label {
                box-shadow: none;
                page-break-after: always;
            }
            
            @page {
                size: 100mm 150mm;
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="shipping-label">
        <!-- Header con Logo y Fecha -->
        <div class="header">
            ${safeLogo ? `<img src="${safeLogo}" alt="Monsite Logo" class="logo">` : '<div style="width: 18mm; font-weight: bold;">MONSITE</div>'}
            <div class="header-right">
                <div class="delivery-date">
                    <span class="label">ENTREGA:</span>
                    <span class="value">${new Date().toLocaleDateString('es-CL', { timeZone: CHILE_TIMEZONE, day: '2-digit', month: 'short' }).toUpperCase()}</span>
                </div>
                <div class="order-id">
                    <span class="label">ORDEN:</span>
                    <div class="value">${safeOrderIdShort}</div>
                </div>
            </div>
        </div>
        
        <!-- Remitente -->
        <div class="from-section">
            <div class="from-title">De:</div>
            <div><strong>Monsite</strong></div>
            <div>Belleza & Cuidado Capilar</div>
            <div>Padre Leon Dehon 6190</div>
            <div>Las Condes, RM</div>
        </div>
        
        <!-- Destinatario -->
        <div class="recipient-section">
            <div class="recipient-title">Para:</div>
            <div class="recipient-box">
                <div>
                    <div class="recipient-name">
                        ${safeFirstName} ${safeLastName}
                    </div>
                    <div class="recipient-address">
                        ${safeStreet}${safeApartment ? ' ' + safeApartment : ''}
                    </div>
                    <div class="recipient-address">
                        RUT: ${safeRut}
                    </div>
                    <div class="recipient-address">
                        Cel: ${safePhone}
                    </div>
                </div>
                <div class="recipient-city">
                    ${safeCity}, ${safeRegion}
                </div>
            </div>
        </div>
        
        <!-- Contenido -->
        <div class="contents">
            <div class="contents-title">📦 Contiene:</div>
            ${safeItems.map(item => `
                <div class="contents-item">• ${item.quantity}x ${item.name}</div>
            `).join('')}
        </div>
        
        <!-- Código de Seguimiento -->
        <div class="tracking-box">
            <div class="tracking-label">Rastrear:</div>
            <div class="tracking-code">${safeOrderId}</div>
            <div class="tracking-status">${safeStatusText}</div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>Impreso: ${new Date().toLocaleDateString('es-CL', { timeZone: CHILE_TIMEZONE })}</p>
        </div>
    </div>
</body>
</html>
        `;
        
        printWindow.document.write(labelHTML);
        printWindow.document.close();

        // La impresión se dispara desde aquí: la política de seguridad no permite <script> en línea
        const startPrint = () => {
            setTimeout(() => { if (!printWindow.closed) printWindow.print(); }, 300);
        };
        printWindow.addEventListener('afterprint', () => printWindow.close());
        if (printWindow.document.readyState === 'complete') startPrint();
        else printWindow.addEventListener('load', startPrint, { once: true });
    }
}

// Obtener texto del estado
function getStatusText(status) {
    const statusTexts = {
        'paid': 'Pagada (por enviar)',
        'shipped': 'En Tránsito',
        'delivered': 'Entregada',
        'cancelled': 'Cancelada',
        'refunded': 'Devuelta'
    };
    return statusTexts[status] || 'Pagada';
}

// Formatear RUT chileno (00.000.000-0)
function formatRut(rut) {
    if (!rut) return 'N/A';
    const clean = String(rut).replace(/[^0-9kK]/g, '');
    if (clean.length < 2) return String(rut);
    const body = clean.slice(0, -1);
    const dv = clean.slice(-1).toUpperCase();
    const reversed = body.split('').reverse();
    const chunks = [];
    for (let i = 0; i < reversed.length; i += 3) {
        chunks.push(reversed.slice(i, i + 3).reverse().join(''));
    }
    const bodyFormatted = chunks.reverse().join('.');
    return `${bodyFormatted}-${dv}`;
}

// Configurar filtros
function setupFilters() {
    const searchInput = document.getElementById('searchOrders');
    const statusFilter = document.getElementById('filterStatus');
    
    if (searchInput) {
        searchInput.addEventListener('input', scheduleApplyFilters);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', applyFilters);
    }

    // Período: vuelve a pedir las órdenes a Firestore
    const period = document.getElementById('ordersPeriod');
    const customRange = document.getElementById('ordersCustomRange');
    if (period && period.dataset.listener !== 'true') {
        period.addEventListener('change', () => {
            const isCustom = period.value === 'custom';
            if (customRange) customRange.hidden = !isCustom;
            if (!isCustom) reloadOrdersForPeriod();
        });
        period.dataset.listener = 'true';
    }
    const applyRange = document.getElementById('ordersRangeApply');
    if (applyRange && applyRange.dataset.listener !== 'true') {
        applyRange.addEventListener('click', () => {
            if (!document.getElementById('ordersFrom')?.value && !document.getElementById('ordersTo')?.value) {
                showNotification('Elige al menos una fecha', 'warning');
                return;
            }
            reloadOrdersForPeriod();
        });
        applyRange.dataset.listener = 'true';
    }
}

async function reloadOrdersForPeriod() {
    const tbody = document.getElementById('ordersTableBody');
    if (tbody) tbody.innerHTML = '<tr><td colspan="8" class="table-loading-cell"><span class="orders-load-more-spinner" aria-hidden="true"></span> Cargando órdenes del período...</td></tr>';
    await loadOrders();
}

function scheduleApplyFilters() {
    if (filterDebounceTimer) {
        clearTimeout(filterDebounceTimer);
    }

    filterDebounceTimer = setTimeout(() => {
        applyFilters();
    }, FILTER_DEBOUNCE_MS);
}

// Aplicar filtros
// Aplicar filtros
function applyFilters({ keepLimit = false } = {}) {
    // Un filtro o búsqueda nueva vuelve a empezar desde las primeras 15
    if (!keepLimit) ordersRenderLimit = ORDERS_PAGE_SIZE;
    const rawSearch = (document.getElementById('searchOrders')?.value || '').trim();
    const searchTerm = rawSearch.toLowerCase();
    lastSearchTerm = rawSearch; // la búsqueda en el historial usa el texto tal cual
    const statusFilter = document.getElementById('filterStatus')?.value || 'all';

    // displayOrders ya excluye las órdenes nunca pagadas
    let filtered = allOrders;

    // Filtrar por búsqueda
    if (searchTerm) {
        filtered = filtered.filter(order => {
            const index = order._searchIndex || '';
            return index.includes(searchTerm);
        });
    }
    
    // Filtrar por estado
    if (statusFilter !== 'all') {
        filtered = filtered.filter(order => order.status === statusFilter);
    }
    
    displayOrders(filtered);
}

// Notificación (verde = éxito, roja = error). Los mensajes con ❌ se tratan como error.
function showNotification(message, type) {
    const isError = type === 'error' || String(message).includes('❌');
    const notification = document.createElement('div');
    notification.className = `orders-toast${isError ? ' orders-toast--error' : ''}`;
    notification.setAttribute('role', isError ? 'alert' : 'status');
    notification.textContent = String(message).replace(/^[✅❌]\s*/, '');
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, isError || type === 'warning' ? 5500 : 4000);
}

// Exponer funciones globalmente
window.viewOrderDetails = viewOrderDetails;
window.hideOrderDetails = hideOrderDetails;
window.updateOrderStatus = updateOrderStatus;
// Para la vista "Productos recientes" de bodega (bodega-products.js)
window.getLoadedOrders = () => allOrders;
window.printOrder = printOrder;
window.printOrderById = printOrderById;

console.log('✅ admin-orders.js listo');

// Actualizar badge en otras páginas admin cuando cambien las órdenes
if (typeof window !== 'undefined') {
    // Cargar contador desde localStorage al iniciar
    const savedCount = localStorage.getItem('hairia_pending_orders_count');
    if (savedCount && parseInt(savedCount) > 0) {
        updateOrdersBadge(parseInt(savedCount));
    }
}
