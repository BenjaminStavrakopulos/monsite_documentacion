document.addEventListener('DOMContentLoaded', async function() {
    console.log('login.html cargado correctamente');

    const params = new URLSearchParams(window.location.search);
    const redirect = params.get('redirect');

    // La copia guardada de la sesión puede estar vencida (p. ej. tras cambiar la contraseña):
    // firebase-config.js la borra al confirmar con Firebase; se espera ese chequeo antes de redirigir.
    for (let i = 0; i < 40 && !window.firebase?.whenSessionChecked; i += 1) {
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    await window.firebase?.whenSessionChecked?.();
    const currentUser = JSON.parse(localStorage.getItem('hairia_current_user') || sessionStorage.getItem('hairia_current_user') || 'null');

    if (params.get('sesion') === 'vencida' && (!currentUser || (!currentUser.id && !currentUser.uid))) {
        const guidance = document.getElementById('authGuidance');
        if (guidance) guidance.innerHTML = '<strong>Tu sesión se cerró</strong> (por ejemplo, porque cambiaste tu contraseña). Ingresa de nuevo para continuar.';
    }

    if (!currentUser || (!currentUser.id && !currentUser.uid)) {
        // Llegó desde una página de la cuenta: se explica por qué debe iniciar sesión
        const guidance = document.getElementById('authGuidance');
        const messages = {
            'my-orders': '<strong>Inicia sesión para ver tus compras.</strong> ¿Compraste sin cuenta? Revisa tu pedido en <a href="seguimiento.html">Sigue tu pedido</a> con tu número de orden.',
            'opciones-cuenta': '<strong>Inicia sesión para ver y cambiar los datos de tu cuenta.</strong>'
        };
        if (guidance && messages[redirect]) guidance.innerHTML = messages[redirect];
        return;
    }

    if (redirect === 'checkout') {
        window.location.href = 'checkout.html';
        return;
    }
    if (redirect === 'my-orders' || redirect === 'opciones-cuenta') {
        window.location.href = `${redirect}.html`;
        return;
    }
    if (redirect === 'admin' && currentUser.role === 'admin') {
        window.location.href = 'admin/admin.html';
        return;
    }
    if (redirect === 'bodega' && currentUser.role === 'bodeguero') {
        window.location.href = 'admin/bodeguero.html';
        return;
    }

    if (currentUser.role === 'admin') {
        window.location.href = 'admin/admin.html';
        return;
    }

    if (currentUser.role === 'bodeguero') {
        window.location.href = 'admin/bodeguero.html';
        return;
    }

    window.location.href = 'index.html';
});
