// home.js - Inicio (index.html): carrusel de ofertas, tutoriales y portada con video.
// "Aprende a usarlos": tarjetas verticales con vista previa en movimiento; al tocarlas
// se abre el tutorial con sonido y el producto asociado con "Agregar al carrito".
(function () {
    // Videos e imágenes del inicio en Firebase Storage (carpeta home-media/)
    const STORAGE_BASE = 'https://firebasestorage.googleapis.com/v0/b/monsite-85424.firebasestorage.app/o/';
    const media = file => `${STORAGE_BASE}${encodeURIComponent('home-media/' + file)}?alt=media`;
    // Tutoriales por defecto. El admin los cambia en "Videos del inicio": la configuración
    // publicada (Firestore siteContent/homeMedia) reemplaza esta lista y la portada.
    const DEFAULT_REELS = [
        { key: 'no-frizz', title: 'No Frizz Shampoo y Acondicionador', brand: 'Living Proof', duration: 53, match: ['No Frizz Shampoo 236', 'No Frizz Conditioner 236'] },
        { key: 'moisture-rescue', title: 'Moisture Rescue Mask', brand: 'Living Proof', duration: 45, match: ['Moisture Rescue'], featured: true },
        { key: 'flex-hairspray', title: 'Flex Hairspray', brand: 'Living Proof', duration: 37, match: ['Flex Hair Spray'] },
        { key: 'triple-bond', title: 'Triple Bond Complex', brand: 'Living Proof', duration: 32, match: ['Triple Bond Complex Tratamiento 45ml'] }
    ].map(reel => ({ ...reel, video: `${reel.key}.mp4`, poster: `${reel.key}.jpg`, preview: `${reel.key}-preview.mp4`, productIds: [] }));
    let reels = DEFAULT_REELS;
    const formatDuration = seconds => `${Math.floor(seconds / 60)}:${String(Math.round(seconds) % 60).padStart(2, '0')}`;
    const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const $ = id => document.getElementById(id);
    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const money = value => new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(Number(value) || 0);

    function findProducts(reel) {
        const products = Array.isArray(window.productsData) ? window.productsData : [];
        const byId = (reel.productIds || [])
            .map(id => products.find(product => String(product.id) === String(id)))
            .filter(Boolean);
        if (byId.length) return byId;
        return (reel.match || [])
            .map(term => products.find(product => String(product.name || '').toLowerCase().includes(term.toLowerCase())))
            .filter(Boolean);
    }

    function finalPrice(product) {
        const price = Number(product.price) || 0;
        if (product.discountType === 'percentage') return Math.round(price - price * (Number(product.discountPercent) || 0) / 100);
        if (product.discountType === 'amount') return Math.max(0, price - (Number(product.discountAmount) || 0));
        return price;
    }

    // ---------- Tarjetas ----------
    // Vista previa por turnos: solo se mueve UNA tarjeta a la vez, 5 s cada una, en orden y
    // volviendo a la primera. Las demás muestran su portada. Así no se decodifican varios
    // videos a la vez y cada vista previa se descarga recién cuando le toca su turno.
    // Solo rotan las tarjetas que están a la vista, y todo se detiene si la sección sale de
    // pantalla, la pestaña queda en segundo plano o se abre un tutorial.
    const PREVIEW_TURN_MS = 5000;
    const preview = { cards: [], visible: new Set(), index: -1, timer: null, sectionVisible: !('IntersectionObserver' in window), paused: false, hovered: null };
    const canHover = window.matchMedia('(hover: hover)').matches;

    const previewVideo = card => card?.querySelector('video');

    function stopPreview(card) {
        const video = previewVideo(card);
        if (!video) return;
        video.pause();
        try { video.currentTime = 0; } catch (error) { /* aún sin cargar */ }
    }

    function activatePreview(card) {
        preview.cards.forEach(other => { if (other !== card) stopPreview(other); });
        preview.index = preview.cards.indexOf(card);
        const video = previewVideo(card);
        if (!video.src) video.src = video.dataset.src;
        video.play().catch(() => {});
    }

    const canAnimate = () => preview.sectionVisible && !preview.paused && !document.hidden && !reducedMotion();

    function nextPreviewTurn() {
        clearTimeout(preview.timer);
        preview.timer = null;
        if (!canAnimate() || preview.hovered) return;
        const order = preview.cards.filter(card => preview.visible.has(card));
        if (!order.length) return;
        const position = order.indexOf(preview.cards[preview.index]);
        activatePreview(order[(position + 1) % order.length]);
        preview.timer = setTimeout(nextPreviewTurn, PREVIEW_TURN_MS);
    }

    // Revisa si corresponde mover las vistas previas (o detenerlas todas)
    function refreshPreviews() {
        if (!canAnimate()) {
            clearTimeout(preview.timer);
            preview.timer = null;
            preview.cards.forEach(stopPreview);
            return;
        }
        if (!preview.timer && !preview.hovered) nextPreviewTurn();
    }

    const cardObserver = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) preview.visible.add(entry.target);
            else preview.visible.delete(entry.target);
        });
        // Si la tarjeta que se movía dejó de verse, pasa de inmediato a la siguiente visible
        const active = preview.cards[preview.index];
        if (active && !preview.visible.has(active) && active !== preview.hovered) {
            stopPreview(active);
            clearTimeout(preview.timer);
            preview.timer = null;
        }
        refreshPreviews();
    }, { threshold: 0.6 }) : null;

    const sectionObserver = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
        preview.sectionVisible = entries.some(entry => entry.isIntersecting);
        refreshPreviews();
    }, { threshold: 0.25 }) : null;

    document.addEventListener('visibilitychange', refreshPreviews);

    function setupPreviewCards(track) {
        clearTimeout(preview.timer);
        preview.timer = null;
        preview.index = -1;
        preview.hovered = null;
        preview.visible.clear();
        cardObserver?.disconnect();
        preview.cards = [...track.querySelectorAll('.v2-reel')];
        preview.cards.forEach(card => {
            if (cardObserver) cardObserver.observe(card);
            else preview.visible.add(card);
            if (!canHover) return;
            // Con mouse: la tarjeta bajo el cursor se reproduce y la rotación espera
            card.addEventListener('pointerenter', () => {
                if (reducedMotion() || preview.paused) return;
                preview.hovered = card;
                clearTimeout(preview.timer);
                preview.timer = null;
                activatePreview(card);
            });
            card.addEventListener('pointerleave', () => {
                if (preview.hovered !== card) return;
                preview.hovered = null;
                clearTimeout(preview.timer);
                preview.timer = canAnimate() ? setTimeout(nextPreviewTurn, PREVIEW_TURN_MS) : null;
                if (!canAnimate()) stopPreview(card);
            });
        });
        if (!sectionObserver) refreshPreviews();
    }

    function renderReels() {
        const track = $('reelsTrack');
        if (!track) return;
        track.innerHTML = reels.map(reel => `
            <button type="button" class="v2-reel" data-reel="${esc(reel.key)}" aria-label="Ver tutorial: ${esc(reel.title)}">
                <video muted loop playsinline preload="none" poster="${media(reel.poster)}" data-src="${media(reel.preview)}"></video>
                <span class="v2-reel-play">▶ ${formatDuration(reel.duration)}</span>
                <span class="v2-reel-info"><small>${esc(reel.brand)}</small><strong>${esc(reel.title)}</strong></span>
            </button>`).join('');
        setupPreviewCards(track);
        window.MonsiteCarousel?.attach(track, $('reelsPrev'), $('reelsNext'), { itemSelector: '.v2-reel' });
    }

    function setupReels() {
        if ($('reelsTrack')) sectionObserver?.observe($('reelsTrack'));
        $('reelsTrack')?.addEventListener('click', event => {
            const card = event.target.closest('[data-reel]');
            if (card) openPlayer(card.dataset.reel);
        });
        renderReels();
    }

    // Mosaico "Aprende a usarlos" de la portada: muestra la vista previa del tutorial destacado
    function updateLearnTile() {
        const reel = reels.find(item => item.featured) || reels[0];
        const video = document.querySelector('.v2-bento-learn video');
        const source = video?.querySelector('source');
        if (!reel || !video || !source || source.src === media(reel.preview)) return;
        video.poster = media(reel.poster);
        source.src = media(reel.preview);
        video.load();
        if (!reducedMotion()) video.play().catch(() => {});
    }

    // ---------- Configuración publicada desde el admin ----------
    function applyHomeMedia(config) {
        if (!config) return;
        // Formato actual: hero.slides (carrusel). Formato anterior: un solo video en hero.
        const slides = Array.isArray(config.hero?.slides) ? config.hero.slides : (config.hero?.video ? [config.hero] : []);
        const valid = slides.filter(slide => slide?.video && slide?.poster);
        if (valid.length) setHeroSlides(valid);

        if (Array.isArray(config.tutorials) && config.tutorials.length) {
            reels = config.tutorials.map(item => ({
                key: item.id, title: item.title, brand: item.brand, duration: Number(item.duration) || 0,
                video: item.video, poster: item.poster, preview: item.preview,
                productIds: item.productIds || [], match: item.match || [], featured: item.featured === true
            }));
            renderReels();
        }
        updateLearnTile();
    }

    async function loadHomeMedia() {
        if (typeof window.firebase?.getHomeMediaConfig !== 'function') {
            await new Promise(resolve => window.addEventListener('hairia:firebase-ready', resolve, { once: true }));
        }
        applyHomeMedia(await window.firebase.getHomeMediaConfig());
    }

    // ---------- Reproductor ----------
    let lastFocus = null;
    function openPlayer(key) {
        const reel = reels.find(item => item.key === key);
        const player = $('reelPlayer');
        if (!reel || !player) return;
        lastFocus = document.activeElement;
        const video = $('reelPlayerVideo');
        video.poster = media(reel.poster);
        video.src = media(reel.video);
        $('reelPlayerBrand').textContent = reel.brand;
        $('reelPlayerTitle').textContent = reel.title;

        const products = findProducts(reel);
        $('reelPlayerProducts').innerHTML = products.length
            ? products.map(product => `
                <div class="v2-player-product">
                    <img src="${esc(product.image || '')}" alt="">
                    <div><strong>${esc(product.name)}</strong><span>${money(finalPrice(product))}</span></div>
                    <button type="button" data-add="${esc(product.id)}">Agregar al carrito</button>
                </div>`).join('')
            : '<p style="opacity:.75">Producto no encontrado en el catálogo.</p>';

        preview.paused = true;
        refreshPreviews();
        player.classList.add('active');
        document.body.style.overflow = 'hidden';
        video.muted = false;
        video.play().catch(() => {});
        $('reelPlayerClose').focus();
    }

    function closePlayer() {
        const player = $('reelPlayer');
        const video = $('reelPlayerVideo');
        if (!player?.classList.contains('active')) return;
        video.pause();
        video.removeAttribute('src');
        video.load();
        player.classList.remove('active');
        document.body.style.overflow = '';
        preview.paused = false;
        refreshPreviews();
        lastFocus?.focus?.();
    }

    function setupPlayer() {
        const player = $('reelPlayer');
        if (!player) return;
        $('reelPlayerClose').addEventListener('click', closePlayer);
        player.addEventListener('click', event => {
            if (event.target === player) { closePlayer(); return; }
            const add = event.target.closest('[data-add]');
            if (add) {
                const product = (window.productsData || []).find(item => String(item.id) === add.dataset.add);
                if (product && typeof window.addToCart === 'function') {
                    window.addToCart(product);
                    window.updateCartUI?.();
                    add.textContent = 'Agregado ✓';
                }
            }
        });
        document.addEventListener('keydown', event => { if (event.key === 'Escape') closePlayer(); });
    }

    // ---------- Portada: carrusel de videos ----------
    // Cada video se reproduce completo y al terminar entra el siguiente (con un fundido);
    // después del último vuelve al primero. Con un solo video, se repite en bucle.
    // Hay dos <video> superpuestos: mientras uno se ve, el otro precarga el siguiente.
    const SAFE_LINK = /^products\.html(\?[A-Za-z0-9=&_%.-]*)?$/;
    const hero = {
        slides: [{
            video: 'portada.mp4', poster: 'portada.jpg', eyebrow: 'Marca destacada', title: 'American Crew',
            linkText: 'Ver la línea completa →', linkHref: 'products.html?brand=american-crew',
            alt: 'Presentación de productos American Crew'
        }],
        index: 0,
        players: [],
        paused: false,
        nextPreloaded: false
    };
    const activePlayer = () => hero.players.find(player => player.classList.contains('is-active')) || hero.players[0];
    const idlePlayer = () => hero.players.find(player => player !== activePlayer());

    function loadInto(player, slide) {
        const src = media(slide.video);
        if (player.dataset.src === src) return;
        player.dataset.src = src;
        player.querySelector('source')?.remove();
        player.poster = media(slide.poster);
        player.src = src;
    }

    // El siguiente video se precarga solo cuando el actual ya cargó casi completo (o va por el 60 %):
    // antes se descargaba junto con el primero (varios MB extra) y le quitaba ancho de banda en el celular.
    function maybePreloadNext(player) {
        if (hero.nextPreloaded || hero.slides.length < 2 || player !== activePlayer()) return;
        const duration = player.duration;
        if (!Number.isFinite(duration) || duration <= 0) return;
        const bufferedEnd = player.buffered.length ? player.buffered.end(player.buffered.length - 1) : 0;
        if (bufferedEnd < duration - 0.5 && player.currentTime < duration * 0.6) return;
        hero.nextPreloaded = true;
        const idle = idlePlayer();
        idle.preload = 'auto';
        loadInto(idle, hero.slides[(hero.index + 1) % hero.slides.length]);
    }

    function renderHeroCaption(slide, animate) {
        const caption = document.querySelector('.v2-bento-caption');
        if (!caption) return;
        const apply = () => {
            const eyebrow = caption.querySelector('.v2-eyebrow');
            const title = caption.querySelector('strong');
            const link = caption.querySelector('a');
            if (eyebrow) { eyebrow.textContent = slide.eyebrow || ''; eyebrow.hidden = !slide.eyebrow; }
            if (title) { title.textContent = slide.title || ''; title.hidden = !slide.title; }
            if (link) {
                link.textContent = slide.linkText || '';
                link.hidden = !slide.linkText;
                link.setAttribute('href', SAFE_LINK.test(slide.linkHref || '') ? slide.linkHref : 'products.html');
            }
            caption.hidden = !slide.eyebrow && !slide.title && !slide.linkText;
            caption.classList.remove('is-changing');
        };
        if (!animate) { apply(); return; }
        caption.classList.add('is-changing');
        setTimeout(apply, 250);
    }

    function renderHeroSteps() {
        const steps = $('heroSteps');
        if (!steps) return;
        const total = hero.slides.length;
        steps.hidden = total < 2;
        steps.innerHTML = total < 2 ? '' : hero.slides.map((slide, i) =>
            `<button type="button" class="v2-hero-step" data-step="${i}" aria-label="Ver video ${i + 1} de ${total}${slide.title ? ': ' + esc(slide.title) : ''}"><span></span></button>`).join('');
        updateHeroSteps(0);
    }

    function updateHeroSteps(progress) {
        document.querySelectorAll('#heroSteps .v2-hero-step').forEach((step, i) => {
            step.classList.toggle('is-done', i < hero.index);
            step.style.setProperty('--progress', i === hero.index ? `${Math.min(100, progress * 100)}%` : '0%');
            if (i === hero.index) step.setAttribute('aria-current', 'true');
            else step.removeAttribute('aria-current');
        });
    }

    function showHeroSlide(index, animate = true) {
        const total = hero.slides.length;
        if (!total || hero.players.length < 2) return;
        hero.index = (index + total) % total;
        const slide = hero.slides[hero.index];
        const src = media(slide.video);
        // Si el video ya está precargado en el reproductor libre, se usa ese
        const target = hero.players.find(player => player.dataset.src === src) || idlePlayer();
        const previous = activePlayer();
        loadInto(target, slide);
        target.loop = total === 1;
        target.currentTime = 0;
        if (slide.alt) target.setAttribute('aria-label', slide.alt);
        target.removeAttribute('aria-hidden');
        if (target !== previous) {
            target.classList.add('is-active');
            previous.classList.remove('is-active');
            previous.setAttribute('aria-hidden', 'true');
            previous.pause();
        }
        if (!hero.paused) target.play().catch(() => {});
        renderHeroCaption(slide, animate);
        updateHeroSteps(0);

        // El siguiente se precarga más adelante (ver maybePreloadNext)
        hero.nextPreloaded = false;
    }

    function setHeroSlides(slides) {
        const same = JSON.stringify(slides.map(s => [s.video, s.poster, s.eyebrow, s.title, s.linkText, s.linkHref, s.alt]))
            === JSON.stringify(hero.slides.map(s => [s.video, s.poster, s.eyebrow, s.title, s.linkText, s.linkHref, s.alt]));
        if (same) return;
        hero.slides = slides;
        renderHeroSteps();
        // Si el primer video es el que ya se está viendo, no se reinicia
        const current = activePlayer();
        if (current && current.dataset.src === media(slides[0].video)) {
            hero.index = 0;
            current.loop = slides.length === 1;
            renderHeroCaption(slides[0], false);
            hero.nextPreloaded = false;
            maybePreloadNext(current);
            return;
        }
        showHeroSlide(0, false);
    }

    function setupHero() {
        const video = $('heroVideo');
        const pause = $('heroPause');
        if (!video || !pause) return;

        const second = document.createElement('video');
        second.muted = true;
        second.playsInline = true;
        second.setAttribute('muted', '');
        second.setAttribute('playsinline', '');
        second.setAttribute('aria-hidden', 'true');
        second.preload = 'none';
        video.after(second);
        video.dataset.src = video.currentSrc || video.querySelector('source')?.src || '';
        hero.players = [video, second];

        hero.players.forEach(player => {
            player.addEventListener('ended', () => {
                if (player === activePlayer() && hero.slides.length > 1) showHeroSlide(hero.index + 1);
            });
            player.addEventListener('timeupdate', () => {
                if (player === activePlayer() && player.duration) updateHeroSteps(player.currentTime / player.duration);
                maybePreloadNext(player);
            });
            player.addEventListener('progress', () => maybePreloadNext(player));
            // Si un video falla, se salta al siguiente para que la portada no quede detenida
            player.addEventListener('error', () => {
                if (player === activePlayer() && hero.slides.length > 1) setTimeout(() => showHeroSlide(hero.index + 1), 1500);
            });
        });

        $('heroSteps')?.addEventListener('click', event => {
            const step = event.target.closest('[data-step]');
            if (step) showHeroSlide(Number(step.dataset.step));
        });

        const setPauseLabel = () => {
            pause.textContent = hero.paused ? '▶' : '❚❚';
            pause.setAttribute('aria-label', hero.paused ? 'Reproducir video' : 'Pausar video');
        };
        // Respeta "reducir movimiento" del sistema
        if (reducedMotion()) {
            hero.paused = true;
            video.removeAttribute('autoplay');
            video.pause();
        }
        setPauseLabel();
        pause.addEventListener('click', () => {
            hero.paused = !hero.paused;
            if (hero.paused) activePlayer().pause();
            else activePlayer().play().catch(() => {});
            setPauseLabel();
        });
        video.loop = hero.slides.length === 1;
    }

    // ---------- Carrusel de ofertas (portada) ----------
    // Todos los productos disponibles con descuento, de mayor a menor %. Cambia cada 3 s;
    // se pausa al pasar el mouse o con foco, con la pestaña oculta y con "reducir movimiento".
    const OFFER_INTERVAL_MS = 3000;
    let offerIndex = 0;
    let offerTimer = null;
    let offerPaused = false;
    let offerCount = 0;
    let offerSignature = '';

    function getOffers() {
        return (Array.isArray(window.productsData) ? window.productsData : [])
            .filter(product => product && product.active !== false && (Number.parseInt(product.stock, 10) || 0) > 0 && product.image)
            .map(product => {
                const price = Number(product.price) || 0;
                const final = finalPrice(product);
                return { product, price, final, pct: price > 0 ? Math.round((1 - final / price) * 100) : 0 };
            })
            .filter(offer => offer.pct > 0)
            .sort((a, b) => b.pct - a.pct);
    }

    function showOffer(index) {
        const slides = document.querySelectorAll('#heroOfferSlides .v2-offer-slide');
        if (!slides.length) return;
        offerIndex = (index + slides.length) % slides.length;
        slides.forEach((slide, i) => {
            const active = i === offerIndex;
            slide.classList.toggle('is-active', active);
            slide.setAttribute('aria-hidden', active ? 'false' : 'true');
            slide.tabIndex = active ? 0 : -1;
        });
        // Reiniciar la barra de progreso (se llena en los 3 s de cada oferta)
        const bar = document.querySelector('#heroOffer .v2-offer-progress span');
        if (bar) { bar.style.animation = 'none'; void bar.offsetWidth; bar.style.animation = ''; }
        const count = $('heroOfferCount');
        if (count) count.textContent = `${offerIndex + 1} / ${slides.length}`;
    }

    function startOfferTimer() {
        clearInterval(offerTimer);
        if (offerCount < 2 || offerPaused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        offerTimer = setInterval(() => { if (!document.hidden) showOffer(offerIndex + 1); }, OFFER_INTERVAL_MS);
    }

    function renderOffer() {
        const tile = $('heroOffer');
        const slidesBox = $('heroOfferSlides');
        const dotsBox = $('heroOfferDots');
        if (!tile || !slidesBox) return;
        const offers = getOffers();
        if (!offers.length) {
            if (Array.isArray(window.productsData) && window.productsData.length) {
                slidesBox.innerHTML = '<a class="v2-offer-slide is-active" href="products.html"><span class="v2-offer-info"><strong>Explora todo el catálogo</strong><span class="v2-offer-cta">Ver productos →</span></span></a>';
                if (dotsBox) dotsBox.innerHTML = '';
            }
            return;
        }
        // No volver a dibujar si las ofertas no cambiaron (el catálogo se actualiza en segundo plano)
        const signature = offers.map(offer => `${offer.product.id}:${offer.final}`).join('|');
        if (signature === offerSignature) return;
        offerSignature = signature;
        offerCount = offers.length;

        slidesBox.innerHTML = offers.map((offer, i) => `
            <a class="v2-offer-slide${i === 0 ? ' is-active' : ''}" href="products.html?search=${encodeURIComponent(offer.product.name)}" aria-label="${esc(offer.product.name)}, ${money(offer.final)}, ${offer.pct}% de descuento">
                <span class="v2-offer-media"><span class="v2-offer-badge">-${offer.pct}%</span><img src="${esc(offer.product.image)}" alt="" loading="${i < 2 ? 'eager' : 'lazy'}"></span>
                <span class="v2-offer-info">
                    <strong>${esc(offer.product.name)}</strong>
                    <span class="v2-offer-prices"><span>${money(offer.final)}</span><del>${money(offer.price)}</del></span>
                    <span class="v2-offer-cta">Ver oferta →</span>
                </span>
            </a>`).join('');

        if (dotsBox) {
            dotsBox.innerHTML = offers.length > 1
                ? `<button type="button" class="v2-offer-nav" data-offer-step="-1" aria-label="Oferta anterior">‹</button>
                   <span class="v2-offer-progress" aria-hidden="true"><span></span></span>
                   <button type="button" class="v2-offer-nav" data-offer-step="1" aria-label="Oferta siguiente">›</button>`
                : '';
        }
        showOffer(0);
        startOfferTimer();
    }

    function setupOfferCarousel() {
        const tile = $('heroOffer');
        if (!tile) return;
        const pause = () => { offerPaused = true; clearInterval(offerTimer); tile.classList.add('is-paused'); };
        const resume = () => { offerPaused = false; tile.classList.remove('is-paused'); showOffer(offerIndex); startOfferTimer(); };
        tile.addEventListener('mouseenter', pause);
        tile.addEventListener('mouseleave', resume);
        tile.addEventListener('focusin', pause);
        tile.addEventListener('focusout', event => { if (!tile.contains(event.relatedTarget)) resume(); });
        $('heroOfferDots')?.addEventListener('click', event => {
            const step = event.target.closest('[data-offer-step]');
            if (!step) return;
            event.preventDefault();
            showOffer(offerIndex + Number(step.dataset.offerStep));
            startOfferTimer();
        });
        // Deslizar con el dedo en celular
        let startX = null;
        tile.addEventListener('touchstart', event => { startX = event.touches[0].clientX; }, { passive: true });
        tile.addEventListener('touchend', event => {
            if (startX === null) return;
            const delta = event.changedTouches[0].clientX - startX;
            if (Math.abs(delta) > 40) { showOffer(offerIndex + (delta < 0 ? 1 : -1)); startOfferTimer(); }
            startX = null;
        });
    }

    function init() {
        setupOfferCarousel();
        window.addEventListener('hairia:data-ready', renderOffer);
        renderOffer();
        document.querySelectorAll('[data-year]').forEach(el => { el.textContent = new Date().getFullYear(); });
        setupReels();
        setupPlayer();
        setupHero();
        loadHomeMedia().catch(error => console.warn('Videos del inicio: se usan los predeterminados', error));
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
