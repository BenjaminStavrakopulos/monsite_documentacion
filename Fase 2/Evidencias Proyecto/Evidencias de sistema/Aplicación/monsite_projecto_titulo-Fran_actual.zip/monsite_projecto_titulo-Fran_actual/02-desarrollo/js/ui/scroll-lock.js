// scroll-lock.js - Bloquea el scroll de la página mientras haya un popup abierto.
// Cada popup del sitio se abre a su manera (.active, display:flex, .show...), así que
// en vez de tocar cada uno, se observa el DOM y se detecta si alguno está visible.
// El CSS (styles.css) aplica html.scroll-locked y overscroll-behavior: contain.
(function () {
    const POPUP_SELECTORS = [
        '.form-modal',
        '.modal-overlay',
        '.product-modal',
        '.order-modal',
        '.delete-modal',
        '.reset-modal',
        '.payment-modal',
        '.payment-success-modal',
        '.processing-modal',
        '.checkout-loader',
        '.cart-overlay',
        '.mobile-overlay',
        '[aria-modal="true"]',
        '[data-scroll-lock]'
    ].join(',');

    const root = document.documentElement;
    let scheduled = false;

    function isShown(element) {
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden' || style.pointerEvents === 'none') {
            return false;
        }
        if (Number.parseFloat(style.opacity) === 0 && !element.matches('.active, .open, .show, .visible')) {
            return false;
        }

        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return false;
        // Paneles "cerrados" que quedan fuera de pantalla (ej: carrito con translateX)
        return rect.right > 0 && rect.bottom > 0 && rect.left < window.innerWidth && rect.top < window.innerHeight;
    }

    function update() {
        scheduled = false;
        const anyOpen = Array.prototype.some.call(document.querySelectorAll(POPUP_SELECTORS), isShown);
        root.classList.toggle('scroll-locked', anyOpen);
    }

    function scheduleUpdate() {
        if (scheduled) return;
        scheduled = true;
        window.requestAnimationFrame(update);
    }

    function start() {
        const observer = new MutationObserver(scheduleUpdate);
        observer.observe(document.body, {
            subtree: true,
            childList: true,
            attributes: true,
            attributeFilter: ['class', 'style', 'hidden', 'open', 'aria-hidden']
        });

        // Los cierres con animación terminan después del cambio de clase
        document.addEventListener('transitionend', scheduleUpdate, true);
        document.addEventListener('animationend', scheduleUpdate, true);
        window.addEventListener('resize', scheduleUpdate);
        update();
    }

    if (document.body) {
        start();
    } else {
        document.addEventListener('DOMContentLoaded', start);
    }
})();
