// site-nav.js - Menú principal de la tienda: Inicio · Marcas ▾ · Categorías ▾ · Ofertas · Tutoriales · Nosotros.
// - Escritorio: paneles desplegables (al pasar el mouse, con clic o con teclado).
// - Celular: arma el menú lateral (#mobileNav) con las mismas secciones, Marcas y Categorías desplegables.
// - Marcas y categorías se completan con los productos reales (window.productsData), así una marca o
//   categoría nueva aparece sola. Los grupos de categorías también los usa products.js (?grupo=).
(function () {
    // Grupos de categorías: reúnen las variantes que usa el catálogo (ej. tratamiento y tratamiento-capilar)
    const CATEGORY_GROUPS = [
        { id: 'cuidado-diario', name: 'Cuidado diario', categories: ['shampoo', 'acondicionador', 'acondicionador-sin-enjuague', 'shampoo-en-seco'] },
        { id: 'tratamientos', name: 'Tratamientos', categories: ['tratamiento', 'tratamiento-capilar', 'mascarilla'] },
        { id: 'aceites-serums', name: 'Aceites y sérums', categories: ['aceite', 'aceite-capilar', 'serum'] },
        { id: 'peinado', name: 'Peinado y styling', categories: ['peinado', 'cera-styling', 'spray-bruma'] },
        { id: 'proteccion-termica', name: 'Protección térmica', categories: ['proteccion-termica', 'protector-termico'] }
    ];

    // Logos locales de las marcas (las demás usan el logo de Admin → Marcas o su nombre)
    const BRAND_LOGOS = {
        olaplex: 'images/olaplex.jpg', kerastase: 'images/kerastase.jpg', tigi: 'images/tigi.jpg', k18: 'images/k18.jpg',
        'living-proof': 'images/livingprof.jpg', revlon: 'images/revlon.jpg', moroccanoil: 'images/Moroccanoil.jpg', dabalash: 'images/Dabalash.jpg'
    };
    const BRAND_NAMES = {
        'l-oreal-professionnel': "L'Oréal Professionnel", 'american-crew': 'American Crew', 'living-proof': 'Living Proof',
        k18: 'K18', kerastase: 'Kérastase', moroccanoil: 'Moroccanoil', olaplex: 'Olaplex', redken: 'Redken', revlon: 'Revlon', tigi: 'Tigi'
    };

    const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const brandKey = value => String(value || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
        .replace(/[^a-z0-9-\s]/g, '').trim().replace(/\s+/g, '-');
    const titleCase = key => key.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    const products = () => (Array.isArray(window.productsData) ? window.productsData : [])
        .filter(product => product && product.active !== false);
    let firestoreLogos = null;
    // Nombres escritos en Admin → Marcas: mandan sobre la lista fija BRAND_NAMES
    const firestoreNames = {};
    const displayName = key => firestoreNames[key] || BRAND_NAMES[key] || titleCase(key);

    function finalPrice(product) {
        const price = Number(product.price) || 0;
        if (product.discountType === 'percentage') return Math.round(price - price * (Number(product.discountPercent) || 0) / 100);
        if (product.discountType === 'amount') return Math.max(0, price - (Number(product.discountAmount) || 0));
        return price;
    }

    function isOnSale(product) {
        const price = Number(product.price) || 0;
        return price > 0 && finalPrice(product) < price && (Number.parseInt(product.stock, 10) || 0) > 0;
    }

    function getBrands() {
        const counts = new Map();
        products().forEach(product => {
            const key = brandKey(product.brand);
            if (key) counts.set(key, (counts.get(key) || 0) + 1);
        });
        return [...counts.entries()]
            .map(([key, count]) => ({ key, count, name: displayName(key), logo: BRAND_LOGOS[key] || firestoreLogos?.[key] || '' }))
            .sort((a, b) => a.name.localeCompare(b.name, 'es'));
    }

    function categoryNames() {
        const names = {};
        (Array.isArray(window.categories) ? window.categories : []).forEach(category => {
            if (category?.id && category.name) names[category.id] = category.name;
        });
        return names;
    }

    function getGroups() {
        const names = categoryNames();
        const counts = {};
        products().forEach(product => { counts[product.category] = (counts[product.category] || 0) + 1; });
        return CATEGORY_GROUPS.map(group => {
            // Categorías distintas con el mismo nombre (ej. "tratamiento" y "tratamiento-capilar")
            // se muestran una sola vez y el enlace incluye ambas
            const byName = new Map();
            group.categories.filter(id => counts[id]).forEach(id => {
                const name = names[id] || titleCase(id);
                const item = byName.get(name) || { ids: [], name, count: 0 };
                item.ids.push(id);
                item.count += counts[id];
                byName.set(name, item);
            });
            return {
                ...group,
                items: [...byName.values()].map(item => ({ ...item, id: item.ids.join(',') })),
                total: group.categories.reduce((sum, id) => sum + (counts[id] || 0), 0)
            };
        }).filter(group => group.total > 0 || !products().length);
    }

    function getOffers() {
        const sale = products().filter(isOnSale);
        const best = sale.reduce((max, product) => Math.max(max, Math.round((1 - finalPrice(product) / (Number(product.price) || 1)) * 100)), 0);
        return { count: sale.length, best };
    }

    // ---------- Render ----------
    function renderBrandsPanel() {
        const target = document.querySelector('[data-nav-brands]');
        if (!target) return;
        const brands = getBrands();
        if (!brands.length) return;
        target.innerHTML = brands.map(brand => `
            <a class="mega-brand" href="products.html?brand=${encodeURIComponent(brand.key)}">
                <span class="mega-brand-logo">${brand.logo ? `<img src="${esc(brand.logo)}" alt="" loading="lazy">` : `<span>${esc(brand.name)}</span>`}</span>
                <span class="mega-brand-name">${esc(brand.name)}</span>
                <span class="mega-brand-count">${brand.count} ${brand.count === 1 ? 'producto' : 'productos'}</span>
            </a>`).join('');
    }

    function renderCategoriesPanel() {
        const target = document.querySelector('[data-nav-categories]');
        if (!target) return;
        const groups = getGroups();
        if (!groups.length) return;
        target.innerHTML = groups.map(group => `
            <div class="mega-group">
                <a class="mega-group-title" href="products.html?grupo=${encodeURIComponent(group.id)}">${esc(group.name)}${group.total ? ` <small>${group.total}</small>` : ''}</a>
                ${group.items.map(item => `<a class="mega-link" href="products.html?category=${encodeURIComponent(item.id)}">${esc(item.name)}</a>`).join('')}
            </div>`).join('');

        const promo = document.querySelector('[data-nav-offer]');
        const offers = getOffers();
        if (promo && offers.count) {
            promo.querySelector('strong').textContent = offers.best ? `Hasta ${offers.best}% OFF` : 'Ofertas';
            promo.querySelector('small').textContent = `${offers.count} productos con descuento`;
        }
    }

    function renderAll() {
        renderBrandsPanel();
        renderCategoriesPanel();
        buildMobileNav();
    }

    // Logos y nombres de Admin → Marcas: se piden una vez, apenas cargan los datos de la tienda
    // (o al abrir el panel de marcas si eso ocurre antes)
    async function loadFirestoreLogos() {
        if (firestoreLogos || typeof window.firebase?.getBrands !== 'function') return;
        firestoreLogos = {};
        try {
            (await window.firebase.getBrands()).forEach(brand => {
                if (!brand?.id || brand.active === false) return;
                const key = brandKey(brand.id);
                if (brand.logo) firestoreLogos[key] = brand.logo;
                if (typeof brand.name === 'string' && brand.name.trim()) firestoreNames[key] = brand.name.trim();
            });
            renderAll();
            // Otras partes (ej. filtro de marcas del catálogo) usan MonsiteNav.brandName
            window.dispatchEvent(new CustomEvent('monsite:brand-names-ready'));
        } catch (error) {
            console.warn('Menú: no se pudieron cargar los logos de marcas', error);
        }
    }

    // ---------- Paneles de escritorio ----------
    function setupDesktop() {
        const megas = [...document.querySelectorAll('.nav .nav-mega')];
        const close = except => megas.forEach(mega => {
            if (mega === except) return;
            mega.classList.remove('is-open');
            mega.querySelector('.nav-mega-trigger')?.setAttribute('aria-expanded', 'false');
        });
        megas.forEach(mega => {
            const trigger = mega.querySelector('.nav-mega-trigger');
            const open = () => {
                close(mega);
                mega.classList.add('is-open');
                trigger.setAttribute('aria-expanded', 'true');
                if (mega.dataset.mega === 'brands') loadFirestoreLogos();
            };
            let leaveTimer = null;
            const closeThis = () => {
                mega.classList.remove('is-open');
                trigger.setAttribute('aria-expanded', 'false');
            };
            mega.addEventListener('mouseenter', () => { clearTimeout(leaveTimer); open(); });
            // Solo se cierra este panel: así pasar de "Marcas" a "Categorías" no cierra el nuevo
            mega.addEventListener('mouseleave', () => { leaveTimer = setTimeout(closeThis, 180); });
            trigger.addEventListener('click', event => {
                event.preventDefault();
                if (mega.classList.contains('is-open')) close(); else open();
            });
            mega.addEventListener('keydown', event => {
                if (event.key === 'Escape') { close(); trigger.focus(); }
            });
            mega.addEventListener('focusout', event => {
                if (!mega.contains(event.relatedTarget)) close();
            });
        });
        document.addEventListener('click', event => {
            if (!event.target.closest('.nav-mega')) close();
        });
    }

    // ---------- Menú lateral (celular) ----------
    function buildMobileNav() {
        const mobileNav = document.getElementById('mobileNav');
        const desktopNav = document.querySelector('.header .nav');
        if (!mobileNav || !desktopNav) return;
        let list = mobileNav.querySelector('.mnav');
        const openSections = list ? [...list.querySelectorAll('.mnav-section.is-open')].map(section => section.dataset.section) : [];
        if (!list) {
            // Reemplaza los enlaces antiguos del menú lateral (se conserva el encabezado)
            mobileNav.querySelectorAll(':scope > .nav-link, :scope > .mobile-catalog-submenu').forEach(node => node.remove());
            list = document.createElement('div');
            list.className = 'mnav';
            mobileNav.appendChild(list);
        }
        const brands = getBrands();
        const groups = getGroups();
        const offers = getOffers();
        list.innerHTML = `
            <a class="nav-link" href="index.html">Inicio</a>
            <div class="mnav-section" data-section="brands">
                <button type="button" class="nav-link mnav-toggle" aria-expanded="false">Marcas</button>
                <div class="mnav-panel">
                    ${brands.map(brand => `<a href="products.html?brand=${encodeURIComponent(brand.key)}">${esc(brand.name)}</a>`).join('')}
                    <a class="mnav-all" href="products.html">Todo el catálogo →</a>
                </div>
            </div>
            <div class="mnav-section" data-section="categories">
                <button type="button" class="nav-link mnav-toggle" aria-expanded="false">Categorías</button>
                <div class="mnav-panel">
                    ${groups.map(group => `<a href="products.html?grupo=${encodeURIComponent(group.id)}">${esc(group.name)}</a>`).join('')}
                    <a class="mnav-all" href="products.html">Todo el catálogo →</a>
                </div>
            </div>
            <a class="nav-link mnav-offer" href="products.html?ofertas=1">Ofertas${offers.best ? ` <span>Hasta ${offers.best}% OFF</span>` : ''}</a>
            <a class="nav-link" href="index.html#aprende">Tutoriales</a>
            <a class="nav-link" href="index.html#nosotros">Nosotros</a>
            <a class="nav-link mnav-track" href="seguimiento.html">Seguir mi compra</a>`;
        openSections.forEach(id => {
            const section = list.querySelector(`[data-section="${id}"]`);
            section?.classList.add('is-open');
            section?.querySelector('.mnav-toggle')?.setAttribute('aria-expanded', 'true');
        });
    }

    function setupMobile() {
        const mobileNav = document.getElementById('mobileNav');
        if (!mobileNav) return;
        mobileNav.addEventListener('click', event => {
            const toggle = event.target.closest('.mnav-toggle');
            if (toggle) {
                const section = toggle.closest('.mnav-section');
                const open = section.classList.toggle('is-open');
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                return;
            }
            // Al elegir un destino se cierra el menú
            if (event.target.closest('.mnav a')) window.closeMobileMenu?.();
        });
    }

    // Sin sesión, "Mis compras" lleva directo al login (que explica por qué y ofrece "Sigue tu pedido")
    function routeAccountLinks() {
        let user = null;
        try { user = window.hairiaSession?.getCurrentUser?.() || null; } catch (error) { user = null; }
        if (user && (user.uid || user.id)) return;
        document.querySelectorAll('a[href="my-orders.html"], a[href="index.html#my-orders"]').forEach(link => {
            link.setAttribute('href', 'login.html?redirect=my-orders');
        });
    }

    function init() {
        routeAccountLinks();
        if (!document.querySelector('.header .nav .nav-mega')) return;
        setupDesktop();
        setupMobile();
        renderAll();
        window.addEventListener('hairia:data-ready', () => { renderAll(); loadFirestoreLogos(); });
        window.addEventListener('hairia:products-updated', renderAll);
    }

    window.MonsiteNav = {
        groups: CATEGORY_GROUPS,
        isOnSale,
        brandName: key => displayName(brandKey(key)),
        refresh: renderAll
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
