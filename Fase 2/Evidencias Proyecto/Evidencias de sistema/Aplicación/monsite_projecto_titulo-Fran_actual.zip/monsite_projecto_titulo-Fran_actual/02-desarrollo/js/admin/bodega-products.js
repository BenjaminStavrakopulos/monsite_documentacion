// bodega-products.js - Panel de Bodega: navegación entre vistas y "Productos recientes".
// La bodega NO ve ni edita el inventario completo: solo los productos pedidos en los
// últimos RECENT_DAYS días, y solo puede "Marcar agotado" (lo oculta de la tienda) o
// "Volver a mostrar" (devuelve exactamente el stock que tenía). Las reglas de Firestore
// rechazan cualquier otro cambio de stock.
(function () {
    const RECENT_DAYS = 30;
    const RECENT_STATUSES = new Set(['paid', 'shipped', 'delivered']);
    const CHILE_TZ = 'America/Santiago';

    let recentOrders = [];
    let productsById = new Map();
    let currentFilter = 'all';
    let pendingAction = null;
    // Carga por tandas: 15 tarjetas y 15 más al llegar al final
    const PAGE_SIZE = 15;
    let renderLimit = PAGE_SIZE;
    let scrollObserver = null;

    const $ = id => document.getElementById(id);

    function esc(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function safeImage(value) {
        const url = String(value || '').trim();
        return /^https:\/\//i.test(url) ? esc(url) : '';
    }

    function formatDay(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return '';
        return date.toLocaleDateString('es-CL', { timeZone: CHILE_TZ, day: 'numeric', month: 'short' });
    }

    function notify(message, type) {
        if (typeof window.showNotification === 'function') window.showNotification(message, type);
    }

    // ---------- Vistas (Pedidos / Productos recientes) ----------
    function setView(view) {
        const next = view === 'products' ? 'products' : 'orders';
        document.querySelectorAll('[data-view-panel]').forEach(panel => {
            panel.hidden = panel.dataset.viewPanel !== next;
        });
        document.querySelectorAll('.admin-nav [data-view]').forEach(link => {
            const active = link.dataset.view === next;
            link.classList.toggle('active', active);
            link.setAttribute('aria-current', active ? 'page' : 'false');
        });
        const title = $('bodegaViewTitle');
        const subtitle = $('bodegaViewSubtitle');
        if (title) title.textContent = next === 'products' ? 'Productos recientes' : 'Pedidos';
        if (subtitle) {
            subtitle.textContent = next === 'products'
                ? `Productos pedidos en los últimos ${RECENT_DAYS} días. Si alguno se acabó, márcalo como agotado para ocultarlo de la tienda.`
                : 'Prepara, despacha y actualiza el estado de los pedidos. El cliente recibe un correo en cada cambio.';
        }
        if (next === 'products') renderProducts();
        try { sessionStorage.setItem('bodega_view', next); } catch (_) { /* sin almacenamiento */ }
    }

    // ---------- Datos ----------
    function collectRecentProducts() {
        const since = Date.now() - RECENT_DAYS * 24 * 60 * 60 * 1000;
        const map = new Map();

        recentOrders
            .filter(order => RECENT_STATUSES.has(String(order.status || '').toLowerCase()))
            .filter(order => new Date(order.createdAt || 0).getTime() >= since)
            .forEach(order => {
                (order.items || []).forEach(item => {
                    const id = String(item?.id || '').trim();
                    if (!id) return;
                    const entry = map.get(id) || { id, name: item.name, image: item.image, units: 0, orders: new Set(), lastAt: 0, preparing: 0 };
                    const quantity = Number(item.quantity) || 0;
                    entry.units += quantity;
                    entry.orders.add(String(order.id));
                    if (order.status === 'paid') entry.preparing += quantity;
                    const time = new Date(order.createdAt || 0).getTime();
                    if (time > entry.lastAt) {
                        entry.lastAt = time;
                        entry.name = item.name || entry.name;
                        entry.image = item.image || entry.image;
                    }
                    map.set(id, entry);
                });
            });

        return [...map.values()]
            .map(entry => {
                const product = productsById.get(entry.id);
                const stock = Number.parseInt(product?.stock, 10);
                let state = 'available';
                if (!product) state = 'missing';
                else if (product.active === false) state = Number.isInteger(product.stockBeforeOutOfStock) ? 'hidden_bodega' : 'hidden_admin';
                else if (Number.isFinite(stock) && stock <= 0) state = 'sold_out';
                return {
                    ...entry,
                    name: product?.name || entry.name || 'Producto',
                    image: product?.image || entry.image,
                    brand: product?.brand || '',
                    state
                };
            })
            .sort((a, b) => b.lastAt - a.lastAt);
    }

    const STATE_META = {
        available: { label: 'En la tienda', tone: 'ok', hint: 'Visible para los clientes.' },
        sold_out: { label: 'Sin stock', tone: 'warn', hint: 'Se vendieron todas las unidades; se ve como agotado.' },
        hidden_bodega: { label: 'Oculto (agotado por bodega)', tone: 'off', hint: 'Lo marcaste como agotado. No aparece en la tienda.' },
        hidden_admin: { label: 'Oculto por administración', tone: 'off', hint: 'Lo ocultó un administrador. Solo administración puede volver a mostrarlo.' },
        missing: { label: 'Ya no existe', tone: 'off', hint: 'El producto fue eliminado del catálogo.' }
    };

    function renderProducts({ keepLimit = false } = {}) {
        const grid = $('bodegaProductsGrid');
        if (!grid) return;
        if (!keepLimit) renderLimit = PAGE_SIZE;
        const search = String($('bodegaProductsSearch')?.value || '').toLowerCase().trim();
        const all = collectRecentProducts();

        const counts = {
            all: all.length,
            available: all.filter(p => p.state === 'available' || p.state === 'sold_out').length,
            hidden: all.filter(p => p.state.startsWith('hidden') || p.state === 'missing').length
        };
        document.querySelectorAll('[data-products-filter]').forEach(chip => {
            const key = chip.dataset.productsFilter;
            chip.classList.toggle('active', key === currentFilter);
            const count = chip.querySelector('span');
            if (count) count.textContent = counts[key] ?? 0;
        });

        const list = all.filter(product => {
            if (currentFilter === 'available' && !(product.state === 'available' || product.state === 'sold_out')) return false;
            if (currentFilter === 'hidden' && !(product.state.startsWith('hidden') || product.state === 'missing')) return false;
            if (search && !`${product.name} ${product.brand}`.toLowerCase().includes(search)) return false;
            return true;
        });

        grid.removeAttribute('aria-busy');
        if (!list.length) {
            grid.innerHTML = `<div class="bodega-empty"><strong>${all.length ? 'No hay productos con ese filtro' : 'Aún no hay productos pedidos'}</strong><span>${all.length ? 'Prueba con otra búsqueda o filtro.' : `Aquí aparecen los productos de los pedidos de los últimos ${RECENT_DAYS} días.`}</span></div>`;
            return;
        }

        const visible = list.slice(0, renderLimit);
        const remaining = list.length - visible.length;
        grid.innerHTML = visible.map(product => {
            const meta = STATE_META[product.state];
            const image = safeImage(product.image);
            const storeUrl = `../products.html?search=${encodeURIComponent(product.name)}`;
            const canHide = product.state === 'available' || product.state === 'sold_out';
            const canRestore = product.state === 'hidden_bodega';
            return `
                <article class="bodega-product" data-product-id="${esc(product.id)}">
                    <div class="bodega-product-thumb">${image ? `<img src="${image}" alt="" loading="lazy">` : '<span aria-hidden="true">📦</span>'}</div>
                    <div class="bodega-product-body">
                        <span class="bodega-state bodega-state--${meta.tone}" title="${esc(meta.hint)}">${esc(meta.label)}</span>
                        <h3>${esc(product.name)}</h3>
                        <p class="bodega-product-meta">
                            ${product.units} ${product.units === 1 ? 'unidad pedida' : 'unidades pedidas'} en ${product.orders.size} ${product.orders.size === 1 ? 'pedido' : 'pedidos'}
                            · último ${esc(formatDay(product.lastAt))}
                        </p>
                        ${product.preparing ? `<p class="bodega-product-prep">${product.preparing} por preparar</p>` : ''}
                    </div>
                    <div class="bodega-product-actions">
                        ${canHide ? '<button type="button" class="btn-secondary bodega-btn-danger" data-product-action="hide">Marcar agotado</button>' : ''}
                        ${canRestore ? '<button type="button" class="btn-primary" data-product-action="restore">Volver a mostrar</button>' : ''}
                        ${product.state !== 'missing' ? `<a class="bodega-link" href="${storeUrl}" target="_blank" rel="noopener">Ver en tienda ↗</a>` : ''}
                    </div>
                </article>`;
        }).join('') + (remaining > 0
            ? `<div class="admin-load-more" data-products-sentinel><span class="orders-load-more-spinner" aria-hidden="true"></span> Cargando más productos… <small>(${remaining} restantes)</small></div>`
            : '');
        observeSentinel(grid);
    }

    function observeSentinel(grid) {
        if (scrollObserver) scrollObserver.disconnect();
        const sentinel = grid.querySelector('[data-products-sentinel]');
        if (!sentinel || !('IntersectionObserver' in window)) return;
        scrollObserver = new IntersectionObserver(entries => {
            if (!entries.some(entry => entry.isIntersecting)) return;
            scrollObserver.disconnect();
            renderLimit += PAGE_SIZE;
            renderProducts({ keepLimit: true });
        }, { rootMargin: '300px 0px' });
        scrollObserver.observe(sentinel);
    }

    // ---------- Confirmación ----------
    function openConfirm(action, product) {
        const modal = $('bodegaConfirmModal');
        if (!modal) return;
        pendingAction = { action, productId: product.id };
        $('bodegaConfirmTitle').textContent = action === 'hide' ? 'Marcar como agotado' : 'Volver a mostrar';
        $('bodegaConfirmText').innerHTML = action === 'hide'
            ? `<strong>${esc(product.name)}</strong> dejará de aparecer en la tienda y nadie podrá comprarlo. Úsalo solo si el producto se acabó físicamente en bodega.`
            : `<strong>${esc(product.name)}</strong> volverá a aparecer en la tienda con el mismo stock que tenía antes de marcarlo como agotado.`;
        const confirmBtn = $('bodegaConfirmBtn');
        confirmBtn.textContent = action === 'hide' ? 'Sí, marcar agotado' : 'Sí, volver a mostrar';
        confirmBtn.classList.toggle('bodega-btn-danger-solid', action === 'hide');
        confirmBtn.disabled = false;
        modal.classList.add('active');
        confirmBtn.focus();
    }

    function closeConfirm() {
        $('bodegaConfirmModal')?.classList.remove('active');
        pendingAction = null;
    }

    async function runPendingAction() {
        if (!pendingAction) return;
        const { action, productId } = pendingAction;
        const button = $('bodegaConfirmBtn');
        button.disabled = true;
        button.textContent = 'Guardando...';
        try {
            await window.firebaseData.setProductWarehouseAvailability(productId, action === 'restore');
            const product = productsById.get(productId);
            if (product) {
                if (action === 'hide') {
                    product.stockBeforeOutOfStock = Number.parseInt(product.stock, 10) || 0;
                    product.stock = 0;
                    product.active = false;
                } else {
                    product.stock = product.stockBeforeOutOfStock;
                    product.active = true;
                    delete product.stockBeforeOutOfStock;
                }
            }
            closeConfirm();
            renderProducts({ keepLimit: true });
            notify(action === 'hide' ? 'Producto marcado como agotado: ya no aparece en la tienda' : 'El producto volvió a la tienda', 'success');
        } catch (error) {
            console.error('Error actualizando producto desde bodega:', error);
            notify('No se pudo guardar el cambio. Inténtalo de nuevo.', 'error');
            button.disabled = false;
            button.textContent = action === 'hide' ? 'Sí, marcar agotado' : 'Sí, volver a mostrar';
        }
    }

    async function loadProducts() {
        try {
            const products = await window.firebaseData.loadProducts();
            productsById = new Map((products || []).map(product => [String(product.id), product]));
        } catch (error) {
            console.error('No se pudieron cargar los productos:', error);
        }
        renderProducts();
    }

    // ---------- Eventos ----------
    function setup() {
        document.querySelectorAll('.admin-nav [data-view]').forEach(link => {
            link.addEventListener('click', event => {
                event.preventDefault();
                setView(link.dataset.view);
                document.querySelector('.admin-sidebar')?.classList.remove('active');
            });
        });

        $('bodegaReloadBtn')?.addEventListener('click', async () => {
            const button = $('bodegaReloadBtn');
            button.disabled = true;
            if (typeof window.loadOrders === 'function') await window.loadOrders();
            await loadProducts();
            button.disabled = false;
            notify('Lista actualizada', 'success');
        });

        $('bodegaProductsSearch')?.addEventListener('input', () => renderProducts());
        document.querySelectorAll('[data-products-filter]').forEach(chip => {
            chip.addEventListener('click', () => {
                currentFilter = chip.dataset.productsFilter;
                renderProducts();
            });
        });

        $('bodegaProductsGrid')?.addEventListener('click', event => {
            const button = event.target.closest('[data-product-action]');
            if (!button) return;
            const id = button.closest('[data-product-id]')?.dataset.productId;
            const product = collectRecentProducts().find(item => item.id === id);
            if (product) openConfirm(button.dataset.productAction, product);
        });

        const modal = $('bodegaConfirmModal');
        modal?.addEventListener('click', event => {
            if (event.target === modal || event.target.closest('[data-confirm-close]')) closeConfirm();
        });
        $('bodegaConfirmBtn')?.addEventListener('click', runPendingAction);
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && modal?.classList.contains('active')) closeConfirm();
        });

        window.addEventListener('monsite:orders-loaded', event => {
            recentOrders = Array.isArray(event.detail?.orders) ? event.detail.orders : [];
            renderProducts({ keepLimit: true });
        });

        // Si los pedidos ya se cargaron antes de registrar el aviso, se toman directamente
        const loaded = typeof window.getLoadedOrders === 'function' ? window.getLoadedOrders() : [];
        if (Array.isArray(loaded) && loaded.length) recentOrders = loaded;

        let initial = 'orders';
        try { initial = sessionStorage.getItem('bodega_view') || 'orders'; } catch (_) { /* sin almacenamiento */ }
        setView(initial);
        loadProducts();
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
    else setup();
})();
