"""
preparar_dataset_quimico.py

Arma el ZIP que se sube a Google Drive para entrenar el modelo de historial químico
(natural / mechas / color) a partir de las carpetas etiquetadas en 02-desarrollo/data:

    data/Apta/natural      -> natural
    data/Apta/mechas       -> mechas
    data/Apta/tenido       -> color   (teñido y decolorado van juntos mientras haya
    data/Apta/decolorado   -> color    pocas fotos de cada uno; la etiqueta original
                                       queda en el CSV para separarlos más adelante)

Las fotos se renombran por su número (0001.jpg...) para evitar nombres largos o con
caracteres raros, y se guardan como JPEG RGB ya orientadas, igual que las prepara la API.

Uso (desde la raíz del proyecto):
    python 02-desarrollo/hair-ai/training/preparar_dataset_quimico.py
Resultado:
    dataset-ia/dataset_quimico_v1.zip   (carpeta fuera de git y fuera del sitio)
"""
import csv
import io
import os
import sys
import zipfile

from PIL import Image, ImageOps

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
DATA = os.path.join(ROOT, "02-desarrollo", "data")
OUT_DIR = os.path.join(ROOT, "dataset-ia")
OUT_ZIP = os.path.join(OUT_DIR, "dataset_quimico_v1.zip")

CLASS_OF = {"natural": "natural", "mechas": "mechas", "tenido": "color", "decolorado": "color"}


def long_path(path):
    # Algunos nombres originales superan el largo máximo de ruta de Windows
    path = os.path.abspath(path)
    return "\\\\?\\" + path if os.name == "nt" else path


def to_jpeg(path):
    img = Image.open(long_path(path))
    img = ImageOps.exif_transpose(img)
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        img = img.convert("RGBA")
        background = Image.new("RGB", img.size, (255, 255, 255))
        background.paste(img, mask=img.getchannel("A"))
        img = background
    else:
        img = img.convert("RGB")
    buffer = io.BytesIO()
    img.save(buffer, "JPEG", quality=95)
    return buffer.getvalue()


def main():
    csv_path = os.path.join(DATA, "etiquetas.csv")
    if not os.path.exists(csv_path):
        sys.exit(f"No existe {csv_path}")
    rows = [r for r in csv.DictReader(open(csv_path, encoding="utf-8-sig")) if r["etiqueta"] in CLASS_OF]

    os.makedirs(OUT_DIR, exist_ok=True)
    out_rows, counts, skipped = [], {}, 0
    with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_STORED) as zf:
        for row in rows:
            cls = CLASS_OF[row["etiqueta"]]
            source = os.path.join(DATA, row["carpeta"], row["archivo"])
            try:
                data = to_jpeg(source)
            except Exception as error:
                print(f"Omitida {row['archivo']}: {error}")
                skipped += 1
                continue
            name = f"{cls}/{int(row['n']):04d}.jpg"
            zf.writestr(name, data)
            counts[cls] = counts.get(cls, 0) + 1
            out_rows.append({"archivo": name, "clase": cls, "etiqueta_original": row["etiqueta"],
                             "confianza": row["confianza"], "nota": row["nota"], "nombre_original": row["archivo"]})

        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=list(out_rows[0].keys()))
        writer.writeheader()
        writer.writerows(out_rows)
        zf.writestr("etiquetas.csv", buffer.getvalue().encode("utf-8"))

    print(f"Listo: {OUT_ZIP} ({os.path.getsize(OUT_ZIP) / 1e6:.1f} MB)")
    print("Fotos por clase:", counts, "| omitidas:", skipped)


if __name__ == "__main__":
    main()
