# Criterios de etiquetado de fotos de cabello (Monsite)

Leer este archivo **antes de etiquetar o auditar cualquier foto**. Los criterios salen de las
revisiones hechas por el equipo (octubre 2026) y se actualizan cada vez que una revisión encuentra
un error nuevo.

## Reglas generales

- **Ante la duda, no se fuerza**: la foto se marca como *dudosa* (columna `dudosa`) y queda fuera
  del entrenamiento hasta que una persona la revise.
- **La luz engaña**: brillo, reflejos y sobreexposición no son mechas, canas, caspa ni grasa.
- Las fotos con `revisado_por_usuario = si` son la referencia: no se cambian en una auditoría.
- No aptas: blanco y negro, filtros de color fuertes, marca de agua grande, collage, foto muy
  pequeña, pelucas o extensiones, trenzas o rastas que tapan el cabello, repetidas.

## Cuerpo del cabello

### Color (modelo químico)

| Etiqueta | Sí | No |
|---|---|---|
| **natural** | Mismo tono de raíz a puntas; diferencias solo por luz o sol | — |
| **mechas** | Hebras claras y oscuras **mezcladas**, balayage, ombré (degradado), mechones de color (fantasía) sobre base distinta, capa inferior o flequillo de otro color | Zonas más claras por luz o reflejo |
| **tenido** | Color artificial **parejo** (cobrizo intenso, caoba, borgoña, fantasía completa) | Castaño o cobrizo que puede ser natural → dudosa |
| **decolorado** | Rubio o platinado **parejo y compacto** en todo el largo, aunque se vea la raíz oscura crecida ("criterio B") | Rubio en largos con hebras oscuras mezcladas → mechas |

- Rubio parejo de nacimiento vs. decolorado: sin raíz ni cejas que lo delaten → dudosa / no apta.
- Bloque rubio **sólido y compacto** (capa inferior tipo *underlayer* o mitad inferior completa, con corte
  tajante) → **decolorado** (criterio B), no mechas. Mechas solo si hay mechones entretejidos con la base.
- Laterales rapados y barba oscuros con el copete claro y parejo → decolorado.

### Frizz

- **Sí**: pelitos sueltos **flotando sobre la superficie** de los mechones, aspecto esponjado,
  opaco o "nube", sobre todo en coronilla y costados.
- **No**: rizos o espirales **definidos** con borde limpio (aunque tengan mucho volumen), mechones
  agrupados con cera, gel o pomada, efecto mojado, despeinado intencional con producto, ondas con brillo.
- El volumen de un afro definido **no** es frizz.
- Cortes texturizados (*wolf cut*, capas desordenadas) con mechones agrupados y brillo → **sin frizz**.
- Mirar sobre todo **flequillo, coronilla, capas superiores y contorno**: ahí es donde aparecen los
  pelitos finos flotando cuando hay frizz (muy común después de una decoloración global).

### Daño visible

- **Sí**: pelo **pajizo**, opaco, áspero, cutícula abierta, puntas quebradizas o deshilachadas,
  enredado de medios a puntas, típico después de decolorar.
- **No**: solo tener mechas o decoloración; aspecto tieso o duro por gel o producto.
- Reseco leve o no se distingue → dudosa.
- **Frizz y daño son distintos**: frizz = pelitos finos sueltos flotando; daño = **quiebre de la fibra**,
  hebras rígidas, ásperas y deshilachadas que se abren hacia los lados. Una foto puede tener frizz sin daño.

## Cuero cabelludo

Cada condición se marca por separado (una foto puede tener varias). Sano = todas en "no".

### Graso: las 3 señales (definidas por el equipo, 12-10-2026)

1. **Raíces brillantes**: el cuero cabelludo y las raíces se ven brillantes, **como si estuvieran húmedos,
   aunque el resto del cabello esté seco**.
2. **Cabello agrupado en mechones**: los pelos se pegan entre sí **cerca de la raíz** y pierden volumen
   (se separan en tiras desde la raya).
3. **Aspecto apelmazado**: la zona de la **coronilla y la raya se ve más oscura o compacta** por la
   acumulación de sebo (el pelo pegado al cuero, "aplastado").

- **Dónde está el brillo (regla clave)**: el brillo de grasa se ve **en la raíz, donde el pelo recién sale
  del cuero** (junto a la raya y la coronilla). Si el brillo está en el **cuerpo o los largos** del pelo,
  probablemente es un producto de brillo (sérum, aceite, spray), que **no se aplica en la raíz** → no es grasa.
- **Caspa pegada al pelo** (no suelta) junto con raíz brillante → también es **grasa** (caspa grasa).
  La caspa suelta y seca sobre un cuero sin brillo no indica grasa.
- **Pelos juntos en la raíz** cuentan aunque la luz no deje confirmar el brillo.
- Grasa **leve** (≈20-30 %: algo de brillo y pelo apenas junto) → se marca graso (nivel bajo).
- **Brillo sin que el pelo se junte ni se apelmace** → probablemente luz → no es grasa.
- Pelo **seco y opaco** (aunque tenga canas) → no es grasa.
- Si las **manos tapan la raíz** → no apta.
- Con **una** señal clara → graso. Con señales débiles o que pueden ser otra cosa → dudosa.
- **No es grasa**: brillo de luz de estudio sobre pelo suelto y con volumen; pelo mojado de verdad (todo el
  largo húmedo); brillo de gel o producto en todo el peinado; brillo de las canas.
- No siempre se puede confirmar solo con una imagen: ante la duda, dudosa.

### Canas: niveles y criterios de aceptación (definidos por el equipo, 12-10-2026)

| Nivel | Nombre | Qué se ve |
|---|---|---|
| **0** | Sin canas visibles | No se identifican cabellos blancos o grises en la zona evaluable de la raíz |
| **1** | Presencia leve | Algunas canas **aisladas** entre cabellos pigmentados |
| **2** | Presencia moderada | **Numerosas** canas mezcladas con cabellos pigmentados |
| **3** | Presencia alta | **Predominan** los cabellos blancos o grises en la zona visible de la raíz |

- **CA-01** La foto debe mostrar claramente la raíz y parte del cuero cabelludo; si no → no apta.
- **CA-02** Cana = cabello blanco, gris o plateado **que nace cerca del cuero cabelludo**.
- **CA-03** Distinguir de los **reflejos de luz**; si no se puede → dudosa.
- **CA-04 / CA-10** Distinguir de cabello **teñido o decolorado** (rubio platinado, gris de fantasía). Si no
  se puede saber si es cana o aclarado artificial → dudosa. Las canas que asoman en la **raíz crecida bajo un
  tinte** sí cuentan.
- **CA-05** Canas aisladas en la raíz → nivel 1. **CA-06** Varias distribuidas → nivel 2 o 3.
- **CA-07** Foto borrosa, oscura o sobreexpuesta → no apta (no se diagnostica).
- **CA-08** Nivel 0 significa "no se ven canas", no que no existan.
- **CA-09** Evaluar en la **zona de la raíz**, no solo en medios y puntas (los largos aclarados no son canas).
- El **cuero cabelludo blanco** entre los pelos **no** es cana.
- **Nivel 1 exige ver hebras blancas individuales y nítidas.** Una raya o zona clara, brillo fuerte o
  luz de estudio, escasez de pelo con cuero visible, o puntos blancos de caspa → **nivel 0**, no "leve".
  (En la revisión del 12-10-2026, 5 de 10 "nivel 1" eran cuero blanco o brillo.)
- Ante la duda entre 0 y 1 → nivel 0.

| Condición | Sí | No |
|---|---|---|
| **graso** | Brillo **aceitoso** en el pelo junto a la raíz, mechones pegados o agrupados, cabello aplastado | Brillo parejo de cabello liso y limpio; brillo de las canas |
| **caspa / irritación** | Escamas blancas o amarillentas **sobre** la piel o el pelo; enrojecimiento del cuero | Piel clara; reflejos de luz en el pelo; puntos dudosos → dudosa |
| **baja densidad** | Raya más ancha de lo normal, cuero visible entre los pelos, entradas o coronilla rala | Juzgar por cuánta piel se ve, **no** por lo clara que es |
| **canas** | **Hebras** blancas o grises visibles en el pelo | Cuero blanco entre los pelos; reflejos de luz |

## Historial de errores corregidos

| Error que se cometía | Corrección |
|---|---|
| Cuero blanco o luz tomados como canas (6 de 10) | Canas solo si se ven hebras |
| Reflejos tomados como caspa | Caspa solo si hay escamas sobre la piel |
| Grasa no vista cuando había raya ancha | Revisar cada condición por separado |
| Luz tomada como mechas (3 de 10) | Mechas solo con hebras claras reales |
| Rizos definidos o cera tomados como frizz | Frizz = pelitos sueltos flotando |
| Mechas tomadas como daño (7 de 10) | Daño = textura pajiza, no el color |
| Rubio con raíz oscura siempre como decolorado | Criterio B |
| Bloque rubio compacto (underlayer) tomado como mechas | Bloque sólido = decolorado |
| Frizz y daño mezclados; decoloración tomada como daño (3.ª revisión) | Frizz = pelitos flotando; daño = quiebre de la fibra |
