# ============================================================
# MONSITE - API IA CAPILAR (Cloud Run)
# Tipo V2 + Condición V3 + Frizz V1 + Cuero cabelludo V1 (beta) + Químico V1
#
# Mismo comportamiento que el notebook TestearModelo.ipynb (Colab + ngrok), pero
# como servicio permanente: los modelos van dentro de la imagen (carpeta models/,
# fuera de git) y se cargan una vez al arrancar.
# ============================================================

import io
import json
import os
import re
import threading
import time
import warnings
from collections import defaultdict, deque

import numpy as np
import tensorflow as tf
from flask import Flask, jsonify, request
from flask_cors import CORS
from PIL import Image, ImageOps, UnidentifiedImageError

API_VERSION = "4.3-cloudrun"
IMG_SIZE = 224
MAX_IMAGE_SIZE_MB = 10
MODEL_PATH = os.environ.get("MODEL_PATH", os.path.join(os.path.dirname(__file__), "models"))

# Una foto de celular tiene ~12-50 MP; más que esto se trata como imagen maliciosa
# ("bomba de descompresión": pocos MB que al abrirse ocupan GB de memoria).
Image.MAX_IMAGE_PIXELS = 60_000_000
warnings.simplefilter("error", Image.DecompressionBombWarning)

# Solo la tienda puede llamar a la API desde el navegador
ALLOWED_ORIGINS = [
    "https://monsite-85424.web.app",
    "https://monsite-85424.firebaseapp.com",
    re.compile(r"^https://monsite-85424--[a-z0-9-]+\.web\.app$"),  # canales de vista previa
    "http://localhost:5500",
    "http://127.0.0.1:5500",
]

# Tope de análisis por IP (en memoria de cada instancia)
RATE_LIMIT_WINDOW_S = 10 * 60
RATE_LIMIT_MAX = int(os.environ.get("PREDICT_MAX_PER_IP", "30"))


# ============================================================
# MODELOS
# ============================================================

MODELS_CONFIG = {
    "type": {
        "file": "hair_classifier_v2.keras",
        "metadata": "hair_classifier_v2_metadata.json",
        "expected_classes": ["straight", "wavy", "curly", "dreadlocks", "kinky"],
        "labels": {
            "straight": "Liso",
            "wavy": "Ondulado",
            "curly": "Rizado",
            "dreadlocks": "Rastas",
            "kinky": "Afro",
        },
    },
    "condition": {
        "file": "hair_condition_classifier_v3.keras",
        "metadata": "hair_condition_classifier_v3_metadata.json",
        "expected_classes": ["normal", "seco"],
        "labels": {"normal": "Normal", "seco": "Seco"},
    },
    "frizz": {
        "file": "hair_frizz_classifier_v1.keras",
        "metadata": "hair_frizz_classifier_v1_metadata.json",
        "expected_classes": ["sin_frizz", "con_frizz"],
        "labels": {"sin_frizz": "Sin frizz", "con_frizz": "Con frizz"},
    },
    # Historial químico: solo para la foto del cuerpo del cabello (la página envía chem=1)
    "chemical": {
        "file": "hair_chemical_classifier_v1.keras",
        "metadata": "hair_chemical_classifier_v1_metadata.json",
        "expected_classes": ["natural", "mechas", "color"],
        "labels": {"natural": "Natural", "mechas": "Con mechas", "color": "Con color"},
    },
}


def load_metadata(path, fallback):
    if not os.path.exists(path):
        return {"class_names": fallback}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"class_names": fallback}


def load_models():
    loaded = {}
    for key, config in MODELS_CONFIG.items():
        model_file = os.path.join(MODEL_PATH, config["file"])
        if not os.path.exists(model_file):
            raise FileNotFoundError(f"No existe el modelo: {model_file}")

        metadata = load_metadata(os.path.join(MODEL_PATH, config["metadata"]), config["expected_classes"])
        classes = [str(x).strip().lower() for x in metadata.get("class_names", config["expected_classes"])]
        expected = [str(x).strip().lower() for x in config["expected_classes"]]
        if classes != expected:
            raise ValueError(f"Orden de clases incorrecto en {key}: {classes} (esperado {expected})")

        model = tf.keras.models.load_model(model_file, compile=False)
        output_units = int(model.output_shape[-1])
        if output_units != len(classes):
            raise ValueError(f"{key}: el modelo devuelve {output_units} clases pero metadata tiene {len(classes)}")

        loaded[key] = {
            "model": model,
            "classes": classes,
            "metadata": metadata,
            "labels": config["labels"],
            "file": config["file"],
        }
        print(f"Modelo {key} cargado: {config['file']}", flush=True)
    return loaded


# Modelo de cuero cabelludo (beta): 2 salidas
#   "condiciones": probabilidad independiente de graso / caspa_irritacion / baja_densidad / canas (sigmoid)
#   "canas_nivel": nivel 0-3 (softmax). Los umbrales por condición vienen en su metadata.
SCALP_CONFIG = {
    "file": "hair_scalp_classifier_v1.keras",
    "metadata": "hair_scalp_classifier_v1_metadata.json",
    "labels": ["graso", "caspa_irritacion", "baja_densidad", "canas"],
    "levels": ["sin_canas", "leve", "moderada", "alta"],
}


def _training_loss_placeholder(y_true, y_pred):
    # El modelo se entrenó con pérdidas propias; para predecir no se usan (compile=False)
    return tf.reduce_mean(y_pred)


def load_scalp_model():
    model_file = os.path.join(MODEL_PATH, SCALP_CONFIG["file"])
    if not os.path.exists(model_file):
        raise FileNotFoundError(f"No existe el modelo: {model_file}")
    metadata = load_metadata(os.path.join(MODEL_PATH, SCALP_CONFIG["metadata"]), [])
    if metadata.get("labels") != SCALP_CONFIG["labels"] or metadata.get("canas_niveles") != SCALP_CONFIG["levels"]:
        raise ValueError(f"Etiquetas del modelo de cuero cabelludo distintas a las esperadas: {metadata.get('labels')}")
    model = tf.keras.models.load_model(
        model_file,
        compile=False,
        custom_objects={
            "monsite>bce_ponderada": _training_loss_placeholder,
            "monsite>nivel_ponderado": _training_loss_placeholder,
        },
    )
    thresholds = {label: float(metadata.get("thresholds", {}).get(label, 0.5)) for label in SCALP_CONFIG["labels"]}
    print(f"Modelo scalp cargado: {SCALP_CONFIG['file']} (v{metadata.get('version')})", flush=True)
    return {"model": model, "thresholds": thresholds, "metadata": metadata, "file": SCALP_CONFIG["file"]}


_started = time.time()
models = load_models()
scalp_model = load_scalp_model()
print(f"Los {len(models) + 1} modelos cargados en {time.time() - _started:.1f} s", flush=True)

# Calentar los modelos: la primera inferencia de TensorFlow es más lenta
_warmup = np.zeros((1, IMG_SIZE, IMG_SIZE, 3), dtype=np.float32)
for _data in models.values():
    _data["model"](_warmup, training=False)
scalp_model["model"](_warmup, training=False)


# ============================================================
# PREPROCESAMIENTO
# ============================================================

def preprocess_image(image_bytes):
    if not image_bytes:
        raise ValueError("La imagen está vacía.")
    if len(image_bytes) / (1024 * 1024) > MAX_IMAGE_SIZE_MB:
        raise ValueError(f"La imagen supera {MAX_IMAGE_SIZE_MB} MB.")

    try:
        img = Image.open(io.BytesIO(image_bytes))
        img.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise ValueError("El archivo no es una imagen válida.")

    img = ImageOps.exif_transpose(img)  # corregir orientación

    if img.mode == "RGBA":  # transparencia -> fondo blanco
        background = Image.new("RGB", img.size, (255, 255, 255))
        background.paste(img, mask=img.getchannel("A"))
        img = background
    elif img.mode != "RGB":
        img = img.convert("RGB")

    img = img.resize((IMG_SIZE, IMG_SIZE), Image.Resampling.LANCZOS)
    img_array = np.asarray(img, dtype=np.float32)
    img_array = tf.keras.applications.resnet50.preprocess_input(img_array)  # los 3 usan ResNet50
    return np.expand_dims(img_array, axis=0)


# ============================================================
# PREDICCIÓN
# ============================================================

def predict_one(model_key, image):
    data = models[model_key]
    probabilities = np.asarray(data["model"](image, training=False))[0]
    index = int(np.argmax(probabilities))
    prediction = data["classes"][index]
    confidence = float(probabilities[index])
    return {
        "prediction": prediction,
        "label": data["labels"].get(prediction, prediction),
        "confidence": confidence,
        "confidence_percent": round(confidence * 100, 2),
        "probabilities": {name: float(probabilities[i]) for i, name in enumerate(data["classes"])},
    }


def predict_scalp(image):
    out = scalp_model["model"](image, training=False)
    if isinstance(out, dict):
        cond, levels = out["condiciones"], out["canas_nivel"]
    else:  # por si el modelo se guardó con salidas en lista (mismo orden de entrenamiento)
        cond, levels = out[0], out[1]
    cond = np.asarray(cond)[0]
    levels = np.asarray(levels)[0]

    labels = SCALP_CONFIG["labels"]
    probabilities = {name: float(cond[i]) for i, name in enumerate(labels)}
    thresholds = scalp_model["thresholds"]
    detected = {name: probabilities[name] >= thresholds[name] for name in labels}

    # Regla del entrenamiento: el sí/no de canas decide; el nivel solo elige leve/moderada/alta
    level_names = SCALP_CONFIG["levels"]
    level = 1 + int(np.argmax(levels[1:])) if detected["canas"] else 0
    return {
        "probabilities": probabilities,
        "thresholds": thresholds,
        "detected": detected,
        "canas_nivel": {
            "level": level,
            "label": level_names[level],
            "probabilities": {name: float(levels[i]) for i, name in enumerate(level_names)},
        },
        "model_version": str(scalp_model["metadata"].get("version", "")),
        "status": "beta",
    }


def get_needs(hair_type, condition, frizz):
    needs = []
    if condition == "seco":
        needs.extend(["Hidratación / cabello seco", "Brillo / suavidad"])
    if frizz == "con_frizz":
        needs.append("Control de frizz")
    if hair_type in ["wavy", "curly", "kinky"]:
        needs.append("Rizos / ondas")
    if not needs:
        needs.append("Mantenimiento")
    return list(dict.fromkeys(needs))


# ============================================================
# LÍMITE POR IP
# ============================================================

_hits = defaultdict(deque)
_hits_lock = threading.Lock()


def client_ip():
    # Cloud Run agrega la IP real del cliente al final de X-Forwarded-For
    forwarded = request.headers.get("X-Forwarded-For", "")
    return forwarded.split(",")[-1].strip() if forwarded else (request.remote_addr or "unknown")


def allow_request(ip):
    now = time.time()
    with _hits_lock:
        window = _hits[ip]
        while window and now - window[0] > RATE_LIMIT_WINDOW_S:
            window.popleft()
        if len(window) >= RATE_LIMIT_MAX:
            return False
        window.append(now)
        if len(_hits) > 10000:
            for key in [k for k, v in _hits.items() if not v or now - v[-1] > RATE_LIMIT_WINDOW_S]:
                _hits.pop(key, None)
        return True


# ============================================================
# FLASK
# ============================================================

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_IMAGE_SIZE_MB * 1024 * 1024

CORS(
    app,
    resources={r"/*": {"origins": ALLOWED_ORIGINS}},
    allow_headers=["Content-Type", "ngrok-skip-browser-warning"],
    methods=["GET", "POST", "OPTIONS"],
)


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.route("/")
def home():
    return jsonify({
        "success": True,
        "name": "Monsite Hair Analysis API",
        "version": API_VERSION,
        "models": {
            "type": "hair_classifier_v2",
            "condition": "hair_condition_classifier_v3",
            "frizz": "hair_frizz_classifier_v1",
            "scalp": "hair_scalp_classifier_v1 (beta)",
            "chemical": "hair_chemical_classifier_v1",
        },
        "endpoints": {"health": "/health", "models": "/models", "predict": "/predict"},
    })


@app.route("/health")
def health():
    return jsonify({
        "success": True,
        "status": "online",
        "api_version": API_VERSION,
        "models": {**{key: True for key in models}, "scalp": True},
    })


@app.route("/models")
def models_info():
    info = {
        key: {
            "file": data["file"],
            "classes": data["classes"],
            "input_shape": [IMG_SIZE, IMG_SIZE, 3],
            "preprocessing": "resnet50.preprocess_input",
        }
        for key, data in models.items()
    }
    info["scalp"] = {
        "file": scalp_model["file"],
        "labels": SCALP_CONFIG["labels"],
        "levels": SCALP_CONFIG["levels"],
        "thresholds": scalp_model["thresholds"],
        "version": scalp_model["metadata"].get("version"),
        "input_shape": [IMG_SIZE, IMG_SIZE, 3],
        "preprocessing": "resnet50.preprocess_input",
    }
    return jsonify(info)


@app.route("/predict", methods=["POST"])
def predict():
    start = time.time()
    if not allow_request(client_ip()):
        return jsonify({"success": False, "error": "Hiciste muchos análisis seguidos. Espera unos minutos e inténtalo de nuevo."}), 429

    try:
        if "image" not in request.files:
            return jsonify({"success": False, "error": "No se envió ninguna imagen."}), 400
        file = request.files["image"]
        if not file.filename:
            return jsonify({"success": False, "error": "Archivo vacío."}), 400

        image = preprocess_image(file.read())

        result_type = predict_one("type", image)
        result_condition = predict_one("condition", image)
        result_frizz = predict_one("frizz", image)

        hair_type = result_type["prediction"]
        condition = result_condition["prediction"]
        frizz = result_frizz["prediction"]

        # El modelo de cuero cabelludo solo corre para la foto de la raíz (la página envía scalp=1)
        result_scalp = predict_scalp(image) if request.form.get("scalp") == "1" else None
        # El modelo químico solo corre para la foto del cuerpo del cabello (chem=1)
        result_chemical = predict_one("chemical", image) if request.form.get("chem") == "1" else None

        return jsonify({
            "success": True,
            "analysis": {
                "hair_type": hair_type,
                "hair_type_label": result_type["label"],
                "condition": condition,
                "condition_label": result_condition["label"],
                "frizz": frizz,
                "frizz_label": result_frizz["label"],
                "needs": get_needs(hair_type, condition, frizz),
            },
            "type": result_type,
            "condition": result_condition,
            "frizz": result_frizz,
            **({"scalp": result_scalp} if result_scalp else {}),
            **({"chemical": result_chemical} if result_chemical else {}),
            "processing_time_ms": int((time.time() - start) * 1000),
        })

    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        print("ERROR en /predict:", repr(e), flush=True)
        return jsonify({"success": False, "error": "Error interno procesando la imagen."}), 500


@app.errorhandler(413)
def too_large(error):
    return jsonify({"success": False, "error": f"La imagen supera {MAX_IMAGE_SIZE_MB} MB."}), 413


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")), debug=False)
