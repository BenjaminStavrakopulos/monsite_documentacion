> Revisión de seguridad estática (2026-10-04) sobre el commit 1bb4903. Sin pruebas en vivo ni de carga (límite acordado: máx. 300 usuarios en futuras pruebas para evitar costos de Firebase).

# Revisión de seguridad

**Resultado: 4 hallazgos de seguridad: 2 HIGH y 2 MEDIUM.** El hallazgo de Webpay depende de la configuración del despliegue. No se estableció ninguna vulnerabilidad CRITICAL.

Se revisó el repositorio en el commit `1bb49036d9ccef95a03ebe9e8f9856f037525e04`, incluyendo el código fuente de la aplicación, las reglas de Firebase, la configuración de hosting, los scripts, los manifiestos de dependencias/lockfiles y el historial disponible localmente.

**Validaciones realizadas**
- Auditorías de dependencias en modo solo lectura en las tres carpetas de paquetes.
- Búsqueda de patrones de credenciales en **75 commits accesibles localmente**, incluyendo aproximadamente **8,8 MB de parches del historial**.
- Verificación de sintaxis en **93 archivos JavaScript versionados**.
- Reproducciones offline, con mocks, de los cuatro hallazgos descritos abajo.
- Ejecución del escáner de secretos existente en el repositorio.

**No se modificó ningún archivo del repositorio. No se hicieron peticiones a las aplicaciones desplegadas, Firebase, proveedores de pago, SMTP, WhatsApp ni a la API de análisis capilar.** Por lo tanto, “OK” significa que no se estableció un problema explotable a partir del código fuente, no que el despliegue esté probadamente seguro. Cloud IAM, las reglas desplegadas, la configuración de Firebase Auth, la configuración de los proveedores y los servicios externos no fueron verificados.

## Tabla de hallazgos

| # | Severidad | Archivo | Líneas | Vulnerabilidad | Confianza |
|---|---|---|---|---|---|
| F1 | **HIGH** | [manage-admin.js](./02-desarrollo/backend/scripts/manage-admin.js:171), [require-admin.js](./02-desarrollo/backend/middleware/require-admin.js:14), [storage.rules](./02-desarrollo/storage.rules:7) | 171–190; 14–17; 7–10 | Administradores revocados/degradados conservan acceso privilegiado mediante claims de admin emitidos previamente | **10/10** |
| F2 | **MEDIUM** | [payment.js](./02-desarrollo/backend/routes/payment.js:695), [order-payment.js](./02-desarrollo/backend/lib/order-payment.js:109), [firebase-config.js](./02-desarrollo/js/config/firebase-config.js:1145) | 695–725; 109–134; 1145–1154 | Los clientes pueden devolver pedidos entregados/cancelados al estado `paid` repitiendo la conciliación de pago | **10/10** |
| F3 | **MEDIUM** | [orders.js](./02-desarrollo/backend/routes/orders.js:206), [pricing.js](./02-desarrollo/backend/lib/pricing.js:51) | 206–208, 234–246; 51–72 | Solicitudes de checkout concurrentes evitan los límites globales y por usuario de los cupones | **10/10** |
| F4 | **HIGH** | [transbank.js](./02-desarrollo/backend/routes/transbank.js:240), [firestore.rules](./02-desarrollo/firestore.rules:250) | 240–255, 308–328, 379–393; 250–255 | La confirmación de Webpay no está vinculada de forma segura al pedido/intención de pago original; un alias por referencia truncada puede marcarse como pagado | **8/10**, condicional |

## Detalle de los hallazgos

### F1 — Revocar a un administrador no invalida sus claims privilegiados existentes

**Categoría:** BrokenAccessControl  
**Severidad: HIGH | Confianza: 10/10**

**Problema:** [revokeAdmin](./02-desarrollo/backend/scripts/manage-admin.js:171) cambia los custom claims y el rol actual en Firestore, pero no revoca los refresh tokens. Los ID tokens emitidos anteriormente siguen conteniendo `admin: true` hasta que expiran.

[requireAdmin](./02-desarrollo/backend/middleware/require-admin.js:14) acepta inmediatamente ese claim antiguo sin consultar el rol actual. La verificación de tokens del backend con soporte de revocación no puede rechazar un token si nunca se ejecutó la revocación.

La misma tolerancia a claims obsoletos existe en la [autorización de Storage](./02-desarrollo/storage.rules:7). Además, el [media worker](./02-desarrollo/media-worker/server.js:52) verifica tokens sin `checkRevoked`.

**Escenario de explotación:** Un administrador guarda un ID token antes de ser removido. Después de la remoción, usa ese token para invocar endpoints de administrador —por ejemplo, el [procesamiento de reembolsos](./02-desarrollo/backend/routes/payment.js:791)— o para realizar escrituras privilegiadas en Storage. El acceso puede mantenerse durante el resto de la vida del ID token, normalmente hasta aproximadamente una hora.

**Evidencia:** Una ejecución offline del middleware de autorización real aceptó un token antiguo con `admin: true` sin consultar el rol actual.

**Solución:**
- Revocar los refresh tokens al quitar/degradar privilegios.
- Exigir verificación con revocación (`checkRevoked`) en todos los servicios privilegiados del backend.
- Consultar el **rol autoritativo actual o una versión de autorización** antes de operaciones sensibles.
- Hacer que las reglas de Storage consulten el estado de autorización actual en vez de aceptar un claim antiguo mediante un `OR` incondicional. La revocación por sí sola no invalida inmediatamente un ID token en todas las evaluaciones de reglas de Firebase.

### F2 — La conciliación de pagos puede deshacer el despacho y la cancelación

**Categoría:** BrokenAccessControl / DataIntegrityFailure  
**Severidad: MEDIUM | Confianza: 10/10**

**Problema:** Las [actualizaciones de estado](./02-desarrollo/js/config/firebase-config.js:1145) del administrador asignan tanto el estado de despacho como `paymentStatus` a valores como `shipped`, `delivered` o `cancelled`.

El [endpoint de estado del pedido](./02-desarrollo/backend/routes/payment.js:695), accesible por el cliente, considera que cualquier valor distinto de `status === paid` o `paymentStatus === approved` requiere conciliación. Busca el pago aprobado original en el proveedor y llama a [markOrderAsPaid](./02-desarrollo/backend/lib/order-payment.js:88).

La rama de idempotencia de inventario de esa función igualmente sobrescribe el estado del pedido con `paid`; no preserva los estados de despacho ni los estados finales.

**Escenario de explotación:** Después de que un administrador marca una compra como entregada, el cliente consulta el endpoint de estado de su pedido. Como el pago original sigue aprobado en Mercado Pago, el pedido entregado vuelve a `paid` y aparece nuevamente como listo para preparar. Esto permite cambios de estado no autorizados y podría provocar un despacho duplicado. La misma regresión puede afectar a un pedido cancelado localmente cuyo pago en el proveedor siga aprobado.

**Evidencia:** Una ejecución offline del endpoint real del cliente volvió a marcar como pagado un pedido `delivered`. Una ejecución separada de la función compartida real confirmó que `inventoryAdjustedAt` evita otro descuento de stock, pero **no evita la regresión de estado**.

**Solución:**
- Separar el estado de pago del estado de despacho.
- Conciliar solo intenciones de pago realmente impagas/pendientes.
- Aplicar las transiciones de estado permitidas dentro de la transacción, usando el pedido recién leído.
- Tratar la confirmación repetida del mismo pago como una operación sin efecto (no-op) sobre el estado de despacho.
- Aplicar las mismas protecciones al procesamiento de webhooks.

### F3 — Los límites de uso de cupones se verifican fuera de la transacción

**Categoría:** BrokenAccessControl / DataIntegrityFailure  
**Severidad: MEDIUM | Confianza: 10/10**

**Problema:** La [resolución del cupón](./02-desarrollo/backend/routes/orders.js:206) verifica los contadores antes de la transacción del pedido. La [transacción](./02-desarrollo/backend/routes/orders.js:234) posterior escribe `usedCount` y `usersApplied` a partir de ese snapshot leído previamente; no vuelve a leer ni a validar el cupón dentro de la transacción.

**Escenario de explotación:** Un comprador envía dos solicitudes de checkout simultáneas con un cupón que permite un solo uso. Ambas leen cero usos, ambas crean pedidos con descuento y ambas escriben el contador en uno. El comprador puede pagar ambos pedidos, porque sus descuentos llevan la marca de precio confiable calculado por el servidor.

**Evidencia:** Una ejecución offline concurrente de la ruta real de pedidos con `maxUses: 1` y `usesPerUser: 1` produjo **dos respuestas HTTP 201 y dos pedidos con descuento**, y ambas actualizaciones escribieron `usedCount: 1`.

**Solución:**
- Leer y validar el documento del cupón dentro de la misma transacción que reserva el uso y crea el pedido.
- Calcular los contadores a partir de ese snapshot transaccional.
- Agregar una reserva de uso idempotente asociada al pedido/cliente.
- Definir cuándo expiran o se liberan las reservas de pedidos abandonados. Un incremento atómico por sí solo no impone un máximo.

### F4 — La referencia truncada de Webpay puede seleccionar otro pedido

**Categoría:** BrokenAccessControl / DataIntegrityFailure  
**Severidad: HIGH | Confianza: 8/10**

**Problema:** La [creación de la transacción](./02-desarrollo/backend/routes/transbank.js:240) trunca el ID del pedido a 26 caracteres para `buyOrder`. Luego, la confirmación [busca un pedido usando ese valor truncado](./02-desarrollo/backend/routes/transbank.js:316), en lugar de resolver un mapeo de intención de pago almacenado.

El callback no valida el token recibido contra el `transbankToken` guardado en el pedido, ni vincula la sesión devuelta con el dueño del pedido. Los montos esperados ausentes son [aceptados](./02-desarrollo/backend/routes/transbank.js:325). La [rama de recuperación de estado](./02-desarrollo/backend/routes/transbank.js:379) tampoco valida el monto.

**Escenario de explotación:** Si Webpay está habilitado y se permite crear pedidos desde el cliente:
1. El atacante crea/paga un pedido barato con un ID largo.
2. Crea otro pedido pendiente cuyo ID corresponde a los primeros 26 caracteres de ese ID, con productos caros.
3. Webpay devuelve la referencia truncada.
4. La confirmación resuelve el pedido alias, acepta que falte el monto esperado y marca como pagado el pedido caro.

**Evidencia:** Una ejecución offline del callback real seleccionó el pedido alias y lo marcó como pagado usando la respuesta aprobada simulada del proveedor para la transacción barata, sin validar monto esperado ni token.

**Condiciones del despliegue:** Webpay está deshabilitado por defecto si no hay credenciales ni el override de integración. Además, las reglas de Firestore versionadas contienen una expresión no soportada, descrita más abajo; su comportamiento real desplegado no fue verificado. Esta es una ruta confirmada en el código de la aplicación, **no una afirmación de que la tienda desplegada permita actualmente este ataque**.

**Solución:**
- Generar un ID de intención de pago distinto, con largo compatible con el proveedor, y guardar un mapeo autoritativo al ID completo del pedido.
- Resolver los callbacks mediante ese mapeo o el token guardado del proveedor, no mediante documentos de pedido arbitrarios.
- Exigir coincidencia de token, referencia, dueño/sesión, monto, moneda y estado aprobado, tanto en la ruta normal como en la de recuperación.
- Fallar de forma segura (fail closed) cuando falten los datos de pago esperados.
- Preferir que la creación de pedidos se haga solo desde el backend.

## Resultados de la auditoría de dependencias

Las tres auditorías se completaron con `npm audit --json --ignore-scripts`; no se instaló nada ni se aplicaron correcciones automáticas.

| Carpeta del paquete | Avisos HIGH | Avisos MODERATE | Total de avisos por paquete |
|---|---:|---:|---:|
| [Frontend/paquete raíz](./02-desarrollo/package.json) | 0 | 0 | 0 |
| [Paquete backend](./02-desarrollo/backend/package.json) | 7 | 8 | 15 |
| [Paquete media-worker](./02-desarrollo/media-worker/package.json) | 2 | 7 | 9 |

Estos son **avisos a nivel de paquete**, incluida la propagación por dependencias duplicadas/transitivas; no son 24 vulnerabilidades independientes explotables en la aplicación.

| Dependencia | Versión bloqueada | Evidencia del aviso | Evaluación / corrección |
|---|---|---|---|
| `firebase-admin` / `node-forge` | 12.7.0 / 1.4.0 | [GHSA-86w9-cpqp-85rv](https://github.com/advisories/GHSA-86w9-cpqp-85rv): debilidad en la verificación de firmas RSA | Presente en ambos servicios. No se estableció un uso alcanzable por un atacante de la operación de verificación afectada; no se debe inferir falsificación de ID tokens de Firebase solo por esta auditoría. La auditoría propone `firebase-admin` 14.5.0. |
| `nodemailer` | 9.1.1 | [Problema de caché de nombre de servidor TLS](https://github.com/advisories/GHSA-6vj9-mwq6-2f5v), [problema de parseo de destinatarios](https://github.com/advisories/GHSA-g57g-f23g-4646), además de avisos de disponibilidad | Dependencia de producción del backend. La aplicación usa un único transporter configurado por variables de entorno, por lo que no se estableció el escenario de transporte entre tenants. Actualizar a una versión parcheada y probada que cubra todos los avisos: al menos 10.0.9 para los rangos listados. |
| `uuid` | 10.0.0 y 9.0.1 anidada | [GHSA-w5hq-g745-h8pq](https://github.com/advisories/GHSA-w5hq-g745-h8pq): problema de límites de buffer en v3/v5/v6 | No se estableció una ruta relevante con buffers controlados por quien llama. Actualizar las cadenas de dependencias afectadas. |
| `mercadopago` | 2.13.0 | Propagación de la auditoría a través de `uuid` | La auditoría propone 3.6.1; validar la compatibilidad de la API del SDK antes de actualizar. |
| `xlsx` | 0.18.5 | [Prototype pollution](https://github.com/advisories/GHSA-4r6h-8v6p-xvw6), [ReDoS](https://github.com/advisories/GHSA-5pgg-2g8v-p4x9) | Usado por un script local de importación, no por un endpoint web de subida identificado. No se estableció explotación remota en producción. Reemplazar/actualizar antes de procesar planillas no confiables; la auditoría no ofrece corrección automática. |
| `nodemon` / `chokidar` / `braces` | 3.1.14 / 3.6.0 / 3.0.3 | [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) | Aviso de disponibilidad solo de desarrollo. No aplicar a ciegas el downgrade de `nodemon` propuesto por la auditoría. |

Resultados en bruto: auditoría del backend, del worker y de la raíz (locales, no versionados).

## Brechas importantes de verificación

- **No se puede asumir que las reglas de Firestore estén desplegadas:** la [línea 163](./02-desarrollo/firestore.rules:163) usa `items.all(orderItem, ...)`. Las listas de Firebase Rules no soportan esa operación de iteración/lambda; ver la [API oficial de List](https://firebase.google.com/docs/reference/rules/rules.List). Se requiere validar su compilación en el emulador y compararlas con las reglas desplegadas. Un despliegue fallido no deja Firestore público automáticamente; puede dejar activas reglas anteriores.
- **Historial:** se encontró un literal histórico `MP_ACCESS_TOKEN` en el frontend en el commit `c9c4ac1`, etiquetado como credencial TEST. No se estableció exposición de un token de producción. No se probó su validez ni su revocación; verificar que esté retirado. No se reproducen aquí valores de credenciales.
- **Sinks del navegador:** algunos mensajes toast y un popup del geocoder interpolan strings sin procesar dentro de HTML. No se estableció una ruta de explotación entre usuarios con alta confianza. Usar nodos de texto/escapado en vez de confiar en quien llama.
- **Servicio externo de IA:** las fotos capilares se envían a un endpoint ngrok configurado. Su implementación de servidor, autorización, retención y propiedad del despliegue están fuera de este repositorio.
- **Disponibilidad y costos:** no se ejecutaron pruebas de carga. El checklist registra límites estáticos y comportamiento en ejecución no verificado, sin presentar problemas solo de disponibilidad como hallazgos explotables confirmados.

## Los 70 puntos del checklist

| # | Punto | Estado | Justificación |
|---|---|---|---|
| 1 | SQL / NoSQL injection | **OK** | No se construye SQL; las consultas de Firestore usan operadores fijos y valores separados, sin inyección de operadores establecida. |
| 2 | XSS reflejado | **OK** | No se confirmó ningún valor de URL/petición remota que llegue a un sink ejecutable reflejado en el navegador. |
| 3 | XSS almacenado | **Requiere prueba en vivo** | El renderizado principal de pedidos/admin escapa los datos del cliente; quedan sinks sin escapar, pero no se estableció un ataque almacenado entre usuarios. |
| 4 | DOM XSS | **Requiere prueba en vivo** | El HTML sin escapar de los toasts y la interpolación del popup del geocoder requieren pruebas focalizadas en navegador y de origen de datos; la CSP permite ejecución inline. |
| 5 | CSRF | **OK** | Las acciones sensibles de la API usan bearer tokens enviados explícitamente, no cookies ambientales; los callbacks de proveedores verifican los resultados con el proveedor. |
| 6 | Broken access control | **Vulnerable** | F1 permite conservar autoridad de administrador tras la revocación; F2 permite cambios de estado restringidos provocados por el cliente. |
| 7 | IDOR / BOLA | **Vulnerable** | F4 puede resolver otro pedido de Webpay mediante un alias por referencia truncada, bajo las condiciones indicadas. |
| 8 | Privilege escalation | **Vulnerable** | F1 permite que una cuenta degradada siga ejerciendo privilegios de administrador con un token antiguo. |
| 9 | Authentication bypass | **Requiere prueba en vivo** | Los tokens firmados de Firebase se verifican, pero la exigencia de activación por email se aplica en el navegador y se desconoce la configuración real del tenant. |
| 10 | Session hijacking | **Requiere prueba en vivo** | No se estableció una forma de robar tokens; no se probaron la persistencia del navegador, las protecciones del dispositivo ni la configuración efectiva de Auth. |
| 11 | Session fixation | **OK** | La autoridad del servidor proviene de tokens emitidos por Firebase, no de metadatos de sesión locales editables ni de IDs de sesión elegidos por quien llama. |
| 12 | Manipulación de tokens / JWT | **Vulnerable** | No se estableció falsificación de firmas, pero los claims privilegiados obsoletos siguen siendo válidos tras la degradación (F1). |
| 13 | Invalidación al cerrar sesión | **Requiere prueba en vivo** | El logout llama a `signOut` de Firebase; no implementa revocación en el servidor de tokens retenidos por separado. |
| 14 | Fuerza bruta en login | **Requiere prueba en vivo** | El login va directo a Firebase Auth; los límites de Express del backend no protegen ese endpoint. |
| 15 | Credential stuffing | **Requiere prueba en vivo** | Las protecciones anti-abuso, MFA y configuración de riesgo de cuentas de Firebase no se pueden determinar desde el código. |
| 16 | Abuso de recuperación de contraseña | **Requiere prueba en vivo** | Los códigos de reset los genera Firebase y las solicitudes están limitadas; no se probó el abuso por destinatario ni el comportamiento de entrega. |
| 17 | Enumeración de usuarios | **Requiere prueba en vivo** | El reset devuelve una respuesta de éxito común, pero los tiempos de respuesta y la configuración de enumeración de Firebase en signup/login no se verificaron. |
| 18 | Rate limiting | **Requiere prueba en vivo** | Existen límites para API/pagos/webhooks/cuentas/seguimiento; no se probó el comportamiento de IP detrás de proxy ni la aplicación distribuida entre instancias. |
| 19 | DoS general / carga | **Requiere prueba en vivo** | Existen límites de tamaño de body y timeouts; no se ejecutaron pruebas de disponibilidad ni de carga. |
| 20 | Consultas sin límite | **Requiere prueba en vivo** | La sincronización de pagos pendientes lee todos los pedidos pendientes del usuario; no se midieron cardinalidades de producción. |
| 21 | Funciones costosas | **Requiere prueba en vivo** | La codificación de media tiene timeouts y límites de tamaño; no se verificaron la concurrencia, IAM ni los presupuestos de recursos desplegados. |
| 22 | Amplificación de costos en Firestore | **Requiere prueba en vivo** | Las lecturas públicas del catálogo, escrituras de analytics y eventos de seguridad persistidos requieren verificar App Check, cuotas y controles de facturación. |
| 23 | Autorización por endpoint | **Vulnerable** | La mayoría de los endpoints sensibles verifican propiedad o rol de staff; F1 y F4 dejan brechas puntuales de autorización/vinculación. |
| 24 | Mass assignment | **Requiere prueba en vivo** | El backend construye explícitamente los campos del pedido y las reglas protegen los roles, pero las reglas de pedidos directos primero deben compilar y coincidir con el despliegue. |
| 25 | Parameter tampering | **Vulnerable** | Los precios generalmente vienen de Firestore, pero F3 evita los límites de descuento y F4 puede evitar la vinculación pedido/pago. |
| 26 | HTTP method tampering | **OK** | Las rutas están registradas explícitamente; Webpay acepta intencionalmente callbacks GET/POST, sin bypass de autorización por método. |
| 27 | CORS | **OK** | El backend compara orígenes completos contra una allowlist; permitir llamadas sin origen (no navegador) no es por sí mismo un bypass de autenticación. |
| 28 | Cabeceras de seguridad | **Requiere prueba en vivo** | Hosting declara CSP/HSTS/nosniff y el backend usa Helmet; hay que inspeccionar las cabeceras efectivas desplegadas y las excepciones amplias de la CSP. |
| 29 | Clickjacking | **OK** | Hosting declara CSP `frame-ancestors 'self'`; Helmet en el backend agrega protección de framing, sujeto a verificación en el despliegue. |
| 30 | Open redirect | **OK** | Los destinos de login están enumerados y los hosts de retorno de pago provienen de la configuración del servidor, no de parámetros de redirección. |
| 31 | Path traversal | **OK** | Las rutas de origen de media y los nombres de archivo de salida están restringidos; no se estableció traversal controlado por un atacante. |
| 32 | Autorización de subidas | **Vulnerable** | Las rutas de Storage exigen staff/propiedad, pero los claims de administrador obsoletos mantienen la autoridad de subida (F1). |
| 33 | MIME / tamaño de subidas | **Requiere prueba en vivo** | Las reglas restringen MIME declarado, extensiones y tamaños; eso no prueba que los bytes subidos coincidan con el tipo declarado. |
| 34 | Imágenes / media maliciosas | **Requiere prueba en vivo** | No se estableció validación de bytes de imagen ni el nivel de parches de FFmpeg/librerías desplegadas; no se intentó explotar parsers. |
| 35 | SSRF | **OK** | Los hosts de fetch del servidor provienen de URLs de servicio fijas/configuradas, no de una entrada HTTP controlada por un atacante. |
| 36 | Command injection | **OK** | El procesamiento de media usa `spawn` con arrays de argumentos y sin shell; la configuración exclusiva de scripts no es entrada remota. |
| 37 | Prototype pollution | **OK** | No se estableció una ruta de prototype pollution desde un atacante hacia producción; el aviso de SheetJS para la herramienta local se registra aparte. |
| 38 | Vulnerabilidades de dependencias | **Vulnerable** | Las auditorías marcan versiones afectadas: 15 avisos en backend y 9 en worker; no implica explotabilidad en producción de cada uno. |
| 39 | Exposición de secretos | **Requiere prueba en vivo** | No se estableció exposición de secretos de producción; falta verificar la validez/revocación del token TEST histórico del frontend. |
| 40 | Exposición de `.env` en hosting / Git | **OK** | No hay archivos de entorno reales versionados; hosting excluye archivos ocultos y los directorios backend/worker. |
| 41 | Source maps / exposición de debug | **OK** | No hay source maps versionados; la ruta de debug de webhooks del backend está deshabilitada en production/staging y el código del servidor está excluido del hosting. |
| 42 | Fuga de información en errores | **OK** | Las respuestas de production/staging generalmente ocultan detalles internos; no se confirmó divulgación remota de secretos ni stack traces. |
| 43 | HTTPS | **Requiere prueba en vivo** | Los servicios públicos configurados usan HTTPS; no se verificaron el TLS real, las redirecciones ni el uso obligatorio de TLS en SMTP. |
| 44 | Seguridad de cookies | **Requiere prueba en vivo** | No hay una implementación propia de cookies de sesión; los atributos de cookies de Firebase/OAuth requieren inspección en el navegador. |
| 45 | Firestore rules | **Requiere prueba en vivo** | La iteración de listas no soportada impide confiar en las reglas versionadas; compilarlas y compararlas con las reglas activas antes de aprobar. |
| 46 | Storage rules | **Vulnerable** | Las restricciones de escritura por rol pueden evitarse con claims de administrador retenidos tras la revocación (F1). |
| 47 | Flujos de Firebase Auth | **Requiere prueba en vivo** | La verificación de cuentas nuevas y la exigencia de contraseña robusta se aplican en el frontend; la política del tenant es desconocida. |
| 48 | Exposición del panel admin | **OK** | Las páginas estáticas de admin son públicas, pero los datos/acciones privilegiadas tienen autorización por reglas/API; ocultar la página no es la barrera de seguridad. |
| 49 | Manipulación del rol admin | **Vulnerable** | Las reglas previstas impiden la autopromoción desde el cliente, pero los custom claims obsoletos mantienen la autoridad tras quitar el rol (F1). |
| 50 | Autenticación de webhooks | **OK** | Producción exige firmas HMAC de Mercado Pago con comparación timing-safe; no se verificó el secreto/configuración desplegados. |
| 51 | Replay de webhooks | **Vulnerable** | Se verifica la frescura, pero el reprocesamiento de pagos puede sobrescribir el estado de despacho; F2 también expone replay de conciliación por el cliente. |
| 52 | Manipulación del estado de pago | **Vulnerable** | F2 permite regresar a `paid`; F4 puede marcar como pagado un pedido de Webpay resuelto incorrectamente. |
| 53 | Manipulación de precio | **Vulnerable** | El checkout normal recalcula los precios del catálogo; F4 permite, de forma condicional, pagar de menos/sustituir pedidos. |
| 54 | Manipulación de cantidad | **Requiere prueba en vivo** | `parseInt` en el backend acepta cantidades fraccionarias o con prefijo de string, y la agregación puede superar los límites por línea; no se estableció obtención de productos gratis. |
| 55 | Manipulación de descuentos | **Vulnerable** | F3 permite pedidos con descuento por encima de los límites de uso configurados. |
| 56 | Reutilización de cupones | **Vulnerable** | Se reprodujo la evasión concurrente de límites globales y por usuario (F3). |
| 57 | Race condition de stock | **Requiere prueba en vivo** | La liquidación usa transacciones y un marcador de inventario, pero no hay reservas ni se hicieron pruebas reales concurrentes/multiproducto. |
| 58 | Idempotencia de pagos / webhooks duplicados | **Vulnerable** | El descuento de inventario está protegido, pero el estado de despacho no es idempotente (F2); el check/send/mark de WhatsApp tampoco es atómico. |
| 59 | Propiedad de pedidos | **Vulnerable** | Las rutas de cliente de Mercado Pago verifican propiedad; el callback de Webpay carece de vinculación equivalente de intención/dueño (F4). |
| 60 | Checkout bypass | **Vulnerable** | F4 puede convertir una transacción barata de Webpay en la confirmación de pago de un pedido alias, si se cumplen las condiciones. |
| 61 | Autorización de reembolsos | **Vulnerable** | Los reembolsos exigen middleware de admin, pero administradores removidos pueden cumplirlo con claims retenidos (F1). |
| 62 | Verificación con la API del proveedor | **Vulnerable** | Se consultan las APIs de los proveedores, pero la vinculación de pedidos de Webpay y la validación de monto en la rama de recuperación están incompletas (F4). |
| 63 | Abuso de email | **Requiere prueba en vivo** | El correo de cuentas está limitado y el de pedidos usa claims transaccionales; falta verificar abuso por destinatario, tiempos y el despliegue SMTP. |
| 64 | Abuso de la API de WhatsApp | **Requiere prueba en vivo** | Los endpoints manuales exigen admin y los destinatarios están configurados en el servidor; la deduplicación de notificaciones por webhook tiene una ventana de concurrencia. |
| 65 | Exposición de PII | **Requiere prueba en vivo** | Existen lecturas por dueño/staff y seguimiento público enmascarado; no se verificaron las reglas activas, el acceso al seguimiento ni el servicio externo de fotos. |
| 66 | Logs sensibles | **OK** | No se confirmó registro en producción de contraseñas, claves privadas ni bearer tokens; sí se registran metadatos de clientes/pagos. |
| 67 | Seguridad de respaldos | **Requiere prueba en vivo** | Los respaldos en la nube, exportaciones, retención, cifrado e IAM no están representados suficientemente en este repositorio. |
| 68 | Supply chain | **Requiere prueba en vivo** | Existen lockfiles; los builds del worker usan `npm install`, los SDK del navegador se cargan externamente y no se verificó la procedencia del despliegue. |
| 69 | SAST | **OK** | Se completó la revisión de sintaxis/patrones en todo el repositorio y pruebas offline focalizadas; el escáner de secretos existente no es un motor SAST semántico completo. |
| 70 | DAST | **Requiere prueba en vivo** | Se identificaron URLs candidatas de despliegue, pero no se hicieron peticiones a la aplicación en vivo ni pruebas de carga. |

### URLs candidatas de despliegue

Identificadas desde el código fuente; no se verificó que estén vigentes ni que respondan:

- Tienda: `https://monsite-85424.web.app`
- Dominio de Firebase Auth/hosting: `https://monsite-85424.firebaseapp.com`
- Backend: `https://monsite-backend-staging-cwv4lkpasa-tl.a.run.app`
- Media worker privado: `https://monsite-media-staging-736268363141.southamerica-west1.run.app`
- API de análisis capilar: `https://curvy-stuck-output.ngrok-free.dev`

**Prioridad:** corregir F1, preservar el estado de pago/despacho para F2, hacer transaccionales las reservas de cupones para F3 y mantener Webpay deshabilitado hasta corregir F4. Compilar y verificar las reglas de Firebase desplegadas antes de considerar cualquier evaluación de autorización basada solo en el código como una aprobación para producción.
