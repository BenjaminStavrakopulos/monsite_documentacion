# Monsite

Documentación principal del proyecto tras separación de carpetas.

## Estructura del repositorio
- `01-documentacion/`: documentación técnica y funcional.
- `02-desarrollo/`: aplicación completa (frontend, backend, Firebase y scripts).

## Stack
- Frontend: HTML, CSS, JavaScript (vanilla)
- Backend: Node.js + Express
- Base de datos/autenticación: Firebase
- Pagos: Mercado Pago

## Documentación técnica
- `01-documentacion/docs/PROJECT_STRUCTURE.md`
- `01-documentacion/docs/DEVELOPMENT_WORKFLOW.md`

## Requisitos
- Node.js 18+
- npm

## Inicio rápido (local)
1. Ir al código:
   - `cd 02-desarrollo`
2. Instalar backend:
   - `npm --prefix backend install`
3. Configurar variables:
   - Crear `backend/.env` desde `backend/.env.example`
4. Configurar Firebase/pagos local (no versionado):
   - `js/config/firebase-config.local.js` o `js/config/firebase-config.local.json`
   - `js/config/payment-config.local.json`
5. Iniciar entorno:
   - `npm run start:clean`

## URLs locales
- Frontend: `http://localhost:5500/index.html`
- Backend health: `http://localhost:3000/health`

## Deploy a Firebase Hosting
1. Ir a `02-desarrollo/`
2. Ejecutar:
   - `npm run stamp && npm run validate` (versiona los `.js`/`.css` por contenido)
   - `firebase deploy --only hosting --project monsite-85424`
   - Reglas: `firebase deploy --only firestore:rules --project monsite-85424`
3. El backend corre en Cloud Run: sus cambios no se publican con `firebase deploy`.

## Seguridad
- Nunca subir secretos reales (`.env`, `service-account*.json`, configs locales).
- Ejecutar escaneo antes de PR:
  - `cd 02-desarrollo`
  - `npm run security:scan`
