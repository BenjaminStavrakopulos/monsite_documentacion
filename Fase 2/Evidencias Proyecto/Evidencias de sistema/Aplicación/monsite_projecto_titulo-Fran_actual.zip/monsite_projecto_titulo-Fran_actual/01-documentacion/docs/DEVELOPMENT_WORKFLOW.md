# Flujo de Desarrollo

## Principios

- Cambios pequeños y reversibles.
- Primero desacoplar, después mover carpetas.
- Validar backend y pagos en cada cambio estructural.
- Mantener la compatibilidad del frontend estático mientras se limpia el código.

## Orden recomendado de trabajo

1. Centralizar configuración y lógica repetida.
2. Extraer utilidades y middlewares comunes.
3. Documentar contratos entre frontend y backend.
4. Reducir el uso de globals en cliente.
5. Mantener la estructura por capas y extraer lógica grande a módulos más pequeños.

## Convenciones backend

- `config/`: lectura y composición de variables de entorno.
- `middleware/`: control de acceso, validaciones HTTP, rate control especializado.
- `routes/`: solo parsing HTTP y delegación.
- `services/`: lógica de negocio e integraciones.
- `utils/`: helpers puros y reutilizables.

## Convenciones frontend para la siguiente fase

- Un archivo por responsabilidad principal.
- Evitar mezclar UI, acceso a datos y estado en un mismo script.
- Mantener cada HTML con un entrypoint claro.
- Toda integración externa debe pasar por un wrapper único.

## Checklist para futuros cambios

- ¿El cambio reduce acoplamiento?
- ¿Evita duplicación?
- ¿Mantiene URLs y flujos actuales?
- ¿Tiene un punto claro de validación manual?

## Validaciones locales

Desde `02-desarrollo/`, ejecutar antes de entregar cambios:

```powershell
npm run validate
npm run smoke
```

`npm run validate` revisa que no existan scripts inline, que las referencias locales de HTML apunten a archivos existentes, que todos los JavaScript tengan sintaxis válida y que cada `<script>`/`<link>` local lleve el `?v=` de su contenido. `npm run smoke` comprueba los endpoints básicos del backend local.

## Versionado de assets (caché)

Firebase Hosting sirve los `.js` y `.css` con `Cache-Control: public, max-age=31536000, immutable` (1 año). Si un archivo cambia pero su URL no, los navegadores que ya lo tienen nunca ven el cambio. Por eso cada referencia local lleva `?v=<hash del contenido>`.

- Después de editar cualquier `.js` o `.css`, ejecutar desde `02-desarrollo/`: `npm run stamp` (actualiza los `?v=` de todos los HTML).
- `npm run validate` (o `npm run stamp:check`) falla si falta un `?v=` o quedó desactualizado.
- No escribir los `?v=` a mano.