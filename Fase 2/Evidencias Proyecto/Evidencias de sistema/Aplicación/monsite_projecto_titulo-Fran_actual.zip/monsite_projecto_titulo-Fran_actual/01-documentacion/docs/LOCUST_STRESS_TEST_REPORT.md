# Informe de pruebas de carga - Locust

Fecha de preparacion: 2026-08-31

## Objetivo y alcance

La prueba usa Locust 2.43.4 para medir la disponibilidad y latencia del backend de Monsite sin crear pagos, ordenes, notificaciones ni modificar datos.

El escenario solicita `GET /health`, que devuelve el estado del proceso. Esta ruta no requiere autenticacion, Firebase, Mercado Pago ni cuerpo de solicitud. El backend la publica por defecto en `http://127.0.0.1:3000`.

## Archivos de prueba

- `02-desarrollo/load-tests/requirements.txt`: fija la version `locust==2.43.4`.
- `02-desarrollo/load-tests/locustfile.py`: define usuarios virtuales y verifica que `/health` responda HTTP 200.
- `02-desarrollo/.coveragerc`: configura Coverage.py para medir el escenario Python de Locust.

## Ejecucion local

En una terminal, iniciar el backend desde `02-desarrollo`:

```powershell
npm --prefix backend install
$env:PORT = "3100"
npm run start:backend
```

En otra terminal, instalar Locust y ejecutar una prueba inicial de 20 usuarios durante un minuto:

```powershell
py -m pip install -r load-tests/requirements.txt
py -m locust -f load-tests/locustfile.py --headless -u 20 -r 2 -t 1m --html load-tests/report.html
```

Para usar otro ambiente, establecer `LOCUST_HOST` antes de ejecutar Locust. Por ejemplo, `$env:LOCUST_HOST = "http://127.0.0.1:3100"`. No ejecutar contra produccion sin autorizacion y una ventana de mantenimiento.

## Cobertura del escenario

Coverage.py 7.10.7 mide solamente `load-tests/locustfile.py`. El backend de Monsite es JavaScript, por lo que esta herramienta no mide sus rutas, servicios ni middleware. En Python 3.14, la configuracion fuerza el trazador C (`ctrace`) porque SysMonitor no admite `concurrency = greenlet`, que Locust utiliza para sus usuarios virtuales.

Con el backend activo, ejecutar Locust bajo Coverage.py y generar los reportes:

```powershell
$env:LOCUST_HOST = "http://127.0.0.1:3100"
py -m coverage erase
py -m coverage run --concurrency=thread -m unittest discover -s load-tests -p test_*.py
npm run coverage:report
py -m coverage html
py -m coverage xml
```

Los artefactos se generan en `02-desarrollo/load-tests/coverage-html/` y `02-desarrollo/load-tests/coverage.xml`; estan excluidos de Git.

## Criterios de aceptacion iniciales

| Medida | Criterio |
| --- | --- |
| Solicitudes fallidas | 0 % |
| Respuesta HTTP | 200 en `GET /health` |
| Percentil p95 | Menor o igual a 500 ms en entorno local |

## Evidencia y hallazgos

| Comprobacion | Resultado | Evidencia |
| --- | --- | --- |
| Instalacion de Locust | Correcta | `py -m locust --version`: Locust 2.43.4 con Python 3.14.1 |
| Instalacion de Coverage.py | Correcta | `py -m coverage --version`: Coverage.py 7.10.7 con extension C |
| Pruebas unitarias del escenario | Correcta | 2 pruebas: simulan HTTP 200 y HTTP 503 sin trafico real |
| Cobertura del escenario Python | Bloqueada por entorno | Coverage.py se interrumpe al combinarlo con el cierre de `gevent` en Python 3.14 |
| Ejecucion cubierta de Locust | Correcta | Ejecucion anterior: 3 usuarios, subida de 1 usuario/s, 5 s, 6 solicitudes, 0 fallos, objetivo `http://127.0.0.1:3100` |
| Reportes de cobertura | No vigentes | Deben regenerarse al resolver la incompatibilidad de Coverage.py, `gevent` y Python 3.14 |
| Escenario Locust | Correcta | 20 usuarios, subida de 2 usuarios/s, 60 s, objetivo `http://127.0.0.1:3100` |
| Solicitudes `GET /health` | Correcta | 546 solicitudes, 0 fallos (0 %) y 9.23 solicitudes/s |
| Latencia `GET /health` | Correcta | Minimo 1 ms, mediana 2 ms, promedio 2 ms, p95 4 ms, p99 5 ms y maximo 24 ms |
| Auditoria de dependencias del backend | Requiere revision | `npm --prefix backend install`: 9 vulnerabilidades moderadas reportadas por npm |
| Validacion de proyecto | Correcta | `npm run validate` (2026-08-31): 37 HTML y 52 JS revisados sin errores |
| Revision de secretos versionados | Correcta | `npm run security:scan` (2026-08-31): no se detectaron secretos criticos trackeados |

## Hallazgos

La prueba cumplio los criterios iniciales: no hubo fallos, todas las respuestas fueron HTTP 200 y el p95 estuvo por debajo de 500 ms. El informe HTML de Locust se genero en `02-desarrollo/load-tests/report.html`; se excluye de Git porque es un artefacto de ejecucion.

En un intento preliminar, el puerto 3000 respondio 404 desde VS Code Live Preview y no desde Express. Esa ejecucion produjo 564 fallos y fue descartada porque no alcanzaba al backend. El backend se levanto en el puerto 3100 y se verifico con una solicitud directa antes de ejecutar la medicion registrada arriba.

La prueba cubre solamente disponibilidad del backend mediante `/health`; no mide Firebase, Mercado Pago, autenticacion, consultas Firestore, checkout ni operaciones que muten datos. Esos flujos requieren escenarios separados y datos de prueba aislados.

La instalacion de dependencias tambien reporto nueve vulnerabilidades moderadas. Se agrego `npm run audit:prod` para detectarlas de manera reproducible. No se ejecutaron correcciones automaticas: npm propone actualizar `firebase-admin` a 14.3.0 y `mercadopago` a 3.6.0, ambos cambios mayores que deben probarse con Firebase y pagos antes de adoptarlos.

La primera ejecucion de Coverage.py midio 83 % del escenario `locustfile.py`. Tras agregar las pruebas de HTTP 200 y HTTP 503, la cobertura debe regenerarse. Los intentos en este entorno se interrumpen durante el cierre de `gevent` con Python 3.14, por lo que no hay un porcentaje vigente verificable. La tarea HTTP queda cubierta funcionalmente por la carga real de Locust, y la rama de fallo queda validada por las pruebas unitarias sin dirigir trafico a un endpoint inexistente.