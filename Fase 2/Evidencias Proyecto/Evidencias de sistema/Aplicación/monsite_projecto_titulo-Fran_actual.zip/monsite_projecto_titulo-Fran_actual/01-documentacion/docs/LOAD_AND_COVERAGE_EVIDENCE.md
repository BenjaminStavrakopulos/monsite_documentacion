# Evidencias detalladas de Locust y Coverage.py

Fecha de ejecucion: 2026-08-31

## Resumen ejecutivo

La prueba de carga valida del endpoint `GET /health` cumplio los criterios definidos: 546 solicitudes, 0 fallos y p95 de 4 ms. La cobertura con Coverage.py 7.10.7 se preparo para el escenario Python de Locust; la medicion inicial fue 83 %, pero no representa el codigo actual despues de agregar pruebas para HTTP 200 y HTTP 503. La regeneracion fue bloqueada por interrupciones durante el cierre de `gevent` con Python 3.14.

## Entorno verificado

| Componente | Evidencia |
| --- | --- |
| Sistema operativo | Windows 11 |
| Python | 3.14.1 |
| Locust | 2.43.4 (`py -m locust --version`) |
| Coverage.py | 7.10.7 con extension C (`py -m coverage --version`) |
| Backend | Node.js/Express, iniciado en desarrollo |
| Objetivo valido | `http://127.0.0.1:3100/health` |

## Evidencia de Locust

### Escenario probado

Archivo: `02-desarrollo/load-tests/locustfile.py`.

El usuario virtual solicita `GET /health` y marca la solicitud como fallida si el estado HTTP no es 200. El endpoint no crea pagos, ordenes, notificaciones ni modifica datos.

### Comando ejecutado

```powershell
$env:LOCUST_HOST = "http://127.0.0.1:3100"
py -m locust -f load-tests/locustfile.py --headless -u 20 -r 2 -t 1m --html load-tests/report.html
```

Parametros:

| Parametro | Valor |
| --- | --- |
| Usuarios maximos | 20 |
| Tasa de subida | 2 usuarios por segundo |
| Duracion | 60 segundos |
| Espera por usuario | Aleatoria entre 1 y 3 segundos |
| Endpoint | `GET /health` |

### Resultado valido

| Medida | Resultado | Criterio | Estado |
| --- | --- | --- | --- |
| Solicitudes | 546 | Sin minimo definido | Informativo |
| Fallos | 0 (0 %) | 0 % | Cumplido |
| Tasa media | 9.23 solicitudes/s | Sin minimo definido | Informativo |
| Latencia minima | 1 ms | Sin maximo definido | Informativo |
| Latencia mediana | 2 ms | Sin maximo definido | Informativo |
| Latencia media | 2 ms | Sin maximo definido | Informativo |
| Latencia p95 | 4 ms | Menor o igual a 500 ms | Cumplido |
| Latencia p99 | 5 ms | Sin maximo definido | Informativo |
| Latencia maxima | 24 ms | Sin maximo definido | Informativo |

### Intento descartado

Una primera ejecución usó el puerto 3000. El objetivo era VS Code Live Preview y no Express, por lo que devolvio 404 para las 564 solicitudes. Esa ejecucion no se usa para evaluar rendimiento del backend. El conflicto se corrigio ejecutando Express en el puerto 3100 y verificando primero que `GET /health` devolviera 200.

### Alcance no cubierto por Locust

La evidencia no permite concluir rendimiento de autenticacion, Firebase/Firestore, Mercado Pago, checkout, webhooks, envio de correo o WhatsApp. Esos flujos requieren datos de prueba aislados, credenciales no productivas y escenarios independientes.

## Evidencia de Coverage.py

### Configuracion

Archivo: `02-desarrollo/.coveragerc`.

La configuracion limita la medicion a `load-tests` y excluye los archivos `test_*.py`. Fuerza `ctrace` y `greenlet` para el uso de Locust. El backend es JavaScript, por lo que Coverage.py no mide `backend/`, `js/` ni archivos HTML.

### Pruebas disponibles

Archivo: `02-desarrollo/load-tests/test_locustfile.py`.

| Caso | Evidencia | Estado |
| --- | --- | --- |
| Respuesta HTTP 200 | No registra fallo en el escenario | Correcto |
| Respuesta HTTP 503 | Registra `Expected 200, received 503` | Correcto |

Comando ejecutado:

```powershell
npm run load:test:unit
```

Resultado: 2 pruebas ejecutadas, resultado `OK`. Python 3.14 emitio avisos al finalizar `gevent`, pero despues del resultado correcto; no cambio el codigo de salida de la prueba.

### Medicion anterior

La primera medicion, antes de introducir las pruebas de ambas respuestas, informo:

| Medida | Valor |
| --- | --- |
| Sentencias | 10 |
| Sentencias sin cubrir | 1 |
| Ramas | 2 |
| Ramas parciales | 1 |
| Cobertura | 83 % |
| Linea no cubierta | Rama de fallo para respuesta distinta de 200 |

Este porcentaje es historico y no debe usarse como cobertura actual. El codigo del escenario cambio despues para que la rama HTTP 503 quede validada mediante test aislado.

### Limitacion actual

Al ejecutar Coverage.py 7.10.7 con el entorno actual, los intentos de regenerar los datos se interrumpieron durante el cierre de `gevent` en Python 3.14. Por tanto, no hay un porcentaje actualizado verificable ni reportes HTML/XML vigentes para el codigo actual.

La solucion recomendada es ejecutar la misma secuencia con Python 3.12 o 3.13, donde se debe volver a obtener la cobertura y archivar los reportes generados:

```powershell
py -m coverage erase
py -m coverage run --concurrency=thread -m unittest discover -s load-tests -p test_*.py
py -m coverage report
py -m coverage html
py -m coverage xml
```

## Evidencia complementaria

| Control | Resultado |
| --- | --- |
| Validacion HTML y JavaScript | Correcta: 37 HTML y 52 JS revisados |
| Escaneo de secretos versionados | Correcto: sin secretos criticos detectados |
| Auditoria de dependencias de produccion | 9 vulnerabilidades moderadas pendientes |

Las vulnerabilidades corresponden principalmente a la cadena de dependencias de `firebase-admin` y `mercadopago`. La correccion requiere actualizaciones mayores y debe evaluarse por separado con pruebas de Firebase y pagos.

## Conclusiones

El endpoint de salud soportó el perfil probado sin errores y con latencia local baja. La prueba de carga es valida solo para disponibilidad de `GET /health`. Las respuestas esperadas y de error del escenario se prueban de manera aislada. La cobertura porcentual actual queda pendiente de regenerar en Python 3.12 o 3.13 por la incompatibilidad observada en Python 3.14 con `gevent`.