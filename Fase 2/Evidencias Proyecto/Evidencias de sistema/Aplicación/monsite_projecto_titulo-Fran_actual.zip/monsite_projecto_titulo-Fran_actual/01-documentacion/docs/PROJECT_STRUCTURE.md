# Estructura del Proyecto Monsite

## Objetivo

Mantener una base simple, estable y fácil de evolucionar sin romper el frontend estático actual.

## Estructura actual ordenada

```text
monsite/
├─ admin/                 # Vistas HTML del panel administrativo
├─ backend/               # API Express e integraciones externas
│  ├─ config/             # Configuración centralizada del backend
│  ├─ lib/                # Adaptadores de SDK externos
│  ├─ middleware/         # Middlewares reutilizables
│  ├─ routes/             # Endpoints HTTP
│  ├─ scripts/            # Scripts operativos y utilitarios
│  ├─ services/           # Servicios de dominio/integraciones
│  └─ utils/              # Utilidades compartidas
├─ css/                   # Estilos del frontend público y admin
├─ data/                  # Datos estáticos o seed local
├─ docs/                  # Documentación técnica y operativa
├─ images/                # Assets visuales
├─ js/
│  ├─ admin/              # Scripts exclusivos del panel admin
│  ├─ config/             # Configuración cliente y archivos locales
│  ├─ core/               # Bootstrap y estado global
│  ├─ pages/              # Lógica por página pública
│  ├─ services/           # Firebase, pagos, auth y notificaciones
│  └─ ui/                 # Menú, tema y utilidades de interfaz
├─ tools/                 # Páginas auxiliares y de prueba fuera del flujo público
├─ scripts/               # Scripts raíz del proyecto
└─ *.html                 # Páginas públicas estáticas
```

## Criterio de organización

- `admin/` solo contiene vistas.
- `backend/` concentra toda la lógica sensible, pagos, validaciones y acceso administrativo.
- `js/` ahora está dividido por capas y no debe volver al esquema plano.
- `js/core/` contiene helpers transversales como sesión y storage compartido.
- `js/config/` concentra runtime config para Firebase y pagos.
- La raíz debe contener solo rutas públicas reales, callbacks e URLs de retorno externas.
- `tools/` es el lugar para HTML de prueba, diagnóstico o soporte manual.
- `docs/` debe explicar arquitectura, flujos y decisiones antes de hacer cambios grandes.

## Estructura del frontend

La carpeta `js/` ya quedó organizada por responsabilidad. El siguiente objetivo no es mover más archivos, sino reducir acoplamiento interno y dependencias globales.

## Regla práctica

Aunque la estructura ya está ordenada, todavía existen dependencias globales (`window.*`). La próxima limpieza debe enfocarse en reducir ese acoplamiento antes de fragmentar lógica más grande.

## Helpers compartidos activos

- `js/core/session.js`: lectura y persistencia unificada de sesión cliente.
- `js/core/storage.js`: utilidades compartidas para JSON en localStorage.
- `js/config/payment-runtime.js`: backend URL, config de pagos y headers autenticados.